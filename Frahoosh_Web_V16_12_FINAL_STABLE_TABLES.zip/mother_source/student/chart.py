from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QFrame,
    QGridLayout
)
from PySide6.QtCore import Qt


class ChartPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setLayoutDirection(Qt.RightToLeft)

        self.init_ui()


    def init_ui(self):

        layout = QVBoxLayout(self)


        title = QLabel("تحلیل عملکرد و نمودار پیشرفت")

        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title.setStyleSheet("""
            QLabel {
                font-size:22px;
                font-weight:bold;
                padding:15px;
            }
        """)

        layout.addWidget(title)


        grid = QGridLayout()


        items = [
            (
                "روند پیشرفت تحصیلی",
                "بررسی تغییرات نمرات"
            ),
            (
                "نقاط قوت",
                "شناسایی توانایی‌های دانش‌آموز"
            ),
            (
                "نیاز به بهبود",
                "پیشنهاد مسیر پیشرفت"
            ),
            (
                "تحلیل هوشمند",
                "گزارش فراهوش"
            )
        ]


        for i, item in enumerate(items):

            card = QFrame()

            card.setFrameShape(QFrame.StyledPanel)


            card_layout = QVBoxLayout(card)


            name = QLabel(item[0])
            name.setAlignment(Qt.AlignmentFlag.AlignCenter)


            desc = QLabel(item[1])
            desc.setAlignment(Qt.AlignmentFlag.AlignCenter)


            card_layout.addWidget(name)
            card_layout.addWidget(desc)


            grid.addWidget(
                card,
                i // 2,
                i % 2
            )


        layout.addLayout(grid)


        info = QLabel(
            "تحلیل عملکرد دانش‌آموز\n"
            "آماده اتصال به موتور تحلیل فراهوش"
        )

        info.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(info)