from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QStackedWidget,
    QFrame,
    QGridLayout,
    QTabBar,
    QSizePolicy
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


# =====================================================
# صفحات دانش‌آموز
# =====================================================

from student.profile import ProfilePage
from student.grades import GradesPage
from student.attendance import AttendancePage
from student.assignments import AssignmentsPage
from student.messages import MessagesPage
from student.online_classes import OnlineClassesPage
from student.chart import ChartPage
from student.competitions import CompetitionsPage


print("STUDENT PANEL LOADED")


# =====================================================
# صفحه ساده برای بخش‌هایی که هنوز صفحه اختصاصی ندارند
# =====================================================

class SimplePage(QWidget):
    def __init__(self,title,description="",parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.title=title; self.description=description; self.init_ui()
    def init_ui(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(30,30,30,30)
        title_label=QLabel(self.title); title_label.setAlignment(Qt.AlignmentFlag.AlignCenter); title_label.setFont(QFont("B Zar",25,QFont.Bold)); layout.addWidget(title_label)
        info=QLabel(self.description); info.setAlignment(Qt.AlignmentFlag.AlignCenter); info.setWordWrap(True); info.setFont(QFont("B Zar",15)); layout.addWidget(info)
        self.result=QLabel("آماده نمایش اطلاعات این بخش"); self.result.setAlignment(Qt.AlignmentFlag.AlignCenter); self.result.setWordWrap(True); layout.addWidget(self.result)
        refresh=QPushButton("تازه‌سازی اطلاعات"); refresh.clicked.connect(self.refresh); layout.addWidget(refresh); layout.addStretch()
    def refresh(self):
        self.result.setText(f"بخش «{self.title}» فعال است و آماده دریافت/نمایش داده‌های مرتبط دانش‌آموز می‌باشد.")


# =====================================================
# پنل دانش‌آموز
# =====================================================

class Panel(QWidget):

    def __init__(
        self,
        parent=None,
        student_id=None,
        username=None
    ):

        super().__init__(
            parent
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.pages = {}
        self.student_id = student_id
        self.username = username
        if not self.student_id and self.username:
            try:
                from services.data_link_service import student_for_username
                self.student_id = student_for_username(self.username)
            except Exception:
                self.student_id = None

        # container اصلی صفحات پنل دانش آموز
        # (برای جلوگیری از خطای Panel object has no attribute stack)
        self.stack = QStackedWidget()

        self.init_ui()

    # =================================================
    # رابط اصلی
    # =================================================

    def init_ui(self):

        main_layout = QVBoxLayout(
            self
        )

        main_layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        main_layout.setSpacing(
            10
        )

        # ---------------------------------------------
        # عنوان
        # ---------------------------------------------

        title = QLabel(
            "فراهوش | پنل دانش‌آموز"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                25,
                QFont.Bold
            )
        )

        main_layout.addWidget(
            title
        )

        # ---------------------------------------------
        # ظاهر هم‌سبک پنل اولیا: عنوان، توضیح، منوی تبّی و محتوای اصلی
        # ---------------------------------------------
        info = QLabel("با انتخاب هر بخش، اطلاعات آموزشی، حضور و غیاب، پیام‌ها و فعالیت‌های دانش‌آموز نمایش داده می‌شود.")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setWordWrap(True)
        info.setFont(QFont("B Zar", 13))
        main_layout.addWidget(info)

        self.tab_bar = QTabBar()
        self.tab_bar.setDocumentMode(True)
        self.tab_bar.setUsesScrollButtons(True)
        self.tab_bar.setExpanding(False)
        self.tab_bar.setDrawBase(False)
        buttons = [
            ("👤 پروفایل", "profile"), ("📊 نمرات", "grades"),
            ("🛡️ حضور و غیاب", "attendance"), ("📝 تکالیف", "assignments"),
            ("✉️ پیام‌ها", "messages"), ("💻 کلاس مجازی", "online_classes"),
            ("📈 تحلیل عملکرد", "charts"), ("🏆 مسابقات", "competitions"),
            ("🎓 خوارزمی", "khwarizmi"), ("🎨 مسابقات فرهنگی", "cultural")
        ]
        for text, key in buttons:
            self.tab_bar.addTab(text)
        self.tab_bar.currentChanged.connect(self._tab_changed)
        main_layout.addWidget(self.tab_bar)
        main_layout.addWidget(self.stack, 1)

        self.setStyleSheet("""
            QWidget { background:#FDF2F8; color:#111827; font-family:"B Zar"; }
            QLabel { color:#111827; font-weight:bold; }
            QTabBar { background:transparent; }
            QTabBar::tab { background:#F9A8D4; color:#111827; padding:9px 13px; margin:2px; border-radius:9px; font-family:"B Zar"; font-size:14px; font-weight:bold; }
            QTabBar::tab:selected { background:#DB2777; color:white; }
            QTabBar::tab:hover { background:#F472B6; color:#111827; }
            QStackedWidget { background:white; border:1px solid #F9A8D4; border-radius:15px; padding:8px; }
        """)

        self.stack.setCurrentIndex(0)
        # Build the actual page widgets once the navigation container exists.
        # This keeps the panel self-contained when opened from the main dashboard.
        if not self.pages:
            self.load_pages()

    # =================================================
    # بارگذاری صفحات
    # =================================================

    def load_pages(self):

        pages = {

            "profile":
                ProfilePage(student_id=self.student_id),

            "grades":
                GradesPage(student_id=self.student_id, username=self.username),

            "attendance":
                AttendancePage(student_id=self.student_id, username=self.username),

            "assignments":
                AssignmentsPage(student_id=self.student_id, username=self.username),

            "messages":
                MessagesPage(student_id=self.student_id, username=self.username),

            "online_classes":
                OnlineClassesPage(student_id=self.student_id),

            "charts":
                ChartPage(),

            "competitions":
                CompetitionsPage(student_id=self.student_id, parent=self, username=self.username),

            "khwarizmi":
                CompetitionsPage(student_id=self.student_id, parent=self, username=self.username),

            "cultural":
                CompetitionsPage(student_id=self.student_id, parent=self, username=self.username)
        }

        for key, page in pages.items():

            self.pages[key] = page

            self.stack.addWidget(
                page
            )

    # =================================================
    # باز کردن صفحه
    # =================================================

    def _tab_changed(self, index):
        if index >= 0 and index < self.stack.count():
            self.stack.setCurrentIndex(index)

    def open_page(
        self,
        key
    ):

        if key not in self.pages:

            print(
                "PAGE NOT FOUND:",
                key
            )

            return

        page = self.pages[key]

        index = self.stack.indexOf(
            page
        )

        if index >= 0:

            self.stack.setCurrentIndex(index)
            if hasattr(self, "tab_bar") and self.tab_bar.currentIndex() != index:
                self.tab_bar.setCurrentIndex(index)
            print("OPEN STUDENT PAGE:", key)