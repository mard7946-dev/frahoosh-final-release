from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton
from PySide6.QtCore import Qt
import sqlite3
from pathlib import Path
from utils.jalali import iso_to_jalali
DB=Path(__file__).resolve().parents[1]/'school.db'
class MessagesPage(QWidget):
 def __init__(self,parent=None,student_id=None,username=None):
  super().__init__(parent); self.username=username or ''; self.sid=student_id
  from services.core_data_service import student_id as resolve
  self.sid=self.sid or resolve(username)
  self.setLayoutDirection(Qt.RightToLeft); l=QVBoxLayout(self); l.addWidget(QLabel('پیام‌های مدرسه')); self.table=QTableWidget(0,4); self.table.setHorizontalHeaderLabels(['فرستنده','موضوع/متن','تاریخ','گیرنده']); l.addWidget(self.table); b=QPushButton('تازه‌سازی');b.clicked.connect(self.load);l.addWidget(b);self.load()
 def load(self):
  receivers={self.username,'all_students','students','all'}
  if self.sid:
   with sqlite3.connect(DB, timeout=30.0) as c:
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('PRAGMA journal_mode=WAL')
    r=c.execute('SELECT national_code,student_code FROM students WHERE id=?',(self.sid,)).fetchone()
   receivers.update(x for x in (r or []) if x)
   receivers.update({str(self.sid),f'student:{self.sid}',f'student_id:{self.sid}'})
  with sqlite3.connect(DB, timeout=30.0) as c:
   c.execute('PRAGMA busy_timeout=30000')
   c.execute('PRAGMA journal_mode=WAL')
   rows=c.execute('SELECT sender,text,created_at,receiver FROM messages ORDER BY id DESC').fetchall()
  rows=[r for r in rows if any(part.strip() in receivers for part in str(r[3] or '').split('/'))]
  self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(iso_to_jalali(v) if j==2 and v else str(v or '')))
