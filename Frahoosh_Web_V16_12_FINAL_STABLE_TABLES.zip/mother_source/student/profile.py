import sqlite3, os
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QFrame,QFormLayout,QLineEdit,QPushButton,QMessageBox
from PySide6.QtCore import Qt
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
class ProfilePage(QWidget):
    def __init__(self,parent=None,student_id=None):
        super().__init__(parent); self.student_id=student_id; self.setLayoutDirection(Qt.RightToLeft); self.fields={}; self.init_ui(); self.load_data()
    def init_ui(self):
        layout=QVBoxLayout(self); title=QLabel('پروفایل دانش‌آموز'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); layout.addWidget(title)
        card=QFrame(); form=QFormLayout(card)
        for key,label in [('first_name','نام'),('last_name','نام خانوادگی'),('student_code','کد دانش‌آموزی'),('grade','پایه'),('class_name','کلاس'),('father_name','نام پدر'),('parent_phone','شماره تماس ولی'),('phone','شماره تماس'),('address','آدرس'),('description','توضیحات')]:
            w=QLineEdit(); self.fields[key]=w; form.addRow(QLabel(label),w)
        layout.addWidget(card); row=QHBoxLayout(); save=QPushButton('ذخیره تغییرات'); save.clicked.connect(self.save); refresh=QPushButton('تازه‌سازی اطلاعات'); refresh.clicked.connect(self.load_data); row.addWidget(save); row.addWidget(refresh); layout.addLayout(row)
        self.status=QLabel(''); self.status.setAlignment(Qt.AlignmentFlag.AlignCenter); layout.addWidget(self.status); layout.addStretch()
    def _resolve_id(self,c):
        if self.student_id:return self.student_id
        row=c.execute('SELECT id FROM students ORDER BY id LIMIT 1').fetchone(); return row[0] if row else None
    def load_data(self):
        with sqlite3.connect(DB) as c:
            c.row_factory=sqlite3.Row; sid=self._resolve_id(c)
            if not sid: self.status.setText('هنوز پرونده دانش‌آموزی ثبت نشده است.'); return
            r=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
        for k,w in self.fields.items(): w.setText(str(r[k] or '') if k in r.keys() else '')
        self.student_id=r['id']; self.status.setText(f'پرونده #{self.student_id} بارگذاری شد.')
    def save(self):
        if not self.student_id:self.status.setText('پرونده‌ای برای ذخیره وجود ندارد.'); return
        with sqlite3.connect(DB) as c:
            c.execute('UPDATE students SET first_name=?,last_name=?,student_code=?,grade=?,class_name=?,father_name=?,parent_phone=?,phone=?,address=?,description=? WHERE id=?',tuple(self.fields[k].text().strip() for k in ['first_name','last_name','student_code','grade','class_name','father_name','parent_phone','phone','address','description'])+(self.student_id,)); c.commit()
        QMessageBox.information(self,'پروفایل','اطلاعات با موفقیت ذخیره شد.'); self.status.setText('آخرین تغییرات ذخیره شد.')
