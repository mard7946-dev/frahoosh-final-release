from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox
from PySide6.QtCore import Qt
import sqlite3
from pathlib import Path
from utils.jalali import iso_to_jalali
DB=Path(__file__).resolve().parents[1]/'school.db'
class AssignmentsPage(QWidget):
 def __init__(self,parent=None,student_id=None,username=None):
  super().__init__(parent); self.sid=student_id; self.username=username; self.setLayoutDirection(Qt.RightToLeft)
  from services.core_data_service import student_id as resolve
  self.sid=self.sid or resolve(username)
  l=QVBoxLayout(self); l.addWidget(QLabel('تکالیف دانش‌آموز')); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['درس/عنوان','توضیحات','وضعیت','تاریخ ثبت','دبیر','شناسه']); l.addWidget(self.table); b=QPushButton('تازه‌سازی'); b.clicked.connect(self.load); l.addWidget(b); self.load()
 def load(self):
  if not self.sid:self.table.setRowCount(0);return
  with sqlite3.connect(DB, timeout=30.0) as c:
   c.execute('PRAGMA busy_timeout=30000')
   c.execute('PRAGMA journal_mode=WAL')
   rows=c.execute('''SELECT a.title,a.description,a.status,a.created_at,COALESCE(t.first_name||' '||t.last_name,''),a.id FROM assignments a LEFT JOIN teachers t ON t.id=a.teacher_id WHERE a.student_id=? OR a.student_id IS NULL ORDER BY a.id DESC''',(self.sid,)).fetchall()
  self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(iso_to_jalali(v) if j==3 and v else str(v or '')))
