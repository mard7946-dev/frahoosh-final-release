from datetime import datetime
import secrets
import sqlite3
from pathlib import Path
import os

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QMessageBox, QComboBox,
    QHeaderView, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

DB = Path(__file__).resolve().parents[1] / "school.db"


class CompetitionsPage(QWidget):
    """ثبت‌نام واقعی دانش‌آموز در مسابقات، جشنواره‌ها و فعالیت‌های فرهنگی."""

    KINDS = {
        "مسابقات": "competition",
        "جشنواره‌ها": "festival",
        "استعدادها": "talent",
        "قرآن و نماز": "quran_prayer",
        "برنامه‌های فرهنگی": "ceremony",
        "اردوها": "trip",
    }

    def __init__(self, student_id=None, parent=None, username=None):
        super().__init__(parent)
        self.student_id = student_id
        self.username = username
        if not self.student_id and self.username:
            try:
                from services.data_link_service import student_for_username
                self.student_id = student_for_username(self.username)
            except Exception:
                self.student_id = None
        self.setLayoutDirection(Qt.RightToLeft)
        self._ensure_schema()
        self._build()
        self.load_items()

    def _db(self):
        conn = sqlite3.connect(str(DB))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self):
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS cultural_items(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                student_name TEXT DEFAULT '',
                details TEXT DEFAULT '',
                fee INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS student_registrations(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                activity_id INTEGER NOT NULL,
                activity_title TEXT NOT NULL,
                activity_kind TEXT NOT NULL,
                fee INTEGER NOT NULL DEFAULT 0,
                payment_status TEXT NOT NULL DEFAULT 'pending',
                payment_url TEXT DEFAULT '',
                payment_reference TEXT DEFAULT '',
                registration_code TEXT NOT NULL UNIQUE,
                registered_at TEXT NOT NULL
            )""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_student_reg_student ON student_registrations(student_id)")

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(10)

        title = QLabel("🏆 مسابقات، جشنواره‌ها و فعالیت‌ها")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("B Zar", 24, QFont.Bold))
        root.addWidget(title)

        self.info = QLabel("فعالیت‌های فعال مدرسه را ببینید و برای مورد دلخواه ثبت‌نام کنید.")
        self.info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info.setWordWrap(True)
        root.addWidget(self.info)

        bar = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItems(self.KINDS.keys())
        self.refresh_btn = QPushButton("🔄 نمایش فعالیت‌ها")
        self.register_btn = QPushButton("✅ ثبت‌نام در فعالیت")
        self.pay_btn = QPushButton("💳 پرداخت هزینه")
        self.refresh_btn.clicked.connect(self.load_items)
        self.register_btn.clicked.connect(self.register)
        self.pay_btn.clicked.connect(self.pay)
        bar.addWidget(self.kind, 1)
        bar.addWidget(self.refresh_btn)
        bar.addWidget(self.register_btn)
        bar.addWidget(self.pay_btn)
        root.addLayout(bar)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["شناسه", "عنوان", "توضیحات", "هزینه", "وضعیت", "وضعیت ثبت‌نام"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        root.addWidget(self.table, 1)

        note = QFrame()
        note.setStyleSheet("QFrame{border:1px solid #F9A8D4;border-radius:10px;padding:8px;background:#FFF7FB;}")
        nl = QVBoxLayout(note)
        self.status = QLabel("در حال آماده‌سازی...")
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        nl.addWidget(self.status)
        root.addWidget(note)

    def load_items(self):
        kind = self.KINDS[self.kind.currentText()]
        try:
            with self._db() as c:
                rows = c.execute(
                    "SELECT id,title,COALESCE(details,'') details,COALESCE(fee,0) fee "
                    "FROM cultural_items WHERE kind=? AND status='active' ORDER BY id DESC",
                    (kind,),
                ).fetchall()
                self.table.setRowCount(len(rows))
                for i, row in enumerate(rows):
                    reg = None
                    if self.student_id:
                        reg = c.execute(
                            "SELECT payment_status FROM student_registrations "
                            "WHERE student_id=? AND activity_id=? ORDER BY id DESC LIMIT 1",
                            (int(self.student_id), int(row["id"])),
                        ).fetchone()
                    state = "ثبت‌نام شده" if reg else "ثبت‌نام نشده"
                    if reg and reg[0] == "pending":
                        state = "ثبت‌نام شده - در انتظار پرداخت"
                    elif reg and reg[0] == "not_required":
                        state = "ثبت‌نام نهایی"
                    vals = [row["id"], row["title"], row["details"], f'{int(row["fee"]):,}', "فعال", state]
                    for j, value in enumerate(vals):
                        self.table.setItem(i, j, QTableWidgetItem(str(value)))
            self.status.setText(f"{len(rows)} مورد فعال برای «{self.kind.currentText()}» پیدا شد.")
        except Exception as e:
            self.status.setText("خطا در بارگذاری فعالیت‌ها")
            QMessageBox.warning(self, "مسابقات و جشنواره‌ها", f"بارگذاری فعالیت‌ها انجام نشد:\n{e}")

    def pay(self):
        if not self.student_id:
            QMessageBox.warning(self, "پرداخت", "شناسه دانش‌آموز برای این حساب مشخص نیست.")
            return
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "پرداخت", "ابتدا یک اردو یا فعالیت را انتخاب کنید.")
            return
        activity_id = int(self.table.item(row, 0).text())
        try:
            with self._db() as c:
                reg = c.execute(
                    "SELECT * FROM student_registrations WHERE student_id=? AND activity_id=? ORDER BY id DESC LIMIT 1",
                    (int(self.student_id), activity_id),
                ).fetchone()
                if not reg:
                    QMessageBox.warning(self, "پرداخت", "ابتدا در این مورد ثبت‌نام کنید.")
                    return
                if int(reg["fee"] or 0) <= 0:
                    QMessageBox.information(self, "پرداخت", "این مورد هزینه‌ای ندارد و ثبت‌نام نهایی است.")
                    return
                base = os.environ.get("FRAHOOSH_PAYMENT_URL") or os.environ.get("FRAHOOSh_PAYMENT_URL")
                if not base:
                    QMessageBox.warning(self, "درگاه پرداخت", "درگاه پرداخت هنوز روی سرور تنظیم نشده است. مقدار FRAHOOSH_PAYMENT_URL را تنظیم کنید.")
                    return
                url = base.rstrip("/") + "?ref=" + str(reg["registration_code"]) + "&amount=" + str(int(reg["fee"]))
                c.execute("UPDATE student_registrations SET payment_url=? WHERE id=?", (url, reg["id"]))
            self.table.item(row, 5).setText("در انتظار پرداخت")
            QMessageBox.information(self, "درگاه پرداخت", f"لینک پرداخت آماده شد:\n\n{url}")
        except Exception as e:
            QMessageBox.critical(self, "خطای پرداخت", f"ایجاد لینک پرداخت انجام نشد:\n{e}")

    def register(self):
        if not self.student_id:
            QMessageBox.warning(self, "ثبت‌نام", "شناسه دانش‌آموز برای این حساب مشخص نیست.")
            return
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "ثبت‌نام", "ابتدا یک مسابقه یا فعالیت را انتخاب کنید.")
            return

        activity_id = int(self.table.item(row, 0).text())
        try:
            with self._db() as c:
                activity = c.execute(
                    "SELECT id,kind,title,COALESCE(fee,0) fee FROM cultural_items WHERE id=? AND status='active'",
                    (activity_id,),
                ).fetchone()
                if not activity:
                    QMessageBox.warning(self, "ثبت‌نام", "این فعالیت دیگر فعال نیست.")
                    return

                exists = c.execute(
                    "SELECT id,payment_status,registration_code FROM student_registrations "
                    "WHERE student_id=? AND activity_id=? ORDER BY id DESC LIMIT 1",
                    (int(self.student_id), activity_id),
                ).fetchone()
                if exists:
                    QMessageBox.information(
                        self, "ثبت‌نام",
                        f"این دانش‌آموز قبلاً ثبت‌نام کرده است.\nکد ثبت‌نام: {exists['registration_code']}"
                    )
                    return

                code = secrets.token_urlsafe(9)
                payment_status = "pending" if int(activity["fee"] or 0) > 0 else "not_required"
                c.execute(
                    "INSERT INTO student_registrations "
                    "(student_id,activity_id,activity_title,activity_kind,fee,payment_status,registration_code,registered_at) "
                    "VALUES(?,?,?,?,?,?,?,?)",
                    (
                        int(self.student_id), activity_id, activity["title"], activity["kind"],
                        int(activity["fee"] or 0), payment_status, code,
                        datetime.now().isoformat(timespec="seconds"),
                    ),
                )

            self.load_items()
            QMessageBox.information(
                self, "ثبت‌نام موفق",
                f"ثبت‌نام با موفقیت انجام شد.\n\nکد ثبت‌نام: {code}\n"
                + ("مرحله بعد: پرداخت هزینه فعالیت." if int(activity["fee"] or 0) > 0 else "این فعالیت رایگان است و ثبت‌نام نهایی شد.")
            )
        except Exception as e:
            QMessageBox.critical(self, "خطای ثبت‌نام", f"ثبت‌نام انجام نشد:\n{e}")
