import sqlite3, os
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox,QHeaderView
from PySide6.QtCore import Qt,QTimer
from services.online_class_service import OnlineClassService
from ui.online_class_room import OnlineClassRoom

DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))

class OnlineClassesPage(QWidget):
    def __init__(self, grade=None, class_name=None, student_id=None, parent=None):
        super().__init__(parent); self.student_id=student_id; self.grade=grade; self.class_name=class_name; self.room=None; self.setLayoutDirection(Qt.RightToLeft)
        self._load_student_identity(); self._build(); self.load_classes()
        self.timer=QTimer(self); self.timer.timeout.connect(self.check_presence); self.timer.start(10000)
    def _load_student_identity(self):
        if not self.student_id and self.grade and self.class_name:return
        try:
            with sqlite3.connect(DB) as c:
                c.row_factory=sqlite3.Row
                if self.student_id:r=c.execute('SELECT grade,class_name FROM students WHERE id=?',(self.student_id,)).fetchone()
                else:r=c.execute('SELECT id,grade,class_name FROM students ORDER BY id LIMIT 1').fetchone(); self.student_id=r['id'] if r else None
                if r:self.grade=r['grade'] or '---'; self.class_name=r['class_name'] or '---'
        except Exception: self.grade=self.grade or '---'; self.class_name=self.class_name or '---'
    def _build(self):
        l=QVBoxLayout(self); title=QLabel('کلاس مجازی من'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setStyleSheet('font-size:24px;font-weight:bold;'); l.addWidget(title)
        self.info=QLabel(f'پایه: {self.grade or "---"} | کلاس: {self.class_name or "---"}'); self.info.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(self.info)
        bar=QHBoxLayout(); ref=QPushButton('تازه‌سازی'); enter=QPushButton('ورود به کلاس'); ref.clicked.connect(self.load_classes); enter.clicked.connect(self.enter); bar.addWidget(ref); bar.addWidget(enter); l.addLayout(bar)
        self.status=QLabel(''); l.addWidget(self.status)
        self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['شناسه','درس','دبیر','شروع','پایان','وضعیت','عملیات']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); l.addWidget(self.table)
    def load_classes(self):
        self.table.setRowCount(0)
        rows=OnlineClassService.get_student_classes(self.grade,self.class_name,self.student_id); self.table.setRowCount(len(rows));
        for i,r in enumerate(rows):
            vals=[r['id'],r['subject'],r['teacher'],r['start_time'] or '-',r['end_time'] or '-',r['status'],'']
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        self.status.setText('کلاس‌های مجازی متصل به شناسه دانش‌آموز نمایش داده می‌شوند.')
    def enter(self):
        row=self.table.currentRow()
        if row<0:QMessageBox.warning(self,'کلاس','یک کلاس را انتخاب کنید.');return
        cid=int(self.table.item(row,0).text()); status=self.table.item(row,5).text()
        if status!='live':QMessageBox.warning(self,'کلاس','کلاس هنوز توسط دبیر شروع نشده است.');return
        if not self.student_id:QMessageBox.warning(self,'کلاس','شناسه دانش‌آموز مشخص نیست.');return
        OnlineClassService.student_join(cid,self.student_id); self.room=OnlineClassRoom(class_id=cid,student_id=self.student_id,role='student'); self.room.show()
    def check_presence(self):
        if not self.room or not self.room.isVisible() or not self.student_id:return
        cid=getattr(self.room,'class_id',None)
        if not cid:return
        check=OnlineClassService.due_presence_check(cid,self.student_id)
        if check:self.room.show_presence_check(check)
