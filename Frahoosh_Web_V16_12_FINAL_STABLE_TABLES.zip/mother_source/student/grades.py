from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QHBoxLayout
from PySide6.QtCore import Qt
import sqlite3
from pathlib import Path
from utils.jalali import iso_to_jalali
from services.grade_service import generate_report_card, student_average, subject_averages, growth_trend
DB=Path(__file__).resolve().parents[1]/'school.db'

class GradesPage(QWidget):
 def __init__(self,parent=None,student_id=None,username=None):
  super().__init__(parent); self.sid=student_id
  from services.core_data_service import student_id as resolve
  self.sid=self.sid or resolve(username); self.setLayoutDirection(Qt.RightToLeft)
  l=QVBoxLayout(self); l.addWidget(QLabel('کارنامه هوشمند و روند پیشرفت'))
  self.summary=QLabel(); l.addWidget(self.summary)
  self.table=QTableWidget(0,8); self.table.setHorizontalHeaderLabels(['درس','نوع','عنوان','نمره','ضریب','تاریخ شمسی','دبیر','توضیحات']); l.addWidget(self.table)
  bar=QHBoxLayout(); b=QPushButton('تولید کارنامه'); b.clicked.connect(self.report); r=QPushButton('نمایش روند'); r.clicked.connect(self.trend); ref=QPushButton('تازه‌سازی'); ref.clicked.connect(self.load)
  for x in (b,r,ref): bar.addWidget(x)
  l.addLayout(bar); self.load()
 def load(self):
  if not self.sid:return
  with sqlite3.connect(DB,timeout=30) as c:
   c.row_factory=sqlite3.Row
   rows=c.execute('''SELECT sg.subject,sg.assessment_type,sg.assessment_title,sg.score,sg.coefficient,
    sg.grade_date_shamsi,COALESCE(t.first_name||' '||t.last_name,''),sg.description
    FROM student_grades sg LEFT JOIN teachers t ON t.id=sg.teacher_id
    WHERE sg.student_id=? AND (sg.assessment_type NOT IN ('میان‌ترم','پایان‌ترم') OR sg.manager_released=1) ORDER BY sg.id DESC''',(self.sid,)).fetchall()
  self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  avg=student_average(self.sid); self.summary.setText(f'میانگین وزنی کل: {avg:.2f} | تعداد ارزشیابی: {len(rows)}')
 def load_student(self,sid): self.sid=sid; self.load()
 def report(self):
  if not self.sid:return
  data=generate_report_card(self.sid)
  self.summary.setText(f'کارنامه تولید شد | میانگین: {data["average"]:.2f} | تاریخ: {data["generated_date_shamsi"]} | دروس: {len(data["subjects"])}')
 def trend(self):
  rows=growth_trend(self.sid)
  self.summary.setText('روند نمرات: '+' | '.join(f'{r[0]}={r[1]}' for r in rows) if rows else 'داده کافی برای روند وجود ندارد.')
