import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton
from PySide6.QtCore import Qt
from utils.jalali import iso_to_jalali
DB=Path(__file__).resolve().parents[1]/"school.db"
class AttendancePage(QWidget):
    def __init__(self,parent=None,student_id=None,username=None):
        super().__init__(parent); self.student_id=student_id; self.username=username or ""; self.setLayoutDirection(Qt.RightToLeft); self.init_ui(); self.load()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel("حضور و غیاب دانش‌آموز"); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(t); self.table=QTableWidget(0,4); self.table.setHorizontalHeaderLabels(["تاریخ","وضعیت","نوع کلاس","توضیحات"]); l.addWidget(self.table); b=QPushButton("تازه‌سازی"); b.clicked.connect(self.load); l.addWidget(b); self.info=QLabel(); self.info.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(self.info)
    def load(self):
        sid=self.student_id
        if not sid and self.username:
            try:
                from services.data_link_service import student_for_username; sid=student_for_username(self.username)
            except Exception: sid=None
        if not sid:
            self.table.setRowCount(0); self.info.setText("حساب دانش‌آموز هنوز به پرونده دانش‌آموزی متصل نیست."); return
        with sqlite3.connect(DB) as c:
            rows=c.execute("SELECT date,status,COALESCE(description,''),'' FROM attendance WHERE student_id=? ORDER BY id DESC",(int(sid),)).fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[iso_to_jalali(r[0]) if r[0] else '',r[1] or '',"حضوری",r[2] or '']
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v)))
        self.info.setText(f"{len(rows)} رکورد حضور و غیاب برای این دانش‌آموز ثبت شده است.")
