"""User-facing date formatting helpers. Storage may remain ISO/UTC."""
from .jalali import iso_to_jalali

def display_datetime(value):
    text=str(value or '')
    if len(text) >= 10 and text[4:5] == '-' and text[7:8] == '-':
        j=iso_to_jalali(text[:10])
        return j + ((' ' + text[11:19]) if len(text) >= 19 else '')
    return text
