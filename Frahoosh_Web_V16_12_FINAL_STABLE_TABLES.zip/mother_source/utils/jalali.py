# Minimal Gregorian -> Jalali converter, no external dependency.
def gregorian_to_jalali(gy,gm,gd):
    gdm=[0,31,59,90,120,151,181,212,243,273,304,334]
    gy2=gy+1 if gm>2 else gy
    days=355666+365*gy+((gy2+3)//4)-((gy2+99)//100)+((gy2+399)//400)+gd+gdm[gm-1]
    jy=-1595+33*(days//12053); days%=12053
    jy+=4*(days//1461); days%=1461
    if days>365:
        jy+=(days-1)//365; days=(days-1)%365
    if days<186: jm=1+days//31
    else: jm=7+(days-186)//30
    jd=1+(days%31 if days<186 else (days-186)%30)
    return jy,jm,jd

def iso_to_jalali(value):
    try:
        y,m,d=map(int,str(value)[:10].split('-')); jy,jm,jd=gregorian_to_jalali(y,m,d); return f'{jy:04d}/{jm:02d}/{jd:02d}'
    except Exception:return str(value or '')

def weekday_fa(value):
    import datetime
    names=['دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه','یکشنبه']
    try:return names[datetime.date.fromisoformat(str(value)[:10]).weekday()]
    except Exception:return ''


def jalali_to_gregorian(jy, jm, jd):
    """Convert Jalali date to Gregorian without external dependencies."""
    jy = int(jy); jm = int(jm); jd = int(jd)
    jy += 1595
    days = -355668 + (365 * jy) + (jy // 33) * 8 + ((jy % 33 + 3) // 4) + jd
    if jm < 7:
        days += (jm - 1) * 31
    else:
        days += (jm - 7) * 30 + 186
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        gy += 100 * ((days - 1) // 36524)
        days = (days - 1) % 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and (gy % 100 != 0 or gy % 400 == 0))
    mdays = [31,29 if leap else 28,31,30,31,30,31,31,30,31,30,31]
    gm = 1
    while gd > mdays[gm-1]:
        gd -= mdays[gm-1]; gm += 1
    return gy, gm, gd

def jalali_to_iso(value):
    try:
        parts = str(value).strip().replace('-', '/').split('/')
        if len(parts) != 3: raise ValueError
        gy,gm,gd = jalali_to_gregorian(*map(int, parts))
        return f'{gy:04d}-{gm:02d}-{gd:02d}'
    except Exception:
        raise ValueError('تاریخ باید به صورت شمسی 1405/01/15 وارد شود')
