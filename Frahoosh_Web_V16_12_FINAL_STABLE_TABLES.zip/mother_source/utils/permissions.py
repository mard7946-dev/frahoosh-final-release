# =====================================
# Frahoosh Permission Manager
# سیستم دسترسی کاربران
# =====================================


ROLES = {


    "manager": {

        "name": "مدیر مدرسه",

        "permissions": [

            "dashboard",
            "students",
            "teachers",
            "education",
            "cultural",
            "executive",
            "finance",
            "advisor",
            "settings"

        ]

    },


    "academic": {

        "name": "معاون آموزشی",

        "permissions": [

            "dashboard",
            "students",
            "teachers",
            "education"

        ]

    },


    "cultural": {

        "name": "معاون پرورشی",

        "permissions": [

            "dashboard",
            "cultural",
            "advisor"

        ]

    },


    "executive": {

        "name": "معاون اجرایی",

        "permissions": [

            "dashboard",
            "students",
            "executive",
            "finance"

        ]

    },


    "advisor": {

        "name": "مشاور",

        "permissions": [

            "dashboard",
            "advisor",
            "students"

        ]

    },


    "teacher": {

        "name": "دبیر",

        "permissions": [

            "dashboard",
            "classes",
            "grades",
            "lesson_plan"

        ]

    },


    "student": {

        "name": "دانش‌آموز",

        "permissions": [

            "student_panel"

        ]

    },


    "parent": {

        "name": "ولی دانش‌آموز",

        "permissions": [

            "parent_panel"

        ]

    }

}




def has_permission(role, page):

    if role not in ROLES:

        return False


    return page in ROLES[role]["permissions"]




def get_role_name(role):

    if role in ROLES:

        return ROLES[role]["name"]


    return "کاربر"