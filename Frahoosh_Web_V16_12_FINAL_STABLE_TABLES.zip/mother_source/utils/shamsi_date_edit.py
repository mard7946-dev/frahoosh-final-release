"""Small Persian/Jalali date editor for user-facing forms.

The internal QDate remains Gregorian so existing code and SQLite sorting keep
working; the visible text is Jalali (yyyy/mm/dd).
"""
from PySide6.QtWidgets import QDateEdit
from PySide6.QtCore import QDate
from .jalali import gregorian_to_jalali

class ShamsiDateEdit(QDateEdit):
    def __init__(self, date=None, parent=None):
        super().__init__(date or QDate.currentDate(), parent)
        self.setCalendarPopup(True)
        self.lineEdit().setReadOnly(True)
        self.dateChanged.connect(self._refresh_text)
        self._refresh_text(self.date())

    def _refresh_text(self, qdate):
        jy,jm,jd=gregorian_to_jalali(qdate.year(),qdate.month(),qdate.day())
        self.lineEdit().setText(f"{jy:04d}/{jm:02d}/{jd:02d}")

    def text_shamsi(self):
        return self.lineEdit().text()
