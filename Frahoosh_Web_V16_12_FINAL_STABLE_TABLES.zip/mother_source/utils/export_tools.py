from PySide6.QtWidgets import QFileDialog
from PySide6.QtPrintSupport import QPrinter, QPrintDialog
from PySide6.QtGui import QTextDocument

def widget_to_pdf(widget, parent=None, title='گزارش فراهوش'):
    path, _ = QFileDialog.getSaveFileName(parent or widget, 'ذخیره PDF', f'{title}.pdf', 'PDF (*.pdf)')
    if not path: return False
    printer=QPrinter(QPrinter.HighResolution); printer.setOutputFormat(QPrinter.PdfFormat); printer.setOutputFileName(path)
    doc=QTextDocument(); doc.setPlainText(widget_to_text(widget)); doc.print_(printer); return True

def print_widget(widget, parent=None):
    printer=QPrinter(QPrinter.HighResolution); dlg=QPrintDialog(printer,parent or widget)
    if dlg.exec()==QPrintDialog.Accepted:
        doc=QTextDocument(); doc.setPlainText(widget_to_text(widget)); doc.print_(printer); return True
    return False

def widget_to_text(widget):
    from PySide6.QtWidgets import QTableWidget, QLabel, QTextEdit
    parts=[]
    for lab in widget.findChildren(QLabel):
        if lab.text().strip(): parts.append(lab.text().strip())
    for te in widget.findChildren(QTextEdit):
        if te.toPlainText().strip(): parts.append(te.toPlainText().strip())
    for table in widget.findChildren(QTableWidget):
        headers=[table.horizontalHeaderItem(i).text() if table.horizontalHeaderItem(i) else '' for i in range(table.columnCount())]
        if headers: parts.append(' | '.join(headers))
        for r in range(table.rowCount()):
            parts.append(' | '.join(table.item(r,c).text() if table.item(r,c) else '' for c in range(table.columnCount())))
    return '\n'.join(parts) or 'گزارشی برای چاپ وجود ندارد.'
