FARAHOOSH_THEME = """
* {
    font-family: "B Zar";
    font-size: 14px;
}

QWidget {
    background-color: #f8fafc;
    color: #111827;
}

QLabel {
    color: #111827;
    background: transparent;
}

QFrame {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
}

QGroupBox {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    font-weight: bold;
    padding-top: 8px;
}

QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox, QDateEdit {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #94a3b8;
    border-radius: 7px;
    padding: 4px 7px;
    min-height: 24px;
}

QTableWidget, QTableView, QListWidget, QListView {
    background-color: #ffffff;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
}

QPushButton, QToolButton {
    background-color: #2563eb;
    color: #ffffff;
    border: 1px solid #1d4ed8;
    border-radius: 7px;
    padding: 3px 8px;
    min-height: 26px;
    max-height: 32px;
    min-width: 110px;
    font-weight: bold;
}

QPushButton:hover, QToolButton:hover {
    background-color: #1d4ed8;
}

QPushButton:pressed, QToolButton:pressed {
    background-color: #1e40af;
}

QPushButton:disabled, QToolButton:disabled {
    background-color: #cbd5e1;
    color: #64748b;
}

QScrollArea {
    background: transparent;
    border: none;
}
"""
