# ==========================================
# Farhoosh Smart School Management System
# نسخه 1.0.0
# ==========================================


# ==========================
# اطلاعات اصلی برنامه
# ==========================

APP_NAME = "فراهوش"

SYSTEM_TITLE = "سامانه هوشمند آموزشی یکپارچه"

SCHOOL_NAME = "دبیرستان سردار شهید حاجی‌زاده ۲"

APP_TITLE = "سامانه هوشمند آموزشی یکپارچه | دبیرستان سردار شهید حاجی‌زاده ۲"

APP_VERSION = "1.0.0"

DEVELOPER = "Farhoosh"


# ==========================
# اندازه پنجره‌ها
# ==========================

WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 850

LOGIN_CARD_WIDTH = 430


# ==========================
# رنگ‌ها
# ==========================

PRIMARY_COLOR = "#0f172a"

SECONDARY_COLOR = "#1e3a8a"

SUCCESS_COLOR = "#22c55e"

WARNING_COLOR = "#facc15"

ERROR_COLOR = "#ef4444"


# رنگ متن
TEXT_COLOR = "#000000"

TEXT_SECONDARY = "#333333"


# ==========================
# رنگ‌بندی پنل فراهوش
# ==========================

PANEL_CARD_COLOR = "#FFE0B2"

PANEL_BORDER_COLOR = "#F57C00"

BUTTON_COLOR = "#4CAF50"

BUTTON_TEXT_COLOR = "#000000"


# ==========================
# گوشه‌های گرد
# ==========================

CARD_RADIUS = 25

BUTTON_RADIUS = 12

INPUT_RADIUS = 12


# ==========================
# فونت
# ==========================

DEFAULT_FONT = "B Zar"

TITLE_SIZE = 28

TEXT_SIZE = 16

SMALL_TEXT = 13


# ==========================
# تصاویر
# ==========================

LOGIN_BACKGROUND = "assets/farhoosh_bg.png"

LOGIN_LOGO = "assets/farhoosh_logo.png"


# ==========================
# پایگاه داده
# ==========================

DATABASE_NAME = "school.db"