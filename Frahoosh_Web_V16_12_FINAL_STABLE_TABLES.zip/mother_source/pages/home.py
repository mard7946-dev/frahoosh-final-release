from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QFrame,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QSizePolicy
)

from PySide6.QtCore import Qt

from PySide6.QtGui import QFont, QPixmap

import qtawesome as qta


class HomePage(QWidget):

    def __init__(self):

        super().__init__()

        self.setObjectName("HomePage")

        self.build_ui()


    # =====================================
    # ساخت رابط کاربری
    # =====================================

    def build_ui(self):

        self.setStyleSheet("""

        QWidget#HomePage{

            background:#EEF3F8;

        }

        """)

        main_layout = QVBoxLayout(self)

        main_layout.setContentsMargins(20,20,20,20)

        main_layout.setSpacing(18)


        # =====================================
        # کارت خوش آمدگویی
        # =====================================

        welcome = QFrame()

        welcome.setFixedHeight(150)

        welcome.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

        }

        """)

        main_layout.addWidget(welcome)


        welcome_layout = QHBoxLayout(welcome)


        text_layout = QVBoxLayout()

        welcome_layout.addLayout(text_layout)


        title = QLabel("سلام مدیر دبیرستان 🌹")

        title.setFont(QFont("B Nazanin",22,QFont.Bold))

        title.setStyleSheet("color:#0D47A1;")

        text_layout.addWidget(title)


        sub = QLabel(

            "به سامانه هوشمند آموزشی یکپارچه فراهوش خوش آمدید."

        )

        sub.setFont(QFont("B Nazanin",13))

        sub.setStyleSheet("color:#666666;")

        text_layout.addWidget(sub)


        info = QLabel(

            "امروز امیدواریم روزی پر از موفقیت برای دبیرستان باشد."

        )

        info.setFont(QFont("B Nazanin",12))

        info.setStyleSheet("color:#888888;")

        text_layout.addWidget(info)


        text_layout.addStretch()


        logo = QLabel()

        pix = QPixmap("assets/farhoosh_logo.png")

        logo.setPixmap(

            pix.scaled(

                120,

                120,

                Qt.KeepAspectRatio,

                Qt.SmoothTransformation

            )

        )

        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        welcome_layout.addWidget(logo)


        # =====================================
        # بخش دستیار هوشمند
        # =====================================

        ai_card = QFrame()

        ai_card.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

            border:2px solid #1565C0;

        }

        """)

        main_layout.addWidget(ai_card)


        ai_layout = QVBoxLayout(ai_card)


        ai_title = QLabel("🧠 دستیار هوشمند فراهوش")

        ai_title.setFont(QFont("B Nazanin",18,QFont.Bold))

        ai_title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        ai_title.setStyleSheet("color:#1565C0;")

        ai_layout.addWidget(ai_title)


        ai_message = QLabel("""

امروز وضعیت مدرسه:

✔ ۳۰۰ دانش آموز فعال

✔ ۲۵ دبیر فعال

✔ ۹ کلاس در حال فعالیت

✔ ۴ پیام جدید از اولیا

✔ هوش مصنوعی پیشنهاد می‌کند
امروز از پایه هشتم یک ارزشیابی کوتاه برگزار شود.

""")

        ai_message.setWordWrap(True)

        ai_message.setFont(QFont("B Nazanin",13))

        ai_message.setStyleSheet("""

        color:#333333;

        padding:10px;

        """)

        ai_layout.addWidget(ai_message)


    from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QFrame,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QSizePolicy
)

from PySide6.QtCore import Qt

from PySide6.QtGui import QFont, QPixmap

import qtawesome as qta


class HomePage(QWidget):

    def __init__(self):

        super().__init__()

        self.setObjectName("HomePage")

        self.build_ui()


    # =====================================
    # ساخت رابط کاربری
    # =====================================

    def build_ui(self):

        self.setStyleSheet("""

        QWidget#HomePage{

            background:#EEF3F8;

        }

        """)

        main_layout = QVBoxLayout(self)

        main_layout.setContentsMargins(20,20,20,20)

        main_layout.setSpacing(18)


        # =====================================
        # کارت خوش آمدگویی
        # =====================================

        welcome = QFrame()

        welcome.setFixedHeight(150)

        welcome.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

        }

        """)

        main_layout.addWidget(welcome)


        welcome_layout = QHBoxLayout(welcome)


        text_layout = QVBoxLayout()

        welcome_layout.addLayout(text_layout)


        title = QLabel("سلام مدیر دبیرستان 🌹")

        title.setFont(QFont("B Nazanin",22,QFont.Bold))

        title.setStyleSheet("color:#0D47A1;")

        text_layout.addWidget(title)


        sub = QLabel(

            "به سامانه هوشمند آموزشی یکپارچه فراهوش خوش آمدید."

        )

        sub.setFont(QFont("B Nazanin",13))

        sub.setStyleSheet("color:#666666;")

        text_layout.addWidget(sub)


        info = QLabel(

            "امروز امیدواریم روزی پر از موفقیت برای دبیرستان باشد."

        )

        info.setFont(QFont("B Nazanin",12))

        info.setStyleSheet("color:#888888;")

        text_layout.addWidget(info)


        text_layout.addStretch()


        logo = QLabel()

        pix = QPixmap("assets/farhoosh_logo.png")

        logo.setPixmap(

            pix.scaled(

                120,

                120,

                Qt.KeepAspectRatio,

                Qt.SmoothTransformation

            )

        )

        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        welcome_layout.addWidget(logo)


        # =====================================
        # بخش دستیار هوشمند
        # =====================================

        ai_card = QFrame()

        ai_card.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

            border:2px solid #1565C0;

        }

        """)

        main_layout.addWidget(ai_card)


        ai_layout = QVBoxLayout(ai_card)


        ai_title = QLabel("🧠 دستیار هوشمند فراهوش")

        ai_title.setFont(QFont("B Nazanin",18,QFont.Bold))

        ai_title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        ai_title.setStyleSheet("color:#1565C0;")

        ai_layout.addWidget(ai_title)


        ai_message = QLabel("""

امروز وضعیت مدرسه:

✔ ۳۰۰ دانش آموز فعال

✔ ۲۵ دبیر فعال

✔ ۹ کلاس در حال فعالیت

✔ ۴ پیام جدید از اولیا

✔ هوش مصنوعی پیشنهاد می‌کند
امروز از پایه هشتم یک ارزشیابی کوتاه برگزار شود.

""")

        ai_message.setWordWrap(True)

        ai_message.setFont(QFont("B Nazanin",13))

        ai_message.setStyleSheet("""

        color:#333333;

        padding:10px;

        """)

        ai_layout.addWidget(ai_message)


    # =====================================
        # فعالیت های امروز
        # =====================================

        today_frame = QFrame()

        today_frame.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

        }

        """)

        main_layout.addWidget(today_frame)


        today_layout = QVBoxLayout(today_frame)


        today_title = QLabel("📅 فعالیت های امروز")

        today_title.setFont(QFont("B Nazanin",17,QFont.Bold))

        today_title.setStyleSheet("color:#1565C0;")

        today_layout.addWidget(today_title)


        activities = [

            "✅ برگزاری جلسه شورای دبیران ساعت ۹:۰۰",

            "✅ آزمون علوم پایه هشتم",

            "✅ کلاس فوق برنامه ریاضی ساعت ۱۴:۰۰",

            "✅ پیگیری ثبت نمرات دبیران",

            "✅ جلسه مشاور با اولیای دانش آموزان"

        ]


        for item in activities:

            lbl = QLabel(item)

            lbl.setFont(QFont("B Nazanin",12))

            lbl.setStyleSheet("""

            color:#444444;

            padding:4px;

            """)

            today_layout.addWidget(lbl)


        # =====================================
        # خلاصه وضعیت مدرسه
        # =====================================

        status = QFrame()

        status.setStyleSheet("""

        QFrame{

            background:white;

            border-radius:18px;

            border:2px solid #43A047;

        }

        """)

        main_layout.addWidget(status)


        status_layout = QVBoxLayout(status)


        status_title = QLabel("📈 خلاصه وضعیت امروز")

        status_title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        status_title.setFont(QFont("B Nazanin",17,QFont.Bold))

        status_title.setStyleSheet("color:#2E7D32;")

        status_layout.addWidget(status_title)


        status_text = QLabel("""

حضور دانش آموزان : ۹۷٪

حضور دبیران : ۱۰۰٪

کلاس های برگزار شده : ۱۲

پیام های جدید : ۴

جلسات امروز : ۲

ثبت نمرات : ۸۵٪

""")

        status_text.setAlignment(Qt.AlignmentFlag.AlignCenter)

        status_text.setFont(QFont("B Nazanin",13))

        status_layout.addWidget(status_text)


        main_layout.addStretch()


        # =====================================
        # فوتر
        # =====================================

        footer = QLabel("""

🧠 فراهوش

سامانه هوشمند آموزشی یکپارچه

دبیرستان سردار شهید حاجی زاده ۲

نسخه 1.0

سال تولید : ۱۴۰۵

طراحی و توسعه

حسن مردانه جهان تیغ

""")

        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)

        footer.setFont(QFont("B Nazanin",11))

        footer.setStyleSheet("""

        color:#666666;

        padding:15px;

        """)

        main_layout.addWidget(footer)