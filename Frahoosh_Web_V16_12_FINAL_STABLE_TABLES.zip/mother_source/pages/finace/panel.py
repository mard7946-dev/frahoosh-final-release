from PySide6.QtCore import Qt
import sqlite3,os
from pages.common_reports import ReportPage
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QDialog,QFormLayout,QDialogButtonBox
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','school.db'))
def db():c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
class Panel(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);l=QVBoxLayout(self);t=QLabel('پنل مالی');t.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(t);bar=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('جستجو...');bar.addWidget(self.search);l.addLayout(bar);actions=QVBoxLayout();add=QPushButton('ثبت تراکنش');edit=QPushButton('ویرایش');ref=QPushButton('تازه‌سازی');[actions.addWidget(x) for x in (add,edit,ref)];l.addLayout(actions);self.table=QTableWidget();l.addWidget(self.table);report=QPushButton('گزارش مالی');l.addWidget(report);
  l.setSpacing(10); actions.setSpacing(8);report.clicked.connect(self.show_report);add.clicked.connect(self.add);edit.clicked.connect(self.edit);ref.clicked.connect(self.load);self.search.textChanged.connect(self.load);self.load();self.setStyleSheet('QWidget{background:#F0FDF4;} QPushButton{background:#16A34A;color:white;padding:8px;border-radius:8px;}')
 def load(self):
  s='%'+self.search.text().strip()+'%';
  with db() as c:rows=c.execute('SELECT id,student_id,amount,description,status,created_at FROM finance_transactions WHERE CAST(student_id AS TEXT) LIKE ? OR description LIKE ? ORDER BY id DESC',(s,s)).fetchall()
  self.table.setColumnCount(6);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','مبلغ','شرح','وضعیت','تاریخ']);self.table.setRowCount(len(rows))
  for r,row in enumerate(rows):
   for j,v in enumerate(row):self.table.setItem(r,j,QTableWidgetItem(str(v or '')))
 def form(self,row=None):
  d=QDialog(self);f=QFormLayout(d);ws=[]
  for k,lbl in [('student_id','شناسه دانش‌آموز'),('amount','مبلغ'),('description','شرح'),('status','وضعیت')]:w=QLineEdit(str((row or {}).get(k,'')));f.addRow(lbl,w);ws.append(w)
  b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addWidget(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject);return d,ws
 def add(self):
  d,w=self.form();
  if d.exec()!=QDialog.Accepted:return
  with db() as c:c.execute('INSERT INTO finance_transactions(student_id,amount,description,status,created_at) VALUES(?,?,?,?,datetime("now"))',[x.text() for x in w]);c.commit()
  self.load()
 def show_report(self):
  d=QDialog(self);d.setWindowTitle('گزارش مالی');lay=QVBoxLayout(d);lay.addWidget(ReportPage('گزارش مالی',d));d.resize(850,600);d.exec()
 def edit(self):
  r=self.table.currentRow();
  if r<0:return
  row={k:self.table.item(r,i).text() for i,k in enumerate(['id','student_id','amount','description','status','created_at'])};d,w=self.form(row)
  if d.exec()!=QDialog.Accepted:return
  with db() as c:c.execute('UPDATE finance_transactions SET student_id=?,amount=?,description=?,status=? WHERE id=?',[x.text() for x in w]+[row['id']]);c.commit()
  self.load()
