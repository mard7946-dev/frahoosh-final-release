from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QTableWidget,QTableWidgetItem,QPushButton,QLabel,QFileDialog,QMessageBox
from PySide6.QtCore import Qt
from services.report_service import snapshot, save_csv

class ReportPage(QWidget):
    def __init__(self,title='گزارش سیستم',parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft)
        l=QVBoxLayout(self); l.addWidget(QLabel(title))
        self.table=QTableWidget(0,2); self.table.setHorizontalHeaderLabels(['شاخص','تعداد']); l.addWidget(self.table)
        bar=QHBoxLayout(); r=QPushButton('تولید/به‌روزرسانی گزارش'); e=QPushButton('خروجی CSV'); back=QPushButton('بازگشت به صفحه اصلی')
        bar.addWidget(r);bar.addWidget(e);bar.addWidget(back);l.addLayout(bar)
        r.clicked.connect(self.load);e.clicked.connect(self.export);back.clicked.connect(self.go_back);self.load()
    def load(self):
        rows=snapshot(); self.table.setRowCount(len(rows))
        for i,(a,b) in enumerate(rows):self.table.setItem(i,0,QTableWidgetItem(a));self.table.setItem(i,1,QTableWidgetItem(str(b)))
    def export(self):
        p,_=QFileDialog.getSaveFileName(self,'ذخیره گزارش','frahoosh_report.csv','CSV (*.csv)')
        if p:
            try: save_csv(p); QMessageBox.information(self,'گزارش','گزارش با موفقیت ذخیره شد.')
            except Exception as e: QMessageBox.critical(self,'خطا',str(e))
    def go_back(self):
        p=self.parent()
        while p:
            if hasattr(p,'show_main_page'): p.show_main_page(); return
            p=p.parent()
