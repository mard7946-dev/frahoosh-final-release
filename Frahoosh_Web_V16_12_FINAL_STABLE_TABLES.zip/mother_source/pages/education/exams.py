from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox,QDialog,QFormLayout,QDialogButtonBox
from PySide6.QtCore import Qt
from services.management_service import ManagementService
from ui.audience_selector import AudienceSelectorDialog
from services.audience_service import begin_capture, end_capture
from utils.jalali import iso_to_jalali, weekday_fa
class ExamsPage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.resize(1100,650); self.init_ui(); self.load()
 def init_ui(self):
  l=QVBoxLayout(self); t=QLabel('برنامه امتحانات معاونت آموزشی — زمان‌بندی هوشمند'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(t)
  form=QHBoxLayout(); self.subject=QLineEdit(); self.subject.setPlaceholderText('درس'); self.grade=QLineEdit(); self.grade.setPlaceholderText('پایه'); self.start=QLineEdit(); self.start.setPlaceholderText('شروع بازه شمسی 1405/01/01'); self.end=QLineEdit(); self.end.setPlaceholderText('پایان بازه شمسی 1405/01/20'); self.weight=QComboBox(); self.weight.addItems(['ساده','متوسط','سخت']); self.duration=QLineEdit(); self.duration.setReadOnly(True); self.duration.setPlaceholderText('خودکار: 30/45/60'); self.weight.currentTextChanged.connect(lambda v: self.duration.setText({'ساده':'30','متوسط':'45','سخت':'60'}.get(v,'45'))) ; self.weight.setCurrentText('متوسط')
  for w in [self.subject,self.grade,self.start,self.end,self.weight,self.duration]:form.addWidget(w)
  add=QPushButton('ثبت و تعیین خودکار تاریخ'); add.clicked.connect(self.add); auto=QPushButton('چیدمان خودکار همه'); auto.clicked.connect(self.auto); edit=QPushButton('ویرایش دستی'); edit.clicked.connect(self.edit); dele=QPushButton('حذف'); dele.clicked.connect(self.delete)
  for b in [add,auto,edit,dele]:form.addWidget(b)
  l.addLayout(form)
  self.table=QTableWidget(0,11); self.table.setHorizontalHeaderLabels(['ID','درس','پایه','شروع بازه شمسی','پایان بازه شمسی','سطح','تاریخ شمسی','روز هفته','مدت','شروع امتحان','پایان امتحان']); l.addWidget(self.table)
 def load(self):
  rows=ManagementService.exam_entries(); self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   vals=[r[0],r[1],r[2],iso_to_jalali(r[3]),iso_to_jalali(r[4]),r[5],iso_to_jalali(r[6]),weekday_fa(r[6]),r[7],r[8],r[9]]
   for c,v in enumerate(vals):self.table.setItem(i,c,QTableWidgetItem(str(v or '')))
 def add(self):
  try:
   if not self.start.text().strip() or not self.end.text().strip():raise ValueError('بازه زمانی الزامی است')
   from utils.jalali import jalali_to_iso
   start=jalali_to_iso(self.start.text().strip()); end=jalali_to_iso(self.end.text().strip())
   d=ManagementService.suggest_exam_date(start,end,self.weight.currentText(),self.grade.text().strip())
   aud=AudienceSelectorDialog(self,[('grade_students',self.grade.text().strip()),('school_parents',''),('manager',''),('vice',''),('teacher','')])
   if not aud.exec(): return
   begin_capture('exam_schedule',aud.targets())
   ManagementService.add_exam(self.subject.text(),self.grade.text(),start,end,self.weight.currentText(),d,self.weight.currentText() and {'ساده':30,'متوسط':45,'سخت':60}[self.weight.currentText()])
   end_capture('exam_schedule'); self.load(); QMessageBox.information(self,'ثبت شد',f'تاریخ به‌صورت خودکار تعیین شد: {iso_to_jalali(d)} — {weekday_fa(d)}')
  except Exception as e:QMessageBox.critical(self,'خطا',str(e))
 def auto(self):
  try:n=ManagementService.auto_schedule_exams(); self.load(); QMessageBox.information(self,'چیدمان',f'{n} امتحان زمان‌بندی شد.')
  except Exception as e:QMessageBox.critical(self,'خطا',str(e))
 def delete(self):
  r=self.table.currentRow()
  if r<0:return
  try:ManagementService.delete_exam(int(self.table.item(r,0).text()));self.load()
  except Exception as e:QMessageBox.critical(self,'خطا',str(e))
 def edit(self):
  r=self.table.currentRow()
  if r<0:return
  vals=[self.table.item(r,c).text() for c in range(9)]; d=QDialog(self); f=QFormLayout(d); ws=[]
  for label,val in [('درس',vals[1]),('پایه',vals[2]),('شروع بازه',vals[3]),('پایان بازه',vals[4]),('تاریخ امتحان میلادی',self._iso_from_row(vals[6])) ,('روز هفته',vals[7]),('مدت',vals[8])]:
   w=QLineEdit(val); f.addRow(label,w); ws.append(w)
  box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addWidget(box);box.accepted.connect(d.accept);box.rejected.connect(d.reject)
  if d.exec()!=QDialog.Accepted:return
  try:
   import sqlite3
   from pathlib import Path
   DB=Path(__file__).resolve().parents[2]/'school.db'
   with sqlite3.connect(DB) as c:c.execute('UPDATE exam_schedule SET subject=?,grade=?,start_date=?,end_date=?,exam_date=?,duration=? WHERE id=?',(ws[0].text(),ws[1].text(),ws[2].text(),ws[3].text(),ws[4].text(),int(ws[6].text() or 90),int(vals[0])));c.commit()
   self.load()
  except Exception as e:QMessageBox.critical(self,'خطا',str(e))
 def _iso_from_row(self,jalali):
  # Editing defaults to the currently stored Gregorian date; table value is display-only.
  try:
   rows=ManagementService.exam_entries(); r=self.table.currentRow(); return rows[r][6] if r>=0 and r<len(rows) else ''
  except Exception:return ''
