from pages.common_reports import ReportPage
class ReportsPage(ReportPage):
    def __init__(self,parent=None): super().__init__('گزارش‌های معاونت آموزشی',parent)
