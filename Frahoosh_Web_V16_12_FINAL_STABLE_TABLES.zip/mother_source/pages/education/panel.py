import sqlite3
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QPushButton,QLabel,QStackedWidget,QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from ui.data_crud import CrudTablePage,db
from services.core_bootstrap import bootstrap
from ui.unified_inbox import UnifiedInboxPage,UnifiedMessengerPage

class EducationPanel(QWidget):
    """معاونت آموزشی؛ تمام گزینه‌ها به جدول واقعی SQLite متصل‌اند."""
    def __init__(self,parent=None):
        super().__init__(parent); bootstrap(); self.pages={}; self.setLayoutDirection(Qt.RightToLeft); self._ensure(); self._build()
    def _ensure(self):
        with db() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,date TEXT,status TEXT,description TEXT);
            CREATE TABLE IF NOT EXISTS vice_referrals(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,teacher TEXT,reason TEXT,status TEXT DEFAULT 'pending',note TEXT,created_at TEXT);
            CREATE TABLE IF NOT EXISTS vice_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,date TEXT,status TEXT DEFAULT 'pending',note TEXT,created_at TEXT);
            CREATE TABLE IF NOT EXISTS vice_notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,created_at TEXT);
            ''')
    def _build(self):
        l=QVBoxLayout(self); title=QLabel('فراهوش | معاونت آموزشی'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setFont(QFont('B Zar',24,QFont.Bold)); l.addWidget(title)
        menu=QGridLayout(); items=[('تأیید حضور و غیاب','attendance'),('ارجاعات دانش‌آموزی','referrals'),('درخواست جلسات','meetings'),('گزارش آموزشی','reports'),('کلاس‌های مجازی','online'),('اطلاع‌رسانی','notifications'),('برنامه امتحانات','exams'),('بانک سوال','questions'),('پیام‌های دریافتی','inbox'),('ارسال پیام','messages')]
        for i,(text,key) in enumerate(items):
            b=QPushButton(text); b.setMinimumHeight(46); b.clicked.connect(lambda _,k=key:self.open_page(k)); menu.addWidget(b,i//4,i%4)
        l.addLayout(menu); self.stack=QStackedWidget(); l.addWidget(self.stack,1); self._load_pages()
    def _add(self,key,page): self.pages[key]=page; self.stack.addWidget(page)
    def _load_pages(self):
        self._add('inbox',UnifiedInboxPage(role='vice',title='پیام‌ها و رویدادهای مدرسه',parent=self))
        self._add('messages',UnifiedMessengerPage(sender='معاون آموزشی',role='vice',parent=self))
        self._add('attendance',CrudTablePage('حضور و غیاب','attendance',[('id','شناسه'),('student_id','دانش‌آموز'),('date','تاریخ'),('status','وضعیت'),('description','توضیحات')],[('student_id','شناسه دانش‌آموز'),('date','تاریخ'),('status','وضعیت'),('description','توضیحات')],self))
        self._add('referrals',CrudTablePage('ارجاعات دانش‌آموزی','vice_referrals',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher','دبیر'),('reason','دلیل'),('status','وضعیت'),('note','یادداشت'),('created_at','تاریخ')],[('student_id','شناسه دانش‌آموز'),('teacher','دبیر'),('reason','دلیل'),('status','وضعیت'),('note','یادداشت')],self))
        self._add('meetings',CrudTablePage('درخواست جلسات','vice_meetings',[('id','شناسه'),('title','عنوان'),('requester','درخواست‌کننده'),('date','تاریخ'),('status','وضعیت'),('note','یادداشت'),('created_at','تاریخ ثبت')],[('title','عنوان'),('requester','درخواست‌کننده'),('date','تاریخ'),('status','وضعیت'),('note','یادداشت')],self))
        self._add('notifications',CrudTablePage('اطلاع‌رسانی','vice_notifications',[('id','شناسه'),('title','عنوان'),('body','متن'),('created_at','تاریخ')],[('title','عنوان'),('body_memo','متن')],self))
        self._add('online',CrudTablePage('کلاس‌های مجازی','online_classes',[('id','شناسه'),('title','عنوان'),('subject','درس'),('teacher','دبیر'),('grade','پایه'),('class_name','کلاس'),('start_time','شروع'),('status','وضعیت')],[('title','عنوان'),('subject','درس'),('teacher','دبیر'),('grade','پایه'),('class_name','کلاس'),('start_time','زمان شروع'),('status','وضعیت')],self))
        self._add('exams',CrudTablePage('برنامه امتحانات','exam_schedule',[('id','شناسه'),('subject','درس'),('grade','پایه'),('exam_date','تاریخ امتحان'),('exam_start_time','شروع'),('duration','مدت'),('weight','سطح')],[('subject','درس'),('grade','پایه'),('exam_date','تاریخ امتحان'),('exam_start_time','ساعت شروع'),('duration','مدت'),('weight','سطح')],self))
        self._add('questions',CrudTablePage('بانک سوال','quiz_questions',[('id','شناسه'),('question','سوال'),('option1','گزینه ۱'),('option2','گزینه ۲'),('option3','گزینه ۳'),('option4','گزینه ۴'),('correct_answer','پاسخ درست')],[('question_memo','متن سوال'),('option1','گزینه ۱'),('option2','گزینه ۲'),('option3','گزینه ۳'),('option4','گزینه ۴'),('correct_answer','پاسخ درست')],self))
        report=QWidget(); rl=QVBoxLayout(report); b=QPushButton('تولید گزارش از داده‌های واقعی'); out=QLabel(); out.setWordWrap(True); rl.addWidget(b); rl.addWidget(out); rl.addStretch(); b.clicked.connect(lambda:self._report(out)); self._add('reports',report)
    def _report(self,out):
        with db() as c:
            vals=[]
            for t,n in [('students','دانش‌آموز'),('teachers','دبیر'),('attendance','رکورد حضور'),('vice_referrals','ارجاع'),('vice_meetings','جلسه'),('online_classes','کلاس مجازی'),('exam_schedule','امتحان'),('quiz_questions','سوال')]: vals.append(f'{n}: {c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]}')
        out.setText('\n'.join(vals))
    def open_page(self,key):
        self.stack.setCurrentWidget(self.pages[key]); page=self.pages[key]; getattr(page,'load',lambda:None)()
    def refresh_all(self):
        for p in self.pages.values(): getattr(p,'load',lambda:None)()
Panel=EducationPanel
