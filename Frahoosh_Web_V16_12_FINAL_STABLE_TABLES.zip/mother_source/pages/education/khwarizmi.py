from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QInputDialog,
    QMessageBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont



class KhwarizmiPage(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.init_ui()



    def init_ui(self):

        layout = QVBoxLayout()

        layout.setContentsMargins(
            20,
            20,
            20,
            20
        )



        title = QLabel(
            "مدیریت جشنواره خوارزمی"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Nazanin",
                20,
                QFont.Bold
            )
        )


        layout.addWidget(
            title
        )



        subtitle = QLabel(
            "ثبت و پیگیری فعالیت‌های پژوهشی و خلاقانه دانش‌آموزان"
        )

        subtitle.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        layout.addWidget(
            subtitle
        )



        buttons = QHBoxLayout()



        add_btn = QPushButton(
            "➕ ثبت شرکت‌کننده"
        )

        add_btn.clicked.connect(
            self.add_student
        )



        delete_btn = QPushButton(
            "🗑 حذف شرکت‌کننده"
        )

        delete_btn.clicked.connect(
            self.delete_student
        )



        buttons.addWidget(
            add_btn
        )

        buttons.addWidget(
            delete_btn
        )


        layout.addLayout(
            buttons
        )



        self.table = QTableWidget()


        self.table.setColumnCount(
            7
        )


        self.table.setHorizontalHeaderLabels(
            [
                "دانش‌آموز",
                "پایه",
                "حوزه فعالیت",
                "عنوان پروژه",
                "مربی",
                "وضعیت",
                "نتیجه"
            ]
        )


        layout.addWidget(
            self.table
        )



        self.setLayout(
            layout
        )


    # ==============================
    # ثبت شرکت کننده جدید
    # ==============================


    def add_student(self):


        student, ok = QInputDialog.getText(
            self,
            "نام دانش‌آموز",
            "نام و نام خانوادگی:"
        )


        if not ok or not student:
            return



        grade, ok = QInputDialog.getText(
            self,
            "پایه",
            "پایه تحصیلی:"
        )


        if not ok:
            return



        field, ok = QInputDialog.getText(
            self,
            "حوزه فعالیت",
            "علمی، پژوهشی، فرهنگی و ..."
        )


        if not ok:
            return



        project, ok = QInputDialog.getText(
            self,
            "عنوان پروژه",
            "عنوان پروژه:"
        )


        if not ok:
            return



        mentor, ok = QInputDialog.getText(
            self,
            "مربی",
            "نام مربی:"
        )


        if not ok:
            return



        status = "در حال بررسی"


        result = "ثبت نشده"



        row = self.table.rowCount()


        self.table.insertRow(
            row
        )



        values = [

            student,

            grade,

            field,

            project,

            mentor,

            status,

            result

        ]



        for col, value in enumerate(values):

            self.table.setItem(
                row,
                col,
                QTableWidgetItem(value)
            )


    # ==============================
    # حذف شرکت کننده
    # ==============================


    def delete_student(self):

        row = self.table.currentRow()


        if row < 0:

            QMessageBox.warning(
                self,
                "انتخاب شرکت کننده",
                "لطفاً یک شرکت کننده را انتخاب کنید."
            )

            return



        self.table.removeRow(
            row
        )