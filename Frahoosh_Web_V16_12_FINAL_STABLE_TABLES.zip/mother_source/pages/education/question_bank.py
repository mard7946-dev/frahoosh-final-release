import sqlite3, os
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QComboBox,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox,QDialog,QFormLayout,QDialogButtonBox
from PySide6.QtCore import Qt
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','school.db'))

def ensure():
    with sqlite3.connect(DB) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS quiz_questions(id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,question TEXT NOT NULL,option1 TEXT DEFAULT '',option2 TEXT DEFAULT '',option3 TEXT DEFAULT '',option4 TEXT DEFAULT '',correct_answer TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')

class QuestionBankPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); ensure(); self.setWindowTitle('فراهوش | بانک سوال'); self.resize(1100,650); self.setLayoutDirection(Qt.RightToLeft); self.init_ui(); self.load()
    def init_ui(self):
        l=QVBoxLayout(self); f=QHBoxLayout(); self.q=QLineEdit(); self.q.setPlaceholderText('متن سوال'); self.a=QLineEdit(); self.a.setPlaceholderText('گزینه ۱'); self.b=QLineEdit(); self.b.setPlaceholderText('گزینه ۲'); self.c=QLineEdit(); self.c.setPlaceholderText('گزینه ۳'); self.d=QLineEdit(); self.d.setPlaceholderText('گزینه ۴'); self.correct=QComboBox(); self.correct.addItems(['گزینه ۱','گزینه ۲','گزینه ۳','گزینه ۴']); add=QPushButton('ثبت سوال'); add.clicked.connect(self.add); edit=QPushButton('ویرایش سوال'); dele=QPushButton('حذف سوال'); edit.clicked.connect(self.edit); dele.clicked.connect(self.delete)
        for w in [self.q,self.a,self.b,self.c,self.d,self.correct,add,edit,dele]: f.addWidget(w)
        l.addLayout(f); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['ID','سوال','گزینه ۱','گزینه ۲','گزینه ۳','گزینه ۴']); l.addWidget(self.table)
    def load(self):
        with sqlite3.connect(DB) as c: rows=c.execute('SELECT id,question,option1,option2,option3,option4 FROM quiz_questions ORDER BY id DESC').fetchall()
        self.table.setRowCount(0)
        for row in rows:
            r=self.table.rowCount(); self.table.insertRow(r)
            for i,v in enumerate(row): self.table.setItem(r,i,QTableWidgetItem(str(v)))
    def add(self):
        if not self.q.text().strip(): QMessageBox.warning(self,'هشدار','متن سوال الزامی است.'); return
        with sqlite3.connect(DB) as c: c.execute('INSERT INTO quiz_questions(question,option1,option2,option3,option4,correct_answer) VALUES(?,?,?,?,?,?)',(self.q.text(),self.a.text(),self.b.text(),self.c.text(),self.d.text(),self.correct.currentText()))
        self.q.clear(); self.load()
    def delete(self):
        r=self.table.currentRow()
        if r<0:return
        with sqlite3.connect(DB) as c: c.execute('DELETE FROM quiz_questions WHERE id=?',(int(self.table.item(r,0).text()),))
        self.load()

    def edit(self):
        r=self.table.currentRow()
        if r<0:return
        rid=int(self.table.item(r,0).text())
        vals=[self.table.item(r,i).text() for i in range(1,6)]
        d=QDialog(self); f=QFormLayout(d); ws=[]
        for label,val in zip(['سوال','گزینه ۱','گزینه ۲','گزینه ۳','گزینه ۴'],vals):
            w=QLineEdit(val);f.addRow(label,w);ws.append(w)
        box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addWidget(box);box.accepted.connect(d.accept);box.rejected.connect(d.reject)
        if d.exec()!=QDialog.Accepted:return
        with sqlite3.connect(DB) as c:c.execute('UPDATE quiz_questions SET question=?,option1=?,option2=?,option3=?,option4=? WHERE id=?',[x.text() for x in ws]+[rid]);c.commit()
        self.load()
