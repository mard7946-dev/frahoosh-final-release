print("SCHOOL PANEL FILE LOADED")
from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QFrame,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLineEdit,
    QTextEdit,
    QComboBox,
    QFileDialog,
    QDateEdit,
    QMessageBox,
    QSizePolicy
)

from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QPixmap


class SchoolPage(QWidget):

    def __init__(self):

        super().__init__()

        self.logo_path = ""

        self.build_ui()


    # ============================================
    # ساخت صفحه
    # ============================================

    def build_ui(self):

        self.main_layout = QVBoxLayout(self)

        self.main_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )

        self.main_layout.setSpacing(
            20
        )


        # ----------------------------------------
        # عنوان
        # ----------------------------------------

        title = QLabel(
            "مدیریت هوشمند دبیرستان"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setStyleSheet("""

        QLabel{

            font-size:28px;

            font-weight:bold;

            color:#1565C0;

        }

        """)

        self.main_layout.addWidget(
            title
        )


        subtitle = QLabel(
            "اطلاعات و تنظیمات اصلی دبیرستان"
        )

        subtitle.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        subtitle.setStyleSheet("""

        QLabel{

            font-size:15px;

            color:#666666;

        }

        """)

        self.main_layout.addWidget(
            subtitle)


        # ----------------------------------------
        # کارت اصلی
        # ----------------------------------------

        self.main_card = QFrame()

        self.main_card.setObjectName(
            "mainCard"
        )

        self.main_layout.addWidget(
            self.main_card
        )

        self.grid = QGridLayout(
            self.main_card
        )

        self.grid.setContentsMargins(
            25,
            25,
            25,
            25
        )

        self.grid.setHorizontalSpacing(
            20
        )

        self.grid.setVerticalSpacing(
            18
        )

    # ============================================
        # اطلاعات دبیرستان
        # ============================================

        lbl_school = QLabel("نام دبیرستان")
        self.school_name = QLineEdit()

        lbl_period = QLabel("دوره تحصیلی")
        self.period = QComboBox()
        self.period.addItems([
            "دوره اول متوسطه",
            "دوره دوم متوسطه",
            "ابتدایی"
        ])

        lbl_year = QLabel("سال تحصیلی")
        self.school_year = QLineEdit()

        lbl_code = QLabel("کد مدرسه")
        self.school_code = QLineEdit()

        lbl_region = QLabel("منطقه آموزش و پرورش")
        self.region = QLineEdit()

        lbl_manager = QLabel("مدیر دبیرستان")
        self.manager = QLineEdit()

        lbl_edu = QLabel("معاون آموزشی")
        self.education = QLineEdit()

        lbl_exec = QLabel("معاون اجرایی")
        self.executive = QLineEdit()

        lbl_cultural = QLabel("معاون پرورشی")
        self.cultural = QLineEdit()

        lbl_advisor = QLabel("مشاور")
        self.advisor = QLineEdit()

        self.grid.addWidget(lbl_school,0,3)
        self.grid.addWidget(self.school_name,0,2)

        self.grid.addWidget(lbl_period,0,1)
        self.grid.addWidget(self.period,0,0)

        self.grid.addWidget(lbl_year,1,3)
        self.grid.addWidget(self.school_year,1,2)

        self.grid.addWidget(lbl_code,1,1)
        self.grid.addWidget(self.school_code,1,0)

        self.grid.addWidget(lbl_region,2,3)
        self.grid.addWidget(self.region,2,2)

        self.grid.addWidget(lbl_manager,2,1)
        self.grid.addWidget(self.manager,2,0)

        self.grid.addWidget(lbl_edu,3,3)
        self.grid.addWidget(self.education,3,2)

        self.grid.addWidget(lbl_exec,3,1)
        self.grid.addWidget(self.executive,3,0)

        self.grid.addWidget(lbl_cultural,4,3)
        self.grid.addWidget(self.cultural,4,2)

        self.grid.addWidget(lbl_advisor,4,1)
        self.grid.addWidget(self.advisor,4,0)


    # ============================================
        # اطلاعات تماس
        # ============================================

        lbl_phone = QLabel("تلفن دبیرستان")
        self.phone = QLineEdit()

        lbl_mobile = QLabel("شماره همراه")
        self.mobile = QLineEdit()

        lbl_email = QLabel("ایمیل")
        self.email = QLineEdit()

        lbl_site = QLabel("وب سایت")
        self.website = QLineEdit()

        lbl_address = QLabel("آدرس")
        self.address = QTextEdit()
        self.address.setFixedHeight(80)

        self.grid.addWidget(lbl_phone,5,3)
        self.grid.addWidget(self.phone,5,2)

        self.grid.addWidget(lbl_mobile,5,1)
        self.grid.addWidget(self.mobile,5,0)

        self.grid.addWidget(lbl_email,6,3)
        self.grid.addWidget(self.email,6,2)

        self.grid.addWidget(lbl_site,6,1)
        self.grid.addWidget(self.website,6,0)

        self.grid.addWidget(lbl_address,7,3)
        self.grid.addWidget(self.address,7,2,1,2)


        # ============================================
        # لوگوی دبیرستان
        # ============================================

        self.logo_label = QLabel()

        self.logo_label.setFixedSize(
            160,
            160
        )

        self.logo_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.logo_label.setStyleSheet("""

        QLabel{

            border:2px dashed #1565C0;
            border-radius:12px;
            background:#fafafa;

        }

        """)

        self.logo_button = QPushButton(
            "انتخاب لوگو"
        )

        self.logo_button.clicked.connect(
            self.select_logo
        )

        logo_layout = QVBoxLayout()

        logo_layout.addWidget(
            self.logo_label
        )

        logo_layout.addWidget(
            self.logo_button
        )

        self.grid.addLayout(
            logo_layout,
            8,
            0,
            2,
            4
        )

    # ============================================
        # تنظیمات دبیرستان
        # ============================================

        lbl_finish = QLabel(
            "تاریخ پایان سال تحصیلی"
        )

        self.finish_date = QDateEdit()

        self.finish_date.setCalendarPopup(
            True
        )

        self.finish_date.setDate(
            QDate.currentDate()
        )


        lbl_status = QLabel(
            "وضعیت سامانه"
        )

        self.status = QComboBox()

        self.status.addItems([
            "فعال",
            "غیرفعال"
        ])


        self.grid.addWidget(
            lbl_finish,
            10,
            3
        )

        self.grid.addWidget(
            self.finish_date,
            10,
            2
        )

        self.grid.addWidget(
            lbl_status,
            10,
            1
        )

        self.grid.addWidget(
            self.status,
            10,
            0
        )


        # ============================================
        # دکمه ها
        # ============================================

        buttons = QHBoxLayout()

        self.save_btn = QPushButton(
            "💾 ذخیره اطلاعات"
        )

        self.edit_btn = QPushButton(
            "✏️ ویرایش"
        )

        self.clear_btn = QPushButton(
            "🗑 پاک کردن"
        )

        self.print_btn = QPushButton(
            "🖨 چاپ"
        )

        buttons.addStretch()

        buttons.addWidget(
            self.save_btn
        )

        buttons.addWidget(
            self.edit_btn
        )

        buttons.addWidget(
            self.clear_btn
        )

        buttons.addWidget(
            self.print_btn
        )

        buttons.addStretch()

        self.main_layout.addLayout(
            buttons
        )

        self.setStyleSheet()


        # ============================================
        # اتصال رویدادها
        # ============================================

        self.save_btn.clicked.connect(
            self.save_school
        )

        self.edit_btn.clicked.connect(
            self.edit_school
        )

        self.clear_btn.clicked.connect(
            self.clear_form
        )

        self.print_btn.clicked.connect(
            self.print_school
        )

    # ============================================
    # انتخاب لوگو
    # ============================================

    def select_logo(self):

        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "انتخاب لوگوی دبیرستان",
            "",
            "Images (*.png *.jpg *.jpeg)"
        )

        if file_name:

            self.logo_path = file_name

            pix = QPixmap(file_name)

            self.logo_label.setPixmap(
                pix.scaled(
                    150,
                    150,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
            )


    # ============================================
    # ذخیره اطلاعات
    # ============================================

    def save_school(self):

        QMessageBox.information(
            self,
            "فراهوش",
            "اطلاعات دبیرستان با موفقیت ذخیره شد."
        )


    # ============================================
    # ویرایش
    # ============================================

    def edit_school(self):

        QMessageBox.information(
            self,
            "فراهوش",
            "حالت ویرایش فعال شد."
        )


    # ============================================
    # پاک کردن فرم
    # ============================================

    def clear_form(self):

        self.school_name.clear()

        self.school_year.clear()

        self.school_code.clear()

        self.region.clear()

        self.manager.clear()

        self.education.clear()

        self.executive.clear()

        self.cultural.clear()

        self.advisor.clear()

        self.phone.clear()

        self.mobile.clear()

        self.email.clear()

        self.website.clear()

        self.address.clear()

        self.logo_label.clear()

        self.logo_path = ""


    # ============================================
    # چاپ اطلاعات
    # ============================================

    def print_school(self):

        QMessageBox.information(
            self,
            "فراهوش",
            "امکان چاپ در نسخه بعدی اضافه خواهد شد."
        )


    # ============================================
    # استایل
    # ============================================

    def setStyleSheet(self):

        super().setStyleSheet("""

        QWidget{

            background:#f4f7fb;

            font-family:B Nazanin;

            font-size:12pt;

        }

        QFrame#mainCard{

            background:white;

            border-radius:18px;

            border:1px solid #d9d9d9;

        }

        QLabel{

            color:#333;

        }

        QLineEdit,
        QTextEdit,
        QComboBox,
        QDateEdit{

            border:1px solid #cfd8dc;

            border-radius:8px;

            padding:8px;

            background:white;

        }

        QPushButton{

            background:#1565C0;

            color:white;

            border:none;

            border-radius:10px;

            padding:10px 18px;

            font-weight:bold;

        }

        QPushButton:hover{

            background:#0d47a1;

        }

        """)