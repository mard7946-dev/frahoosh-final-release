import sqlite3
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QPushButton,QLabel,QStackedWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from ui.data_crud import CrudTablePage,db
from services.core_bootstrap import bootstrap
from ui.unified_inbox import UnifiedInboxPage,UnifiedMessengerPage
from ui.complete_module_pages import CompleteTabs, teacher_specs
from teacher.online_classes import OnlineClassesPage
from teacher.exam_scheduler import ExamSchedulerPage

class ClassesPage(CrudTablePage):
    def __init__(self,teacher_name='',teacher_id=None,parent=None):
        self.teacher_name=teacher_name; self.teacher_id=teacher_id
        super().__init__('کلاس‌های دبیر','teacher_classes',[('id','شناسه'),('teacher_id','شناسه دبیر'),('teacher_name','دبیر'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('active','فعال')],[('teacher_id','شناسه دبیر'),('teacher_name','دبیر'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('active','فعال')],parent)
    def load(self):
        try:
            with db() as c:
                rows=c.execute('''SELECT id,teacher_id,teacher_name,subject,grade,class_name,active FROM teacher_classes WHERE (? IS NULL OR teacher_id=? OR teacher_name=?) ORDER BY id DESC''',(self.teacher_id,self.teacher_id,self.teacher_name)).fetchall()
            self.table.setRowCount(len(rows))
            for i,r in enumerate(rows):
                for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        except Exception: super().load()

class Panel(QWidget):
    def __init__(self,parent=None,teacher_name=None,teacher_id=None):
        super().__init__(parent);bootstrap();self.teacher_name=teacher_name or 'دبیر';self.teacher_id=teacher_id or self._resolve_teacher_id();self.pages={};self.setLayoutDirection(Qt.RightToLeft);self._ensure();self._build()
    def _resolve_teacher_id(self):
        with db() as c:
            r=c.execute("SELECT id FROM teachers WHERE trim(first_name||' '||last_name)=? LIMIT 1",(self.teacher_name.strip(),)).fetchone()
        return r[0] if r else None
    def _ensure(self):
        with db() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS teacher_attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER,student_id INTEGER,student_name TEXT,status TEXT,note TEXT,recorded_at TEXT);CREATE TABLE IF NOT EXISTS lesson_plans(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,subject TEXT,grade TEXT,class_name TEXT,title TEXT,objective TEXT,content TEXT,session_date TEXT,created_at TEXT);CREATE TABLE IF NOT EXISTS teacher_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,student_id INTEGER,student_name TEXT,parent_name TEXT,meeting_at TEXT,subject TEXT,status TEXT DEFAULT 'requested',report TEXT,created_at TEXT);CREATE TABLE IF NOT EXISTS teacher_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,subject TEXT,grade TEXT,class_name TEXT,active INTEGER DEFAULT 1,created_at TEXT);''')
    def _build(self):
        l=QVBoxLayout(self);t=QLabel(f'فراهوش | پنل دبیر — {self.teacher_name}');t.setAlignment(Qt.AlignmentFlag.AlignCenter);t.setFont(QFont('B Zar',23,QFont.Bold));l.addWidget(t)
        info=QLabel('کلاس‌ها از اطلاعات مدیریت تغذیه می‌شوند و عملیات این پنل در دیتابیس ثبت می‌شود.');info.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(info)
        menu=QGridLayout();items=[('کلاس‌های من','classes'),('حضور و غیاب','attendance'),('ثبت نمرات','grades'),('تکالیف','assignments'),('آزمون آنلاین','quiz'),('کلاس مجازی','online'),('طرح درس','lesson'),('جلسات اولیا','meetings'),('گزارش‌ها','reports'),('جداول آموزشی کامل','complete'),('پیام‌های دریافتی','inbox'),('ارسال پیام','messages')]
        for i,(text,key) in enumerate(items):b=QPushButton(text);b.setMinimumHeight(45);b.clicked.connect(lambda _,k=key:self.open_page(k));menu.addWidget(b,i//5,i%5)
        l.addLayout(menu);self.stack=QStackedWidget();l.addWidget(self.stack,1);self._load()
    def _add(self,k,p):self.pages[k]=p;self.stack.addWidget(p)
    def _load(self):
        filt='teacher_id=?' if self.teacher_id else None; fargs=(self.teacher_id,) if self.teacher_id else ()
        self._add('classes',ClassesPage(self.teacher_name,self.teacher_id,self))
        self._add('attendance',CrudTablePage('حضور و غیاب دبیر','teacher_attendance',[('id','شناسه'),('class_id','کلاس'),('student_id','دانش‌آموز'),('student_name','نام دانش‌آموز'),('status','وضعیت'),('note','یادداشت'),('recorded_at','تاریخ')],[('class_id','شناسه کلاس'),('student_id','شناسه دانش‌آموز'),('student_name','نام دانش‌آموز'),('status','وضعیت'),('note','یادداشت')],self))
        self._add('grades',CrudTablePage('دفتر نمرات','grades',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('exam_name','ارزشیابی'),('score','نمره'),('description','توضیحات'),('created_at','تاریخ')],[('student_id','شناسه دانش‌آموز'),('teacher_id','شناسه دبیر'),('subject','درس'),('exam_name','عنوان ارزشیابی'),('score','نمره'),('description','توضیحات')],self,where=filt,where_args=fargs))
        self._add('assignments',CrudTablePage('تکالیف','assignments',[('id','شناسه'),('teacher_id','دبیر'),('teacher','نام دبیر'),('class_name','کلاس'),('subject','درس'),('title','عنوان'),('description','توضیحات'),('status','وضعیت'),('due_date','مهلت'),('created_at','تاریخ')],[('teacher_id','شناسه دبیر'),('teacher','نام دبیر'),('class_name','کلاس'),('subject','درس'),('title','عنوان'),('description','توضیحات'),('status','وضعیت'),('due_date','مهلت')],self,where=filt,where_args=fargs))
        self._add('quiz',ExamSchedulerPage(self.teacher_id,self.teacher_name,self))
        self._add('online',OnlineClassesPage(self.teacher_name,self))
        self._add('lesson',CrudTablePage('طرح درس','lesson_plans',[('id','شناسه'),('teacher_id','دبیر'),('teacher_name','نام دبیر'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('title','عنوان'),('objective','هدف'),('content','محتوا'),('session_date','تاریخ جلسه'),('created_at','ثبت')],[('teacher_id','شناسه دبیر'),('teacher_name','نام دبیر'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('title','عنوان'),('objective','هدف'),('content_memo','محتوا'),('session_date','تاریخ جلسه')],self,where=filt,where_args=fargs))
        self._add('meetings',CrudTablePage('جلسات اولیا','teacher_meetings',[('id','شناسه'),('teacher_id','دبیر'),('student_id','دانش‌آموز'),('student_name','نام دانش‌آموز'),('parent_name','ولی'),('meeting_at','زمان'),('subject','موضوع'),('status','وضعیت'),('report','گزارش')],[('teacher_id','شناسه دبیر'),('student_id','شناسه دانش‌آموز'),('student_name','دانش‌آموز'),('parent_name','ولی'),('meeting_at','زمان'),('subject','موضوع'),('status','وضعیت'),('report_memo','گزارش')],self,where=filt,where_args=fargs))
        self._add('inbox',UnifiedInboxPage(role='teacher',title='پیام‌ها و رویدادهای مدرسه',parent=self))
        self._add('messages',UnifiedMessengerPage(sender=self.teacher_name,role='teacher',parent=self))
        self._add('complete',CompleteTabs(teacher_specs(),'دبیر | جداول آموزشی کامل',self))
        report=QWidget();rl=QVBoxLayout(report);b=QPushButton('تولید گزارش عملکرد دبیر');out=QLabel();out.setWordWrap(True);rl.addWidget(b);rl.addWidget(out);rl.addStretch();b.clicked.connect(lambda:self._report(out));self._add('reports',report)
    def _report(self,out):
        with db() as c:
            q=lambda t:c.execute(f'SELECT COUNT(*) FROM {t} WHERE teacher_id=?',(self.teacher_id,)).fetchone()[0] if self.teacher_id else c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
            out.setText(f'دبیر: {self.teacher_name}\nکلاس‌ها: {q("teacher_classes")}\nنمرات: {q("grades")}\nتکالیف: {q("assignments")}\nطرح درس: {q("lesson_plans")}\nجلسات: {q("teacher_meetings")}')
    def open_page(self,k):self.stack.setCurrentWidget(self.pages[k]);getattr(self.pages[k],'load',lambda:None)()
