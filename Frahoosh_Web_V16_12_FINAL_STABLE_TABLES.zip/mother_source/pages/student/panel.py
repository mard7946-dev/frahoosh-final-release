import sqlite3
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QPushButton,QLabel,QStackedWidget,QTableWidget,QTableWidgetItem,QProgressBar,QHBoxLayout
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from ui.data_crud import CrudTablePage,db
from services.core_bootstrap import bootstrap
from services.data_link_service import student_for_username
from utils.jalali import iso_to_jalali
from services.school_context import school_info, student_info
from student.online_classes import OnlineClassesPage
from ui.payment_gateway import OnlinePaymentPage


class Panel(QWidget):
    """Student panel using the same single-selected-student data flow as Parent.

    The logged-in student is resolved once, then every page reads from that same
    student context. No page creates a second student identity or expects a
    manually entered student id.
    """
    def __init__(self,parent=None,student_id=None,username=None):
        super().__init__(parent)
        bootstrap()
        self.username = username or getattr(parent,'current_username',None) or 'student'
        self.student_id = self._resolve_student(student_id)
        self.pages={}
        self.setLayoutDirection(Qt.RightToLeft)
        self._ensure()
        self._build()

    def _resolve_student(self, supplied=None):
        try:
            sid = student_for_username(self.username)
            if sid:
                return int(sid)
        except Exception:
            pass
        if supplied:
            try:
                return int(supplied)
            except Exception:
                pass
        # Last safe fallback: resolve by username/student_code if the account
        # was not linked yet. This is only a resolver, not a new identity path.
        try:
            with db() as c:
                r=c.execute('''SELECT s.id FROM students s
                    LEFT JOIN users u ON u.linked_student_id=s.id
                    WHERE u.username=? OR s.student_code=? LIMIT 1''',
                    (self.username,self.username)).fetchone()
                return int(r['id']) if r else None
        except Exception:
            return None


    def _refresh_school_context(self):
        si=school_info(); st=student_info(self.student_id) if self.student_id else None
        if st:
            full=f"{st.get('first_name','')} {st.get('last_name','')}".strip()
            self.school_context.setText(f"🏫 {si['name']} | سال تحصیلی: {si['year']}   •   👤 {full} | پایه: {st.get('grade','-')} | کلاس: {st.get('class_name','-')}")
        else:
            self.school_context.setText(f"🏫 {si['name']} | سال تحصیلی: {si['year']}   •   حساب دانش‌آموز هنوز به پرونده دانش‌آموزی متصل نشده است.")

    def _ensure(self):
        # Do not create a shadow student_assignments table. Teachers write to
        # the canonical assignments table and students read that same table.
        with db() as c:
            c.execute('CREATE INDEX IF NOT EXISTS idx_grades_student ON grades(student_id)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_assignments_student ON assignments(student_id)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_registrations_student ON student_registrations(student_id)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_discipline_student ON discipline_records(student_id)')

    def _build(self):
        l=QVBoxLayout(self)
        t=QLabel('فراهوش | پنل دانش‌آموز'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont('B Zar',24,QFont.Bold)); l.addWidget(t)
        info=QLabel('تمام بخش‌ها با همان دانش‌آموز واردشده از دیتابیس اصلی مدرسه خوانده می‌شوند.')
        info.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(info)
        self.school_context=QLabel(); self.school_context.setAlignment(Qt.AlignmentFlag.AlignCenter); self.school_context.setWordWrap(True); l.addWidget(self.school_context)
        self._refresh_school_context()
        menu=QGridLayout()
        items=[('پروفایل','profile'),('حضور و غیاب','attendance'),('نمرات','grades'),('تکالیف','assignments'),('📥 صندوق پیام','messages'),('مسابقات و فعالیت‌ها','activities'),('برنامه هفتگی','schedule'),('امتحانات','exams'),('گزارش عملکرد','reports'),('کلاس آنلاین','online'),('پرداخت آنلاین','payment')]
        for i,(text,key) in enumerate(items):
            b=QPushButton(text); b.setMinimumHeight(46); b.clicked.connect(lambda _,k=key:self.open_page(k)); menu.addWidget(b,i//4,i%4)
        l.addLayout(menu)
        self.stack=QStackedWidget(); l.addWidget(self.stack,1)
        self._load()

    def _add(self,k,p):
        self.pages[k]=p; self.stack.addWidget(p)

    def _student_where(self, field='student_id'):
        return (f'{field}=?',(self.student_id,)) if self.student_id else ('1=0',())

    def _load(self):
        # 1) Profile — exactly the student's own row.
        w,a=self._student_where('id')
        self._add('profile',CrudTablePage(
            'پروفایل دانش‌آموز','students',
            [('id','شناسه'),('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('student_code','کد دانش‌آموزی'),('grade','پایه'),('class_name','کلاس'),('phone','تلفن'),('parent_phone','تلفن ولی'),('email','ایمیل'),('address','نشانی')],
            [('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('student_code','کد دانش‌آموزی'),('grade','پایه'),('class_name','کلاس'),('phone','تلفن'),('parent_phone','تلفن ولی'),('email','ایمیل'),('address','نشانی')],
            self,where=w,where_args=a,readonly=True))

        # 2) Attendance — canonical teacher/education table.
        w,a=self._student_where()
        self._add('attendance',CrudTablePage(
            'حضور و غیاب','attendance',
            [('id','شناسه'),('student_id','دانش‌آموز'),('date','تاریخ'),('status','وضعیت'),('description','توضیحات')],
            [('student_id','دانش‌آموز'),('date','تاریخ'),('status','وضعیت'),('description','توضیحات')],
            self,where=w,where_args=a,readonly=True))

        # 3) Grades — same source and filtering rule used by Parent. This is
        # deliberately not a copy/snapshot table.
        self._add('grades',StudentGrades(self,self.student_id))

        # 4) Assignments — canonical assignments table. A task addressed to
        # this student, to the student's class, or broadcast to all students is visible.
        self._add('assignments',StudentAssignments(self,self.student_id))

        # 5) Messages — same receiver-resolution idea as Parent, extended for
        # student accounts and student identifiers.
        self._add('messages',StudentMessages(self,self.username,self.student_id))

        # 6) Cultural registrations — canonical student_registrations table.
        self._add('activities',CrudTablePage(
            'ثبت‌نام‌های فرهنگی','student_registrations',
            [('id','شناسه'),('student_id','دانش‌آموز'),('activity_title','فعالیت'),('activity_kind','نوع'),('fee','هزینه'),('payment_status','وضعیت پرداخت'),('registration_code','کد'),('registered_at','تاریخ')],
            [('student_id','دانش‌آموز'),('activity_title','فعالیت'),('activity_kind','نوع'),('fee','هزینه'),('payment_status','وضعیت پرداخت'),('registration_code','کد')],
            self,where=w,where_args=a,readonly=True))

        # 7) Weekly schedule — filtered to the student's grade/class.
        self._add('schedule',StudentSchedule(self,self.student_id))

        # 8) Exams — filtered to the student's grade.
        self._add('exams',StudentExams(self,self.student_id))
        st=student_info(self.student_id) if self.student_id else {}
        self._add('online',OnlineClassesPage(st.get('grade') if st else None,st.get('class_name') if st else None,self.student_id,self))
        self._add('payment',OnlinePaymentPage(self,self.username,'student',self.student_id))

        # 9) Reports — canonical report_cards table.
        self._add('reports',CrudTablePage(
            'گزارش عملکرد دانش‌آموز','report_cards',
            [('id','شناسه'),('student_id','دانش‌آموز'),('term','نوبت'),('average','معدل'),('description','توضیحات'),('created_at','تاریخ')],
            [('student_id','دانش‌آموز'),('term','نوبت'),('average','معدل'),('description','توضیحات')],
            self,where=w,where_args=a,readonly=True))

    def open_page(self,k):
        page=self.pages[k]
        self.stack.setCurrentWidget(page)
        if hasattr(page,'load'):
            try: page.load()
            except Exception: pass
        elif hasattr(page,'load_student'):
            try: page.load_student(self.student_id)
            except Exception: pass



class StudentSchedule(QWidget):
    """Read-only weekly schedule for the logged-in student's grade/class."""
    def __init__(self,parent=None,student_id=None):
        super().__init__(parent); self.student_id=student_id
        l=QVBoxLayout(self); self.info=QLabel(); self.info.setAlignment(Qt.AlignmentFlag.AlignCenter); self.info.setWordWrap(True); l.addWidget(self.info)
        self.table=QTableWidget(); l.addWidget(self.table); self.load()

    def load_student(self,sid): self.student_id=sid; self.load()

    def load(self):
        st=student_info(self.student_id) if self.student_id else None
        grade=(st or {}).get('grade'); cls=(st or {}).get('class_name')
        self.info.setText(f"برنامه هفتگی | پایه: {grade or '-'} | کلاس: {cls or '-'}")
        with db() as c:
            rows=c.execute("""SELECT teacher,subject,hours,bell_pattern,class_names
                              FROM weekly_schedule
                              WHERE (? IS NULL OR grade=?)
                                AND (? IS NULL OR class_names LIKE '%'||?||'%')
                              ORDER BY id DESC""",(grade,grade,cls,cls)).fetchall()
        cols=['دبیر','درس','ساعت','زنگ','کلاس‌ها']
        self.table.setColumnCount(len(cols)); self.table.setHorizontalHeaderLabels(cols); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):
                self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        if not rows:
            self.info.setText(self.info.text()+"\nبرای این پایه/کلاس هنوز برنامه‌ای ثبت نشده است.")

class StudentExams(QWidget):
    """Read-only exam schedule for the logged-in student's grade."""
    def __init__(self,parent=None,student_id=None):
        super().__init__(parent); self.student_id=student_id
        l=QVBoxLayout(self); self.info=QLabel(); self.info.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(self.info)
        self.table=QTableWidget(); l.addWidget(self.table); self.load()

    def load_student(self,sid): self.student_id=sid; self.load()

    def load(self):
        st=student_info(self.student_id) if self.student_id else None
        grade=(st or {}).get('grade')
        self.info.setText(f"برنامه امتحانات | پایه: {grade or '-'}")
        with db() as c:
            rows=c.execute("""SELECT subject,exam_date,duration,weight,exam_start_time,exam_end_time
                              FROM exam_schedule
                              WHERE (? IS NULL OR grade=?)
                              ORDER BY exam_date ASC, id ASC""",(grade,grade)).fetchall()
        cols=['درس','تاریخ امتحان','مدت','ضریب','شروع','پایان']
        self.table.setColumnCount(len(cols)); self.table.setHorizontalHeaderLabels(cols); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):
                self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        if not rows:
            self.info.setText(self.info.text()+"\nبرای این پایه هنوز برنامه امتحانی ثبت نشده است.")

class StudentGrades(QWidget):
    """Student view of the exact canonical grades table used by Parent."""
    def __init__(self,parent=None,student_id=None):
        super().__init__(parent); self.student_id=student_id
        l=QVBoxLayout(self); self.table=QTableWidget(); l.addWidget(self.table); self.load()

    def load_student(self,sid): self.student_id=sid; self.load()

    def load(self):
        with db() as c:
            rows=c.execute('''SELECT subject,exam_name,score,description,created_at
                              FROM grades WHERE student_id=? ORDER BY id DESC''',(self.student_id,)).fetchall() if self.student_id else []
        self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['درس','آزمون','نمره','توضیحات','تاریخ شمسی']); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r['subject'],r['exam_name'],r['score'],r['description'],iso_to_jalali(r['created_at']) if r['created_at'] else '']
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))


class StudentAssignments(QWidget):
    """Student view of canonical teacher assignments, using class + broadcast rules."""
    def __init__(self,parent=None,student_id=None):
        super().__init__(parent); self.student_id=student_id; self.class_name=''; self.ui(); self.load()

    def ui(self):
        l=QVBoxLayout(self); self.table=QTableWidget(); l.addWidget(self.table)

    def load_student(self,sid): self.student_id=sid; self.load()

    def load(self):
        self.class_name=''
        if self.student_id:
            with db() as c:
                r=c.execute('SELECT class_name FROM students WHERE id=?',(self.student_id,)).fetchone()
                self.class_name=(r['class_name'] or '') if r else ''
        if not self.student_id:
            rows=[]
        else:
            with db() as c:
                if self.class_name:
                    rows=c.execute('''SELECT id,teacher,class_name,subject,title,description,status,due_date,created_at
                                      FROM assignments
                                      WHERE student_id=? OR student_id IS NULL OR student_id=0 OR class_name=?
                                      ORDER BY id DESC''',(self.student_id,self.class_name)).fetchall()
                else:
                    rows=c.execute('''SELECT id,teacher,class_name,subject,title,description,status,due_date,created_at
                                      FROM assignments
                                      WHERE student_id=? OR student_id IS NULL OR student_id=0
                                      ORDER BY id DESC''',(self.student_id,)).fetchall()
        self.table.setColumnCount(9); self.table.setHorizontalHeaderLabels(['شناسه','دبیر','کلاس','درس','عنوان','توضیحات','وضعیت','مهلت','تاریخ']); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r[k] for k in ('id','teacher','class_name','subject','title','description','status','due_date','created_at')]
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))


class StudentMessages(QWidget):
    """Student view of canonical school messages using the same receiver logic as Parent."""
    def __init__(self,parent=None,username='student',student_id=None):
        super().__init__(parent); self.username=username; self.student_id=student_id; self.table=QTableWidget(); l=QVBoxLayout(self); l.addWidget(QLabel('پیام‌های مدرسه')); l.addWidget(self.table); self.load()

    def load_student(self,sid): self.student_id=sid; self.load()

    def load(self):
        try:
            from services.unified_event_service import inbox
            rows=inbox(self.username,200)
            import json
            self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['نوع','عنوان','فرستنده','جزئیات','تاریخ']); self.table.setRowCount(len(rows))
            for i,r in enumerate(rows):
                try:
                    d=json.loads(r.get('payload') or '{}'); detail=' | '.join(f"{k}: {v}" for k,v in d.items() if v not in ('',None))[:700]
                except Exception: detail=str(r.get('payload') or '')[:700]
                vals=[r.get('event_type',''),r.get('title',''),r.get('actor_username','سیستم/مدرسه'),detail,r.get('created_at','')]
                for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        except Exception:
            self.table.setRowCount(0)
