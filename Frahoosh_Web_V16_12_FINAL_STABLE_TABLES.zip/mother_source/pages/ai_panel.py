import sqlite3,os
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QPushButton,QLabel,QTextEdit,QMessageBox
from PySide6.QtCore import Qt
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
def db():return sqlite3.connect(DB)
class Panel(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);l=QVBoxLayout(self);t=QLabel('پنل هوش مصنوعی');t.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(t);g=QGridLayout();self.out=QTextEdit();self.out.setReadOnly(True)
  actions=[('تحلیل عملکرد دانش‌آموزان','دانش‌آموزان: {students}\nمیانگین نمرات: {avg}'),('دستیار هوشمند دبیر','تعداد دبیران: {teachers}\nپیشنهاد: بررسی نمرات و حضور و غیاب کلاس‌ها'),('گزارش‌های هوشمند','دانش‌آموزان: {students}\nدبیران: {teachers}\nنمرات ثبت‌شده: {grades}'),('پیشنهادهای آموزشی','پیشنهاد: دانش‌آموزان با غیبت/نمره پایین برای پیگیری مشاوره‌ای بررسی شوند.'),('تحلیل روند پیشرفت','برای روند دقیق، داده‌های نمرات هر دانش‌آموز در بازه‌های زمانی تحلیل می‌شود.'),('مرکز تصمیم‌یار مدیریت','تصمیم‌یار: ابتدا گزارش حضور و غیاب و میانگین نمرات را بررسی کنید.')]
  for i,(name,msg) in enumerate(actions):b=QPushButton(name);b.setMinimumHeight(50);b.clicked.connect(lambda _,m=msg:self.run(m));g.addWidget(b,i//2,i%2)
  l.addLayout(g);l.addWidget(self.out);self.setStyleSheet('QWidget{background:#F5F3FF;} QPushButton{background:#7C3AED;color:white;padding:10px;border-radius:9px;}')
 def run(self,msg):
  try:
   with db() as c:
    vals={'students':c.execute('SELECT COUNT(*) FROM students').fetchone()[0],'teachers':c.execute('SELECT COUNT(*) FROM teachers').fetchone()[0],'grades':c.execute('SELECT COUNT(*) FROM grades').fetchone()[0],'avg':round(c.execute('SELECT COALESCE(AVG(score),0) FROM grades').fetchone()[0],2)}
   self.out.setPlainText(msg.format(**vals))
  except Exception as e:self.out.setPlainText('خطا: '+str(e))
