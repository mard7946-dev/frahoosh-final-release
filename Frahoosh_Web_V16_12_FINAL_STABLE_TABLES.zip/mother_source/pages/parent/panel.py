import sqlite3, os
from datetime import datetime
from pathlib import Path
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,QTableWidget,
    QTableWidgetItem,QMessageBox,QLineEdit,QTabWidget,QFormLayout,QTextEdit,QDateEdit,QProgressBar,QListWidget,QListWidgetItem)
from utils.shamsi_date_edit import ShamsiDateEdit
from PySide6.QtCore import Qt, QDate, QTimer
from ui.complete_module_pages import CompleteTabs, parent_specs
from pages.surveys import PublicSurvey
from utils.jalali import iso_to_jalali
from services.school_context import school_info, student_info
from ui.payment_gateway import OnlinePaymentPage

DB=str(Path(__file__).resolve().parents[2]/'school.db')

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def ensure_parent_schema():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS parent_children(
            parent_username TEXT NOT NULL, student_id INTEGER NOT NULL,
            PRIMARY KEY(parent_username,student_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS weekly_schedule(
            id INTEGER PRIMARY KEY AUTOINCREMENT, grade TEXT, class_name TEXT,
            day TEXT, period TEXT, teacher_name TEXT, subject TEXT,
            sessions_per_week TEXT, hours_per_week TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS exam_schedule(
            id INTEGER PRIMARY KEY AUTOINCREMENT, grade TEXT, class_name TEXT,
            exam_date TEXT, exam_time TEXT, subject TEXT, exam_name TEXT,
            room TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS parent_meetings(
            id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL,
            teacher_id INTEGER NOT NULL DEFAULT 0, parent_phone TEXT DEFAULT '',
            reason TEXT DEFAULT '', meeting_date TEXT, status TEXT DEFAULT 'pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS transport_requests(
            id INTEGER PRIMARY KEY AUTOINCREMENT,parent_username TEXT,address TEXT,
            vehicle_type TEXT,origin TEXT,destination TEXT,note TEXT,
            status TEXT DEFAULT 'در انتظار',created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')

def child_ids(username):
    with db() as c:
        return [r['student_id'] for r in c.execute(
            'SELECT student_id FROM parent_children WHERE parent_username=?',(username,)).fetchall()]

class ChildSelector(QWidget):
    def __init__(self,parent=None,username='parent'):
        super().__init__(parent); self.username=username; self.current_student_id=None; self.selected_student_ids=[]; self.ui(); self.load()
    def ui(self):
        l=QVBoxLayout(self); l.addWidget(QLabel('انتخاب یک یا چند فرزند'))
        self.list=QListWidget(); self.list.setSelectionMode(QListWidget.MultiSelection); l.addWidget(self.list)
        self.refresh=QPushButton('اعمال انتخاب'); self.refresh.clicked.connect(self.changed); l.addWidget(self.refresh)
    def load(self):
        self.list.clear()
        with db() as c:
            rows=c.execute('''SELECT s.id,s.first_name,s.last_name,s.student_code,s.grade,s.class_name
                FROM students s JOIN parent_children p ON p.student_id=s.id
                WHERE p.parent_username=? ORDER BY s.last_name,s.first_name''',(self.username,)).fetchall()
        for r in rows:
            item=QListWidgetItem(f"{r['first_name']} {r['last_name']} | {r['student_code'] or '-'} | {r['grade'] or ''} {r['class_name'] or ''}")
            item.setData(Qt.UserRole,r['id']); self.list.addItem(item)
    def changed(self):
        self.selected_student_ids=[i.data(Qt.UserRole) for i in self.list.selectedItems()]
        self.current_student_id=self.selected_student_ids[0] if self.selected_student_ids else None
        host=self.parent(); panel=None
        p=host
        while p is not None:
            if p.__class__.__name__ == 'Panel' and hasattr(p,'student_changed'):
                panel=p; break
            p=p.parentWidget() if hasattr(p,'parentWidget') else None
        if panel is not None: panel.student_changed(self.current_student_id,self.selected_student_ids)

class Children(QWidget):
    def __init__(self,parent=None,username='parent'):
        super().__init__(parent); self.username=username; self.ui(); self.load()
    def ui(self):
        l=QVBoxLayout(self); title=QLabel('فرزندان من | مدیریت چندفرزندی'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(title)
        bar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('جستجوی دانش‌آموز برای افزودن'); self.available=QComboBox(); self.available.addItem('انتخاب دانش‌آموز',None)
        add=QPushButton('افزودن فرزند'); remove=QPushButton('حذف فرزند'); ref=QPushButton('تازه‌سازی')
        for x in (self.search,self.available,add,remove,ref):bar.addWidget(x)
        l.addLayout(bar); self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['شناسه','نام','نام خانوادگی','کد دانش‌آموزی','پایه','کلاس','تلفن والد']); l.addWidget(self.table)
        add.clicked.connect(self.add_child); remove.clicked.connect(self.remove_child); ref.clicked.connect(self.load); self.search.textChanged.connect(self.fill_available)
        with db() as c:c.execute('CREATE TABLE IF NOT EXISTS parent_children(parent_username TEXT NOT NULL,student_id INTEGER NOT NULL,PRIMARY KEY(parent_username,student_id))')
        self.fill_available()
    def fill_available(self):
        s='%'+self.search.text().strip()+'%'; self.available.clear(); self.available.addItem('انتخاب دانش‌آموز',None)
        with db() as c: rows=c.execute('SELECT id,first_name,last_name,student_code,grade,class_name FROM students WHERE first_name LIKE ? OR last_name LIKE ? OR student_code LIKE ? ORDER BY last_name,first_name',(s,s,s)).fetchall()
        for r in rows:self.available.addItem(f"{r['first_name']} {r['last_name']} | {r['student_code'] or '-'} | {r['grade'] or ''} {r['class_name'] or ''}",r['id'])
    def load(self):
        with db() as c: rows=c.execute('''SELECT s.id,s.first_name,s.last_name,s.student_code,s.grade,s.class_name,s.parent_phone FROM students s JOIN parent_children p ON p.student_id=s.id WHERE p.parent_username=? ORDER BY s.last_name,s.first_name''',(self.username,)).fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(['id','first_name','last_name','student_code','grade','class_name','parent_phone']):self.table.setItem(i,j,QTableWidgetItem(str(r[k] or '')))
    def add_child(self):
        sid=self.available.currentData()
        if sid is None:return QMessageBox.warning(self,'فرزندان','یک دانش‌آموز را انتخاب کنید.')
        with db() as c:c.execute('INSERT OR IGNORE INTO parent_children(parent_username,student_id) VALUES(?,?)',(self.username,sid));c.commit()
        self.load()
        host=self.parent()
        while host is not None:
            if host.__class__.__name__ == 'Panel' and hasattr(host,'student_changed'):
                host.student_changed(sid); break
            host=host.parentWidget() if hasattr(host,'parentWidget') else None
    def remove_child(self):
        r=self.table.currentRow()
        if r<0:return
        sid=int(self.table.item(r,0).text())
        with db() as c:c.execute('DELETE FROM parent_children WHERE parent_username=? AND student_id=?',(self.username,sid));c.commit()
        self.load()

class StudentInfo(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent); self.username=username; self.sid=None; self.ui()
    def ui(self):
        l=QVBoxLayout(self); self.selector=None; self.table=QTableWidget(0,2); self.table.setHorizontalHeaderLabels(['مشخصه','مقدار']); l.addWidget(self.table)
    def load_student(self,sid):
        self.sid=sid
        if not sid:return
        with db() as c:r=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
        if not r:return
        keys=[('first_name','نام'),('last_name','نام خانوادگی'),('student_code','کد دانش‌آموزی'),('national_code','کد ملی'),('grade','پایه'),('class_name','کلاس'),('father_name','نام پدر'),('mother_name','نام مادر'),('birth_date','تاریخ تولد'),('phone','تلفن دانش‌آموز'),('parent_phone','تلفن ولی'),('address','آدرس')]
        self.table.setRowCount(len(keys))
        for i,(k,label) in enumerate(keys):self.table.setItem(i,0,QTableWidgetItem(label));self.table.setItem(i,1,QTableWidgetItem(str(r[k] or '')))

class Grades(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent); self.username=username; self.sid=None; self.ui()
    def ui(self):
        l=QVBoxLayout(self); self.selector=None; self.table=QTableWidget(); l.addWidget(self.table)
    def load_student(self,sid):
        self.sid=sid
        if not sid:return
        with db() as c: rows=c.execute("SELECT subject,assessment_title,score,description,grade_date_shamsi FROM student_grades WHERE student_id=? AND (assessment_type NOT IN ('میان‌ترم','پایان‌ترم') OR manager_released=1) ORDER BY id DESC",(sid,)).fetchall()
        self.table.setColumnCount(5);self.table.setHorizontalHeaderLabels(['درس','آزمون','نمره','توضیحات','تاریخ']);self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r['subject'],r['exam_name'],r['score'],r['description'],iso_to_jalali(r['created_at']) if r['created_at'] else '']
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))

class Discipline(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent); self.username=username; self.sid=None; self.ui()
    def ui(self):
        l=QVBoxLayout(self); self.selector=None; self.summary=QLabel('');l.addWidget(self.summary);self.table=QTableWidget();l.addWidget(self.table)
    def load_student(self,sid):
        self.sid=sid
        if not sid:return
        with db() as c: rows=c.execute('SELECT title,deduction,status,created_at,note FROM discipline_records WHERE student_id=? ORDER BY id DESC',(sid,)).fetchall()
        total=sum(float(r['deduction'] or 0) for r in rows); rating='خیلی خوب' if total<=1 else 'خوب' if total<=3 else 'قابل قبول' if total<=5 else 'نیاز به تلاش'
        self.summary.setText(f'مجموع کسر نمره: {total:g} | وضعیت انضباطی: {rating}')
        self.table.setColumnCount(5);self.table.setHorizontalHeaderLabels(['مورد','کسر نمره','وضعیت','تاریخ','توضیحات']);self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))

class PerformanceChart(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent); self.username=username; self.sid=None; self.ui()
    def ui(self):
        l=QVBoxLayout(self); self.selector=None; self.container=QVBoxLayout();l.addLayout(self.container)
    def load_student(self,sid):
        self.sid=sid
        while self.container.count():
            w=self.container.takeAt(0).widget()
            if w:w.deleteLater()
        if not sid:return
        with db() as c: rows=c.execute("SELECT subject,AVG(score) avg_score FROM student_grades WHERE student_id=? AND (assessment_type NOT IN ('میان‌ترم','پایان‌ترم') OR manager_released=1) GROUP BY subject ORDER BY subject",(sid,)).fetchall()
        if not rows:self.container.addWidget(QLabel('هنوز نمره‌ای برای نمودار ثبت نشده است.'));return
        for r in rows:
            row=QHBoxLayout();row.addWidget(QLabel(str(r['subject'] or 'بدون درس'))); bar=QProgressBar();bar.setRange(0,20);bar.setValue(max(0,min(20,round(float(r['avg_score'] or 0)))));bar.setFormat(f"{float(r['avg_score'] or 0):.1f} از 20");row.addWidget(bar);w=QWidget();w.setLayout(row);self.container.addWidget(w)

class Messages(QWidget):
    def __init__(self,parent=None,username='parent'):
        super().__init__(parent); self.username=username; self.sid=None; self.table=QTableWidget(); l=QVBoxLayout(self); l.addWidget(QLabel('پیام‌های مدرسه')); l.addWidget(self.table); self.load()
    def load_student(self,sid): self.sid=sid; self.load()
    def load(self):
        try:
            from services.unified_event_service import inbox
            rows=inbox(self.username,200)
            self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['نوع','عنوان','فرستنده','جزئیات','تاریخ']); self.table.setRowCount(len(rows))
            import json
            for i,r in enumerate(rows):
                try:
                    d=json.loads(r.get('payload') or '{}'); detail=' | '.join(f"{k}: {v}" for k,v in d.items() if v not in ('',None))[:700]
                except Exception: detail=str(r.get('payload') or '')[:700]
                vals=[r.get('event_type',''),r.get('title',''),r.get('actor_username','سیستم/مدرسه'),detail,r.get('created_at','')]
                for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        except Exception:
            self.table.setRowCount(0)

class ParentMeetings(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent);self.username=username;self.ui();self.load()
    def ui(self):
        l=QVBoxLayout(self);f=QFormLayout();self.selector=None;self.sid=None;self.teacher=QLineEdit();self.phone=QLineEdit();self.reason=QTextEdit();self.date=ShamsiDateEdit(QDate.currentDate());self.date.setCalendarPopup(True)
        self.child_label=QLabel('فرزند انتخاب‌شده: هنوز انتخاب نشده'); f.addRow('فرزند',self.child_label);f.addRow('شناسه دبیر/عامل',self.teacher);f.addRow('شماره تماس ولی',self.phone);f.addRow('تاریخ پیشنهادی',self.date);f.addRow('دلیل ملاقات',self.reason);l.addLayout(f);b=QPushButton('ثبت درخواست ملاقات');l.addWidget(b);self.table=QTableWidget();l.addWidget(self.table);b.clicked.connect(self.save)
    def load_student(self,sid):
        self.sid=sid
        if sid is None:
            self.child_label.setText('فرزند انتخاب‌شده: هنوز انتخاب نشده')
        else:
            with db() as c:
                r=c.execute('SELECT first_name,last_name FROM students WHERE id=?',(sid,)).fetchone()
            self.child_label.setText('فرزند انتخاب‌شده: ' + (f"{r['first_name']} {r['last_name']}" if r else str(sid)))
        self.load()

    def save(self):
        sid=self.sid
        if not sid or not self.teacher.text().strip() or not self.reason.toPlainText().strip():return QMessageBox.warning(self,'ملاقات','فرزند، شناسه دبیر و دلیل ملاقات الزامی است.')
        with db() as c:c.execute('INSERT INTO parent_meetings(student_id,teacher_id,parent_phone,reason,meeting_date) VALUES(?,?,?,?,?)',(sid,int(self.teacher.text()),self.phone.text().strip(),self.reason.toPlainText().strip(),self.date.date().toString('yyyy-MM-dd')));c.commit()
        self.reason.clear();self.load()
    def load(self):
        with db() as c:rows=c.execute('''SELECT m.meeting_date,m.reason,m.status,s.first_name||' '||s.last_name child FROM parent_meetings m JOIN students s ON s.id=m.student_id WHERE s.id IN (SELECT student_id FROM parent_children WHERE parent_username=?) ORDER BY m.id DESC''',(self.username,)).fetchall()
        self.table.setColumnCount(4);self.table.setHorizontalHeaderLabels(['فرزند','تاریخ','دلیل','وضعیت']);self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))

class WeeklySchedule(QWidget):
    def __init__(self,parent=None,username='parent'): super().__init__(parent);self.username=username;self.sid=None;self.ui()
    def ui(self):l=QVBoxLayout(self);self.selector=None;self.table=QTableWidget();l.addWidget(self.table)
    def load_student(self,sid):
        self.sid=sid
        if not sid:return
        with db() as c:r=c.execute('SELECT grade,class_name FROM students WHERE id=?',(sid,)).fetchone()
        if not r:return
        with db() as c:
            rows=c.execute('''SELECT weekday,bell,teacher,subject,week_index FROM generated_weekly_schedule
                              WHERE grade=? AND (class_name=? OR class_name='') ORDER BY id''',(r['grade'],r['class_name'])).fetchall()
        self.table.setColumnCount(5);self.table.setHorizontalHeaderLabels(['روز','زنگ','دبیر','درس','هفته']);self.table.setRowCount(len(rows))
        for i,x in enumerate(rows):
            for j,v in enumerate(x):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))

class ExamSchedule(WeeklySchedule):
    def load_student(self,sid):
        self.sid=sid
        if not sid:return
        with db() as c:r=c.execute('SELECT grade,class_name FROM students WHERE id=?',(sid,)).fetchone()
        if not r:return
        with db() as c:rows=c.execute('SELECT exam_date,exam_start_time,subject,weight,duration FROM exam_schedule WHERE grade=? ORDER BY exam_date,exam_start_time,id',(r['grade'],)).fetchall()
        from utils.jalali import iso_to_jalali
        self.table.setColumnCount(5);self.table.setHorizontalHeaderLabels(['تاریخ شمسی','ساعت شروع','درس','سطح','مدت']);self.table.setRowCount(len(rows))
        rows=[(iso_to_jalali(x[0]),x[1],x[2],x[3],x[4]) for x in rows]
        for i,x in enumerate(rows):
            for j,v in enumerate(x):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))

class Payments(QWidget):
    def __init__(self,parent=None,username='parent'):
        super().__init__(parent); self.username=username; self.sid=None
        l=QVBoxLayout(self); l.addWidget(QLabel('پرداخت‌های فرزندان | payment_records'))
        self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['ID','فرزند','عنوان','مبلغ','وضعیت','تاریخ شمسی','ولی']); l.addWidget(self.table)
        b=QPushButton('ثبت پرداخت/اعلام پرداخت'); l.addWidget(b); b.clicked.connect(self.add_payment); self.load()
    def load_student(self,sid): self.sid=sid; self.load()
    def load(self):
        with db() as c:
            rows=c.execute('''SELECT p.id,s.first_name||' '||s.last_name,p.title,p.amount,p.status,
                                     COALESCE(p.payment_date_shamsi,''),COALESCE(p.parent_name,p.parent_username,'')
                              FROM payment_records p JOIN students s ON s.id=p.student_id
                              JOIN parent_children pc ON pc.student_id=p.student_id
                              WHERE pc.parent_username=? AND (? IS NULL OR p.student_id=?)
                              ORDER BY p.id DESC''',(self.username,self.sid,self.sid)).fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def add_payment(self):
        if self.sid is None:
            QMessageBox.warning(self,'پرداخت','ابتدا یک فرزند را انتخاب کنید.'); return
        d=QDialog(self); d.setWindowTitle('ثبت پرداخت'); f=QFormLayout(d)
        title=QLineEdit(); amount=QLineEdit(); ref=QLineEdit(); f.addRow('عنوان',title);f.addRow('مبلغ',amount);f.addRow('شماره پیگیری',ref)
        ok=QPushButton('ثبت');f.addRow(ok);ok.clicked.connect(d.accept)
        if not d.exec() or not title.text().strip():return
        try: amount_i=int(amount.text().replace(',',''))
        except ValueError: QMessageBox.warning(self,'پرداخت','مبلغ باید عددی باشد.');return
        sh=iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
        with db() as c:
            c.execute('''INSERT INTO payment_records(student_id,parent_username,parent_name,title,amount,reference,status,payment_date,payment_date_shamsi,description)
                         VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?,?)''',
                      (self.sid,self.username,self.username,title.text().strip(),amount_i,ref.text().strip(),'pending',sh,'ثبت از پنل اولیا'))
            c.commit()
        self.load();QMessageBox.information(self,'پرداخت','پرداخت ثبت شد و برای بررسی مدرسه ارسال شد.')

class Transport(QWidget):
    def __init__(self,parent=None,username='parent'):
        super().__init__(parent); self.username=username; l=QVBoxLayout(self); l.addWidget(QLabel('ثبت نام و درخواست سرویس مدرسه'));f=QFormLayout();self.address=QLineEdit();self.vehicle=QComboBox();self.vehicle.addItems(['سواری','ون']);self.origin=QLineEdit();self.destination=QLineEdit();self.note=QLineEdit();f.addRow('آدرس محل سکونت',self.address);f.addRow('نوع وسیله',self.vehicle);f.addRow('مبدأ حرکت',self.origin);f.addRow('مقصد',self.destination);f.addRow('توضیحات',self.note);l.addLayout(f);b=QPushButton('ثبت درخواست سرویس');l.addWidget(b);self.status=QLabel();l.addWidget(self.status);b.clicked.connect(self.save)
    def save(self):
        if not self.address.text().strip() or not self.origin.text().strip():return QMessageBox.warning(self,'سرویس','آدرس و مبدأ الزامی است.')
        with db() as c:c.execute('INSERT INTO transport_requests(parent_username,address,vehicle_type,origin,destination,note) VALUES(?,?,?,?,?,?)',(self.username,self.address.text().strip(),self.vehicle.currentText(),self.origin.text().strip(),self.destination.text().strip(),self.note.text().strip()));c.commit()
        self.status.setText('درخواست سرویس ثبت شد و برای مدرسه ارسال گردید.')

class Panel(QWidget):
    def __init__(self,parent=None,username=None):
        super().__init__(parent);ensure_parent_schema();self.setLayoutDirection(Qt.RightToLeft);self.username=username or getattr(parent,'current_username','parent') or 'parent';self.selected_student_id=None
        l=QVBoxLayout(self); l.setContentsMargins(12,10,12,10); l.setSpacing(8); title=QLabel('فراهوش | پنل اولیا');title.setAlignment(Qt.AlignmentFlag.AlignCenter);title.setStyleSheet('font-size:24px;font-weight:bold;color:#9D174D;padding:8px;');l.addWidget(title)
        info=QLabel('فرزند را فقط یک‌بار در این قسمت انتخاب کنید؛ انتخاب شما در تمام بخش‌های پنل اعمال می‌شود.');info.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(info)
        self.school_context = QLabel(); self.school_context.setAlignment(Qt.AlignmentFlag.AlignCenter); self.school_context.setWordWrap(True); l.addWidget(self.school_context)
        self.global_selector=ChildSelector(self,self.username); l.addWidget(self.global_selector)
        self._refresh_school_context(None)
        tabs=QTabWidget();l.addWidget(tabs)
        tabs.addTab(Children(self,self.username),'👨‍👩‍👧 انتخاب دانش‌آموز')
        tabs.addTab(StudentInfo(self,self.username),'👤 اطلاعات دانش‌آموز')
        tabs.addTab(Grades(self,self.username),'📊 کارنامه و نمرات')
        tabs.addTab(Discipline(self,self.username),'🛡️ وضعیت انضباطی')
        tabs.addTab(PerformanceChart(self,self.username),'📈 عملکرد')
        tabs.addTab(Messages(self,self.username),'📥 صندوق پیام')
        tabs.addTab(ParentMeetings(self,self.username),'🤝 درخواست ملاقات')
        tabs.addTab(PublicSurvey(self,role='parent',username=self.username),'📋 نظرسنجی')
        tabs.addTab(WeeklySchedule(self,self.username),'📅 برنامه هفتگی')
        tabs.addTab(ExamSchedule(self,self.username),'📝 برنامه امتحانات')
        tabs.addTab(Payments(self,self.username),'💳 پرداخت‌های ثبت‌شده')
        tabs.addTab(OnlinePaymentPage(self,self.username,'parent',getattr(self,'current_student_id',None)),'💳 پرداخت آنلاین')
        tabs.addTab(Transport(self,self.username),'🚌 سرویس مدرسه')
        tabs.addTab(CompleteTabs(parent_specs(),'اولیا | همه اطلاعات آموزشی، مالی، پیام‌ها و پرورشی',self,readonly=True),'📚 همه اطلاعات مدرسه')
        tabs.setUsesScrollButtons(True)
        tabs.setDocumentMode(True)
        tabs.setMovable(False)
        tabs.setMinimumHeight(48)
        self.setStyleSheet('''QWidget{background:#FDF2F8;color:#111827;} QLabel{color:#111827;font-weight:bold;} QPushButton{background:#DB2777;color:white;border:0;border-radius:9px;padding:7px 10px;font-size:14px;} QLineEdit,QComboBox,QTextEdit,QDateEdit{background:white;color:#111827;padding:6px;border:1px solid #DB2777;border-radius:7px;} QTableWidget{background:white;color:#111827;} QTabBar::tab{padding:8px 12px;font-size:14px;} QProgressBar{background:white;color:#111827;border:1px solid #DB2777;border-radius:5px;text-align:center;} QProgressBar::chunk{background:#DB2777;}''')

    def _refresh_school_context(self, sid):
        si=school_info(); st=student_info(sid) if sid else None
        if st:
            full=f"{st.get('first_name','')} {st.get('last_name','')}".strip()
            self.school_context.setText(f"🏫 {si['name']} | سال تحصیلی: {si['year']}   •   👤 {full} | پایه: {st.get('grade','-')} | کلاس: {st.get('class_name','-')}")
        else:
            self.school_context.setText(f"🏫 {si['name']} | سال تحصیلی: {si['year']}   •   لطفاً فرزند را فقط از انتخاب دانش‌آموز انتخاب کنید.")

    def student_changed(self, sid, selected_ids=None):
        self.selected_student_id = sid
        self.selected_student_ids = selected_ids or ([sid] if sid else [])
        self._refresh_school_context(sid)
        # Propagate the selected child to every tab that supports it.
        # QTabWidget is local in init; discover child pages by traversing direct tab widgets.
        tabs = self.findChildren(QTabWidget)
        if not tabs: return
        tab = tabs[0]
        for i in range(tab.count()):
            page = tab.widget(i)
            if hasattr(page, 'load_student'):
                try: page.load_student(sid)
                except Exception: pass


    def tabs_count(self):
        tabs=self.findChildren(QTabWidget); return tabs[0].count() if tabs else 0
