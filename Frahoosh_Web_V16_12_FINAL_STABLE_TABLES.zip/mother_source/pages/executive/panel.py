import sqlite3, os
from datetime import datetime
from ui.online_class_manager import OnlineClassManagerPage
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QTabWidget,QDialog,QFormLayout,QDialogButtonBox,QMessageBox,QHeaderView,QTextEdit
from PySide6.QtCore import Qt
from ui.panel_tools import add_toolbar,edit_dialog
from pages.discipline import DisciplinePage
from ui.unified_inbox import UnifiedInboxPage,UnifiedMessengerPage
from ui.complete_module_pages import CompleteTabs, executive_specs
DB=os.path.join(os.path.dirname(__file__),'..','..','school.db')

def db(): c=sqlite3.connect(os.path.abspath(DB)); c.row_factory=sqlite3.Row; return c

def ensure():
 with db() as c:
  c.executescript('''
  CREATE TABLE IF NOT EXISTS executive_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,grade TEXT,teacher TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS seating(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,seat_no TEXT,exam TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,title TEXT,code TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS student_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,card_type TEXT,code TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS report_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,term TEXT,average REAL,description TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,category TEXT,quantity INTEGER,location TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS archive_items(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,student_id INTEGER,location TEXT,description TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS executive_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,status TEXT,description TEXT,created_at TEXT);
  CREATE TABLE IF NOT EXISTS executive_operations(id INTEGER PRIMARY KEY AUTOINCREMENT,operation_type TEXT,title TEXT,student_id INTEGER,class_name TEXT,status TEXT,operation_date TEXT,description TEXT);
  CREATE TABLE IF NOT EXISTS executive_reports(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,report_type TEXT,student_id INTEGER,class_name TEXT,report_date TEXT,created_by TEXT);
  ''')

class CRUDTab(QWidget):
 def __init__(self,title,table,columns,fields,parent=None,transform=None):
  super().__init__(parent); self.table_name=table; self.columns=columns; self.fields=fields; self.transform=transform
  l=QVBoxLayout(self); self.title=QLabel(title); self.title.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(self.title)
  bar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('جستجو در این بخش...'); bar.addWidget(self.search); self.add=QPushButton('ثبت'); self.edit=QPushButton('ویرایش'); self.delete=QPushButton('حذف'); self.refresh=QPushButton('تازه‌سازی'); [bar.addWidget(x) for x in (self.add,self.edit,self.delete,self.refresh)]; l.addLayout(bar)
  self.table=QTableWidget(0,len(columns)); self.table.setHorizontalHeaderLabels([x[1] for x in columns]); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.table.setSelectionBehavior(QTableWidget.SelectRows); l.addWidget(self.table)
  self.add.clicked.connect(self.add_row); self.edit.clicked.connect(self.edit_row); self.delete.clicked.connect(self.delete_row); self.refresh.clicked.connect(self.load); self.search.textChanged.connect(self.load); self.load()
 def load(self):
  q='SELECT '+','.join(x[0] for x in self.columns)+' FROM '+self.table_name; s=self.search.text().strip()
  if s: q+=' WHERE '+' OR '.join(f"CAST({x[0]} AS TEXT) LIKE ?" for x in self.columns)+' ORDER BY id DESC'; args=['%'+s+'%']*len(self.columns)
  else: q+=' ORDER BY id DESC'; args=[]
  with db() as c: rows=c.execute(q,args).fetchall()
  self.table.setRowCount(len(rows))
  for r,row in enumerate(rows):
   for col,x in enumerate(self.columns): self.table.setItem(r,col,QTableWidgetItem(str(row[x[0]] if row[x[0]] is not None else '')))
 def add_row(self):
  d,w=edit_dialog(self,'ثبت '+self.title.text(),self.fields)
  if d.exec()!=QDialog.Accepted:return
  vals=[w[k].text().strip() for k,_ in self.fields]
  try:
   with db() as c:c.execute(f"INSERT INTO {self.table_name}({','.join(k for k,_ in self.fields)}) VALUES({','.join('?' for _ in vals)})",vals); c.commit()
   self.load()
  except Exception as e: QMessageBox.critical(self,'خطا',str(e))
 def edit_row(self):
  r=self.table.currentRow()
  if r<0:return
  row={x[0]:self.table.item(r,i).text() if self.table.item(r,i) else '' for i,x in enumerate(self.columns)}
  d,w=edit_dialog(self,'ویرایش '+self.title.text(),self.fields,row)
  if d.exec()!=QDialog.Accepted:return
  vals=[w[k].text().strip() for k,_ in self.fields]; ident=row['id']
  try:
   with db() as c:c.execute(f"UPDATE {self.table_name} SET {','.join(k+'=?' for k,_ in self.fields)} WHERE id=?",vals+[ident]); c.commit()
   self.load()
  except Exception as e: QMessageBox.critical(self,'خطا',str(e))
 def delete_row(self):
  r=self.table.currentRow()
  if r<0:return
  ident=self.table.item(r,0).text()
  if QMessageBox.question(self,'حذف','این رکورد حذف شود؟')!=QMessageBox.Yes:return
  with db() as c:c.execute(f'DELETE FROM {self.table_name} WHERE id=?',(ident,)); c.commit()
  self.load()

class StudentFileTab(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent); l=QVBoxLayout(self); bar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText("جستجوی نام، کد ملی یا شناسه..."); self.loadb=QPushButton("جستجو"); bar.addWidget(self.search);bar.addWidget(self.loadb);l.addLayout(bar); self.table=QTableWidget(); l.addWidget(self.table); self.editb=QPushButton("ویرایش پرونده"); self.refresh=QPushButton("تازه‌سازی"); bar2=QHBoxLayout();bar2.addWidget(self.editb);bar2.addWidget(self.refresh);l.addLayout(bar2);self.loadb.clicked.connect(self.load);self.refresh.clicked.connect(self.load);self.search.returnPressed.connect(self.load);self.editb.clicked.connect(self.edit);self.load()
 def load(self):
  s="%"+self.search.text().strip()+"%"
  with db() as c: rows=c.execute("SELECT id,first_name,last_name,national_code,student_code,grade,class_name,phone,parent_phone,email,address FROM students WHERE CAST(id AS TEXT) LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR national_code LIKE ? OR student_code LIKE ? ORDER BY id DESC",(s,s,s,s,s)).fetchall()
  cols=['id','first_name','last_name','national_code','student_code','grade','class_name','phone','parent_phone','email','address'];self.table.setColumnCount(len(cols));self.table.setHorizontalHeaderLabels(cols);self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def edit(self):
  r=self.table.currentRow();
  if r<0:return
  sid=int(self.table.item(r,0).text()); row={k:self.table.item(r,i).text() for i,k in enumerate(['id','first_name','last_name','national_code','student_code','grade','class_name','phone','parent_phone','email','address'])}
  d,w=edit_dialog(self,'ویرایش پرونده دانش‌آموز',[('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('student_code','کد دانش‌آموزی'),('grade','پایه'),('class_name','کلاس'),('phone','تلفن'),('parent_phone','تلفن ولی'),('email','ایمیل'),('address','نشانی')],row)
  if d.exec()!=QDialog.Accepted:return
  vals=[w[k].text().strip() for k,_ in [('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('student_code','کد دانش‌آموزی'),('grade','پایه'),('class_name','کلاس'),('phone','تلفن'),('parent_phone','تلفن ولی'),('email','ایمیل'),('address','نشانی')]]
  with db() as c:
   c.execute('UPDATE students SET first_name=?,last_name=?,national_code=?,student_code=?,grade=?,class_name=?,phone=?,parent_phone=?,email=?,address=? WHERE id=?',vals+[sid]);c.execute('INSERT OR IGNORE INTO student_files(student_id) VALUES(?)',(sid,));c.commit()
  self.load()

class Panel(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent); ensure(); self.pages=[]; self.setLayoutDirection(Qt.RightToLeft)
  l=QVBoxLayout(self); l.setContentsMargins(12,10,12,10); l.setSpacing(8)
  title=QLabel('فراهوش | پنل معاونت اجرایی'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setStyleSheet('font-size:24px;font-weight:bold;color:#C2410C;padding:8px;'); l.addWidget(title)
  info=QLabel('مدیریت یکپارچه دانش‌آموزان، کلاس‌ها، پرونده‌ها، کارت‌ها، گواهی‌ها، کارکنان و امور اجرایی مدرسه'); info.setAlignment(Qt.AlignmentFlag.AlignCenter); info.setStyleSheet('font-size:14px;color:#7C2D12;padding-bottom:4px;'); l.addWidget(info)
  tabs=QTabWidget(); l.addWidget(tabs)
  tabs.addTab(UnifiedInboxPage(role='vice',title='پیام‌ها و رویدادهای مدرسه',parent=self),'📥 پیام‌ها')
  tabs.addTab(UnifiedMessengerPage(sender='معاون اجرایی',role='vice',parent=self),'✉️ ارسال پیام')
  tabs.addTab(CompleteTabs(executive_specs(),'اجرایی | کلاس‌ها، امور اجرایی، گزارش، برنامه و امتحانات',self),'📚 جداول کامل اجرایی')
  tabs.addTab(OnlineClassManagerPage(self,actor_role='executive'),'🎓 کلاس آنلاین')
  specs=[
   ('دانش‌آموزان','students',[('id','شناسه'),('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کدملی'),('grade','پایه'),('class_name','کلاس')],[('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('grade','پایه'),('class_name','کلاس'),('phone','تلفن'),('parent_phone','تلفن ولی')]),
   ('اولیا','students',[('id','شناسه'),('first_name','نام'),('last_name','نام خانوادگی'),('parent_phone','تلفن ولی')],[('first_name','نام دانش‌آموز'),('last_name','نام خانوادگی'),('parent_phone','تلفن ولی')]),
   ('مدیریت کلاس‌ها','executive_classes',[('id','شناسه'),('name','کلاس'),('grade','پایه'),('teacher','دبیر')],[('name','نام کلاس'),('grade','پایه'),('teacher','دبیر')]),
   ('صندلی‌ها','seating',[('id','شناسه'),('student_id','دانش‌آموز'),('seat_no','صندلی'),('exam','آزمون')],[('student_id','شناسه دانش‌آموز'),('seat_no','شماره صندلی'),('exam','آزمون')]),
   ('گواهی‌ها','certificates',[('id','شناسه'),('student_id','دانش‌آموز'),('title','عنوان'),('code','کد')],[('student_id','شناسه دانش‌آموز'),('title','عنوان گواهی'),('code','کد')]),
   ('کارت‌ها','student_cards',[('id','شناسه'),('student_id','دانش‌آموز'),('card_type','نوع کارت'),('code','کد')],[('student_id','شناسه دانش‌آموز'),('card_type','نوع کارت'),('code','کد')]),
   ('کارنامه‌ها','report_cards',[('id','شناسه'),('student_id','دانش‌آموز'),('term','نوبت'),('average','معدل')],[('student_id','شناسه دانش‌آموز'),('term','نوبت'),('average','معدل'),('description','توضیحات')]),
   ('کارکنان','staff',[('id','شناسه'),('first_name','نام'),('last_name','نام خانوادگی'),('role','سمت'),('phone','تلفن')],[('first_name','نام'),('last_name','نام خانوادگی'),('role','سمت'),('phone','تلفن'),('description','توضیحات')]),
   ('اموال','assets',[('id','شناسه'),('title','عنوان'),('category','دسته'),('quantity','تعداد'),('location','محل')],[('title','عنوان'),('category','دسته'),('quantity','تعداد'),('location','محل')]),
   ('بایگانی','archive_items',[('id','شناسه'),('title','عنوان'),('student_id','دانش‌آموز'),('location','محل'),('description','توضیح')],[('title','عنوان'),('student_id','دانش‌آموز'),('location','محل'),('description','توضیح')]),
   ('درخواست‌ها','executive_requests',[('id','شناسه'),('title','عنوان'),('requester','درخواست‌کننده'),('status','وضعیت'),('description','توضیح')],[('title','عنوان'),('requester','درخواست‌کننده'),('status','وضعیت'),('description','توضیح')])]
  for title,table,cols,fields in specs:
   try:
    p=CRUDTab(title,table,cols,fields,self); tabs.addTab(p,title); self.pages.append(p)
   except Exception as e:
    err=QWidget(); q=QVBoxLayout(err); q.addWidget(QLabel(f'خطا در بخش {title}: {e}')); q.addStretch(); tabs.addTab(err,title)
  try: tabs.addTab(StudentFileTab(self),'پرونده دانش‌آموزی')
  except Exception as e:
   err=QWidget(); q=QVBoxLayout(err); q.addWidget(QLabel(f'خطا در پرونده دانش‌آموزی: {e}')); tabs.addTab(err,'پرونده دانش‌آموزی')
  try: tabs.addTab(DisciplinePage(self, actor_role='executive', manager=False),'🛡️ ثبت موارد انضباطی')
  except Exception as e:
   err=QWidget(); q=QVBoxLayout(err); q.addWidget(QLabel(f'خطا در انضباط: {e}')); tabs.addTab(err,'🛡️ ثبت موارد انضباطی')
  # کارت کلاس و امتحان
  for title,table,cols,fields in [
   ('کارت کلاسی','class_cards',[('id','شناسه'),('student_id','دانش‌آموز'),('class_name','کلاس'),('code','کد')],[('student_id','شناسه دانش‌آموز'),('class_name','نام کلاس'),('code','کد کارت')]),
   ('کارت امتحان','exam_cards',[('id','شناسه'),('student_id','دانش‌آموز'),('exam_name','آزمون'),('code','کد')],[('student_id','شناسه دانش‌آموز'),('exam_name','نام آزمون'),('code','کد کارت')]),
   ('شماره صندلی کلاسی','class_seats',[('id','شناسه'),('student_id','دانش‌آموز'),('class_name','کلاس'),('seat_no','شماره')],[('student_id','شناسه دانش‌آموز'),('class_name','کلاس'),('seat_no','شماره صندلی')]),
   ('شماره صندلی امتحانی','exam_seats',[('id','شناسه'),('student_id','دانش‌آموز'),('exam_name','آزمون'),('seat_no','شماره')],[('student_id','شناسه دانش‌آموز'),('exam_name','نام آزمون'),('seat_no','شماره صندلی')])]:
   p=CRUDTab(title,table,cols,fields,self);tabs.addTab(p,title);self.pages.append(p)
  # reports/settings as real actions
  for name in ('گزارش‌ها','تنظیمات'):
   p=QWidget(); q=QVBoxLayout(p); b=QPushButton('تازه‌سازی و نمایش گزارش' if name=='گزارش‌ها' else 'ذخیره تنظیمات پایه'); out=QLabel('برای مشاهده نتیجه روی دکمه کلیک کنید.'); out.setWordWrap(True); q.addWidget(b); q.addWidget(out); q.addStretch()
   if name=='گزارش‌ها': b.clicked.connect(lambda _,o=out:self.report(o))
   else: b.clicked.connect(lambda _,o=out:self.settings(o))
   tabs.addTab(p,name)
  tabs.setUsesScrollButtons(True); tabs.setDocumentMode(True); tabs.setMovable(False); tabs.setMinimumHeight(48)
  self.setStyleSheet('''QWidget{background:#FFF7ED;color:#1F2937;} QLabel{color:#1F2937;font-weight:bold;} QPushButton{background:#EA580C;color:white;border:0;border-radius:9px;padding:7px 10px;font-size:14px;} QPushButton:hover{background:#C2410C;} QPushButton:pressed{background:#9A3412;} QLineEdit,QComboBox,QTextEdit,QDateEdit{background:white;color:#111827;padding:6px;border:1px solid #FDBA74;border-radius:7px;} QTableWidget{background:white;color:#111827;border:1px solid #FED7AA;border-radius:7px;gridline-color:#E5E7EB;} QHeaderView::section{background:#FFEDD5;color:#7C2D12;font-weight:bold;padding:7px;border:0;} QTabWidget::pane{background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;} QTabBar::tab{background:#FFEDD5;color:#7C2D12;padding:8px 12px;margin:2px;border-radius:8px;font-size:14px;font-weight:bold;} QTabBar::tab:selected{background:#EA580C;color:white;} QTabBar::tab:hover{background:#FDBA74;color:#7C2D12;}''')
 def report(self,out):
  with db() as c:
   parts=[]
   for t,label in [('students','دانش‌آموز'),('teachers','دبیر'),('staff','کارکنان'),('executive_classes','کلاس'),('assets','اموال')]:
    try: parts.append(f'{label}: {c.execute("SELECT COUNT(*) FROM "+t).fetchone()[0]}')
    except: pass
  out.setText('\n'.join(parts))
 def settings(self,out): out.setText('تنظیمات اجرایی ذخیره شد. زمان ثبت: '+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
