# -*- coding: utf-8 -*-
import sqlite3, os
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QTextEdit,QLabel,QMessageBox,QTabWidget,QTableWidget,QTableWidgetItem,QLineEdit,QFormLayout
from PySide6.QtCore import Qt
from utils.jalali import iso_to_jalali
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))

class Panel(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build()
 def db(self):
  c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
 def build(self):
  l=QVBoxLayout(self); l.addWidget(QLabel('تابلو هوشمند | محتوای آموزشی، فایل، رسانه، آزمون و فعالیت'))
  self.tabs=QTabWidget(); l.addWidget(self.tabs)
  self._make_content(); self._make_files(); self._make_media(); self._make_quiz(); self._make_activity(); self._make_interactive()
 def _table_tab(self,title,columns):
  w=QWidget(); v=QVBoxLayout(w); form=QHBoxLayout(); edits=[]
  for ph in columns: e=QLineEdit(); e.setPlaceholderText(ph); form.addWidget(e); edits.append(e)
  v.addLayout(form); t=QTableWidget(0,len(columns)+1); t.setHorizontalHeaderLabels(['ID']+columns); v.addWidget(t)
  self.tabs.addTab(w,title); return edits,t
 def _make_content(self):
  e,t=self._table_tab('محتوا',[ 'عنوان','محتوا','کلاس','دبیر'])
  b=QPushButton('ذخیره محتوا'); b.clicked.connect(lambda:self._insert('smart_board_content',['title','content','class_id','teacher_id'],e,t)); t._loader=lambda:self._load(t,'SELECT id,title,content,class_id,teacher_id FROM smart_board_content ORDER BY id DESC'); t._loader()
 def _make_files(self):
  e,t=self._table_tab('فایل‌ها',['عنوان','مسیر فایل','نوع','کلاس','دبیر'])
  b=QPushButton('ثبت فایل'); self.tabs.widget(1).layout().addWidget(b); b.clicked.connect(lambda:self._insert('smart_board_files',['title','file_path','file_type','class_id','teacher_id'],e,t)); t._loader=lambda:self._load(t,'SELECT id,title,file_path,file_type,class_id,teacher_id FROM smart_board_files ORDER BY id DESC'); t._loader()
 def _make_media(self):
  e,t=self._table_tab('تصاویر و ویدئو',['عنوان','مسیر رسانه','نوع','کلاس','دبیر'])
  b=QPushButton('ثبت رسانه'); self.tabs.widget(2).layout().addWidget(b); b.clicked.connect(lambda:self._insert('smart_board_media',['title','media_path','media_type','class_id','teacher_id'],e,t)); t._loader=lambda:self._load(t,'SELECT id,title,media_path,media_type,class_id,teacher_id FROM smart_board_media ORDER BY id DESC'); t._loader()
 def _make_quiz(self):
  e,t=self._table_tab('آزمون کوتاه',['عنوان','سؤال','گزینه صحیح','کلاس','دبیر'])
  b=QPushButton('ثبت آزمون'); self.tabs.widget(3).layout().addWidget(b); b.clicked.connect(lambda:self._insert('smart_board_quizzes',['title','question','correct_option','class_id','teacher_id'],e,t)); t._loader=lambda:self._load(t,'SELECT id,title,question,correct_option,class_id,teacher_id FROM smart_board_quizzes ORDER BY id DESC'); t._loader()
 def _make_activity(self):
  e,t=self._table_tab('فعالیت کلاس',['عنوان','شرح فعالیت','کلاس','دبیر'])
  b=QPushButton('ثبت فعالیت'); self.tabs.widget(4).layout().addWidget(b); b.clicked.connect(lambda:self._insert('smart_board_activities',['title','activity_text','class_id','teacher_id'],e,t)); t._loader=lambda:self._load(t,'SELECT id,title,activity_text,class_id,teacher_id FROM smart_board_activities ORDER BY id DESC'); t._loader()
 def _make_interactive(self):
  w=QWidget(); v=QVBoxLayout(w)
  v.addWidget(QLabel('ابزارهای تعاملی | ثبت و مدیریت فعالیت‌های تعاملی کلاس'))
  form=QHBoxLayout(); title=QLineEdit(); title.setPlaceholderText('عنوان ابزار/فعالیت'); kind=QLineEdit(); kind.setPlaceholderText('نوع ابزار'); detail=QLineEdit(); detail.setPlaceholderText('توضیحات یا دستور اجرا'); form.addWidget(title); form.addWidget(kind); form.addWidget(detail); v.addLayout(form)
  b=QPushButton('ثبت ابزار تعاملی'); v.addWidget(b)
  t=QTableWidget(0,5); t.setHorizontalHeaderLabels(['ID','عنوان','نوع','توضیحات','تاریخ']); v.addWidget(t)
  self.tabs.addTab(w,'ابزارهای تعاملی')
  def load():
   try:
    with self.db() as c:
     rows=c.execute('SELECT id,title,tool_type,description,created_at FROM smart_board_interactive_tools ORDER BY id DESC').fetchall()
    t.setRowCount(len(rows))
    for i,r in enumerate(rows):
     for j,val in enumerate(r): t.setItem(i,j,QTableWidgetItem(str(val or '')))
   except Exception as ex: QMessageBox.critical(self,'ابزارهای تعاملی','خطای بارگذاری: '+str(ex))
  def save():
   if not title.text().strip():
    QMessageBox.warning(self,'ابزارهای تعاملی','عنوان الزامی است.'); return
   try:
    with self.db() as c:
     c.execute('CREATE TABLE IF NOT EXISTS smart_board_interactive_tools(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,tool_type TEXT,description TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
     c.execute('INSERT INTO smart_board_interactive_tools(title,tool_type,description) VALUES(?,?,?)',(title.text().strip(),kind.text().strip(),detail.text().strip()))
     c.commit()
    title.clear(); kind.clear(); detail.clear(); load(); QMessageBox.information(self,'ابزارهای تعاملی','ابزار با موفقیت ثبت شد.')
   except Exception as ex: QMessageBox.critical(self,'ابزارهای تعاملی','خطای ثبت: '+str(ex))
  b.clicked.connect(save); load()
 def _load(self,t,q):
  try:
   with self.db() as c: rows=c.execute(q).fetchall()
   t.setRowCount(len(rows))
   for i,r in enumerate(rows):
    for j,v in enumerate(r): t.setItem(i,j,QTableWidgetItem(str(v or '')))
  except Exception as ex: QMessageBox.critical(self,'تابلو هوشمند','خطای بارگذاری: '+str(ex))
 def _insert(self,table,cols,edits,t):
  vals=[e.text().strip() for e in edits]
  if not vals[0]: QMessageBox.warning(self,'تابلو','عنوان الزامی است.'); return
  try:
   with self.db() as c:
    c.execute(f'INSERT INTO {table} ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',vals)
    # keep Jalali date for supported tables
    if table=='smart_board_content': c.execute('UPDATE smart_board_content SET content_date_shamsi=? WHERE id=last_insert_rowid()',(iso_to_jalali(datetime.now().strftime("%Y-%m-%d")),))
    elif table=='smart_board_quizzes': c.execute('UPDATE smart_board_quizzes SET quiz_date_shamsi=? WHERE id=last_insert_rowid()',(iso_to_jalali(datetime.now().strftime("%Y-%m-%d")),))
    elif table=='smart_board_activities': c.execute('UPDATE smart_board_activities SET activity_date_shamsi=? WHERE id=last_insert_rowid()',(iso_to_jalali(datetime.now().strftime("%Y-%m-%d")),))
    c.commit()
   for e in edits:e.clear()
   t._loader(); QMessageBox.information(self,'تابلو','ثبت شد.')
  except Exception as ex: QMessageBox.critical(self,'خطا',str(ex))
