import sqlite3, os
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QComboBox,QTextEdit,QMessageBox,QDialog,QFormLayout,QDialogButtonBox,QDoubleSpinBox
from PySide6.QtCore import Qt
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def ensure_schema():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS discipline_items(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL UNIQUE,description TEXT DEFAULT '',deduction REAL NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS discipline_records(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,teacher_id INTEGER,title TEXT NOT NULL,description TEXT DEFAULT '',priority TEXT DEFAULT 'normal',status TEXT DEFAULT 'pending',created_at TEXT NOT NULL,item_id INTEGER,deduction REAL DEFAULT 0,actor_username TEXT DEFAULT '',actor_role TEXT DEFAULT '',note TEXT DEFAULT '')")
        cols={r[1] for r in c.execute('PRAGMA table_info(discipline_records)').fetchall()}
        for col,typ in [('item_id','INTEGER'),('deduction','REAL DEFAULT 0'),('actor_username','TEXT DEFAULT ""'),('actor_role','TEXT DEFAULT ""'),('note','TEXT DEFAULT ""')]:
            if col not in cols:c.execute(f'ALTER TABLE discipline_records ADD COLUMN {col} {typ}')
        c.execute("CREATE TABLE IF NOT EXISTS discipline_settings(id INTEGER PRIMARY KEY CHECK(id=1),base_score REAL NOT NULL DEFAULT 20,updated_at TEXT NOT NULL)")
        c.execute("INSERT OR IGNORE INTO discipline_settings(id,base_score,updated_at) VALUES(1,20,datetime('now'))")
def rating(score, has_records):
    if not has_records:return 'مشخص نیست'
    if score < 10:return 'نیاز به تلاش'
    if score < 15:return 'قابل قبول'
    if score < 18:return 'خوب'
    return 'خیلی خوب'
class ItemDialog(QDialog):
    def __init__(self,parent=None,row=None):
        super().__init__(parent); self.setWindowTitle('تعریف مورد انضباطی'); f=QFormLayout(self)
        self.title=QLineEdit(str((row or {}).get('title',''))); self.desc=QTextEdit(str((row or {}).get('description','')))
        self.ded=QDoubleSpinBox(); self.ded.setRange(0,20); self.ded.setDecimals(2); self.ded.setValue(float((row or {}).get('deduction',0)))
        self.active=QComboBox(); self.active.addItems(['فعال','غیرفعال']); self.active.setCurrentIndex(0 if (row or {}).get('active',1) else 1)
        f.addRow('عنوان',self.title);f.addRow('توضیحات',self.desc);f.addRow('کسر نمره',self.ded);f.addRow('وضعیت',self.active)
        b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);b.accepted.connect(self.accept);b.rejected.connect(self.reject);f.addRow(b)
    def values(self):return self.title.text().strip(),self.desc.toPlainText().strip(),self.ded.value(),1 if self.active.currentIndex()==0 else 0
class DisciplinePage(QWidget):
    def __init__(self,parent=None,actor_username='',actor_role='staff',manager=False):
        super().__init__(parent); ensure_schema(); self.actor_username=actor_username or getattr(parent,'current_username',''); self.actor_role=actor_role; self.manager=manager
        l=QVBoxLayout(self); title=QLabel('🛡️ ثبت موارد انضباطی');title.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(title)
        if manager:
            mb=QHBoxLayout()
            for text,fn in [('تعریف مورد انضباطی',self.add_item),('ویرایش مورد',self.edit_item),('غیرفعال‌سازی',self.delete_item),('تنظیم نمره پایه',self.set_base)]:
                b=QPushButton(text);b.clicked.connect(fn);mb.addWidget(b)
            l.addLayout(mb); self.items=QTableWidget(0,4);self.items.setHorizontalHeaderLabels(['ID','مورد','کسر نمره','وضعیت']);l.addWidget(self.items);self.load_items()
        form=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('جستجوی نام، نام خانوادگی یا کد دانش‌آموزی');self.student=QComboBox();self.item=QComboBox();self.note=QLineEdit();self.note.setPlaceholderText('توضیح');self.add=QPushButton('ثبت مورد انضباطی');[form.addWidget(x) for x in (self.search,self.student,self.item,self.note,self.add)];l.addLayout(form)
        self.search.textChanged.connect(self.load_students);self.add.clicked.connect(self.add_record);self.records=QTableWidget(0,7);self.records.setHorizontalHeaderLabels(['دانش‌آموز','مورد','کسر','توضیح','ثبت‌کننده','تاریخ','نمره انضباط']);l.addWidget(self.records);self.load_students();self.load_items_to_combo();self.load_records()
    def load_students(self):
        s='%'+self.search.text().strip()+'%';self.student.clear()
        with db() as c:rows=c.execute("SELECT id,first_name,last_name,student_code FROM students WHERE first_name LIKE ? OR last_name LIKE ? OR student_code LIKE ? ORDER BY last_name,first_name",(s,s,s)).fetchall()
        for r in rows:self.student.addItem(f"{r['first_name'] or ''} {r['last_name'] or ''} | {r['student_code'] or '-'}",r['id'])
    def load_items(self):
        if not hasattr(self,'items'):return
        with db() as c:rows=c.execute('SELECT id,title,deduction,active FROM discipline_items ORDER BY id DESC').fetchall()
        self.items.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate([r['id'],r['title'],r['deduction'],'فعال' if r['active'] else 'غیرفعال']):self.items.setItem(i,j,QTableWidgetItem(str(v)))
    def load_items_to_combo(self):
        self.item.clear()
        with db() as c:rows=c.execute('SELECT id,title,deduction FROM discipline_items WHERE active=1 ORDER BY title').fetchall()
        for r in rows:self.item.addItem(f"{r['title']} | کسر {r['deduction']}",r['id'])
    def add_item(self):
        d=ItemDialog(self)
        if d.exec()!=QDialog.Accepted:return
        title,desc,ded,active=d.values()
        if not title:return
        try:
            with db() as c:c.execute('INSERT INTO discipline_items(title,description,deduction,active,created_at) VALUES(?,?,?,?,?)',(title,desc,ded,active,datetime.now().isoformat(timespec='seconds')));c.commit()
            self.load_items();self.load_items_to_combo()
        except Exception as e:QMessageBox.warning(self,'انضباط',str(e))
    def edit_item(self):
        r=self.items.currentRow() if hasattr(self,'items') else -1
        if r<0:return
        row={'id':self.items.item(r,0).text(),'title':self.items.item(r,1).text(),'deduction':self.items.item(r,2).text(),'active':1 if self.items.item(r,3).text()=='فعال' else 0};d=ItemDialog(self,row)
        if d.exec()!=QDialog.Accepted:return
        title,desc,ded,active=d.values()
        with db() as c:c.execute('UPDATE discipline_items SET title=?,description=?,deduction=?,active=? WHERE id=?',(title,desc,ded,active,row['id']));c.commit()
        self.load_items();self.load_items_to_combo()
    def delete_item(self):
        r=self.items.currentRow() if hasattr(self,'items') else -1
        if r<0:return
        with db() as c:c.execute('UPDATE discipline_items SET active=0 WHERE id=?',(self.items.item(r,0).text(),));c.commit()
        self.load_items();self.load_items_to_combo()
    def set_base(self):
        d=QDialog(self);f=QFormLayout(d);w=QDoubleSpinBox();w.setRange(1,20);w.setValue(20);f.addRow('نمره پایه',w);b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject)
        if d.exec()==QDialog.Accepted:
            with db() as c:c.execute("UPDATE discipline_settings SET base_score=?,updated_at=datetime('now') WHERE id=1",(w.value(),));c.commit()
    def add_record(self):
        sid=self.student.currentData();iid=self.item.currentData()
        if sid is None or iid is None:QMessageBox.warning(self,'انضباط','دانش‌آموز و مورد را انتخاب کنید.');return
        with db() as c:
            it=c.execute('SELECT title,deduction FROM discipline_items WHERE id=? AND active=1',(iid,)).fetchone()
            if not it:return
            c.execute('INSERT INTO discipline_records(student_id,title,description,status,created_at,item_id,deduction,actor_username,actor_role,note) VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,it['title'],it['title'],'confirmed',datetime.now().isoformat(timespec='seconds'),iid,it['deduction'],self.actor_username,self.actor_role,self.note.text().strip()));c.commit()
        self.note.clear();self.load_records();QMessageBox.information(self,'انضباط','مورد انضباطی ثبت شد.')
    def load_records(self):
        with db() as c:
            rows=c.execute('SELECT d.student_id,s.first_name||\' \'||s.last_name name,d.title,d.deduction,d.note,d.actor_username,d.created_at FROM discipline_records d LEFT JOIN students s ON s.id=d.student_id ORDER BY d.id DESC LIMIT 300').fetchall();base=c.execute('SELECT base_score FROM discipline_settings WHERE id=1').fetchone()[0]
        self.records.setRowCount(len(rows))
        for i,r in enumerate(rows):
            with db() as c2:agg=c2.execute('SELECT COALESCE(SUM(deduction),0) total,COUNT(*) n FROM discipline_records WHERE student_id=?',(r['student_id'],)).fetchone()
            score=max(0,float(base)-float(agg['total'])); vals=[r['name'] or r['student_id'],r['title'],r['deduction'],r['note'],r['actor_username'],r['created_at'],f'{score:g} | {rating(score,agg["n"]>0)}']
            for j,v in enumerate(vals):self.records.setItem(i,j,QTableWidgetItem(str(v or '')))
