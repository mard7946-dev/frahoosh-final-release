from ui.online_class_manager import OnlineClassManagerPage

class VirtualClassPage(OnlineClassManagerPage):
    def __init__(self,parent=None):
        super().__init__(parent,actor_role='manager')
