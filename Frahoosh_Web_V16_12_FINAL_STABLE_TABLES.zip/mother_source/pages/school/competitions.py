from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QTextEdit,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
from services.management_service import ManagementService
from ui.audience_selector import AudienceSelectorDialog
from services.audience_service import begin_capture, end_capture
from utils.jalali import jalali_to_iso, iso_to_jalali
class CompetitionsPage(QWidget):
    def __init__(self,parent=None): super().__init__(parent); self.init_ui(); self.load_data()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel("مدیریت مسابقات و فعالیت‌ها"); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont("B Nazanin",24,QFont.Bold)); l.addWidget(t); f=QHBoxLayout(); self.title=QLineEdit(); self.title.setPlaceholderText("عنوان"); self.cat=QLineEdit(); self.cat.setPlaceholderText("دسته"); self.start=QLineEdit(); self.start.setPlaceholderText("شروع شمسی 1405/01/01"); self.end=QLineEdit(); self.end.setPlaceholderText("پایان شمسی 1405/01/30"); add=QPushButton("ثبت"); add.clicked.connect(self.add); [f.addWidget(x) for x in [self.title,self.cat,self.start,self.end,add]]; l.addLayout(f); self.desc=QTextEdit(); self.desc.setPlaceholderText("توضیحات"); l.addWidget(self.desc); self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(["ID","عنوان","دسته","شروع","پایان","وضعیت","توضیحات"]); l.addWidget(self.table); d=QPushButton("حذف"); d.clicked.connect(self.delete); l.addWidget(d)
    def load_data(self):
        rows=ManagementService.competitions(); self.table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            vals=list(row); vals[3]=iso_to_jalali(vals[3]); vals[4]=iso_to_jalali(vals[4])
            for c,v in enumerate(vals): self.table.setItem(r,c,QTableWidgetItem(str(v)))
    def add(self):
        try:
            d=AudienceSelectorDialog(self,[('school_students',''),('school_parents',''),('manager',''),('vice',''),('advisor','')])
            if not d.exec(): return
            targets=d.targets(); begin_capture('competitions',targets); begin_capture('cultural_items',targets)
            ManagementService.add_competition(self.title.text(),self.cat.text(),jalali_to_iso(self.start.text()),jalali_to_iso(self.end.text()),self.desc.toPlainText())
            end_capture('competitions'); end_capture('cultural_items'); self.load_data()
        except Exception as e:
            end_capture('competitions'); end_capture('cultural_items'); QMessageBox.warning(self,"خطا",str(e))
    def delete(self):
        r=self.table.currentRow()
        if r>=0: ManagementService.delete_competition(int(self.table.item(r,0).text())); self.load_data()
