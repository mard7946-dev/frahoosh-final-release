from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QLineEdit,QComboBox,QMessageBox,QInputDialog
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from services.management_service import ManagementService

class UsersPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.init_ui(); self.load_data()
    def init_ui(self):
        layout=QVBoxLayout(self); title=QLabel("مدیریت کاربران و سطح دسترسی"); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setFont(QFont("B Nazanin",24,QFont.Bold)); layout.addWidget(title)
        form=QHBoxLayout(); self.username=QLineEdit(); self.username.setPlaceholderText("نام کاربری"); self.password=QLineEdit(); self.password.setPlaceholderText("رمز (خالی = 1234)"); self.role=QComboBox(); self.role.addItems(ManagementService.ROLES)
        add=QPushButton("افزودن"); add.clicked.connect(self.add_user); form.addWidget(self.username); form.addWidget(self.password); form.addWidget(self.role); form.addWidget(add); layout.addLayout(form)
        self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(["شناسه","نام کاربری","نقش","دسترسی","عملیات"]); layout.addWidget(self.table)
        row=QHBoxLayout(); change=QPushButton("تغییر رمز"); change.clicked.connect(self.change_password); delete=QPushButton("حذف کاربر"); delete.clicked.connect(self.delete_user); row.addWidget(change); row.addWidget(delete); layout.addLayout(row)
        self.setStyleSheet('''QWidget{background:#F8FAFD;font-family:"B Nazanin";} QLineEdit,QComboBox{background:white;padding:8px;border:1px solid #CBD5E1;border-radius:8px;} QPushButton{background:#1565C0;color:white;border-radius:9px;padding:9px;} QTableWidget{background:white;}''')
    def load_data(self):
        rows=ManagementService.users(); self.table.setRowCount(len(rows))
        for r,data in enumerate(rows):
            for c,val in enumerate(data): self.table.setItem(r,c,QTableWidgetItem(str(val)))
            self.table.setItem(r,4,QTableWidgetItem("قابل مدیریت"))
    def add_user(self):
        try:
            ManagementService.create_user(self.username.text(),self.role.currentText(),self.password.text())
            self.username.clear(); self.password.clear(); self.load_data()
        except Exception as e: QMessageBox.critical(self,"خطا",str(e))
    def selected_id(self):
        r=self.table.currentRow(); return int(self.table.item(r,0).text()) if r>=0 and self.table.item(r,0) else None
    def delete_user(self):
        uid=self.selected_id()
        if uid is None: return
        try: ManagementService.delete_user(uid); self.load_data()
        except Exception as e: QMessageBox.warning(self,"حذف",str(e))
    def change_password(self):
        uid=self.selected_id()
        if uid is None: return
        pwd,ok=QInputDialog.getText(self,"تغییر رمز","رمز جدید:")
        if ok:
            try: ManagementService.set_password(uid,pwd); QMessageBox.information(self,"رمز","رمز با موفقیت تغییر کرد.")
            except Exception as e: QMessageBox.warning(self,"خطا",str(e))
