from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
import sqlite3, shutil, os
from services.management_service import ManagementService
from utils.jalali import iso_to_jalali

class SettingsPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.init_ui(); self.load_data()
    def db(self):
        c=sqlite3.connect(ManagementService.DB_PATH); c.row_factory=sqlite3.Row; return c
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel('تنظیمات فراهوش'); t.setAlignment(Qt.AlignCenter); t.setFont(QFont('B Nazanin',24,QFont.Bold)); l.addWidget(t)
        tabs=QTabWidget(); l.addWidget(tabs)
        # School settings: independent table + management form
        sw=QWidget(); sl=QVBoxLayout(sw); form=QFormLayout()
        self.school_name=QLineEdit(); self.school_code=QLineEdit(); self.principal=QLineEdit(); self.phone=QLineEdit(); self.address=QLineEdit(); self.year=QLineEdit(); self.logo=QLineEdit()
        for label,w in [('نام مدرسه',self.school_name),('کد مدرسه',self.school_code),('مدیر',self.principal),('تلفن',self.phone),('آدرس',self.address),('سال تحصیلی',self.year),('مسیر لوگو',self.logo)]: form.addRow(label,w)
        sl.addLayout(form); b=QPushButton('ذخیره اطلاعات مدرسه'); b.clicked.connect(self.save_school); sl.addWidget(b)
        self.school_table=QTableWidget(0,7); self.school_table.setHorizontalHeaderLabels(['ID','مدرسه','کد','مدیر','تلفن','سال','آخرین بروزرسانی']); sl.addWidget(self.school_table)
        tabs.addTab(sw,'تنظیمات مدرسه')
        # Account settings
        aw=QWidget(); al=QVBoxLayout(aw); af=QFormLayout()
        self.username=QLineEdit('admin'); self.display=QLineEdit(); self.account_phone=QLineEdit(); self.email=QLineEdit(); self.password=QLineEdit(); self.password.setEchoMode(QLineEdit.Password)
        for label,w in [('نام کاربری',self.username),('نام نمایشی',self.display),('تلفن',self.account_phone),('ایمیل',self.email),('رمز جدید (اختیاری)',self.password)]: af.addRow(label,w)
        al.addLayout(af); ab=QPushButton('ذخیره/تغییر اطلاعات حساب'); ab.clicked.connect(self.save_account); al.addWidget(ab)
        self.account_table=QTableWidget(0,5); self.account_table.setHorizontalHeaderLabels(['کاربر','نام نمایشی','تلفن','ایمیل','آخرین بروزرسانی']); al.addWidget(self.account_table)
        al.addWidget(QLabel('کاربران سامانه'))
        self.users_table=QTableWidget(0,5); self.users_table.setHorizontalHeaderLabels(['ID','نام کاربری','نقش','نام نمایشی','دانش‌آموز/دبیر مرتبط']); al.addWidget(self.users_table)
        tabs.addTab(aw,'تنظیمات حساب')
        # backup
        bw=QWidget(); bl=QVBoxLayout(bw); bb=QPushButton('پشتیبان‌گیری از دیتابیس'); bb.clicked.connect(self.backup); bl.addWidget(bb); tabs.addTab(bw,'پشتیبان')
    def load_data(self):
        with self.db() as c:
            r=c.execute('SELECT * FROM school_profile WHERE id=1').fetchone()
            if r:
                for w,k in [(self.school_name,'school_name'),(self.school_code,'school_code'),(self.principal,'principal_name'),(self.phone,'phone'),(self.address,'address'),(self.year,'academic_year'),(self.logo,'logo_path')]:w.setText(str(r[k] or ''))
            rows=c.execute('SELECT id,school_name,school_code,principal_name,phone,academic_year,updated_at FROM school_profile').fetchall()
            self._fill(self.school_table,rows)
            ar=c.execute('SELECT username,display_name,phone,email,updated_at FROM account_settings ORDER BY username').fetchall(); self._fill(self.account_table,ar)
            ur=c.execute('SELECT id,username,role,display_name,COALESCE(linked_student_id,linked_teacher_id,linked_staff_id,\'\') FROM users ORDER BY username').fetchall(); self._fill(self.users_table,ur)
            a=c.execute('SELECT display_name,phone,email FROM account_settings WHERE username=?',(self.username.text() or 'admin',)).fetchone()
            if a:self.display.setText(a['display_name'] or '');self.account_phone.setText(a['phone'] or '');self.email.setText(a['email'] or '')
    def _fill(self,t,rows):
        t.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):t.setItem(i,j,QTableWidgetItem(str(v or '')))
    def save_school(self):
        try:
            with self.db() as c:
                c.execute('''UPDATE school_profile SET school_name=?,school_code=?,principal_name=?,phone=?,address=?,academic_year=?,logo_path=?,updated_at=CURRENT_TIMESTAMP WHERE id=1''',
                    (self.school_name.text(),self.school_code.text(),self.principal.text(),self.phone.text(),self.address.text(),self.year.text(),self.logo.text()));c.commit()
            self.load_data();QMessageBox.information(self,'تنظیمات مدرسه','اطلاعات مدرسه ذخیره شد.')
        except Exception as e:QMessageBox.critical(self,'خطا',str(e))
    def save_account(self):
        u=self.username.text().strip()
        if not u:return QMessageBox.warning(self,'حساب','نام کاربری الزامی است.')
        try:
            with self.db() as c:
                c.execute('''INSERT INTO account_settings(username,display_name,phone,email,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)
                             ON CONFLICT(username) DO UPDATE SET display_name=excluded.display_name,phone=excluded.phone,email=excluded.email,updated_at=CURRENT_TIMESTAMP''',
                          (u,self.display.text(),self.account_phone.text(),self.email.text()))
                if self.password.text():
                    c.execute('UPDATE users SET password=? WHERE username=?',(self.password.text(),u))
                c.commit()
            self.password.clear();self.load_data();QMessageBox.information(self,'حساب','اطلاعات حساب ذخیره شد.')
        except Exception as e:QMessageBox.critical(self,'خطا',str(e))
    def backup(self):
        target,_=QFileDialog.getSaveFileName(self,'ذخیره پشتیبان','school_backup.db','SQLite DB (*.db)')
        if target:
            try: shutil.copy2(str(ManagementService.DB_PATH),target);QMessageBox.information(self,'پشتیبان','پشتیبان ساخته شد.')
            except Exception as e:QMessageBox.critical(self,'خطا',str(e))
class Panel(SettingsPage): pass
