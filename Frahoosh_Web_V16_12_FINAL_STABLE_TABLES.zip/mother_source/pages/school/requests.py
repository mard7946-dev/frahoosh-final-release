from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QTextEdit,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
from services.management_service import ManagementService
class RequestsPage(QWidget):
    def __init__(self,parent=None): super().__init__(parent); self.init_ui(); self.load_data()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel("مدیریت درخواست‌ها و تأییدها"); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont("B Nazanin",24,QFont.Bold)); l.addWidget(t); f=QHBoxLayout(); self.typ=QLineEdit(); self.typ.setPlaceholderText("نوع درخواست"); self.req=QLineEdit(); self.req.setPlaceholderText("درخواست‌کننده"); self.role=QComboBox(); self.role.addItems(ManagementService.ROLES); self.desc=QLineEdit(); self.desc.setPlaceholderText("توضیحات"); add=QPushButton("ثبت درخواست"); add.clicked.connect(self.add); [f.addWidget(x) for x in [self.typ,self.req,self.role,self.desc,add]]; l.addLayout(f); self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(["ID","نوع","درخواست‌کننده","نقش","توضیحات","وضعیت","تاریخ"]); l.addWidget(self.table); row=QHBoxLayout(); a=QPushButton("تأیید"); a.clicked.connect(lambda:self.set_status("تأیید شده")); r=QPushButton("رد"); r.clicked.connect(lambda:self.set_status("رد شده")); row.addWidget(a); row.addWidget(r); l.addLayout(row)
    def load_data(self):
        conn=ManagementService.connect()
        try: rows=conn.execute("SELECT id,request_type,requester,role,description,status,created_at FROM school_requests ORDER BY id DESC").fetchall()
        finally: conn.close()
        self.table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row): self.table.setItem(r,c,QTableWidgetItem(str(v)))
    def add(self):
        if not self.typ.text().strip() or not self.req.text().strip(): return
        conn=ManagementService.connect()
        try: conn.execute("INSERT INTO school_requests(request_type,requester,role,description,created_at) VALUES(?,?,?,?,?)",(self.typ.text(),self.req.text(),self.role.currentText(),self.desc.text(),ManagementService._now())); conn.commit(); self.load_data()
        finally: conn.close()
    def set_status(self,status):
        r=self.table.currentRow()
        if r<0:return
        conn=ManagementService.connect()
        try: conn.execute("UPDATE school_requests SET status=?,updated_at=? WHERE id=?",(status,ManagementService._now(),int(self.table.item(r,0).text()))); conn.commit(); self.load_data()
        finally: conn.close()
