from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTextEdit,QLineEdit,QComboBox,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from ui.audience_selector import AudienceSelectorDialog, AudienceDropdownWidget
from services.management_service import ManagementService
class AnnouncementsPage(QWidget):
    def __init__(self,parent=None): super().__init__(parent); self.init_ui(); self.load_data()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel("مدیریت اطلاع‌رسانی مدرسه"); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont("B Nazanin",24,QFont.Bold)); l.addWidget(t)
        self.title=QLineEdit(); self.title.setPlaceholderText("عنوان اطلاعیه"); self.audiences=[]; self.audience_picker=AudienceDropdownWidget(self, [], "مخاطب اطلاعیه — قبل از ثبت نهایی"); self.priority=QComboBox(); self.priority.addItems(["عادی","مهم","فوری"]); self.text=QTextEdit(); self.text.setPlaceholderText("متن اطلاعیه")
        add=QPushButton("ثبت و انتشار"); add.clicked.connect(self.add); l.addWidget(self.title); l.addWidget(self.audience_picker); l.addWidget(self.priority); l.addWidget(self.text); l.addWidget(add)
        self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(["شناسه","عنوان","اولویت","تاریخ","متن"]); l.addWidget(self.table); dele=QPushButton("حذف اطلاعیه انتخاب‌شده"); dele.clicked.connect(self.delete); l.addWidget(dele)
    def load_data(self):
        rows=ManagementService.announcements(); self.table.setRowCount(len(rows))
        for r,(i,title,msg,p,date,creator) in enumerate(rows):
            vals=[i,title,p,date,msg]
            for c,v in enumerate(vals): self.table.setItem(r,c,QTableWidgetItem(str(v)))
    def add(self):
        try:
            msg=self.text.toPlainText().strip()
            if not msg: raise ValueError('متن اطلاعیه الزامی است')
            self.audiences=self.audience_picker.targets()
            if not self.audiences: raise ValueError('ابتدا مخاطبان را از منوی کشویی انتخاب کنید.')
            item_id=ManagementService.add_announcement(self.title.text(),msg,self.priority.currentText(),"مدیریت")
            from services.message_service import send
            send("مدیریت",msg,'school','all',self.title.text(),audiences=self.audiences)
            self.title.clear(); self.text.clear(); self.audiences=[]; self.audience_picker._targets=[]; self.audience_picker._refresh_list(); self.load_data()
        except Exception as e: QMessageBox.warning(self,"خطا",str(e))
    def delete(self):
        r=self.table.currentRow()
        if r<0:return
        ManagementService.delete_announcement(int(self.table.item(r,0).text())); self.load_data()
