from PySide6.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QLabel, QFrame
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from services.management_service import ManagementService


class DashboardPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        self.load_data()

    def init_ui(self):
        layout = QVBoxLayout(self)
        title = QLabel("داشبورد مدیریت مدرسه")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("B Nazanin", 28, QFont.Bold))
        layout.addWidget(title)
        self.grid = QGridLayout()
        layout.addLayout(self.grid)
        layout.addStretch()
        self.setStyleSheet('''QFrame{background:white;border-radius:18px;border:1px solid #E1E8ED;padding:15px;} QLabel{color:#263238;}''')

    def load_data(self):
        stats = ManagementService.stats()
        while self.grid.count():
            item = self.grid.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        cards = [
            ("دانش‌آموزان", stats["students"]), ("دبیران", stats["teachers"]),
            ("کلاس‌ها", stats["classes"]), ("کلاس‌های فعال", stats["live_classes"]),
            ("درخواست‌های در انتظار", stats["pending_requests"]), ("اطلاعیه‌ها", stats["announcements"]),
        ]
        for i, (title, value) in enumerate(cards):
            card = QFrame(); box = QVBoxLayout(card)
            a = QLabel(title); a.setAlignment(Qt.AlignmentFlag.AlignCenter); a.setFont(QFont("B Nazanin", 15, QFont.Bold))
            b = QLabel(str(value)); b.setAlignment(Qt.AlignmentFlag.AlignCenter); b.setFont(QFont("B Nazanin", 28, QFont.Bold))
            box.addWidget(a); box.addWidget(b); self.grid.addWidget(card, i // 3, i % 3)
