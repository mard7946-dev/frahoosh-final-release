from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QFileDialog,QMessageBox
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import csv
from services.management_service import ManagementService
class ReportsPage(QWidget):
    def __init__(self,parent=None): super().__init__(parent); self.init_ui(); self.load_data()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel("گزارشات مدیریتی"); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont("B Nazanin",24,QFont.Bold)); l.addWidget(t); self.table=QTableWidget(0,2); self.table.setHorizontalHeaderLabels(["شاخص","مقدار"]); l.addWidget(self.table); row=QHBoxLayout(); ref=QPushButton("تازه‌سازی"); ref.clicked.connect(self.load_data); exp=QPushButton("خروجی CSV"); exp.clicked.connect(self.export_csv); row.addWidget(ref); row.addWidget(exp); l.addLayout(row)
    def load_data(self):
        stats=ManagementService.stats(); self.table.setRowCount(len(stats)); labels={"students":"دانش‌آموزان","teachers":"دبیران","classes":"کلاس‌ها","live_classes":"کلاس فعال","pending_requests":"درخواست در انتظار","announcements":"اطلاعیه‌ها"}
        for r,(k,v) in enumerate(stats.items()): self.table.setItem(r,0,QTableWidgetItem(labels.get(k,k))); self.table.setItem(r,1,QTableWidgetItem(str(v)))
    def export_csv(self):
        path,_=QFileDialog.getSaveFileName(self,"ذخیره گزارش","management_report.csv","CSV (*.csv)")
        if not path:return
        try:
            with open(path,"w",newline="",encoding="utf-8-sig") as f:
                w=csv.writer(f); w.writerow(["شاخص","مقدار"])
                for r in range(self.table.rowCount()): w.writerow([self.table.item(r,0).text(),self.table.item(r,1).text()])
            QMessageBox.information(self,"گزارش","فایل گزارش ساخته شد.")
        except Exception as e: QMessageBox.critical(self,"خطا",str(e))
