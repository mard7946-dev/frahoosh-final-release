from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,
    QSpinBox,QDoubleSpinBox,QPushButton,QTableWidget,QTableWidgetItem,QTabWidget,QMessageBox,QDialog,QFormLayout,QDialogButtonBox)
from PySide6.QtGui import QFont
from services.management_service import ManagementService
from utils.jalali import iso_to_jalali, weekday_fa, jalali_to_iso
from ui.audience_selector import AudienceSelectorDialog
from services.audience_service import begin_capture, end_capture

class PlanningPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.init_ui(); self.load_data()

    def _jalali_edit(self, placeholder):
        w=QLineEdit(); w.setPlaceholderText(placeholder); return w

    def init_ui(self):
        l=QVBoxLayout(self)
        title=QLabel("مدیریت برنامه هفتگی و برنامه امتحانی")
        title.setFont(QFont("B Nazanin",24,QFont.Bold)); title.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(title)
        tabs=QTabWidget(); l.addWidget(tabs)

        # Weekly schedule
        w=QWidget(); wl=QVBoxLayout(w); f=QHBoxLayout()
        self.wteacher=QLineEdit(); self.wteacher.setPlaceholderText("نام دبیر")
        self.whours=QDoubleSpinBox(); self.whours.setRange(0.5,100); self.whours.setSingleStep(0.5); self.whours.setSuffix(" ساعت در هفته")
        self.wgrade=QLineEdit(); self.wgrade.setPlaceholderText("پایه تدریس")
        self.wclasses=QSpinBox(); self.wclasses.setRange(1,100); self.wclasses.setPrefix("تعداد کلاس: ")
        self.wsubject=QLineEdit(); self.wsubject.setPlaceholderText("نام درس")
        self.wpattern=QComboBox(); self.wpattern.addItems(["یک زنگ کامل","یک زنگ کامل + یک زنگ یکی در میان در هفته","دو زنگ کامل"])
        self.wclassnames=QLineEdit(); self.wclassnames.setPlaceholderText("کلاس‌ها: 7/1، 7/2")
        add=QPushButton("ثبت اطلاعات")
        generate=QPushButton("تولید برنامه")
        add.clicked.connect(self.add_weekly); generate.clicked.connect(self.generate_weekly)
        for x in [self.wteacher,self.whours,self.wgrade,self.wclasses,self.wsubject,self.wpattern,self.wclassnames,add,generate]: f.addWidget(x)
        wl.addLayout(f)
        self.wsearch=QLineEdit(); self.wsearch.setPlaceholderText('جستجوی اطلاعات برنامه هفتگی...'); wl.addWidget(self.wsearch)
        self.wtable=QTableWidget(0,8); self.wtable.setHorizontalHeaderLabels(["ID","دبیر","ساعت","پایه","تعداد کلاس","درس","چینش زنگ","کلاس‌ها"]); self.wtable.setAlternatingRowColors(True); wl.addWidget(self.wtable)
        row=QHBoxLayout(); d=QPushButton("حذف ردیف انتخاب‌شده"); e=QPushButton("ویرایش ردیف انتخاب‌شده"); row.addWidget(d); row.addWidget(e); row.addStretch(); d.clicked.connect(self.del_weekly); e.clicked.connect(self.edit_weekly); wl.addLayout(row)
        self.generated_label=QLabel("برنامه تولیدشده: هنوز تولید نشده است"); wl.addWidget(self.generated_label)
        self.generated_table=QTableWidget(0,7); self.generated_table.setHorizontalHeaderLabels(["دبیر","درس","پایه","کلاس","روز هفته","زنگ","هفته"]); wl.addWidget(self.generated_table)
        self.wsearch.textChanged.connect(self.load_data); tabs.addTab(w,"برنامه هفتگی")

        # Exam schedule: only Jalali range is entered; exam date is generated automatically.
        e=QWidget(); el=QVBoxLayout(e); ef=QHBoxLayout()
        self.esub=QLineEdit(); self.esub.setPlaceholderText("نام درس")
        self.egrade=QLineEdit(); self.egrade.setPlaceholderText("پایه")
        self.estart=self._jalali_edit("شروع بازه شمسی: 1405/03/01")
        self.eend=self._jalali_edit("پایان بازه شمسی: 1405/03/20")
        self.eweight=QComboBox(); self.eweight.addItems(["ساده","متوسط","سخت"])
        self.edur=QLineEdit(); self.edur.setReadOnly(True); self.edur.setPlaceholderText("خودکار: ساده ۳۰ / متوسط ۴۵ / سخت ۶۰")
        self.eweight.currentTextChanged.connect(lambda v: self.edur.setText({"ساده":"30","متوسط":"45","سخت":"60"}.get(v,"45")))
        self.eweight.setCurrentText("متوسط")
        ea=QPushButton('ثبت امتحان و تعیین خودکار تاریخ'); ea.clicked.connect(self.add_exam)
        for x in [self.esub,self.egrade,self.estart,self.eend,self.eweight,self.edur,ea]: ef.addWidget(x)
        el.addLayout(ef)
        buttons=QHBoxLayout(); auto=QPushButton("چیدمان خودکار بر اساس سنگینی درس"); auto.clicked.connect(self.auto_schedule); refresh=QPushButton("تازه‌سازی"); refresh.clicked.connect(self.load_data); buttons.addWidget(auto); buttons.addWidget(refresh); el.addLayout(buttons)
        self.esearch=QLineEdit(); self.esearch.setPlaceholderText('جستجوی برنامه امتحانی...'); el.addWidget(self.esearch)
        self.etable=QTableWidget(0,11); self.etable.setHorizontalHeaderLabels(["ID","درس","پایه","شروع بازه شمسی","پایان بازه شمسی","سطح","تاریخ امتحان شمسی","روز هفته","دقیقه","شروع","پایان"]); self.etable.setAlternatingRowColors(True); el.addWidget(self.etable)
        row2=QHBoxLayout(); ed=QPushButton("حذف امتحان انتخاب‌شده"); ee=QPushButton("ویرایش دستی تاریخ/درس"); row2.addWidget(ed); row2.addWidget(ee); row2.addStretch(); ed.clicked.connect(self.del_exam); ee.clicked.connect(self.edit_exam); el.addLayout(row2)
        self.esearch.textChanged.connect(self.load_data); tabs.addTab(e,"برنامه امتحانی")

    def load_data(self):
        rows=ManagementService.weekly_entries(); q=self.wsearch.text().strip().lower(); rows=[x for x in rows if not q or q in " ".join(map(str,x)).lower()]; self.wtable.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row): self.wtable.setItem(r,c,QTableWidgetItem(str(v or '')))
        gen=ManagementService.generated_weekly_entries(); self.generated_table.setRowCount(len(gen))
        for r,row in enumerate(gen):
            for c,v in enumerate(row): self.generated_table.setItem(r,c,QTableWidgetItem(str(v or '')))
        self.generated_label.setText(f"برنامه تولیدشده: {len(gen)} جلسه")

        rows=ManagementService.exam_entries(); q=self.esearch.text().strip().lower(); rows=[x for x in rows if not q or q in " ".join(map(str,x)).lower()]; self.etable.setRowCount(len(rows))
        for r,row in enumerate(rows):
            vals=[row[0],row[1],row[2],iso_to_jalali(row[3]),iso_to_jalali(row[4]),row[5],iso_to_jalali(row[6]),weekday_fa(row[6]),row[7],row[8],row[9]]
            for c,v in enumerate(vals): self.etable.setItem(r,c,QTableWidgetItem(str(v or '')))

    def add_weekly(self):
        if not self.wteacher.text().strip() or not self.wgrade.text().strip() or not self.wsubject.text().strip(): QMessageBox.warning(self,"خطا","نام دبیر، پایه و نام درس الزامی است."); return
        try:
            d=AudienceSelectorDialog(self,[('teacher',''),('manager',''),('vice',''),('grade_students',self.wgrade.text().strip()),('school_parents','')])
            if not d.exec(): return
            begin_capture('weekly_schedule',d.targets())
            ManagementService.add_weekly_entry(self.wteacher.text(),self.whours.value(),self.wgrade.text(),self.wclasses.value(),self.wsubject.text(),self.wpattern.currentText(),self.wclassnames.text())
            end_capture('weekly_schedule'); self.load_data()
        except Exception as e:
            end_capture('weekly_schedule'); QMessageBox.warning(self,"خطا",str(e))

    def generate_weekly(self):
        try:
            if not ManagementService.weekly_entries(): QMessageBox.warning(self,"برنامه هفتگی","ابتدا اطلاعات دبیر و درس را ثبت کنید."); return
            n=ManagementService.generate_weekly_schedule(); self.load_data(); QMessageBox.information(self,"تولید برنامه",f"برنامه هفتگی با {n} جلسه تولید شد.")
        except Exception as e: QMessageBox.critical(self,"خطای تولید برنامه",str(e))

    def edit_weekly(self):
        r=self.wtable.currentRow()
        if r<0:return
        QMessageBox.information(self,'ویرایش','برای اصلاح اطلاعات، ردیف را حذف و اطلاعات جدید را ثبت کنید.')
    def del_weekly(self):
        r=self.wtable.currentRow()
        if r>=0: ManagementService.delete_weekly_entry(int(self.wtable.item(r,0).text())); self.load_data()

    def add_exam(self):
        if not self.esub.text().strip() or not self.egrade.text().strip(): QMessageBox.warning(self,"خطا","درس و پایه الزامی است."); return
        try:
            start=jalali_to_iso(self.estart.text()); end=jalali_to_iso(self.eend.text())
            if start>end: raise ValueError('بازه زمانی نامعتبر است')
            date=ManagementService.suggest_exam_date(start,end,self.eweight.currentText(),self.egrade.text().strip())
            d=AudienceSelectorDialog(self,[('grade_students',self.egrade.text().strip()),('school_parents',''),('manager',''),('vice',''),('teacher','')])
            if not d.exec(): return
            begin_capture('exam_schedule',d.targets())
            ManagementService.add_exam(self.esub.text(),self.egrade.text(),start,end,self.eweight.currentText(),date,{'ساده':30,'متوسط':45,'سخت':60}[self.eweight.currentText()])
            end_capture('exam_schedule'); self.load_data()
            QMessageBox.information(self,'ثبت شد',f'تاریخ امتحان: {iso_to_jalali(date)} — {weekday_fa(date)}')
        except Exception as e: QMessageBox.warning(self,"خطا",str(e))

    def auto_schedule(self):
        try: n=ManagementService.auto_schedule_exams(); self.load_data(); QMessageBox.information(self,'چیدمان',f'{n} امتحان زمان‌بندی شد.')
        except Exception as e: QMessageBox.warning(self,'خطا',str(e))

    def edit_exam(self):
        r=self.etable.currentRow()
        if r<0:return
        vals=[self.etable.item(r,c).text() for c in range(11)]
        d=QDialog(self); d.setWindowTitle('ویرایش دستی برنامه امتحان'); f=QFormLayout(d); ws=[]
        for label,val in [('درس',vals[1]),('پایه',vals[2]),('شروع بازه شمسی',vals[3]),('پایان بازه شمسی',vals[4]),('تاریخ امتحان شمسی',vals[6]),('روز هفته',vals[7]),('مدت',vals[8])]:
            w=QLineEdit(val); f.addRow(label,w); ws.append(w)
        box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); f.addWidget(box); box.accepted.connect(d.accept); box.rejected.connect(d.reject)
        if d.exec()!=QDialog.Accepted:return
        try:
            import sqlite3
            from pathlib import Path
            DB=Path(__file__).resolve().parents[2]/'school.db'
            start=jalali_to_iso(ws[2].text()); end=jalali_to_iso(ws[3].text()); exam=jalali_to_iso(ws[4].text())
            with sqlite3.connect(DB) as c: c.execute('UPDATE exam_schedule SET subject=?,grade=?,start_date=?,end_date=?,exam_date=?,duration=? WHERE id=?',(ws[0].text(),ws[1].text(),start,end,exam,int(ws[6].text() or 90),int(vals[0]))); c.commit()
            self.load_data()
        except Exception as e: QMessageBox.critical(self,'خطا',str(e))

    def del_exam(self):
        r=self.etable.currentRow()
        if r>=0: ManagementService.delete_exam(int(self.etable.item(r,0).text())); self.load_data()
