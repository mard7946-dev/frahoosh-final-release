from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QStackedWidget, QFrame, QGridLayout
from PySide6.QtCore import Qt
from utils.export_tools import widget_to_pdf, print_widget
from PySide6.QtGui import QFont

from pages.school.dashboard import DashboardPage
from services.management_service import ManagementService
from ui.unified_inbox import UnifiedInboxPage,UnifiedMessengerPage


class Panel(QWidget):
    """پنل مدیریت مدرسه؛ همه عملیات اصلی به دیتابیس متصل هستند."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pages = {}
        ManagementService.initialize()
        self.init_ui()

    def init_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(0, 0, 0, 0)
        self.menu = self.create_menu()
        self.stack = QStackedWidget()
        self.load_pages()
        main.addWidget(self.menu)
        main.addWidget(self.stack, 1)
        self.open_page("dashboard")
        self.apply_style()

    def load_pages(self):
        page_files = [
            ("dashboard", "pages.school.dashboard", "DashboardPage"),
            ("reports", "pages.school.reports", "ReportsPage"),
            ("virtual", "pages.school.virtual_class", "VirtualClassPage"),
            ("requests", "pages.school.requests", "RequestsPage"),
            ("competitions", "pages.school.competitions", "CompetitionsPage"),
            ("trips", "pages.cultural.trips", "Panel"),
            ("planning", "pages.school.planning", "PlanningPage"),
            ("notice", "pages.school.announcements", "AnnouncementsPage"),
            ("users", "pages.school.users", "UsersPage"),
            ("settings", "pages.school.settings", "SettingsPage"),
            ("discipline", "pages.discipline", "DisciplinePage"),
            ("surveys", "pages.surveys", "SurveyManager"),
            ("inbox", None, None), ("messages", None, None),
        ]
        import importlib
        for key, module_name, class_name in page_files:
            try:
                module = importlib.import_module(module_name)
                page_cls = getattr(module, class_name)
                if key == "inbox":
                    page = UnifiedInboxPage(username=getattr(self, "current_username", "admin"), role="manager", title="پیام‌ها و رویدادهای مدرسه", parent=self)
                elif key == "messages":
                    page = UnifiedMessengerPage(sender="مدیریت", role="manager", parent=self)
                elif key == "discipline":
                    page = page_cls(parent=self, actor_username=getattr(self, "current_username", "admin"), actor_role="manager", manager=True)
                elif key == "surveys":
                    page = page_cls(parent=self, username=getattr(self, "current_username", "admin"))
                else:
                    page = page_cls(parent=self)
                self.pages[key] = page
                self.stack.addWidget(page)
            except Exception as exc:
                error = QLabel(f"خطا در بارگذاری بخش «{key}»\n{exc}")
                error.setAlignment(Qt.AlignmentFlag.AlignCenter)
                self.pages[key] = error
                self.stack.addWidget(error)

    def create_menu(self):
        frame = QFrame()
        frame.setObjectName("management_menu")
        layout = QVBoxLayout(frame)
        layout.setSpacing(8)
        title = QLabel("فراهوش\nمدیریت مدرسه")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("B Nazanin", 20, QFont.Bold))
        layout.addWidget(title)
        buttons = [
            ("داشبورد", "dashboard"), ("گزارشات", "reports"),
            ("کلاس آنلاین", "virtual"), ("درخواست‌ها", "requests"),
            ("برنامه هفتگی و امتحانات", "planning"), ("مسابقات", "competitions"),
            ("اطلاع‌رسانی", "notice"), ("📥 پیام‌های دریافتی", "inbox"), ("✉️ ارسال پیام", "messages"), ("کاربران و دسترسی", "users"),
            ("تنظیمات و سرور", "settings"),
            ("🛡️ ثبت موارد انضباطی", "discipline"),
            ("📊 مدیریت نظرسنجی", "surveys"),
            ("🚌 مدیریت اردوها", "trips"),
            ("🔗 معاونت آموزشی", "nav_education"), ("🔗 معاونت پرورشی", "nav_cultural"), ("🔗 معاونت اجرایی", "nav_executive"),
            ("🔗 مشاور", "nav_advisor"), ("🔗 دبیران", "nav_teachers"), ("🔗 دانش‌آموزان", "nav_students"), ("🔗 اولیا", "nav_parents"), ("🔗 مالی", "nav_finance"), ("🔗 هوش مصنوعی", "nav_ai"),
        ]
        grid = QGridLayout()
        grid.setSpacing(8)
        for i, (text, key) in enumerate(buttons):
            btn = QPushButton(text)
            btn.setMinimumSize(125, 44)
            btn.setMaximumHeight(50)
            btn.setStyleSheet("font-size:14px; padding:5px 8px; border-radius:9px;")
            btn.clicked.connect(lambda checked=False, k=key: self.open_page(k))
            grid.addWidget(btn, i // 6, i % 6)
        layout.addLayout(grid)
        layout.addStretch()
        return frame

    def open_page(self, name):
        nav = {
            "nav_education":"معاونت آموزشی", "nav_cultural":"معاونت پرورشی", "nav_executive":"معاونت اجرایی",
            "nav_advisor":"مشاور", "nav_teachers":"دبیران", "nav_students":"دانش‌آموزان", "nav_parents":"اولیا",
            "nav_finance":"مالی", "nav_ai":"هوش مصنوعی"
        }
        if name in nav:
            p=self.parent()
            while p is not None:
                if hasattr(p,'open_page'):
                    p.open_page(nav[name]); return
                p=p.parent()
        page = self.pages.get(name)
        if page is None:
            return
        self.stack.setCurrentWidget(page)
        if hasattr(page, "load_data"):
            try:
                page.load_data()
            except Exception:
                pass

    def apply_style(self):
        self.setStyleSheet('''
            QWidget { background:#F7F9FC; color:#263238; font-family:"B Nazanin"; }
            QFrame#management_menu { background:#0D47A1; border-radius:14px; }
            QFrame#management_menu QLabel { color:white; padding:8px; }
            QFrame#management_menu QPushButton { background:#43A047; color:white; border:0; border-radius:10px; padding:10px; font-size:14px; }
            QFrame#management_menu QPushButton:hover { background:#2E7D32; }
        ''')
