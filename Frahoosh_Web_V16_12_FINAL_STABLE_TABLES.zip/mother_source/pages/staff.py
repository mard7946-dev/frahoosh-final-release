from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame


class StaffPage(QWidget):

    def __init__(self):
        super().__init__()

        self.build_ui()


    def build_ui(self):

        layout = QVBoxLayout(self)


        title = QLabel("مدیریت کارکنان مدرسه")

        title.setStyleSheet("""
            font-size:22px;
            font-weight:bold;
            color:#2E7D32;
        """)

        layout.addWidget(title)


        card = QFrame()

        card.setStyleSheet("""
            QFrame{
                background:#E8F5E9;
                border-radius:15px;
                padding:20px;
            }
        """)


        card_layout = QVBoxLayout(card)


        info = QLabel(
            "مدیریت اطلاعات کارکنان مدرسه\n\n"
            "• پرونده پرسنلی\n"
            "• اطلاعات دبیران و عوامل اجرایی\n"
            "• سوابق کاری\n"
            "• گزارشات پرسنلی"
        )

        info.setStyleSheet("""
            font-size:16px;
        """)


        card_layout.addWidget(info)

        layout.addWidget(card)

        layout.addStretch()