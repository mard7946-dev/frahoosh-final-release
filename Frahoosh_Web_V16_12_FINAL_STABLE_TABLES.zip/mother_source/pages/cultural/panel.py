from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QStackedWidget,QMessageBox,QGridLayout
from PySide6.QtCore import Qt
from utils.export_tools import widget_to_pdf, print_widget
from ui.unified_inbox import UnifiedInboxPage,UnifiedMessengerPage
from PySide6.QtGui import QFont
from ui.complete_module_pages import CompleteTabs, cultural_specs

class Panel(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.pages={}; self.init_ui()
    def init_ui(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(20,20,20,20); layout.setSpacing(15)
        title=QLabel("فراهوش | معاونت پرورشی و فرهنگی"); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setFont(QFont("B Zar",26,QFont.Bold)); layout.addWidget(title)
        menu=QGridLayout(); menu.setSpacing(8)
        for i,(text,key) in enumerate([("صبحگاه / ظهرگاه","ceremonies"),("مسابقات","competitions"),("اردوها","trips"),("جشنواره‌ها","festivals"),("استعداد","talents"),("قرآن و نماز","quran"),("گزارشات","reports"),("ثبت‌نام فعالیت‌ها","complete"),("📥 پیام‌های دریافتی","inbox"),("✉️ ارسال پیام","messages")]):
            btn=QPushButton(text); btn.setMinimumSize(125,44); btn.setMaximumHeight(50); btn.setFont(QFont("B Zar",14,QFont.Bold)); btn.clicked.connect(lambda checked=False,k=key:self.open_page(k)); menu.addWidget(btn,i//6,i%6)
        layout.addLayout(menu); self.stack=QStackedWidget(); layout.addWidget(self.stack); self.load_pages()
    def load_pages(self):
        specs = [
            ("ceremonies", "pages.cultural.ceremonies", "Panel"),
            ("competitions", "pages.cultural.competitions", "Panel"),
            ("trips", "pages.cultural.trips", "Panel"),
            ("festivals", "pages.cultural.festivals", "Panel"),
            ("talents", "pages.cultural.talents", "Panel"),
            ("quran", "pages.cultural.quran", "Panel"),
            ("reports", "pages.cultural.reports", "Panel"),
        ]
        self.pages = {
            'inbox': UnifiedInboxPage(role='vice', title='پیام‌ها و رویدادهای مدرسه', parent=self),
            'messages': UnifiedMessengerPage(sender='معاون پرورشی', role='vice', parent=self),
            'complete': CompleteTabs(cultural_specs(), 'پرورشی | ثبت‌نام فعالیت‌ها و سوابق فرهنگی', self),
        }
        self.stack.addWidget(self.pages['inbox']); self.stack.addWidget(self.pages['messages']); self.stack.addWidget(self.pages['complete'])
        import importlib
        for key, module_name, class_name in specs:
            try:
                cls = getattr(importlib.import_module(module_name), class_name)
                page = cls(self)
            except Exception as e:
                page = QWidget(self)
                box = QVBoxLayout(page)
                lab = QLabel(f'خطا در بارگذاری «{key}»\n{e}')
                lab.setAlignment(Qt.AlignmentFlag.AlignCenter); lab.setWordWrap(True)
                box.addWidget(lab)
            self.pages[key] = page
            self.stack.addWidget(page)

    def open_page(self,key):
        page=self.pages.get(key)
        if page is not None:
            self.stack.setCurrentWidget(page)
            if hasattr(page,"reload"): page.reload()
    def show_main_page(self): self.stack.setCurrentIndex(0)
