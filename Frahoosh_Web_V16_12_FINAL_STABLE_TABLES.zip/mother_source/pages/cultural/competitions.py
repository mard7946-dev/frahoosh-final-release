from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind="competition"; title="فراهوش | مسابقات"; input_placeholder="عنوان مسابقه را وارد کنید..."; add_text="ثبت مسابقه"; list_title="مسابقات ثبت‌شده"; delete_text="حذف مسابقه"
