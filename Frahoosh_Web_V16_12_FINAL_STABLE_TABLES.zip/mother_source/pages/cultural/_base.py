from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QTableWidget,QTableWidgetItem,QDialog,QFormLayout,QLineEdit,QTextEdit,QDialogButtonBox,QMessageBox,QHeaderView
from PySide6.QtCore import Qt
from database.cultural_db import list_items,add_item,update_item,delete_item,initialize

class CulturalCrudPanel(QWidget):
    kind='generic'; title='فعالیت فرهنگی'; add_text='ثبت'; list_title='رکوردهای ثبت‌شده'; delete_text='حذف'
    def __init__(self,parent=None):
        super().__init__(parent); initialize(); self.setLayoutDirection(Qt.RightToLeft); self._build(); self.reload()
    def _build(self):
        l=QVBoxLayout(self); t=QLabel(self.title); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setStyleSheet('font-size:24px;font-weight:bold;'); l.addWidget(t)
        bar=QHBoxLayout(); add=QPushButton(self.add_text); edit=QPushButton('ویرایش'); dele=QPushButton(self.delete_text); ref=QPushButton('تازه‌سازی');
        for b in (add,edit,dele,ref):bar.addWidget(b)
        l.addLayout(bar); self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['ID','عنوان','دانش‌آموز','جزئیات','هزینه','وضعیت','تاریخ']); self.table.setSelectionBehavior(QTableWidget.SelectRows); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); l.addWidget(self.table)
        add.clicked.connect(self.add_record); edit.clicked.connect(self.edit_record); dele.clicked.connect(self.delete_record); ref.clicked.connect(self.reload)
    def reload(self):
        rows=list_items(self.kind); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate([r['id'],r['title'],r['student_name'],r['details'],r['fee'],r['status'],r['created_at']]): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def form(self,row=None):
        d=QDialog(self); f=QFormLayout(d); w={}
        for k,label in [('title','عنوان'),('student_name','نام دانش‌آموز'),('details','جزئیات'),('fee','هزینه'),('status','وضعیت')]:
            x=QTextEdit() if k=='details' else QLineEdit();
            if isinstance(x,QTextEdit):x.setPlainText(str((row or {}).get(k,'') or ''))
            else:x.setText(str((row or {}).get(k,'') or ''))
            w[k]=x;f.addRow(label,x)
        box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addWidget(box);box.accepted.connect(d.accept);box.rejected.connect(d.reject);return d,w
    def val(self,x):return x.toPlainText().strip() if isinstance(x,QTextEdit) else x.text().strip()
    def add_record(self):
        d,w=self.form()
        if d.exec()!=QDialog.Accepted:return
        title=self.val(w['title']);
        if not title:return QMessageBox.warning(self,'ثبت','عنوان الزامی است.')
        try:add_item(self.kind,title,self.val(w['student_name']),self.val(w['details'])); self.reload()
        except Exception as e:QMessageBox.critical(self,'ثبت',str(e))
    def edit_record(self):
        r=self.table.currentRow()
        if r<0:return
        rid=int(self.table.item(r,0).text()); rows=list_items(self.kind); old=next((dict(x) for x in rows if int(x['id'])==rid),None)
        if not old:return
        d,w=self.form(old)
        if d.exec()!=QDialog.Accepted:return
        try:
            update_item(rid,self.val(w['title']),self.val(w['student_name']),self.val(w['details']),self.val(w['status']) or 'active')
            with __import__('sqlite3').connect(__import__('os').path.abspath(__import__('os').path.join(__import__('os').path.dirname(__file__),'..','..','school.db'))) as c:c.execute('UPDATE cultural_items SET fee=? WHERE id=?',(int(float(self.val(w['fee']) or 0)),rid));c.commit()
            self.reload()
        except Exception as e:QMessageBox.critical(self,'ویرایش',str(e))
    def delete_record(self):
        r=self.table.currentRow()
        if r<0:return
        if QMessageBox.question(self,'حذف','رکورد حذف شود؟',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        delete_item(int(self.table.item(r,0).text()));self.reload()
    def go_back(self):
        p=self.parent()
        while p:
            if hasattr(p,'show_main_page'):p.show_main_page();return
            p=p.parent()
