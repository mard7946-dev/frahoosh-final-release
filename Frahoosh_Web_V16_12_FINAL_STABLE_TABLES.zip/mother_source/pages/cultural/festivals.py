from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind='festival'; title='فراهوش | جشنواره‌ها'; input_placeholder='عنوان جشنواره را وارد کنید...'; add_text='ثبت جشنواره'; list_title='جشنواره‌های ثبت‌شده'; delete_text='حذف جشنواره'
