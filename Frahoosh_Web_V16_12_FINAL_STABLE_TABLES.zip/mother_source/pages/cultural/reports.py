from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind="cultural_report"; title="فراهوش | گزارشات معاونت پرورشی"; input_placeholder="عنوان گزارش را وارد کنید..."; add_text="ثبت گزارش"; list_title="گزارشات ثبت‌شده"; delete_text="حذف گزارش"
