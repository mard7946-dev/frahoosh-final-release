from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind="talent"; title="فراهوش | استعدادهای دانش‌آموزان"; input_placeholder="نام دانش‌آموز و استعداد او را وارد کنید..."; add_text="ثبت استعداد"; list_title="استعدادهای ثبت‌شده"; delete_text="حذف استعداد"
