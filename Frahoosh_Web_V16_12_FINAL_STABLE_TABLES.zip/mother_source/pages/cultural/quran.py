from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind="quran_prayer"; title="فراهوش | قرآن و نماز"; input_placeholder="عنوان فعالیت قرآنی یا نماز را وارد کنید..."; add_text="ثبت فعالیت"; list_title="فعالیت‌های ثبت‌شده"; delete_text="حذف فعالیت"
