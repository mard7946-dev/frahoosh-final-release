from ._base import CulturalCrudPanel


class Panel(CulturalCrudPanel):
    kind = "trip"
    title = "فراهوش | مدیریت اردوها"
    input_placeholder = "عنوان اردو را وارد کنید..."
    add_text = "ثبت اردو"
    list_title = "اردوهای ثبت‌شده"
    delete_text = "حذف اردو"
