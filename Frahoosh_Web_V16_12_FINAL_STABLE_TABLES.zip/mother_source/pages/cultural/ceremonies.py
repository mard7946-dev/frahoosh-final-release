from ._base import CulturalCrudPanel
class Panel(CulturalCrudPanel):
    kind="ceremony"; title="فراهوش | صبحگاه / ظهرگاه"; input_placeholder="عنوان برنامه صبحگاه / ظهرگاه را وارد کنید..."; add_text="ثبت برنامه"; list_title="برنامه‌های ثبت‌شده"; delete_text="حذف برنامه"
