import sqlite3, os
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QDialog,QFormLayout,QDialogButtonBox,QComboBox,QTextEdit,QMessageBox,QCheckBox
from PySide6.QtCore import Qt
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
def db(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def ensure_schema():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS surveys(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'draft',audience TEXT NOT NULL DEFAULT 'students_parents',start_at TEXT DEFAULT '',end_at TEXT DEFAULT '',created_by TEXT DEFAULT 'admin',created_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS survey_questions(id INTEGER PRIMARY KEY AUTOINCREMENT,survey_id INTEGER NOT NULL,question TEXT NOT NULL,question_type TEXT NOT NULL DEFAULT 'text',options TEXT DEFAULT '',required INTEGER NOT NULL DEFAULT 0,sort_order INTEGER NOT NULL DEFAULT 0);CREATE TABLE IF NOT EXISTS survey_responses(id INTEGER PRIMARY KEY AUTOINCREMENT,survey_id INTEGER NOT NULL,respondent_username TEXT NOT NULL,respondent_role TEXT NOT NULL,student_id INTEGER,submitted_at TEXT NOT NULL,UNIQUE(survey_id,respondent_username,respondent_role,student_id));CREATE TABLE IF NOT EXISTS survey_answers(id INTEGER PRIMARY KEY AUTOINCREMENT,response_id INTEGER NOT NULL,question_id INTEGER NOT NULL,answer TEXT DEFAULT '');''')
class SurveyManager(QWidget):
    def __init__(self,parent=None,username='admin'):
        super().__init__(parent);ensure_schema();self.username=username;l=QVBoxLayout(self);h=QLabel('📊 مدیریت نظرسنجی | فقط پس از تایید مدیر فعال می‌شود');h.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(h)
        bar=QHBoxLayout()
        for text,fn in [('نظرسنجی جدید',self.add_survey),('ویرایش',self.edit_survey),('افزودن آیتم',self.add_question),('فعال‌سازی/تایید مدیر',self.publish),('بایگانی',self.archive),('گزارش پاسخ‌ها',self.report)]:
            b=QPushButton(text);b.clicked.connect(fn);bar.addWidget(b)
        l.addLayout(bar);self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(['ID','عنوان','وضعیت','مخاطب','تاریخ']);l.addWidget(self.table);self.load()
    def load(self):
        with db() as c:rows=c.execute('SELECT id,title,status,audience,created_at FROM surveys ORDER BY id DESC').fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def selected(self):
        r=self.table.currentRow();return int(self.table.item(r,0).text()) if r>=0 else None
    def add_survey(self):
        d=QDialog(self);f=QFormLayout(d);title=QLineEdit();desc=QTextEdit();aud=QComboBox();aud.addItems(['دانش‌آموزان','اولیا','دانش‌آموزان و اولیا']);f.addRow('عنوان',title);f.addRow('توضیحات',desc);f.addRow('مخاطب',aud);b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject)
        if d.exec()!=QDialog.Accepted or not title.text().strip():return
        av=['students','parents','students_parents'][aud.currentIndex()]
        with db() as c:c.execute('INSERT INTO surveys(title,description,audience,created_by,created_at) VALUES(?,?,?,?,?)',(title.text().strip(),desc.toPlainText().strip(),av,self.username,datetime.now().isoformat(timespec='seconds')));c.commit()
        self.load()
    def edit_survey(self):
        sid=self.selected()
        if not sid:return
        with db() as c:r=c.execute('SELECT title,description FROM surveys WHERE id=? AND status="draft"',(sid,)).fetchone()
        if not r:return
        d=QDialog(self);f=QFormLayout(d);title=QLineEdit(r['title']);desc=QTextEdit(r['description'] or '');f.addRow('عنوان',title);f.addRow('توضیحات',desc);b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject)
        if d.exec()==QDialog.Accepted:
            with db() as c:c.execute('UPDATE surveys SET title=?,description=? WHERE id=?',(title.text().strip(),desc.toPlainText().strip(),sid));c.commit()
            self.load()
    def add_question(self):
        sid=self.selected()
        if not sid:return
        with db() as c:r=c.execute('SELECT status FROM surveys WHERE id=?',(sid,)).fetchone()
        if not r or r['status']!='draft':QMessageBox.warning(self,'نظرسنجی','بعد از فعال‌سازی امکان تغییر آیتم‌ها بسته می‌شود.');return
        d=QDialog(self);f=QFormLayout(d);q=QTextEdit();typ=QComboBox();typ.addItems(['متنی','بله/خیر','امتیاز 1 تا 5','انتخابی']);opts=QLineEdit();req=QCheckBox('پاسخ الزامی');f.addRow('سؤال',q);f.addRow('نوع',typ);f.addRow('گزینه‌ها با |',opts);f.addRow(req);b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject)
        if d.exec()!=QDialog.Accepted or not q.toPlainText().strip():return
        qt=['text','yesno','rating','choice'][typ.currentIndex()]
        with db() as c:
            order=c.execute('SELECT COALESCE(MAX(sort_order),0)+1 FROM survey_questions WHERE survey_id=?',(sid,)).fetchone()[0]
            c.execute('INSERT INTO survey_questions(survey_id,question,question_type,options,required,sort_order) VALUES(?,?,?,?,?,?)',(sid,q.toPlainText().strip(),qt,opts.text().strip(),1 if req.isChecked() else 0,order));c.commit()
        QMessageBox.information(self,'نظرسنجی','آیتم سؤال ثبت شد.')
    def publish(self):
        sid=self.selected()
        if not sid:return
        with db() as c:n=c.execute('SELECT COUNT(*) FROM survey_questions WHERE survey_id=?',(sid,)).fetchone()[0]
        if n==0:QMessageBox.warning(self,'نظرسنجی','حداقل یک آیتم سؤال اضافه کنید.');return
        with db() as c:c.execute('UPDATE surveys SET status="published" WHERE id=?',(sid,));c.commit()
        self.load();QMessageBox.information(self,'نظرسنجی','نظرسنجی با تایید مدیر فعال شد.')
    def archive(self):
        sid=self.selected()
        if sid:
            with db() as c:c.execute('UPDATE surveys SET status="archived" WHERE id=?',(sid,));c.commit();self.load()
    def report(self):
        sid=self.selected()
        if not sid:return
        with db() as c:rows=c.execute('SELECT respondent_role,COUNT(*) n FROM survey_responses WHERE survey_id=? GROUP BY respondent_role',(sid,)).fetchall()
        QMessageBox.information(self,'گزارش پاسخ‌ها','\n'.join(f'{r[0]}: {r[1]}' for r in rows) or 'هنوز پاسخی ثبت نشده است.')
class PublicSurvey(QWidget):
    def __init__(self,parent=None,role='student',username='guest',student_id=None):
        super().__init__(parent);ensure_schema();self.role=role;self.username=username;self.student_id=student_id;l=QVBoxLayout(self);t=QLabel('📊 نظرسنجی‌های فعال');t.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(t);self.list=QTableWidget(0,4);self.list.setHorizontalHeaderLabels(['ID','عنوان','توضیحات','مخاطب']);l.addWidget(self.list);b=QPushButton('شرکت در نظرسنجی انتخاب‌شده');b.clicked.connect(self.open_selected);l.addWidget(b);self.load()
    def load(self):
        audience='students' if self.role=='student' else 'parents'
        with db() as c:rows=c.execute('SELECT id,title,description,audience FROM surveys WHERE status="published" AND audience IN (?,"students_parents") ORDER BY id DESC',(audience,)).fetchall()
        self.list.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate(r):self.list.setItem(i,j,QTableWidgetItem(str(v or '')))
    def open_selected(self):
        r=self.list.currentRow()
        if r<0:return
        sid=int(self.list.item(r,0).text())
        with db() as c:qs=c.execute('SELECT * FROM survey_questions WHERE survey_id=? ORDER BY sort_order,id',(sid,)).fetchall()
        d=QDialog(self);d.setWindowTitle(self.list.item(r,1).text());f=QFormLayout(d);widgets=[]
        for q in qs:
            if q['question_type']=='yesno':w=QComboBox();w.addItems(['بله','خیر'])
            elif q['question_type']=='rating':w=QComboBox();w.addItems([str(i) for i in range(1,6)])
            elif q['question_type']=='choice':w=QComboBox();w.addItems([x.strip() for x in (q['options'] or '').split('|') if x.strip()])
            else:w=QLineEdit()
            widgets.append((q,w));f.addRow(q['question'],w)
        b=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(b);b.accepted.connect(d.accept);b.rejected.connect(d.reject)
        if d.exec()!=QDialog.Accepted:return
        try:
            with db() as c:
                cur=c.execute('INSERT INTO survey_responses(survey_id,respondent_username,respondent_role,student_id,submitted_at) VALUES(?,?,?,?,?)',(sid,self.username,self.role,self.student_id,datetime.now().isoformat(timespec='seconds')));rid=cur.lastrowid
                for q,w in widgets:
                    ans=w.currentText() if isinstance(w,QComboBox) else w.text();c.execute('INSERT INTO survey_answers(response_id,question_id,answer) VALUES(?,?,?)',(rid,q['id'],ans))
                c.commit()
            QMessageBox.information(self,'نظرسنجی','پاسخ شما با موفقیت ثبت شد.')
        except sqlite3.IntegrityError:QMessageBox.warning(self,'نظرسنجی','این نظرسنجی قبلاً برای این حساب ثبت شده است.')
