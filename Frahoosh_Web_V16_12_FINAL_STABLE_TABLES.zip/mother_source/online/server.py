# =====================================================
# Frahoosh Online Classroom Server
# مدیریت کلاس آنلاین فراهوش
# =====================================================


import uuid
import time
from datetime import datetime


class ClassroomServer:


    def __init__(self):

        # لیست کلاس‌های فعال
        self.rooms = {}



    # =================================================
    # ساخت کلاس جدید
    # =================================================

    def create_room(
        self,
        teacher_id,
        lesson_name,
        class_name
    ):

        room_id = str(
            uuid.uuid4()
        )[:8]


        self.rooms[room_id] = {

            "room_id": room_id,

            "teacher": teacher_id,

            "lesson": lesson_name,

            "class": class_name,


            "created": datetime.now(),


            "users": {},


            "status": "active"

        }


        return room_id



    # =================================================
    # ورود کاربر به کلاس
    # =================================================

    def join_room(
        self,
        room_id,
        user_id,
        name,
        role
    ):


        if room_id not in self.rooms:

            return False



        self.rooms[room_id]["users"][user_id] = {


            "id": user_id,


            "name": name,


            "role": role,


            # وضعیت‌ها

            "microphone": False,

            "camera": False,


            "hand_raise": False,


            "online": True,


            "joined":

                datetime.now()

        }


        return True



    # =================================================
    # خروج کاربر
    # =================================================

    def leave_room(
        self,
        room_id,
        user_id
    ):


        if room_id in self.rooms:


            if user_id in self.rooms[room_id]["users"]:


                del self.rooms[room_id]["users"][user_id]


                return True



        return False



    # =================================================
    # گرفتن کاربران کلاس
    # =================================================

    def get_users(
        self,
        room_id
    ):


        if room_id in self.rooms:


            return list(
                self.rooms[room_id]["users"].values()
            )


        return []



    # =================================================
    # تغییر وضعیت میکروفن
    # =================================================

    def set_microphone(
        self,
        room_id,
        user_id,
        state
    ):


        if room_id in self.rooms:


            user = self.rooms[room_id]["users"].get(
                user_id
            )


            if user:

                user["microphone"] = state

                return True


        return False
    

    # =================================================
    # تغییر وضعیت دوربین
    # =================================================

    def set_camera(
        self,
        room_id,
        user_id,
        state
    ):


        if room_id in self.rooms:


            user = self.rooms[room_id]["users"].get(
                user_id
            )


            if user:

                user["camera"] = state

                return True



        return False




    # =================================================
    # درخواست دست بالا بردن دانش‌آموز
    # =================================================

    def raise_hand(
        self,
        room_id,
        user_id
    ):


        if room_id in self.rooms:


            user = self.rooms[room_id]["users"].get(
                user_id
            )


            if user:


                user["hand_raise"] = True


                user["hand_time"] = datetime.now()


                return True



        return False




    # =================================================
    # پایین آوردن دست
    # توسط دبیر
    # =================================================

    def lower_hand(
        self,
        room_id,
        user_id
    ):


        if room_id in self.rooms:


            user = self.rooms[room_id]["users"].get(
                user_id
            )


            if user:


                user["hand_raise"] = False


                return True



        return False




    # =================================================
    # اجازه دادن به میکروفن
    # توسط دبیر
    # =================================================

    def allow_microphone(
        self,
        room_id,
        user_id
    ):


        return self.set_microphone(
            room_id,
            user_id,
            True
        )




    # =================================================
    # قطع میکروفن
    # =================================================

    def mute_microphone(
        self,
        room_id,
        user_id
    ):


        return self.set_microphone(
            room_id,
            user_id,
            False
        )




    # =================================================
    # اجازه دوربین
    # =================================================

    def allow_camera(
        self,
        room_id,
        user_id
    ):


        return self.set_camera(
            room_id,
            user_id,
            True
        )




    # =================================================
    # قطع دوربین
    # =================================================

    def disable_camera(
        self,
        room_id,
        user_id
    ):


        return self.set_camera(
            room_id,
            user_id,
            False
        )




    # =================================================
    # دریافت درخواست‌های انتظار
    # مخصوص دبیر
    # =================================================

    def get_requests(
        self,
        room_id
    ):


        requests = []


        if room_id in self.rooms:


            for user in self.rooms[room_id]["users"].values():


                if user.get(
                    "hand_raise",
                    False
                ):


                    requests.append(user)



        return requests
    


    # =================================================
    # تغییر وضعیت آنلاین کاربر
    # =================================================

    def set_online_status(
        self,
        room_id,
        user_id,
        status
    ):


        if room_id in self.rooms:


            user = self.rooms[room_id]["users"].get(
                user_id
            )


            if user:


                user["online"] = status

                user["last_seen"] = datetime.now()

                return True



        return False




    # =================================================
    # بررسی وضعیت کاربران
    # برای تشخیص قطع اتصال
    # =================================================

    def check_users_status(
        self,
        room_id
    ):


        offline_users = []


        if room_id in self.rooms:


            now = datetime.now()


            for user in self.rooms[room_id]["users"].values():


                last_seen = user.get(
                    "last_seen",
                    now
                )


                difference = (
                    now - last_seen
                ).seconds



                # بیشتر از 10 دقیقه بدون فعالیت

                if difference > 600:


                    user["online"] = False


                    offline_users.append(user)



        return offline_users




    # =================================================
    # تعداد حاضرین کلاس
    # =================================================

    def get_online_count(
        self,
        room_id
    ):


        count = 0


        if room_id in self.rooms:


            for user in self.rooms[room_id]["users"].values():


                if user["online"]:


                    count += 1



        return count




    # =================================================
    # اطلاعات کامل کلاس
    # =================================================

    def get_room_info(
        self,
        room_id
    ):


        if room_id in self.rooms:


            room = self.rooms[room_id]


            return {

                "room_id":
                    room["room_id"],


                "teacher":
                    room["teacher"],


                "lesson":
                    room["lesson"],


                "class":
                    room["class"],


                "users":
                    room["users"],


                "count":
                    len(room["users"])


            }


        return None




    # =================================================
    # پایان کلاس
    # =================================================

    def close_room(
        self,
        room_id
    ):


        if room_id in self.rooms:


            self.rooms[room_id]["status"] = "closed"


            return True



        return False




    # =================================================
    # حذف کامل کلاس
    # =================================================

    def remove_room(
        self,
        room_id
    ):


        if room_id in self.rooms:


            del self.rooms[room_id]


            return True



        return False




    # =================================================
    # تست ساده سرور
    # =================================================

    def test_server(self):


        return {

            "server":
                "Frahoosh Online Server",


            "status":
                "ready",


            "rooms":
                len(self.rooms)

        }