# =====================================================
# Frahoosh Online Classroom
# WebRTC Client Manager
# آماده‌سازی ارتباط صدا و تصویر کلاس آنلاین
# =====================================================


from datetime import datetime



class WebRTCClient:



    def __init__(
        self,
        user_id,
        role
    ):


        self.user_id = user_id


        self.role = role


        # وضعیت اتصال

        self.connected = False



        # وضعیت رسانه

        self.microphone_enabled = False


        self.camera_enabled = False


        self.screen_share = False



        # اطلاعات کلاس

        self.room_id = None



        # زمان اتصال

        self.connected_time = None



        # کاربران متصل

        self.peers = {}




    # =================================================
    # ورود به کلاس
    # =================================================

    def join_room(
        self,
        room_id
    ):


        self.room_id = room_id


        self.connected = True


        self.connected_time = datetime.now()


        return {


            "status":

                "joined",


            "room":

                room_id

        }




    # =================================================
    # خروج از کلاس
    # =================================================

    def leave_room(self):


        self.connected = False


        self.room_id = None


        self.peers.clear()



        return True




    # =================================================
    # فعال کردن میکروفن
    # =================================================

    def enable_microphone(self):


        self.microphone_enabled = True



        return {


            "microphone":

                True

        }




    # =================================================
    # خاموش کردن میکروفن
    # =================================================

    def disable_microphone(self):


        self.microphone_enabled = False



        return {


            "microphone":

                False

        }
    

    # =================================================
    # فعال کردن دوربین
    # =================================================

    def enable_camera(self):


        self.camera_enabled = True



        return {


            "camera":

                True

        }




    # =================================================
    # خاموش کردن دوربین
    # =================================================

    def disable_camera(self):


        self.camera_enabled = False



        return {


            "camera":

                False

        }




    # =================================================
    # فعال کردن اشتراک صفحه
    # =================================================

    def start_screen_share(self):


        self.screen_share = True



        return {


            "screen_share":

                True

        }




    # =================================================
    # توقف اشتراک صفحه
    # =================================================

    def stop_screen_share(self):


        self.screen_share = False



        return {


            "screen_share":

                False

        }




    # =================================================
    # ثبت کاربر مقابل
    # Peer
    # =================================================

    def add_peer(
        self,
        peer_id,
        info
    ):


        self.peers[peer_id] = {


            "info":

                info,


            "connected":

                False,


            "created":

                datetime.now()

        }



        return True




    # =================================================
    # حذف کاربر مقابل
    # =================================================

    def remove_peer(
        self,
        peer_id
    ):


        if peer_id in self.peers:


            del self.peers[peer_id]


            return True



        return False




    # =================================================
    # تغییر وضعیت Peer
    # =================================================

    def update_peer_status(
        self,
        peer_id,
        status
    ):


        if peer_id in self.peers:


            self.peers[peer_id][
                "connected"
            ] = status



            return True



        return False




    # =================================================
    # دریافت کاربران متصل
    # =================================================

    def get_peers(self):


        return self.peers
    

    # =================================================
    # ساخت درخواست اتصال
    # Offer
    # =================================================

    def create_offer(
        self,
        target_id
    ):


        return {


            "type":

                "offer",


            "from":

                self.user_id,


            "to":

                target_id,


            "room":

                self.room_id,


            "time":

                datetime.now()

        }




    # =================================================
    # پاسخ به درخواست اتصال
    # Answer
    # =================================================

    def create_answer(
        self,
        target_id
    ):


        return {


            "type":

                "answer",


            "from":

                self.user_id,


            "to":

                target_id,


            "room":

                self.room_id,


            "time":

                datetime.now()

        }




    # =================================================
    # اطلاعات اتصال شبکه
    # ICE Candidate
    # =================================================

    def create_ice_candidate(
        self,
        candidate
    ):


        return {


            "type":

                "ice_candidate",


            "user":

                self.user_id,


            "candidate":

                candidate,


            "time":

                datetime.now()

        }




    # =================================================
    # دریافت پیام WebRTC
    # =================================================

    def handle_signal(
        self,
        message
    ):


        message_type = message.get(
            "type"
        )


        if message_type == "offer":


            return "offer_received"



        elif message_type == "answer":


            return "answer_received"



        elif message_type == "ice_candidate":


            return "candidate_received"



        return "unknown"




    # =================================================
    # وضعیت کامل کلاینت
    # =================================================

    def status(self):


        return {


            "user":

                self.user_id,


            "role":

                self.role,


            "room":

                self.room_id,


            "connected":

                self.connected,


            "microphone":

                self.microphone_enabled,


            "camera":

                self.camera_enabled,


            "screen_share":

                self.screen_share,


            "peers":

                len(self.peers)

        }




    # =================================================
    # تست WebRTC Client
    # =================================================

    def test_client(self):


        return {


            "module":

                "Frahoosh WebRTC Client",


            "status":

                "ready"

        }