# =====================================================
# Frahoosh Online Classroom
# Signaling Manager
# مدیریت پیام‌های ارتباطی کلاس آنلاین
# =====================================================


from datetime import datetime



class SignalingManager:


    def __init__(self):


        # پیام‌های هر کلاس

        self.messages = {}


        # اتصال کاربران

        self.connections = {}




    # =================================================
    # ثبت اتصال کاربر
    # =================================================

    def register_user(
        self,
        room_id,
        user_id
    ):


        if room_id not in self.connections:


            self.connections[room_id] = {}



        self.connections[room_id][user_id] = {


            "connected":

                True,


            "joined":

                datetime.now()

        }


        return True




    # =================================================
    # حذف اتصال کاربر
    # =================================================

    def unregister_user(
        self,
        room_id,
        user_id
    ):


        if room_id in self.connections:


            if user_id in self.connections[room_id]:


                del self.connections[room_id][user_id]


                return True



        return False




    # =================================================
    # ساخت کانال پیام کلاس
    # =================================================

    def create_channel(
        self,
        room_id
    ):


        if room_id not in self.messages:


            self.messages[room_id] = []



        return True




    # =================================================
    # ارسال پیام
    # =================================================

    def send_message(
        self,
        room_id,
        sender,
        message_type,
        data
    ):


        if room_id not in self.messages:


            self.create_channel(room_id)




        packet = {


            "sender":

                sender,


            "type":

                message_type,


            "data":

                data,


            "time":

                datetime.now()

        }



        self.messages[room_id].append(
            packet
        )


        return packet
    


    # =================================================
    # دریافت پیام‌های کلاس
    # =================================================

    def get_messages(
        self,
        room_id
    ):


        if room_id in self.messages:


            return self.messages[room_id]


        return []




    # =================================================
    # پاک کردن پیام‌های قدیمی
    # =================================================

    def clear_messages(
        self,
        room_id
    ):


        if room_id in self.messages:


            self.messages[room_id].clear()


            return True



        return False




    # =================================================
    # درخواست فعال شدن میکروفن
    # =================================================

    def request_microphone(
        self,
        room_id,
        student_id
    ):


        return self.send_message(


            room_id,


            student_id,


            "microphone_request",


            {

                "status":
                    "waiting"

            }

        )




    # =================================================
    # تایید میکروفن توسط دبیر
    # =================================================

    def approve_microphone(
        self,
        room_id,
        teacher_id,
        student_id
    ):


        return self.send_message(


            room_id,


            teacher_id,


            "microphone_permission",


            {

                "student":
                    student_id,


                "allow":
                    True

            }

        )




    # =================================================
    # درخواست دوربین
    # =================================================

    def request_camera(
        self,
        room_id,
        student_id
    ):


        return self.send_message(


            room_id,


            student_id,


            "camera_request",


            {

                "status":
                    "waiting"

            }

        )




    # =================================================
    # تایید دوربین
    # =================================================

    def approve_camera(
        self,
        room_id,
        teacher_id,
        student_id
    ):


        return self.send_message(


            room_id,


            teacher_id,


            "camera_permission",


            {

                "student":
                    student_id,


                "allow":
                    True

            }

        )




    # =================================================
    # بالا بردن دست
    # =================================================

    def hand_raise(
        self,
        room_id,
        student_id
    ):


        return self.send_message(


            room_id,


            student_id,


            "hand_raise",


            {

                "status":
                    "waiting"

            }

        )
    

    # =================================================
    # ارسال تغییرات تخته هوشمند
    # =================================================

    def send_board_event(
        self,
        room_id,
        user_id,
        event
    ):


        return self.send_message(


            room_id,


            user_id,


            "smart_board",


            event

        )




    # =================================================
    # اشتراک گذاری صفحه نمایش
    # =================================================

    def request_screen_share(
        self,
        room_id,
        user_id
    ):


        return self.send_message(


            room_id,


            user_id,


            "screen_share_request",


            {

                "status":
                    "waiting"

            }

        )




    # =================================================
    # پیام چت کلاس
    # =================================================

    def send_chat_message(
        self,
        room_id,
        user_id,
        text
    ):


        return self.send_message(


            room_id,


            user_id,


            "chat",


            {

                "text":
                    text

            }

        )




    # =================================================
    # اعلام وضعیت اتصال
    # =================================================

    def update_connection_status(
        self,
        room_id,
        user_id,
        status
    ):


        return self.send_message(


            room_id,


            user_id,


            "connection_status",


            {

                "online":
                    status

            }

        )




    # =================================================
    # دریافت آخرین پیام‌ها
    # =================================================

    def get_latest_messages(
        self,
        room_id,
        count=20
    ):


        messages = self.get_messages(
            room_id
        )


        return messages[-count:]




    # =================================================
    # تست Signaling
    # =================================================

    def test_signaling(self):


        return {


            "module":

                "Frahoosh Signaling",


            "status":

                "ready",


            "channels":

                len(self.messages)

        }