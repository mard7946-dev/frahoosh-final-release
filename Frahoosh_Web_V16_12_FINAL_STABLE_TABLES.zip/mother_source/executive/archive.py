import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox
from PySide6.QtCore import Qt
DB=Path(__file__).resolve().parents[1]/'school.db'
class ArchivePage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);self.setLayoutDirection(Qt.RightToLeft);l=QVBoxLayout(self);l.addWidget(__import__('PySide6').QtWidgets.QLabel('بایگانی و سوابق مدرسه'));f=QHBoxLayout();self.title=QLineEdit();self.title.setPlaceholderText('عنوان سند');self.sid=QLineEdit();self.sid.setPlaceholderText('شناسه دانش‌آموز (اختیاری)');self.loc=QLineEdit();self.loc.setPlaceholderText('محل بایگانی');self.desc=QLineEdit();self.desc.setPlaceholderText('توضیحات');a=QPushButton('ثبت');d=QPushButton('حذف');r=QPushButton('تازه‌سازی');[f.addWidget(x) for x in (self.title,self.sid,self.loc,self.desc,a,d,r)];l.addLayout(f);self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['ID','عنوان','دانش‌آموز','محل','توضیحات','تاریخ']);l.addWidget(self.table);a.clicked.connect(self.add);d.clicked.connect(self.delete);r.clicked.connect(self.load);self.ensure();self.load()
 def ensure(self):
  with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS archive_items(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,student_id INTEGER,location TEXT,description TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)');c.commit()
 def load(self):
  with sqlite3.connect(DB) as c:rows=c.execute('SELECT id,title,student_id,location,description,created_at FROM archive_items ORDER BY id DESC').fetchall()
  self.table.setRowCount(len(rows));
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def add(self):
  if not self.title.text().strip():return QMessageBox.warning(self,'بایگانی','عنوان الزامی است.')
  sid=int(self.sid.text()) if self.sid.text().strip().isdigit() else None
  with sqlite3.connect(DB) as c:c.execute('INSERT INTO archive_items(title,student_id,location,description) VALUES(?,?,?,?)',(self.title.text().strip(),sid,self.loc.text().strip(),self.desc.text().strip()));c.commit()
  self.load()
 def delete(self):
  r=self.table.currentRow()
  if r<0:return
  with sqlite3.connect(DB) as c:c.execute('DELETE FROM archive_items WHERE id=?',(int(self.table.item(r,0).text()),));c.commit()
  self.load()
