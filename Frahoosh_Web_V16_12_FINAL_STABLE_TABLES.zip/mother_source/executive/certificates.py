import sqlite3,secrets,os
from pathlib import Path
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QMessageBox,QFileDialog,QHeaderView
from PySide6.QtCore import Qt
from PySide6.QtPrintSupport import QPrinter,QPrintDialog
from PySide6.QtGui import QTextDocument
from .data_schema import ensure_schema
DB=str(Path(__file__).resolve().parents[1]/'school.db')
def db(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

class CertificatesPage(QWidget):
 def __init__(self):
  super().__init__(); ensure_schema(); self.selected_student_id=None; self.ui(); self.fill()
 def load(self): self.fill()
 def ui(self):
  l=QVBoxLayout(self); t=QLabel('گواهی اشتغال به تحصیل / گواهی موقت'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(t)
  b=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('جستجوی نام، کد ملی یا کد دانش‌آموزی'); clear=QPushButton('پاک کردن انتخاب'); create=QPushButton('صدور گواهی'); self.pdf_btn=QPushButton('ذخیره PDF'); self.print_btn=QPushButton('پرینت')
  for w in (self.search,clear,create,self.pdf_btn,self.print_btn): b.addWidget(w)
  l.addLayout(b)
  self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(['انتخاب','دانش‌آموز','کد دانش‌آموزی','کد ملی','پایه']); self.table.setSelectionBehavior(QTableWidget.SelectRows); self.table.setAlternatingRowColors(True); self.table.cellClicked.connect(self.select_student); l.addWidget(self.table)
  self.status=QLabel('دانش‌آموزی انتخاب نشده است'); l.addWidget(self.status)
  self.cert_table=QTableWidget(0,6); self.cert_table.setHorizontalHeaderLabels(['ID','دانش‌آموز','کد دانش‌آموزی','عنوان','کد گواهی','تاریخ']); l.addWidget(self.cert_table)
  self.search.textChanged.connect(self.fill); clear.clicked.connect(self.clear_selection); create.clicked.connect(self.create); self.pdf_btn.clicked.connect(self.save_pdf); self.print_btn.clicked.connect(self.print_cert)
  with db() as c:c.execute('CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,title TEXT,code TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
 def fill(self):
  s='%'+self.search.text().strip()+'%'
  with db() as c:
   ss=c.execute('SELECT id,first_name,last_name,student_code,national_code,grade FROM students WHERE first_name LIKE ? OR last_name LIKE ? OR student_code LIKE ? OR national_code LIKE ? ORDER BY last_name,first_name',(s,s,s,s)).fetchall()
   rs=c.execute('SELECT c.id,s.first_name||" "||s.last_name name,s.student_code,c.title,c.code,c.created_at FROM certificates c LEFT JOIN students s ON s.id=c.student_id ORDER BY c.id DESC').fetchall()
  self.table.setRowCount(len(ss))
  for i,x in enumerate(ss):
   chk=QTableWidgetItem(); chk.setFlags(Qt.ItemFlag.ItemIsEnabled|Qt.ItemFlag.ItemIsUserCheckable); chk.setData(Qt.ItemDataRole.UserRole, int(x['id'])); chk.setCheckState(Qt.CheckState.Checked if x['id']==self.selected_student_id else Qt.CheckState.Unchecked); self.table.setItem(i,0,chk)
   vals=[f"{x['first_name']} {x['last_name']}",x['student_code'] or '',x['national_code'] or '',x['grade'] or '']
   for j,v in enumerate(vals,1): self.table.setItem(i,j,QTableWidgetItem(str(v)))
  self.cert_table.setRowCount(len(rs))
  for i,r in enumerate(rs):
   for j,v in enumerate(r): self.cert_table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def select_student(self,row,col=0):
  item=self.table.item(row,0)
  if not item:return
  sid=item.data(Qt.ItemDataRole.UserRole)
  if sid is not None:self.selected_student_id=int(sid)
  for i in range(self.table.rowCount()): self.table.item(i,0).setCheckState(Qt.CheckState.Checked if i==row else Qt.CheckState.Unchecked)
  name=self.table.item(row,1).text()
  self.status.setText(f"انتخاب شد: {name}")
 def clear_selection(self):
  self.selected_student_id=None
  for i in range(self.table.rowCount()): self.table.item(i,0).setCheckState(Qt.CheckState.Unchecked)
  self.status.setText('دانش‌آموزی انتخاب نشده است')
 def _html(self):
  sid=self.selected_student_id
  if not sid:return None
  with db() as c:r=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
  if not r:return None
  with db() as c:
   school_row=c.execute("SELECT value FROM school_settings WHERE key='school_name'").fetchone() if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='school_settings'").fetchone() else None
   year_row=c.execute("SELECT value FROM school_settings WHERE key='academic_year'").fetchone() if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='school_settings'").fetchone() else None
  school=(school_row['value'] if school_row else '') or 'دبیرستان سردارشهیدحاجی زاده ۲'; year=(year_row['value'] if year_row else '') or '1404-1405'
  photo=''
  if r['photo'] and os.path.exists(str(r['photo'])):
   photo_path=str(r['photo']).replace('\\','/')
   photo=f'<img src="file:///{photo_path}" width="90" height="110">'
  return f'''<html><body dir="rtl" style="font-family:B Nazanin;font-size:15px;direction:rtl;"><div style="text-align:center"><b>جمهوری اسلامی ایران</b><br>وزارت آموزش و پرورش<br><br><b style="font-size:23px">گواهی اشتغال به تحصیل</b></div><table width="100%"><tr><td>{photo}</td><td style="text-align:right">شماره: {r['temporary_certificate_no'] or '-'}<br>سال تحصیلی: {year}<br>دوره تحصیلی: دوره متوسطه اول</td></tr></table><p>بدین وسیله گواهی می‌شود: <b>{r['first_name'] or ''} {r['last_name'] or ''}</b> کد ملی <b>{r['national_code'] or '-'}</b> فرزند: <b>{r['father_name'] or '-'}</b></p><p>شماره شناسنامه: {r['birth_certificate_no'] or r['national_code'] or '-'} &nbsp;&nbsp; تاریخ تولد: {r['birth_date'] or '-'}<br>در مدرسه: <b>{school}</b> در پایه: <b>{r['grade'] or '-'}</b><br>مشغول به تحصیل می‌باشد.</p><p>این گواهی طبق تقاضای مورخ: .................... فقط به منظور ارائه به: ................................ صادر گردید و فاقد هرگونه ارزش دیگری می‌باشد.</p><br><table width="100%"><tr><td>مهر و امضای مدیر مدرسه</td><td style="text-align:left">تاریخ: {datetime.now().strftime('%Y/%m/%d')}</td></tr></table><p style="text-align:center">{school} — مدیر مدرسه</p></body></html>'''
 def _doc(self):
  html=self._html()
  if not html: QMessageBox.warning(self,'گواهی','ابتدا یک دانش‌آموز را از جدول انتخاب کنید.'); return None
  d=QTextDocument(); d.setHtml(html); return d
 def save_pdf(self):
  d=self._doc()
  if not d:return
  path,_=QFileDialog.getSaveFileName(self,'ذخیره گواهی PDF','گواهی-اشتغال.pdf','PDF (*.pdf)')
  if not path:return
  p=QPrinter(QPrinter.HighResolution); p.setOutputFormat(QPrinter.PdfFormat); p.setOutputFileName(path); d.print_(p); QMessageBox.information(self,'گواهی','PDF ذخیره شد.')
 def print_cert(self):
  d=self._doc()
  if not d:return
  p=QPrinter(QPrinter.HighResolution); dlg=QPrintDialog(p,self)
  if dlg.exec()==QDialog.Accepted:d.print_(p)
 def create(self):
  sid=self.selected_student_id
  if not sid: QMessageBox.warning(self,'گواهی','ابتدا یک دانش‌آموز را از جدول انتخاب کنید.'); return
  code='CERT-'+secrets.token_hex(5).upper()
  with db() as c:c.execute('INSERT INTO certificates(student_id,title,code) VALUES(?,?,?)',(sid,'گواهی اشتغال به تحصیل',code));c.commit()
  self.fill(); QMessageBox.information(self,'گواهی صادر شد',f'کد گواهی: {code}')
