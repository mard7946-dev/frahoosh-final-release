import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QSpinBox,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox
from PySide6.QtCore import Qt
DB=Path(__file__).resolve().parents[1]/'school.db'
class InventoryPage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);self.setLayoutDirection(Qt.RightToLeft);l=QVBoxLayout(self);l.addWidget(__import__('PySide6').QtWidgets.QLabel('مدیریت اموال و تجهیزات مدرسه'))
  f=QHBoxLayout();self.title=QLineEdit();self.title.setPlaceholderText('نام مال');self.cat=QLineEdit();self.cat.setPlaceholderText('دسته‌بندی');self.qty=QSpinBox();self.qty.setRange(1,100000);self.loc=QLineEdit();self.loc.setPlaceholderText('محل');add=QPushButton('ثبت مال');edit=QPushButton('ویرایش');delete=QPushButton('حذف');archive=QPushButton('بایگانی');refresh=QPushButton('تازه‌سازی')
  for x in (self.title,self.cat,self.qty,self.loc,add,edit,delete,archive,refresh):f.addWidget(x)
  l.addLayout(f);self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['ID','عنوان','دسته','تعداد','محل','تاریخ']);l.addWidget(self.table)
  add.clicked.connect(self.add);edit.clicked.connect(self.edit);delete.clicked.connect(self.delete);archive.clicked.connect(self.archive);refresh.clicked.connect(self.load);self.ensure();self.load()
 def ensure(self):
  with sqlite3.connect(DB) as c:
   c.execute('CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,category TEXT,quantity INTEGER DEFAULT 1,location TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
   cols={r[1] for r in c.execute('PRAGMA table_info(assets)').fetchall()}
   if 'archived' not in cols: c.execute('ALTER TABLE assets ADD COLUMN archived INTEGER DEFAULT 0')
   c.commit()
 def load(self):
  with sqlite3.connect(DB) as c:rows=c.execute('SELECT id,title,category,quantity,location,created_at FROM assets WHERE COALESCE(archived,0)=0 ORDER BY id DESC').fetchall()
  self.table.setRowCount(len(rows));
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def add(self):
  if not self.title.text().strip():return QMessageBox.warning(self,'اموال','عنوان الزامی است.')
  with sqlite3.connect(DB) as c:c.execute('INSERT INTO assets(title,category,quantity,location) VALUES(?,?,?,?)',(self.title.text().strip(),self.cat.text().strip(),self.qty.value(),self.loc.text().strip()));c.commit()
  self.load()
 def edit(self):
  r=self.table.currentRow()
  if r<0:return
  with sqlite3.connect(DB) as c:c.execute('UPDATE assets SET title=?,category=?,quantity=?,location=? WHERE id=?',(self.title.text().strip(),self.cat.text().strip(),self.qty.value(),self.loc.text().strip(),int(self.table.item(r,0).text())));c.commit()
  self.load()
 def delete(self):
  r=self.table.currentRow()
  if r<0:return
  with sqlite3.connect(DB) as c:c.execute('DELETE FROM assets WHERE id=?',(int(self.table.item(r,0).text()),));c.commit()
  self.load()
 def archive(self):
  r=self.table.currentRow()
  if r<0:return
  with sqlite3.connect(DB) as c:c.execute('UPDATE assets SET archived=1 WHERE id=?',(int(self.table.item(r,0).text()),));c.commit()
  self.load()
