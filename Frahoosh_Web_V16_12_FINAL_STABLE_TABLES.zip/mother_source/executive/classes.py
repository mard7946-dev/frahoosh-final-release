from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QHeaderView
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

import sqlite3


from database.db import DATABASE_NAME


class ClassesPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setLayoutDirection(Qt.RightToLeft)

        self.init_ui()
        self.load_classes()

    def init_ui(self):

        layout = QVBoxLayout(self)

        title = QLabel("مدیریت کلاس‌ها")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("B Zar", 24, QFont.Bold))

        layout.addWidget(title)

        subtitle = QLabel(
            "مشاهده کلاس‌های ثبت‌شده در سامانه فراهوش"
        )
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setFont(QFont("B Zar", 13))

        layout.addWidget(subtitle)

        search_layout = QHBoxLayout()

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(
            "درس، عنوان، دبیر، پایه یا کلاس..."
        )
        self.search_box.setFont(QFont("B Zar", 12))
        self.search_box.textChanged.connect(
            self.load_classes
        )

        search_layout.addWidget(self.search_box)

        refresh_button = QPushButton("تازه‌سازی")
        refresh_button.setMinimumHeight(40)
        refresh_button.setFont(
            QFont("B Zar", 12, QFont.Bold)
        )
        refresh_button.clicked.connect(
            self.load_classes
        )

        search_layout.addWidget(refresh_button)

        layout.addLayout(search_layout)

        self.table = QTableWidget()
        self.table.setColumnCount(7)

        self.table.setHorizontalHeaderLabels([
            "درس",
            "عنوان",
            "دبیر",
            "پایه",
            "کلاس",
            "شروع",
            "وضعیت"
        ])

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setAlternatingRowColors(True)
        self.table.setLayoutDirection(Qt.RightToLeft)

        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                color: black;
                font-family: "B Zar";
                font-size: 13px;
                gridline-color: #d1d5db;
            }

            QTableWidget::item {
                padding: 6px;
                color: black;
            }

            QTableWidget::item:selected {
                background-color: #bbf7d0;
                color: black;
            }

            QHeaderView::section {
                background-color: #16a34a;
                color: black;
                font-family: "B Zar";
                font-size: 13px;
                font-weight: bold;
                padding: 8px;
                border: 1px solid #15803d;
            }

            QLineEdit {
                background-color: white;
                color: black;
                font-family: "B Zar";
                padding: 8px;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
            }

            QPushButton {
                background-color: #16a34a;
                color: black;
                font-family: "B Zar";
                font-weight: bold;
                border-radius: 8px;
                padding: 8px 15px;
            }

            QPushButton:hover {
                background-color: #22c55e;
            }
        """)

        layout.addWidget(self.table)

        self.count_label = QLabel(
            "تعداد کلاس‌ها: 0"
        )

        self.count_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.count_label.setFont(
            QFont("B Zar", 13, QFont.Bold)
        )

        layout.addWidget(self.count_label)

    def load_classes(self):

        search = self.search_box.text().strip()

        conn = None

        try:

            conn = sqlite3.connect(DATABASE_NAME)
            cursor = conn.cursor()

            if search:

                like = f"%{search}%"

                cursor.execute("""
                    SELECT
                        lesson,
                        title,
                        teacher,
                        grade,
                        class_name,
                        start_time,
                        status
                    FROM online_classes
                    WHERE
                        lesson LIKE ?
                        OR title LIKE ?
                        OR teacher LIKE ?
                        OR grade LIKE ?
                        OR class_name LIKE ?
                    ORDER BY id DESC
                """, (
                    like,
                    like,
                    like,
                    like,
                    like
                ))

            else:

                cursor.execute("""
                    SELECT
                        lesson,
                        title,
                        teacher,
                        grade,
                        class_name,
                        start_time,
                        status
                    FROM online_classes
                    ORDER BY id DESC
                """)

            rows = cursor.fetchall()

            self.table.setRowCount(len(rows))

            for row, data in enumerate(rows):

                for col, value in enumerate(data):

                    if col == 6:
                        value = self.status_text(value)

                    item = QTableWidgetItem(
                        str(value or "")
                    )

                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignCenter
                    )

                    self.table.setItem(
                        row,
                        col,
                        item
                    )

            self.table.resizeColumnsToContents()

            self.count_label.setText(
                f"تعداد کلاس‌ها: {len(rows)}"
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای کلاس‌ها",
                str(e)
            )

        finally:

            if conn:
                conn.close()

    def status_text(self, status):

        if status == "pending":
            return "در انتظار تأیید"

        if status == "approved":
            return "تأیید شده"

        if status == "live":
            return "در حال برگزاری"

        if status == "finished":
            return "پایان یافته"

        return status or ""

    def load_data(self):

        self.load_classes()