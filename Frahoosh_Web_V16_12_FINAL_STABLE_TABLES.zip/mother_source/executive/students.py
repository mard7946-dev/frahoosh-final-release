from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QFileDialog, QDialog, QFormLayout
from .data_schema import DB, ensure_schema


DATABASE_NAME = DB


class StudentsPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setLayoutDirection(Qt.RightToLeft)
        ensure_schema()

        self.init_ui()
        self.load_students()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        title = QLabel("فراهوش | مدیریت دانش‌آموزان")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("B Zar", 24, QFont.Bold))
        title.setObjectName("pageTitle")
        layout.addWidget(title)

        subtitle = QLabel("ثبت، جستجو و مدیریت پرونده دانش‌آموزان مدرسه")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setFont(QFont("B Zar", 13))
        layout.addWidget(subtitle)

        tools = QHBoxLayout()
        tools.setSpacing(8)
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("جستجو بر اساس نام، نام خانوادگی، کد ملی یا کد دانش‌آموزی...")
        self.search_box.textChanged.connect(self.load_students)
        tools.addWidget(self.search_box, 1)

        excel_in = QPushButton("📥 ورودی اکسل")
        excel_out = QPushButton("📤 خروجی اکسل")
        manual = QPushButton("➕ افزودن دستی")
        refresh = QPushButton("↻ بازخوانی")
        excel_in.clicked.connect(self.import_excel)
        excel_out.clicked.connect(self.export_excel)
        manual.clicked.connect(self.add_manual)
        refresh.clicked.connect(self.load_students)
        for b in (excel_in, excel_out, manual, refresh):
            b.setMinimumHeight(40)
            tools.addWidget(b)
        layout.addLayout(tools)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "نام", "نام خانوادگی", "کد ملی", "کد دانش‌آموزی",
            "پایه", "کلاس", "نام پدر", "شماره والد"
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setLayoutDirection(Qt.RightToLeft)
        self.table.setMinimumHeight(260)
        layout.addWidget(self.table, 1)

        self.count_label = QLabel("تعداد دانش‌آموزان: 0")
        self.count_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.count_label.setFont(QFont("B Zar", 13, QFont.Bold))
        layout.addWidget(self.count_label)

        self.setStyleSheet("""
            QWidget { background:#FDF2F8; color:#111827; font-family:"B Zar"; }
            QLabel#pageTitle { color:#9D174D; padding:8px; }
            QLineEdit { background:white; color:#111827; border:1px solid #DB2777; border-radius:8px; padding:8px; font-size:14px; }
            QPushButton { background:#DB2777; color:white; border:0; border-radius:9px; padding:7px 12px; font-size:14px; font-weight:bold; }
            QPushButton:hover { background:#BE185D; }
            QTableWidget { background:white; color:#111827; border:1px solid #F9A8D4; border-radius:10px; gridline-color:#E5E7EB; font-size:13px; }
            QTableWidget::item:selected { background:#FBCFE8; color:#111827; }
            QHeaderView::section { background:#F9A8D4; color:#111827; padding:8px; font-weight:bold; border:0; }
        """)

    def _ensure_student_columns(self):
        """Ensure the student table used by all executive modules has the required columns."""
        ensure_schema()

    def load_students(self):
        if not hasattr(self, "search_box") or not hasattr(self, "table"):
            return
        search = self.search_box.text().strip()
        try:
            self._ensure_student_columns()
            with sqlite3.connect(DATABASE_NAME) as conn:
                cursor = conn.cursor()
                if search:
                    like = f"%{search}%"
                    cursor.execute("""
                        SELECT first_name,last_name,national_code,student_code,grade,class_name,father_name,parent_phone
                        FROM students
                        WHERE first_name LIKE ? OR last_name LIKE ? OR national_code LIKE ?
                           OR student_code LIKE ? OR father_name LIKE ? OR parent_phone LIKE ?
                        ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE
                    """, (like,like,like,like,like,like))
                else:
                    cursor.execute("""
                        SELECT first_name,last_name,national_code,student_code,grade,class_name,father_name,parent_phone
                        FROM students
                        ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE
                    """)
                rows = cursor.fetchall()

            self.table.setRowCount(0)
            for row_data in rows:
                row = self.table.rowCount()
                self.table.insertRow(row)
                for col, value in enumerate(row_data):
                    item = QTableWidgetItem(str(value or ""))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.table.setItem(row, col, item)
            self.table.resizeColumnsToContents()
            self.count_label.setText(f"تعداد دانش‌آموزان: {len(rows)}")
        except Exception as e:
            self.count_label.setText("خطا در بارگذاری دانش‌آموزان")
            QMessageBox.critical(self, "خطای دانش‌آموزان", str(e))

    def import_excel(self):
        try:
            from openpyxl import load_workbook
        except Exception as e:
            QMessageBox.warning(self,"اکسل",f"کتابخانه Excel در دسترس نیست: {e}"); return
        path,_=QFileDialog.getOpenFileName(self,"ورودی اکسل","","Excel (*.xlsx)")
        if not path:return
        try:
            wb=load_workbook(path); ws=wb.active
            headers=[str(c.value or "").strip() for c in ws[1]]; idx={h:i for i,h in enumerate(headers)}
            required=["first_name","last_name"]
            if not all(x in idx for x in required): raise ValueError("ستون‌های first_name و last_name الزامی هستند")
            with sqlite3.connect(DATABASE_NAME) as c:
                for row in ws.iter_rows(min_row=2,values_only=True):
                    vals=lambda k: row[idx[k]] if k in idx and idx[k] < len(row) else ""
                    c.execute("INSERT INTO students(first_name,last_name,national_code,student_code,grade,class_name,phone,parent_phone,father_name,mother_name,religion,sect,nationality,photo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(vals("first_name"),vals("last_name"),vals("national_code"),vals("student_code"),vals("grade"),vals("class_name"),vals("phone"),vals("parent_phone"),vals("father_name"),vals("mother_name"),vals("religion"),vals("sect"),vals("nationality"),vals("photo")))
                c.commit()
            self.load_students(); QMessageBox.information(self,"اکسل","اطلاعات دانش‌آموزان وارد شد.")
        except Exception as e: QMessageBox.critical(self,"خطای اکسل",str(e))

    def export_excel(self):
        try:
            from openpyxl import Workbook
            path,_=QFileDialog.getSaveFileName(self,"خروجی اکسل","دانش‌آموزان.xlsx","Excel (*.xlsx)")
            if not path:return
            with sqlite3.connect(DATABASE_NAME) as c:
                rows=c.execute("SELECT first_name,last_name,national_code,student_code,grade,class_name,phone,parent_phone,father_name,mother_name,religion,sect,nationality,photo FROM students ORDER BY last_name,first_name").fetchall()
            wb=Workbook(); ws=wb.active; ws.title="Students"; headers=["first_name","last_name","national_code","student_code","grade","class_name","phone","parent_phone","father_name","mother_name","religion","sect","nationality","photo"]; ws.append(headers)
            for r in rows: ws.append(list(r))
            wb.save(path); QMessageBox.information(self,"اکسل","خروجی اکسل ذخیره شد.")
        except Exception as e: QMessageBox.critical(self,"خطای اکسل",str(e))

    def add_manual(self):
        d = QDialog(self)
        d.setWindowTitle("ثبت دستی دانش‌آموز")
        d.setLayoutDirection(Qt.RightToLeft)
        d.resize(520, 620)
        form = QFormLayout(d)
        fields = {}
        specs = [
            ("first_name","نام"),("last_name","نام خانوادگی"),
            ("national_code","کد ملی"),("student_code","کد دانش‌آموزی"),
            ("grade","پایه"),("class_name","کلاس"),
            ("father_name","نام پدر"),("mother_name","نام مادر"),
            ("religion","دین"),("sect","مذهب"),("nationality","ملیت"),
            ("parent_phone","شماره والد")
        ]
        for key,label in specs:
            w=QLineEdit(); form.addRow(label,w); fields[key]=w

        photo = QLineEdit(); photo.setReadOnly(True)
        pick = QPushButton("بارگذاری عکس")
        def choose_photo():
            path,_=QFileDialog.getOpenFileName(d,"انتخاب عکس دانش‌آموز","","Images (*.png *.jpg *.jpeg)")
            if path: photo.setText(path)
        pick.clicked.connect(choose_photo)
        photo_row=QHBoxLayout(); photo_row.addWidget(photo,1); photo_row.addWidget(pick)
        form.addRow("عکس",photo_row); fields["photo"]=photo

        save = QPushButton("💾 ثبت و ذخیره دانش‌آموز")
        cancel = QPushButton("انصراف")
        buttons=QHBoxLayout(); buttons.addWidget(save); buttons.addWidget(cancel); form.addRow(buttons)
        cancel.clicked.connect(d.reject)

        def save_student():
            first=fields["first_name"].text().strip(); last=fields["last_name"].text().strip()
            if not first or not last:
                QMessageBox.warning(d,"ثبت دانش‌آموز","نام و نام خانوادگی الزامی است."); return
            try:
                self._ensure_student_columns()
                columns=[k for k,_ in specs]+["photo"]
                values=[fields[k].text().strip() for k,_ in specs]+[fields["photo"].text().strip()]
                with sqlite3.connect(DATABASE_NAME) as conn:
                    cur=conn.cursor()
                    cur.execute(
                        f"INSERT INTO students({','.join(columns)}) VALUES({','.join(['?']*len(columns))})",
                        values
                    )
                    new_id=cur.lastrowid
                    conn.commit()
                d.accept()
                self.search_box.clear()
                self.load_students()
                for r in range(self.table.rowCount()):
                    code=self.table.item(r,3)
                    if code and fields["student_code"].text().strip() and code.text()==fields["student_code"].text().strip():
                        self.table.selectRow(r); self.table.scrollToItem(code); break
                QMessageBox.information(self,"ثبت موفق",f"دانش‌آموز «{first} {last}» با شناسه {new_id} در دیتابیس اصلی فراهوش ذخیره شد.")
            except sqlite3.IntegrityError as e:
                QMessageBox.critical(d,"خطای ثبت",f"ثبت دانش‌آموز انجام نشد:\n{e}")
            except Exception as e:
                QMessageBox.critical(d,"خطای ثبت",str(e))

        save.clicked.connect(save_student)
        d.exec()

    def load_data(self):

        self.load_students()