import sqlite3,secrets
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
DB=str(Path(__file__).resolve().parents[1]/'school.db')
def db(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
class StudentCardsPage(QWidget):
 def __init__(self): super().__init__(); self.ui(); self.load()
 def ui(self):
  l=QVBoxLayout(self); t=QLabel('کارت شناسایی دانش‌آموز'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(t)
  b=QHBoxLayout(); self.student=QComboBox(); self.student.addItem('انتخاب دانش‌آموز',None); self.card_type=QComboBox(); self.card_type.addItems(['کارت شناسایی','کارت کلاس']); create=QPushButton('صدور کارت'); edit=QPushButton('ویرایش/صدور مجدد'); b.addWidget(self.student);b.addWidget(self.card_type);b.addWidget(create);b.addWidget(edit);l.addLayout(b)
  self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','نوع','کد کارت','تاریخ','شناسه دانش‌آموز']);l.addWidget(self.table);create.clicked.connect(self.create_card);edit.clicked.connect(self.create_card)
  with db() as c:
   c.execute('CREATE TABLE IF NOT EXISTS student_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,card_type TEXT,code TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
   c.execute('CREATE TABLE IF NOT EXISTS class_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,class_name TEXT,code TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
  self.fill()
 def fill(self):
  self.student.clear();self.student.addItem('انتخاب دانش‌آموز',None)
  with db() as c: ss=c.execute('SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name').fetchall()
  for s in ss:self.student.addItem(f"{s['first_name']} {s['last_name']} | {s['student_code'] or '-'}",s['id'])
 def load(self):
  try:
   with db() as c: rows=c.execute('SELECT c.id,s.first_name||" "||s.last_name name,c.card_type,c.code,c.created_at,c.student_id FROM student_cards c LEFT JOIN students s ON s.id=c.student_id ORDER BY c.id DESC').fetchall()
  except: rows=[]
  if hasattr(self,'table'):
   self.table.setRowCount(len(rows));
   for i,r in enumerate(rows):
    for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def create_card(self):
  sid=self.student.currentData()
  if not sid:QMessageBox.warning(self,'کارت','دانش‌آموز را انتخاب کنید.');return
  code='STU-'+secrets.token_hex(5).upper()
  with db() as c:
   c.execute('INSERT INTO student_cards(student_id,card_type,code) VALUES(?,?,?)',(sid,self.card_type.currentText(),code))
   if self.card_type.currentText() == 'کارت کلاس':
    st=c.execute('SELECT class_name FROM students WHERE id=?',(sid,)).fetchone()
    c.execute('INSERT OR REPLACE INTO class_cards(student_id,class_name,code) VALUES(?,?,?)',(sid,(st['class_name'] if st else '') or '',code))
   c.commit()
  self.load();QMessageBox.information(self,'کارت صادر شد',f'کد کارت: {code}')
