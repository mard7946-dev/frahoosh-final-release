from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame


class ReportsPage(QWidget):

    def __init__(self):
        super().__init__()

        self.build_ui()


    def build_ui(self):

        layout = QVBoxLayout(self)


        title = QLabel("گزارشات معاونت اجرایی")

        title.setStyleSheet("""
            font-size:22px;
            font-weight:bold;
            color:#1565C0;
        """)

        layout.addWidget(title)


        card = QFrame()

        card.setStyleSheet("""
            QFrame{
                background:#E3F2FD;
                border-radius:15px;
                padding:20px;
            }
        """)


        card_layout = QVBoxLayout(card)


        info = QLabel(
            "مرکز گزارشات اجرایی مدرسه\n\n"
            "• گزارش وضعیت دانش‌آموزان\n"
            "• گزارش کارکنان\n"
            "• گزارش اموال و تجهیزات\n"
            "• گزارش عملکرد اجرایی"
        )


        info.setStyleSheet("""
            font-size:16px;
        """)


        card_layout.addWidget(info)

        layout.addWidget(card)

        layout.addStretch()