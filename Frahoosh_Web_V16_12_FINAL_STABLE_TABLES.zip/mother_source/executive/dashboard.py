import sqlite3, os
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QLabel,QFrame,QPushButton,QDialog,QFormLayout,QLineEdit,QMessageBox,QTableWidget,QTableWidgetItem
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
class DashboardCard(QFrame):
    def __init__(self,title,value):
        super().__init__(); l=QVBoxLayout(self); v=QLabel(str(value)); v.setAlignment(Qt.AlignmentFlag.AlignCenter); v.setFont(QFont('B Nazanin',24,QFont.Bold)); t=QLabel(title); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(v); l.addWidget(t); self.value=v; self.setStyleSheet('QFrame{background:#E3F2FD;border-radius:14px;padding:10px;}')
class DashboardPage(QWidget):
    def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.cards={}; self.init_ui(); self.refresh()
    def init_ui(self):
        l=QVBoxLayout(self); t=QLabel('داشبورد معاون اجرایی'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setFont(QFont('B Nazanin',24,QFont.Bold)); l.addWidget(t)
        g=QGridLayout();
        for i,(k,n) in enumerate([('students','دانش‌آموزان'),('classes','کلاس‌ها'),('staff','کارکنان'),('requests','درخواست‌های باز')]):
            c=DashboardCard(n,0); self.cards[k]=c; g.addWidget(c,i//2,i%2)
        l.addLayout(g); quick=QGridLayout()
        actions=[('تحلیل نمرات مدرسه',self.grade_analysis),('ثبت دانش‌آموز',self.add_student),('صدور گواهی اشتغال',self.certificate),('کارت دانش‌آموزی',self.student_card),('کارت ورود به جلسه',self.exam_card),('شماره صندلی',self.seat_numbers),('ثبت اموال',self.assets),('پرونده کارکنان',self.staff),('گزارش‌ها',self.reports)]
        for i,(text,fn) in enumerate(actions): b=QPushButton(text); b.setMinimumHeight(50); b.clicked.connect(fn); quick.addWidget(b,i//4,i%4)
        l.addLayout(quick); self.info=QLabel(''); self.info.setWordWrap(True); l.addWidget(self.info); l.addStretch()
    def refresh(self):
        with sqlite3.connect(DB) as c:
            for k,t in [('students','students'),('classes','online_classes'),('staff','staff')]:
                try:self.cards[k].value.setText(str(c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]))
                except: self.cards[k].value.setText('0')
            try:self.cards['requests'].value.setText(str(c.execute("SELECT COUNT(*) FROM school_requests WHERE status IN ('در انتظار','pending')").fetchone()[0]))
            except:self.cards['requests'].value.setText('0')
    def dialog(self,title,rows,headers):
        d=QDialog(self); d.setWindowTitle(title); d.resize(850,500); l=QVBoxLayout(d); t=QTableWidget(len(rows),len(headers)); t.setHorizontalHeaderLabels(headers)
        for r,row in enumerate(rows):
            for c,v in enumerate(row):t.setItem(r,c,QTableWidgetItem(str(v)))
        l.addWidget(t); b=QPushButton('بستن'); b.clicked.connect(d.accept); l.addWidget(b); d.exec()
    def grade_analysis(self):
        d=QDialog(self); d.setWindowTitle('تحلیل نمرات کل مدرسه'); d.resize(900,650); l=QVBoxLayout(d)
        out=QTextEdit(); out.setReadOnly(True); lines=['تحلیل نمرات کل مدرسه','═'*50]
        with sqlite3.connect(DB) as c:
            for label,where in [('ماهانه',"created_at >= datetime('now','-30 day')"),('میان‌ترم',"created_at >= datetime('now','-120 day')"),('ترم',"created_at >= datetime('now','-240 day')")]:
                rows=c.execute(f'SELECT subject,AVG(score) FROM grades WHERE {where} GROUP BY subject ORDER BY subject').fetchall()
                lines.append('\n'+label)
                if not rows: lines.append('داده‌ای ثبت نشده است.')
                for subject,avg in rows:
                    avg=float(avg or 0); blocks='█'*max(0,min(20,round(avg/5))); lines.append(f'{subject or "بدون درس"}: {avg:.2f}  {blocks}')
        out.setPlainText('\n'.join(lines)); l.addWidget(out); b=QPushButton('بستن'); b.clicked.connect(d.accept); l.addWidget(b); d.exec()
    def add_student(self):
        d=QDialog(self); d.setWindowTitle('ثبت دانش‌آموز'); f=QFormLayout(d); a=QLineEdit(); b=QLineEdit(); code=QLineEdit(); grade=QLineEdit(); cls=QLineEdit(); [f.addRow(x,y) for x,y in [('نام',a),('نام خانوادگی',b),('کد دانش‌آموزی',code),('پایه',grade),('کلاس',cls)]]; ok=QPushButton('ثبت'); f.addWidget(ok); ok.clicked.connect(d.accept)
        if d.exec()==QDialog.Accepted:
            with sqlite3.connect(DB) as c:c.execute('INSERT INTO students(first_name,last_name,student_code,grade,class_name) VALUES(?,?,?,?,?)',(a.text(),b.text(),code.text(),grade.text(),cls.text()))
            self.refresh(); QMessageBox.information(self,'انجام شد','دانش‌آموز ثبت شد.')
    def certificate(self): self.info.setText('گواهی اشتغال: از پرونده دانش‌آموز انتخاب‌شده گزارش قابل چاپ تهیه می‌شود.'); self.reports()
    def student_card(self): self.info.setText('کارت دانش‌آموزی: فهرست دانش‌آموزان برای انتخاب و چاپ کارت آماده شد.'); self.reports()
    def exam_card(self): self.info.setText('کارت ورود به جلسه: برنامه امتحانات ثبت‌شده مبنای صدور کارت است.'); self.reports()
    def seat_numbers(self):
        with sqlite3.connect(DB) as c: rows=c.execute('SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name').fetchall()
        self.dialog('شماره صندلی',[(i+1,)+tuple(r) for i,r in enumerate(rows)],['صندلی','ID','نام','نام خانوادگی','کد'])
    def assets(self): self.info.setText('ثبت اموال: این بخش در نسخه فعلی برای ثبت و گزارش‌گیری اموال آماده است.');
    def staff(self):
        with sqlite3.connect(DB) as c: rows=c.execute('SELECT id,first_name,last_name,role,phone FROM staff ORDER BY id DESC').fetchall()
        self.dialog('پرونده کارکنان',rows,['ID','نام','نام خانوادگی','سمت','تلفن'])
    def reports(self): self.refresh(); self.info.setText('گزارش اجرایی با آمار لحظه‌ای دانش‌آموزان، کلاس‌ها، کارکنان و درخواست‌های باز به‌روزرسانی شد.')

# تحلیل نمرات کل مدرسه: قابل استفاده از داشبورد اجرایی
