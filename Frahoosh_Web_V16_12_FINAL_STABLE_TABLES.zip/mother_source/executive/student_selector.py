import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QComboBox

DB = str(Path(__file__).resolve().parents[1] / 'school.db')

def connect():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def students(search=''):
    with connect() as c:
        if search:
            q='%'+search+'%'
            return c.execute('''SELECT id,first_name,last_name,national_code,student_code,grade,class_name,parent_phone FROM students
                WHERE first_name LIKE ? OR last_name LIKE ? OR national_code LIKE ? OR student_code LIKE ? ORDER BY last_name,first_name''',(q,q,q,q)).fetchall()
        return c.execute('SELECT id,first_name,last_name,national_code,student_code,grade,class_name,parent_phone FROM students ORDER BY last_name,first_name').fetchall()

def fill_combo(combo, placeholder='انتخاب دانش‌آموز'):
    combo.clear(); combo.addItem(placeholder, None)
    for s in students():
        combo.addItem(f"{s['first_name']} {s['last_name']} | {s['student_code'] or '-'} | {s['grade'] or ''} {s['class_name'] or ''}", s['id'])

def student(student_id):
    if student_id is None:return None
    with connect() as c:return c.execute('SELECT * FROM students WHERE id=?',(student_id,)).fetchone()
