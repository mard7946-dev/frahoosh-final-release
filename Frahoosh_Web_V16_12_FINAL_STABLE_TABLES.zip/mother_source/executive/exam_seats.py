import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,QLineEdit,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
DB=str(Path(__file__).resolve().parents[1]/'school.db')
def db(): c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
class ExamSeatsPage(QWidget):
 def __init__(self): super().__init__(); self.setLayoutDirection(Qt.RightToLeft); self.ui(); self.load()
 def ui(self):
  l=QVBoxLayout(self); t=QLabel('صندلی امتحانی | اتصال مستقیم به برنامه امتحانات'); t.setAlignment(Qt.AlignmentFlag.AlignCenter); l.addWidget(t)
  b=QHBoxLayout(); self.exam=QComboBox(); self.exam.setMinimumWidth(240); self.grade=QLineEdit(); self.grade.setPlaceholderText('پایه (اختیاری)'); self.seat=QLineEdit(); self.seat.setPlaceholderText('شماره صندلی دستی'); manual=QPushButton('ثبت/ویرایش'); auto=QPushButton('تولید خودکار برای آزمون'); b.addWidget(self.exam);b.addWidget(self.grade);b.addWidget(self.seat);b.addWidget(manual);b.addWidget(auto);l.addLayout(b)
  self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','کد','پایه','آزمون','صندلی']);l.addWidget(self.table)
  manual.clicked.connect(self.save);auto.clicked.connect(self.auto_assign)
  with db() as c:c.execute('CREATE TABLE IF NOT EXISTS exam_seats(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,exam_name TEXT,seat_no TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(exam_name,seat_no))')
  self.fill_exams()
 def fill_exams(self):
  self.exam.clear(); self.exam.addItem('انتخاب برنامه امتحان',None)
  with db() as c:
   rows=c.execute('SELECT id,subject,grade,exam_date FROM exam_schedule ORDER BY exam_date,id').fetchall()
  for r in rows:self.exam.addItem(f"{r['subject']} | پایه {r['grade']} | {r['exam_date']}",r['id'])
 def load(self):
  if not hasattr(self,'table'):return
  with db() as c:rs=c.execute('SELECT x.id,s.first_name||" "||s.last_name,x2.student_code,s.grade,x.exam_name,x.seat_no FROM exam_seats x LEFT JOIN students s ON s.id=x.student_id LEFT JOIN students x2 ON x2.id=x.student_id ORDER BY x.exam_name,CAST(x.seat_no AS INTEGER),x.seat_no').fetchall()
  self.table.setRowCount(len(rs))
  for i,r in enumerate(rs):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def selected_exam(self):
  eid=self.exam.currentData()
  if not eid:return None
  with db() as c:return c.execute('SELECT id,subject,grade,exam_date FROM exam_schedule WHERE id=?',(eid,)).fetchone()
 def save(self):
  ex=self.selected_exam(); seat=self.seat.text().strip()
  r=self.table.currentRow(); sid=int(self.table.item(r,0).text()) if r>=0 else None
  if not ex or not sid or not seat:QMessageBox.warning(self,'صندلی','برنامه امتحان، دانش‌آموز و شماره صندلی را مشخص کنید.');return
  name=f"{ex['subject']} | {ex['exam_date']}"
  with db() as c:
   c.execute('DELETE FROM exam_seats WHERE student_id=? AND exam_name=?',(sid,name)); c.execute('INSERT INTO exam_seats(student_id,exam_name,seat_no) VALUES(?,?,?)',(sid,name,seat));c.commit()
  self.load()
 def auto_assign(self):
  ex=self.selected_exam()
  if not ex:QMessageBox.warning(self,'صندلی','ابتدا یک برنامه امتحان انتخاب کنید.');return
  grade=self.grade.text().strip() or str(ex['grade'] or '').strip(); name=f"{ex['subject']} | {ex['exam_date']}"
  with db() as c:
   if grade: students=c.execute('SELECT id,first_name,last_name FROM students WHERE grade=? ORDER BY class_name,last_name,first_name,id',(grade,)).fetchall()
   else: students=c.execute('SELECT id,first_name,last_name FROM students ORDER BY class_name,last_name,first_name,id').fetchall()
   c.execute('DELETE FROM exam_seats WHERE exam_name=?',(name,))
   for n,s in enumerate(students,1): c.execute('INSERT INTO exam_seats(student_id,exam_name,seat_no) VALUES(?,?,?)',(s['id'],name,str(n)))
   c.commit()
  self.load();QMessageBox.information(self,'انجام شد',f'{len(students)} دانش‌آموز برای «{name}» شماره صندلی اختصاص گرفتند. در امتحان بعدی شماره‌ها از نو و مستقل تولید می‌شوند.')
