import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
from services.grade_service import release_grade
DB=Path(__file__).resolve().parents[1]/'school.db'
class ReportCardsPage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);self.setLayoutDirection(Qt.RightToLeft);l=QVBoxLayout(self);l.addWidget(QLabel('مدیریت کارنامه دانش‌آموزان'))
  bar=QHBoxLayout();self.student=QComboBox();self.student.addItem('انتخاب دانش‌آموز',None);self.term=QComboBox();self.term.addItems(['نوبت اول','نوبت دوم','سالانه']);self.issue=QPushButton('صدور / به‌روزرسانی');self.review=QPushButton('بررسی کارنامه');self.refresh=QPushButton('تازه‌سازی');self.release=QPushButton('اجازه نمایش نمره میان‌ترم/پایانی');self.release.clicked.connect(self.release_selected);[bar.addWidget(x) for x in (self.student,self.term,self.issue,self.review,self.release,self.refresh)];l.addLayout(bar)
  self.table=QTableWidget(0,9);self.table.setHorizontalHeaderLabels(['درس','عنوان','نمره','توضیحات','تاریخ شمسی','دبیر','شناسه','نوع','مجوز نمایش']);l.addWidget(self.table);self.summary=QLabel('');l.addWidget(self.summary)
  self.issue.clicked.connect(self.issue_card);self.review.clicked.connect(self.review_card);self.refresh.clicked.connect(self.load);self.student.currentIndexChanged.connect(self.load);self.load()
 def load(self):
  with sqlite3.connect(DB) as c:
   rows=c.execute('SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name').fetchall()
  cur=self.student.currentData();self.student.blockSignals(True);self.student.clear();self.student.addItem('انتخاب دانش‌آموز',None)
  for r in rows:self.student.addItem(f'{r[1]} {r[2]} | {r[3] or "-"}',r[0])
  if cur:self.student.setCurrentIndex(max(0,self.student.findData(cur)));self.student.blockSignals(False)
  self.review_card()
 def review_card(self):
  sid=self.student.currentData()
  if not sid:self.table.setRowCount(0);self.summary.setText('ابتدا دانش‌آموز را انتخاب کنید.');return
  with sqlite3.connect(DB) as c:
   rows=c.execute('''SELECT g.subject,g.assessment_title,g.score,g.description,g.grade_date_shamsi,COALESCE(t.first_name||' '||t.last_name,''),g.id,g.assessment_type,g.manager_released FROM student_grades g LEFT JOIN teachers t ON t.id=g.teacher_id WHERE g.student_id=? ORDER BY g.subject,g.id DESC''',(sid,)).fetchall()
  self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  scores=[float(r[2]) for r in rows if r[2] is not None];self.summary.setText(f'تعداد نمرات: {len(scores)} | معدل: {sum(scores)/len(scores):.2f} از 20' if scores else 'هنوز نمره‌ای ثبت نشده است.')
 def release_selected(self):
  r=self.table.currentRow()
  if r<0:return
  gid=int(self.table.item(r,6).text()); release_grade(gid,'مدیر'); self.review_card(); QMessageBox.information(self,'مجوز نمایش','این نمره برای دانش‌آموز و ولی قابل مشاهده شد.')
 def issue_card(self):
  sid=self.student.currentData()
  if not sid:return QMessageBox.warning(self,'کارنامه','دانش‌آموز را انتخاب کنید.')
  with sqlite3.connect(DB) as c:
   avg=c.execute('SELECT AVG(score) FROM grades WHERE student_id=?',(sid,)).fetchone()[0] or 0
   c.execute('INSERT INTO report_cards(student_id,term,average,description,created_at) VALUES(?,?,?,?,datetime("now")) ON CONFLICT DO NOTHING',(sid,self.term.currentText(),float(avg),'کارنامه صادر و آماده بررسی شد'))
   # report_cards has no unique constraint in old DB; replace same student/term instead.
   c.execute('DELETE FROM report_cards WHERE id NOT IN (SELECT MAX(id) FROM report_cards GROUP BY student_id,term) AND student_id=? AND term=?',(sid,self.term.currentText()));c.commit()
  self.review_card();QMessageBox.information(self,'کارنامه',f'کارنامه {self.term.currentText()} صادر/به‌روزرسانی شد.')
