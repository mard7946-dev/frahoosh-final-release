import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QComboBox,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox
from PySide6.QtCore import Qt
DB=Path(__file__).resolve().parents[1]/'school.db'
class RequestsPage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent);self.setLayoutDirection(Qt.RightToLeft);l=QVBoxLayout(self);l.addWidget(__import__('PySide6').QtWidgets.QLabel('مدیریت درخواست‌ها و تاییدیه‌ها'));f=QHBoxLayout();self.typ=QLineEdit();self.typ.setPlaceholderText('نوع درخواست');self.req=QLineEdit();self.req.setPlaceholderText('درخواست‌کننده');self.desc=QLineEdit();self.desc.setPlaceholderText('توضیحات');a=QPushButton('ثبت درخواست');ok=QPushButton('تأیید');no=QPushButton('رد');ref=QPushButton('تازه‌سازی');[f.addWidget(x) for x in (self.typ,self.req,self.desc,a,ok,no,ref)];l.addLayout(f);self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(['ID','نوع','درخواست‌کننده','نقش','توضیحات','وضعیت','تاریخ']);l.addWidget(self.table);a.clicked.connect(self.add);ok.clicked.connect(lambda:self.set_status('تأیید شده'));no.clicked.connect(lambda:self.set_status('رد شده'));ref.clicked.connect(self.load);self.ensure();self.load()
 def ensure(self):
  with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS executive_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,status TEXT DEFAULT "در انتظار",description TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,role TEXT DEFAULT "")');c.commit()
 def load(self):
  with sqlite3.connect(DB) as c:rows=c.execute('SELECT id,title,requester,role,description,status,created_at FROM executive_requests ORDER BY id DESC').fetchall()
  self.table.setRowCount(len(rows));
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def add(self):
  if not self.typ.text().strip() or not self.req.text().strip():return QMessageBox.warning(self,'درخواست','نوع و درخواست‌کننده الزامی است.')
  with sqlite3.connect(DB) as c:c.execute('INSERT INTO executive_requests(title,requester,status,description) VALUES(?,?,?,?)',(self.typ.text().strip(),self.req.text().strip(),'در انتظار',self.desc.text().strip()));c.commit()
  self.load()
 def set_status(self,status):
  r=self.table.currentRow()
  if r<0:return
  with sqlite3.connect(DB) as c:c.execute('UPDATE executive_requests SET status=? WHERE id=?',(status,int(self.table.item(r,0).text())));c.commit()
  self.load()
