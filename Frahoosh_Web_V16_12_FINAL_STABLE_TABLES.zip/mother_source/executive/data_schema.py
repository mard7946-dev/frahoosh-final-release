import sqlite3
from pathlib import Path
DB = str(Path(__file__).resolve().parents[1] / 'school.db')

def ensure_schema():
    c=sqlite3.connect(DB)
    try:
        c.execute('''CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT,last_name TEXT,national_code TEXT,student_code TEXT,grade TEXT,class_name TEXT,phone TEXT,parent_phone TEXT,photo TEXT,father_name TEXT,mother_name TEXT,birth_date TEXT,email TEXT,address TEXT,description TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT,last_name TEXT,role TEXT,phone TEXT,description TEXT)''')
        def cols(table): return {r[1] for r in c.execute(f'PRAGMA table_info({table})').fetchall()}
        student_cols={'religion':'TEXT','sect':'TEXT','nationality':'TEXT','birth_certificate_no':'TEXT','mother_national_code':'TEXT','father_national_code':'TEXT','father_phone':'TEXT','mother_phone':'TEXT','father_job':'TEXT','mother_job':'TEXT','temporary_certificate_no':'TEXT'}
        staff_cols={'national_code':'TEXT','personnel_code':'TEXT','mobile':'TEXT','position':'TEXT','employment_status':'TEXT','children_count':'INTEGER DEFAULT 0','insurance_type':'TEXT','work_experience':'TEXT','nationality':'TEXT','sect':'TEXT','religion':'TEXT','photo':'TEXT','birth_date':'TEXT','address':'TEXT','email':'TEXT'}
        for table, mapping in [('students',student_cols),('staff',staff_cols)]:
            existing=cols(table)
            for name,typ in mapping.items():
                if name not in existing: c.execute(f'ALTER TABLE {table} ADD COLUMN {name} {typ}')
        c.commit()
    finally:c.close()
