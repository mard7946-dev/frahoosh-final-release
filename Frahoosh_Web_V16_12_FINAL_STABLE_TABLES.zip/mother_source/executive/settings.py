from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame


class SettingsPage(QWidget):

    def __init__(self):
        super().__init__()

        self.build_ui()


    def build_ui(self):

        layout = QVBoxLayout(self)


        title = QLabel("تنظیمات معاونت اجرایی")

        title.setStyleSheet("""
            font-size:22px;
            font-weight:bold;
            color:#37474F;
        """)

        layout.addWidget(title)


        card = QFrame()

        card.setStyleSheet("""
            QFrame{
                background:#ECEFF1;
                border-radius:15px;
                padding:20px;
            }
        """)


        card_layout = QVBoxLayout(card)


        info = QLabel(
            "تنظیمات بخش اجرایی مدرسه\n\n"
            "• تنظیمات پرونده‌ها\n"
            "• تنظیمات گزارشات\n"
            "• مدیریت دسترسی‌ها\n"
            "• تنظیمات عمومی"
        )


        info.setStyleSheet("""
            font-size:16px;
        """)


        card_layout.addWidget(info)

        layout.addWidget(card)

        layout.addStretch()