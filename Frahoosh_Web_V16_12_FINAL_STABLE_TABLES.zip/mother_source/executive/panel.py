from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
    QStackedWidget,
    QGridLayout,
    QHBoxLayout,
    QTabBar,
    QMessageBox
)

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from utils.export_tools import widget_to_pdf, print_widget

from executive.dashboard import DashboardPage
from executive.students import StudentsPage
from executive.classes import ClassesPage
from executive.classroom_seats import ClassroomSeatsPage
from executive.exam_seats import ExamSeatsPage
from executive.certificates import CertificatesPage
from executive.student_cards import StudentCardsPage
from executive.exam_cards import ExamCardsPage
from executive.report_cards import ReportCardsPage
from executive.staff import StaffPage
from executive.inventory import InventoryPage
from executive.archive import ArchivePage
from executive.reports import ReportsPage
from executive.requests import RequestsPage
from executive.settings import SettingsPage


# =====================================================
# پنل اصلی معاونت اجرایی
# =====================================================

class ExecutivePanel(QWidget):

    page_changed = Signal(str)

    def __init__(self, parent=None, username=None, role=None):

        super().__init__(parent)

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.pages = {}

        self.current_user = {"username": username, "role": role or "executive"}

        self.init_ui()

    # =================================================
    # رابط اصلی
    # =================================================

    def init_ui(self):

        main_layout = QVBoxLayout(
            self
        )

        main_layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        main_layout.setSpacing(
            10
        )

        # =================================================
        # هدر
        # =================================================

        header = self.create_header()

        main_layout.addWidget(
            header
        )
        export_bar=QHBoxLayout(); pdf=QPushButton('ذخیره PDF'); pr=QPushButton('پرینت'); pdf.clicked.connect(lambda: widget_to_pdf(self.stack.currentWidget(), self, 'گزارش اجرایی')); pr.clicked.connect(lambda: print_widget(self.stack.currentWidget(), self)); export_bar.addWidget(pdf); export_bar.addWidget(pr); export_bar.addStretch(); main_layout.addLayout(export_bar)

        # =================================================
        # منوی ردیفی
        # =================================================

        menu_layout = QGridLayout()

        menu_layout.setSpacing(
            8
        )

        self.stack = QStackedWidget()

        # =================================================
        # صفحات
        # =================================================

        pages = [

            (
                "داشبورد",
                "dashboard",
                DashboardPage()
            ),

            (
                "دانش‌آموزان",
                "students",
                StudentsPage()
            ),

            (
                "مدیریت کلاس‌ها",
                "classes",
                ClassesPage()
            ),

            (
                "صندلی کلاسی",
                "classroom_seats",
                ClassroomSeatsPage()
            ),

            (
                "صندلی امتحانی",
                "exam_seats",
                ExamSeatsPage()
            ),

            (
                "گواهی‌ها",
                "certificates",
                CertificatesPage()
            ),

            (
                "کارت دانش‌آموزی",
                "student_cards",
                StudentCardsPage()
            ),

            (
                "کارت ورود",
                "exam_cards",
                ExamCardsPage()
            ),

            (
                "کارنامه‌ها",
                "report_cards",
                ReportCardsPage()
            ),

            (
                "کارکنان",
                "staff",
                StaffPage()
            ),

            (
                "اموال و انبار",
                "inventory",
                InventoryPage()
            ),

            (
                "بایگانی",
                "archive",
                ArchivePage()
            ),

            (
                "گزارش‌ها",
                "reports",
                ReportsPage()
            ),

            (
                "درخواست‌ها",
                "requests",
                RequestsPage()),

            (
                "تنظیمات",
                "settings",
                SettingsPage()
            )

        ]

        # =================================================
        # منوی حرفه‌ای به سبک پنل اولیا
        # =================================================
        self.tab_bar = QTabBar()
        self.tab_bar.setDocumentMode(True)
        self.tab_bar.setUsesScrollButtons(True)
        self.tab_bar.setExpanding(False)
        self.tab_bar.setDrawBase(False)
        for text, key, page in pages:
            self.pages[key] = page
            self.stack.addWidget(page)
            self.tab_bar.addTab(text)
        self.tab_bar.currentChanged.connect(self._tab_changed)
        main_layout.addWidget(self.tab_bar)

        # =================================================
        # محتوای صفحات
        # =================================================

        main_layout.addWidget(
            self.stack,
            1
        )

        # =================================================
        # صفحه پیش‌فرض
        # =================================================

        self.stack.setCurrentWidget(
            self.pages["dashboard"]
        )

        self.apply_style()

    # =================================================
    # هدر
    # =================================================

    def create_header(self):

        frame = QFrame()

        frame.setObjectName(
            "executive_header"
        )

        layout = QVBoxLayout(
            frame
        )

        layout.setContentsMargins(
            10,
            8,
            10,
            8
        )

        title = QLabel(
            "فراهوش | معاونت اجرایی"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )

        layout.addWidget(
            title
        )

        subtitle = QLabel(
            "مدیریت امور اجرایی مدرسه، پرونده‌ها و اسناد"
        )

        subtitle.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        subtitle.setFont(
            QFont(
                "B Zar",
                13
            )
        )

        layout.addWidget(
            subtitle
        )

        return frame

    # =================================================
    # تغییر صفحه
    # =================================================

    def _tab_changed(self, index):
        if index < 0 or index >= self.stack.count():
            return
        self.stack.setCurrentIndex(index)

    def change_page(
        self,
        page_name
    ):

        if page_name not in self.pages:
            return

        page = self.pages[
            page_name
        ]

        self.stack.setCurrentWidget(page)
        if hasattr(self, "tab_bar"):
            idx = self.stack.indexOf(page)
            if idx >= 0 and self.tab_bar.currentIndex() != idx:
                self.tab_bar.setCurrentIndex(idx)
        self.page_changed.emit(page_name)

    # =================================================
    # بازخوانی صفحه فعلی
    # =================================================

    def refresh_current_page(self):

        current = self.stack.currentWidget()

        if hasattr(
            current,
            "load_data"
        ):

            try:

                current.load_data()

            except Exception as e:

                print("REFRESH ERROR:",
                    e
                )

    # =================================================
    # اطلاعات کاربر
    # =================================================

    def set_user_info(
        self,
        username=None,
        role=None
    ):

        self.current_user = {

            "username": username,

            "role": role

        }

    # =================================================
    # دسترسی
    # =================================================

    def has_permission(
        self,
        permission
    ):

        return True

    # =================================================
    # پیام
    # =================================================

    def show_message(
        self,
        title,
        text
    ):

        msg = QMessageBox(
            self
        )

        msg.setWindowTitle(
            title
        )

        msg.setText(
            text
        )

        msg.exec()

    # =================================================
    # بازگشت به داشبورد
    # =================================================

    def reset_panel(self):

        if "dashboard" in self.pages:

            self.stack.setCurrentWidget(
                self.pages["dashboard"]
            )

    # =================================================
    # صفحه فعلی
    # =================================================

    def current_page(self):

        return self.stack.currentWidget()

    # =================================================
    # خروجی گزارش
    # =================================================

    def export_report(
        self,
        report_type
    ):

        print(
            "EXPORT:",
            report_type
        )

    # =================================================
    # چاپ
    # =================================================

    def print_document(
        self,
        document_type
    ):

        print(
            "PRINT:",
            document_type
        )

    # =================================================
    # تازه‌سازی همه صفحات
    # =================================================

    def refresh_all_pages(self):

        for page in self.pages.values():

            if hasattr(
                page,
                "load_data"
            ):

                try:

                    page.load_data()

                except Exception as e:

                    print(
                        "PAGE REFRESH ERROR:",
                        e
                    )

    # =================================================
    # استایل
    # =================================================

    def apply_style(self):

        self.setStyleSheet("""
            QWidget {

                background:#f1f5f9;

                color:#111827;

                font-family:"B Zar";

            }

            QFrame#executive_header {

                background:#e5e7eb;

                border-radius:15px;

            }

            QStackedWidget {
                background:#FFFFFF;
                border:1px solid #F9A8D4;
                border-radius:15px;
                padding:8px;
            }
            QTabBar { background:transparent; }
            QTabBar::tab {
                background:#F9A8D4; color:#111827;
                padding:9px 13px; margin:2px;
                border-radius:9px; font-family:"B Zar"; font-size:14px; font-weight:bold;
            }
            QTabBar::tab:selected { background:#DB2777; color:white; }
            QTabBar::tab:hover { background:#F472B6; color:#111827; }

            QPushButton {

                background:#4CAF50;

                color:#000000;

                border-radius:9px;

                min-height:36px;

                font-family:"B Zar";

                font-weight:bold;

            }

            QPushButton:hover {

                background:#81C784;

            }

            QPushButton:pressed {

                background:#388E3C;

                color:white;

            }
        """)


# =====================================================
# کلاس مورد نیاز داشبورد اصلی
# =====================================================

class Panel(ExecutivePanel):
    pass

# Public entry point used by the authenticated dashboard.
Panel = ExecutivePanel
