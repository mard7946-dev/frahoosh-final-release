import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,QLineEdit,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
DB=str(Path(__file__).resolve().parents[1]/'school.db')
def db(): c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
class ClassroomSeatsPage(QWidget):
 def __init__(self): super().__init__();self.ui();self.load()
 def ui(self):
  l=QVBoxLayout(self);t=QLabel('شماره صندلی کلاسی');t.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(t);b=QHBoxLayout();self.student=QComboBox();self.student.addItem('انتخاب دانش‌آموز',None);self.seat=QLineEdit();self.seat.setPlaceholderText('شماره صندلی');self.cls=QLineEdit();self.cls.setPlaceholderText('نام کلاس (خالی = کلاس دانش‌آموز)');save=QPushButton('ثبت/ویرایش صندلی');b.addWidget(self.student);b.addWidget(self.cls);b.addWidget(self.seat);b.addWidget(save);l.addLayout(b);self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','کلاس','صندلی','تاریخ']);l.addWidget(self.table);save.clicked.connect(self.save);withdb=0
  with db() as c:c.execute('CREATE TABLE IF NOT EXISTS class_seats(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,class_name TEXT,seat_no TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(class_name,seat_no))')
  self.fill()
 def fill(self):
  self.student.clear();self.student.addItem('انتخاب دانش‌آموز',None)
  with db() as c:ss=c.execute('SELECT id,first_name,last_name,student_code,grade,class_name FROM students ORDER BY last_name,first_name').fetchall()
  for s in ss:self.student.addItem(f"{s['first_name']} {s['last_name']} | {s['student_code'] or '-'} | {s['class_name'] or ''}",s['id'])
 def load(self):
  if not hasattr(self,'table'):return
  with db() as c:rs=c.execute('SELECT x.id,s.first_name||" "||s.last_name name,x.class_name,x.seat_no,x.created_at FROM class_seats x LEFT JOIN students s ON s.id=x.student_id ORDER BY x.class_name,x.seat_no').fetchall()
  self.table.setRowCount(len(rs))
  for i,r in enumerate(rs):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def save(self):
  sid=self.student.currentData()
  if not sid or not self.seat.text().strip():QMessageBox.warning(self,'صندلی','دانش‌آموز و شماره صندلی را وارد کنید.');return
  with db() as c:
   s=c.execute('SELECT class_name FROM students WHERE id=?',(sid,)).fetchone(); cls=self.cls.text().strip() or (s['class_name'] if s else '') or 'بدون کلاس'
   try:c.execute('INSERT INTO class_seats(student_id,class_name,seat_no) VALUES(?,?,?) ON CONFLICT(class_name,seat_no) DO UPDATE SET student_id=excluded.student_id,created_at=CURRENT_TIMESTAMP',(sid,cls,self.seat.text().strip()));c.commit()
   except Exception as e:QMessageBox.warning(self,'خطا',str(e));return
  self.load()
