from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

import sqlite3
from PySide6.QtWidgets import QFileDialog, QDialog, QFormLayout, QHBoxLayout
from .data_schema import ensure_schema


from database.db import DATABASE_NAME


class StaffPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setLayoutDirection(Qt.RightToLeft)
        ensure_schema()

        self.selected_staff_id = None
        self.init_ui()
        self.load_staff()

    def init_ui(self):

        layout = QVBoxLayout(self)

        title = QLabel(
            "مدیریت کارکنان مدرسه"
        )

        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(
            QFont("B Zar", 24, QFont.Bold)
        )

        layout.addWidget(title)

        subtitle = QLabel(
            "مشاهده اطلاعات دبیران و کارکنان مدرسه"
        )

        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setFont(
            QFont("B Zar", 13)
        )

        layout.addWidget(subtitle)

        search_layout = QHBoxLayout()

        self.search_box = QLineEdit()

        self.search_box.setPlaceholderText(
            "نام، نام خانوادگی، کد پرسنلی، سمت یا شماره همراه..."
        )

        self.search_box.setFont(
            QFont("B Zar", 12)
        )

        self.search_box.textChanged.connect(
            self.load_staff
        )

        search_layout.addWidget(
            self.search_box
        )

        refresh_button = QPushButton("ورودی اکسل")
        refresh_button.clicked.connect(self.import_excel)
        search_layout.addWidget(refresh_button)

        refresh_button = QPushButton("افزودن دستی")
        refresh_button.clicked.connect(self.add_manual)
        search_layout.addWidget(refresh_button)

        refresh_button = QPushButton("خروجی اکسل")
        refresh_button.clicked.connect(self.export_excel)

        refresh_button.setMinimumHeight(40)
        refresh_button.setFont(
            QFont("B Zar", 12, QFont.Bold)
        )

        refresh_button.clicked.connect(
            self.load_staff
        )

        search_layout.addWidget(
            refresh_button
        )

        delete_button = QPushButton("🗑 حذف")
        delete_button.clicked.connect(self.delete_selected)
        search_layout.addWidget(delete_button)

        layout.addLayout(search_layout)

        self.table = QTableWidget()

        self.table.setColumnCount(7)

        self.table.setHorizontalHeaderLabels([
            "نام",
            "نام خانوادگی",
            "کد ملی",
            "کد پرسنلی",
            "شماره همراه",
            "سمت",
            "وضعیت استخدام"
        ])

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setAlternatingRowColors(True)
        self.table.setLayoutDirection(Qt.RightToLeft)

        self.table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                color: black;
                font-family: "B Zar";
                font-size: 13px;
                gridline-color: #d1d5db;
            }

            QTableWidget::item {
                padding: 6px;
                color: black;
            }

            QTableWidget::item:selected {
                background-color: #bbf7d0;
                color: black;
            }

            QHeaderView::section {
                background-color: #16a34a;
                color: black;
                font-family: "B Zar";
                font-size: 13px;
                font-weight: bold;
                padding: 8px;
                border: 1px solid #15803d;
            }

            QLineEdit {
                background-color: white;
                color: black;
                font-family: "B Zar";
                padding: 8px;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
            }

            QPushButton {
                background-color: #16a34a;
                color: black;
                font-family: "B Zar";
                font-weight: bold;
                border-radius: 8px;
                padding: 8px 15px;
            }

            QPushButton:hover {
                background-color: #22c55e;
            }
        """)

        layout.addWidget(
            self.table
        )

        self.count_label = QLabel(
            "تعداد کارکنان: 0"
        )

        self.count_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.count_label.setFont(QFont("B Zar", 13, QFont.Bold)
        )

        layout.addWidget(
            self.count_label
        )

    def import_excel(self):
        try:
            from openpyxl import load_workbook
        except Exception as e: QMessageBox.warning(self,"اکسل",str(e)); return
        path,_=QFileDialog.getOpenFileName(self,"ورودی اکسل","","Excel (*.xlsx)")
        if not path:return
        try:
            ws=load_workbook(path).active; headers=[str(c.value or "").strip() for c in ws[1]]; idx={h:i for i,h in enumerate(headers)}
            if not all(k in idx for k in ("first_name","last_name")): raise ValueError("first_name و last_name الزامی هستند")
            keys=["first_name","last_name","national_code","personnel_code","mobile","position","employment_status","children_count","insurance_type","work_experience","nationality","sect","religion","photo"]
            with sqlite3.connect(DATABASE_NAME) as c:
                for row in ws.iter_rows(min_row=2,values_only=True):
                    vals=[row[idx[k]] if k in idx and idx[k]<len(row) else "" for k in keys]
                    cur = c.execute("INSERT INTO staff("+','.join(keys)+") VALUES("+','.join('?'*len(keys))+")",vals)
                    self._sync_teacher_from_staff(c, cur.lastrowid, vals, keys)
                c.commit()
            self.load_staff(); QMessageBox.information(self,"اکسل","اطلاعات کارکنان وارد شد.")
        except Exception as e: QMessageBox.critical(self,"اکسل",str(e))

    def export_excel(self):
        try:
            from openpyxl import Workbook
            path,_=QFileDialog.getSaveFileName(self,"خروجی اکسل","کارکنان.xlsx","Excel (*.xlsx)")
            if not path:return
            keys=["first_name","last_name","national_code","personnel_code","mobile","position","employment_status","children_count","insurance_type","work_experience","nationality","sect","religion","photo"]
            with sqlite3.connect(DATABASE_NAME) as c: rows=c.execute("SELECT "+','.join(keys)+" FROM staff ORDER BY last_name,first_name").fetchall()
            wb=Workbook(); ws=wb.active; ws.title="Staff"; ws.append(keys)
            for r in rows: ws.append(list(r))
            wb.save(path); QMessageBox.information(self,"اکسل","خروجی اکسل ذخیره شد.")
        except Exception as e: QMessageBox.critical(self,"اکسل",str(e))

    def add_manual(self):
        d=QDialog(self); d.setWindowTitle("افزودن کارمند"); f=QFormLayout(d); fields={}
        items=[("first_name","نام"),("last_name","نام خانوادگی"),("national_code","کد ملی"),("personnel_code","کد پرسنلی"),("mobile","موبایل"),("position","سمت"),("children_count","تعداد فرزند"),("insurance_type","نوع بیمه"),("work_experience","سابقه کاری"),("nationality","ملیت"),("sect","مذهب"),("religion","دین"),("photo","مسیر عکس")]
        for k,label in items:
            if k=="photo":
                w=QLineEdit(); w.setReadOnly(True); pick=QPushButton("بارگذاری عکس")
                def choose_photo():
                    path,_=QFileDialog.getOpenFileName(d,"انتخاب عکس","","Images (*.png *.jpg *.jpeg)")
                    if path: w.setText(path)
                pick.clicked.connect(choose_photo); row=QHBoxLayout(); row.addWidget(w); row.addWidget(pick); f.addRow(label,row); fields[k]=w
            else:
                w=QLineEdit(); f.addRow(label,w); fields[k]=w
        b=QPushButton("ثبت"); b.clicked.connect(d.accept); f.addRow(b)
        if d.exec():
            try:
                keys=list(fields); vals=[fields[k].text().strip() for k in keys]
                with sqlite3.connect(DATABASE_NAME) as c:
                    cur=c.execute("INSERT INTO staff("+','.join(keys)+") VALUES("+','.join('?'*len(keys))+")",vals)
                    self._sync_teacher_from_staff(c, cur.lastrowid, vals, keys)
                    c.commit()
                self.load_staff()
            except Exception as e: QMessageBox.critical(self,"ثبت",str(e))

    def _sync_teacher_from_staff(self, conn, staff_id, vals, keys):
        """اگر کارمند دبیر/معلم باشد، همان رکورد را به پرونده دبیران متصل می‌کند."""
        data = dict(zip(keys, vals))
        position = (data.get("position") or data.get("role") or "").strip().lower()
        if not any(word in position for word in ("دبیر", "معلم", "teacher")):
            return

        # ستون اتصال را در جدول دبیران اضافه می‌کنیم تا ثبت تکراری ایجاد نشود.
        cols = {r[1] for r in conn.execute("PRAGMA table_info(teachers)").fetchall()}
        teacher_columns = {
            "employment_status": "TEXT",
            "subject": "TEXT",
            "phone": "TEXT",
            "source_staff_id": "INTEGER",
        }
        for col, typ in teacher_columns.items():
            if col not in cols:
                conn.execute(f"ALTER TABLE teachers ADD COLUMN {col} {typ}")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_teachers_source_staff ON teachers(source_staff_id)")

        teacher_id = conn.execute(
            "SELECT id FROM teachers WHERE source_staff_id=?", (staff_id,)
        ).fetchone()
        values = (
            data.get("first_name", ""), data.get("last_name", ""),
            data.get("national_code", ""), data.get("mobile", ""),
            data.get("position", ""), data.get("employment_status", ""),
            staff_id,
        )
        if teacher_id:
            conn.execute("""
                UPDATE teachers
                SET first_name=?, last_name=?, national_code=?, phone=?,
                    subject=?, employment_status=?, source_staff_id=?
                WHERE id=?
            """, values[:-1] + (staff_id, teacher_id[0]))
        else:
            conn.execute("""
                INSERT INTO teachers(
                    first_name,last_name,national_code,phone,subject,
                    employment_status,source_staff_id
                ) VALUES(?,?,?,?,?,?,?)
            """, values)

    def delete_selected(self):
        if self.selected_staff_id is None:
            QMessageBox.warning(self, "حذف", "ابتدا یک کارمند را از جدول انتخاب کنید.")
            return
        row = self.table.currentRow()
        name = ""
        if row >= 0:
            name = " ".join(str(self.table.item(row, c).text() if self.table.item(row,c) else "") for c in (0,1)).strip()
        result = QMessageBox.question(
            self, "تأیید حذف",
            f"آیا از حذف {name or 'این کارمند'} مطمئن هستید؟\n\nسوابق مرتبط دبیر نیز در صورت وجود حذف می‌شود.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if result != QMessageBox.Yes:
            return
        try:
            with sqlite3.connect(DATABASE_NAME) as c:
                c.execute("DELETE FROM teachers WHERE source_staff_id=?", (self.selected_staff_id,))
                c.execute("DELETE FROM staff WHERE id=?", (self.selected_staff_id,))
                c.commit()
            self.selected_staff_id = None
            self.load_staff()
        except Exception as e:
            QMessageBox.critical(self, "حذف", str(e))

    def load_staff(self):

        search = self.search_box.text().strip()

        conn = None

        try:

            conn = sqlite3.connect(
                DATABASE_NAME
            )

            cursor = conn.cursor()

            if search:

                like = f"%{search}%"

                cursor.execute("""
                    SELECT
                        id, first_name,
                        last_name,
                        national_code,
                        personnel_code,
                        mobile,
                        position,
                        employment_status
                    FROM staff
                    WHERE
                        first_name LIKE ?
                        OR last_name LIKE ?
                        OR national_code LIKE ?
                        OR personnel_code LIKE ?
                        OR mobile LIKE ?
                        OR position LIKE ?
                    ORDER BY last_name, first_name
                """, (
                    like,
                    like,
                    like,
                    like,
                    like,
                    like
                ))

            else:

                cursor.execute("""
                    SELECT
                        id, first_name,
                        last_name,
                        national_code,
                        personnel_code,
                        mobile,
                        position,
                        employment_status
                    FROM staff
                    ORDER BY last_name, first_name
                """)

            rows = cursor.fetchall()

            self.table.setRowCount(
                len(rows)
            )

            for row, data in enumerate(rows):
                staff_id = data[0]
                display_data = data[1:]
                for col, value in enumerate(display_data):
                    item = QTableWidgetItem(str(value or ""))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.table.setItem(row, col, item)
                self.table.item(row, 0).setData(Qt.ItemDataRole.UserRole, staff_id)

            self.table.itemSelectionChanged.connect(self._capture_selected_staff) if not hasattr(self, "_selection_connected") else None
            self._selection_connected = True

            self.table.resizeColumnsToContents()

            self.count_label.setText(
                f"تعداد کارکنان: {len(rows)}"
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای کارکنان",
                str(e)
            )

        finally:

            if conn:
                conn.close()

    def _capture_selected_staff(self):
        row = self.table.currentRow()
        if row >= 0 and self.table.item(row, 0):
            self.selected_staff_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)

    def load_data(self):

        self.load_staff()