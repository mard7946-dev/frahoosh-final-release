import sqlite3,secrets
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,QLineEdit,QTableWidget,QTableWidgetItem,QMessageBox
from PySide6.QtCore import Qt
DB=str(Path(__file__).resolve().parents[1]/'school.db')
def db(): c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
class ExamCardsPage(QWidget):
 def __init__(self): super().__init__();self.ui();self.load()
 def ui(self):
  l=QVBoxLayout(self);t=QLabel('کارت ورود به جلسه امتحان');t.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(t);b=QHBoxLayout();self.student=QComboBox();self.student.addItem('انتخاب دانش‌آموز',None);self.exam=QLineEdit();self.exam.setPlaceholderText('نام امتحان');create=QPushButton('صدور کارت');reissue=QPushButton('ویرایش/صدور مجدد');b.addWidget(self.student);b.addWidget(self.exam);b.addWidget(create);b.addWidget(reissue);l.addLayout(b);self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','آزمون','صندلی','کد کارت','تاریخ','شناسه دانش‌آموز']);l.addWidget(self.table);create.clicked.connect(self.create);reissue.clicked.connect(self.create);with_db=0
  with db() as c:c.execute('CREATE TABLE IF NOT EXISTS exam_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,exam_name TEXT,code TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
  self.fill()
 def fill(self):
  self.student.clear();self.student.addItem('انتخاب دانش‌آموز',None)
  with db() as c:ss=c.execute('SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name').fetchall()
  for s in ss:self.student.addItem(f"{s['first_name']} {s['last_name']} | {s['student_code'] or '-'}",s['id'])
 def load(self):
  if not hasattr(self,'table'):return
  with db() as c:rs=c.execute('''SELECT c.id,s.first_name||' '||s.last_name name,c.exam_name,COALESCE(es.seat_no,'تعیین نشده') seat,c.code,c.created_at,c.student_id FROM exam_cards c LEFT JOIN students s ON s.id=c.student_id LEFT JOIN exam_seats es ON es.student_id=c.student_id AND es.exam_name=c.exam_name ORDER BY c.id DESC''').fetchall()
  self.table.setRowCount(len(rs))
  for i,r in enumerate(rs):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def create(self):
  sid=self.student.currentData(); exam=self.exam.text().strip()
  if not sid or not exam:QMessageBox.warning(self,'کارت امتحان','دانش‌آموز و نام امتحان را وارد کنید.');return
  with db() as c:seat=c.execute('SELECT seat_no FROM exam_seats WHERE student_id=? AND exam_name=?',(sid,exam)).fetchone()
  if not seat:QMessageBox.warning(self,'کارت امتحان','ابتدا شماره صندلی امتحانی این دانش‌آموز را ثبت کنید.');return
  code='EXAM-'+secrets.token_hex(5).upper()
  with db() as c:c.execute('INSERT INTO exam_cards(student_id,exam_name,code) VALUES(?,?,?)',(sid,exam,code));c.commit()
  self.load();QMessageBox.information(self,'کارت صادر شد',f'کد کارت: {code}\nشماره صندلی: {seat[0]}')
