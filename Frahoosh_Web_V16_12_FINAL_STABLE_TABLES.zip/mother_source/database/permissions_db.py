from database.db import get_connection



def check_access(
    role,
    module
):

    conn = get_connection()


    try:

        cursor = conn.cursor()



        cursor.execute(
            """
            SELECT COUNT(*)

            FROM permissions

            WHERE role=?

            AND module=?

            AND allowed=1

            """,

            (
                role,
                module
            )
        )



        result = cursor.fetchone()[0]



        return result > 0



    except Exception:

        return False



    finally:

        conn.close()