import sqlite3

from pathlib import Path
DATABASE_NAME = str(Path(__file__).resolve().parents[1] / "school.db")


# =========================================================
# اتصال به دیتابیس
# =========================================================

def _repair_schema_before_wal(conn):
    """Repair legacy school_events schema before SQLite WAL initialization.

    Older Frahoosh databases may contain idx_school_events_remote while the
    school_events table predates the remote_id column. SQLite then raises
    `malformed database schema` as soon as PRAGMA journal_mode=WAL is run.
    This migration is deliberately non-destructive.
    """
    try:
        table = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='school_events'"
        ).fetchone()
        if not table:
            return

        cols = {row[1] for row in conn.execute("PRAGMA table_info(school_events)").fetchall()}
        # Older Smart Board builds used the name school_events for their own
        # calendar table. The unified cross-panel event hub now owns that
        # name, so quarantine the legacy table before touching WAL/indexes.
        if "source_table" not in cols and "event_date" in cols and "description" in cols:
            conn.execute("ALTER TABLE school_events RENAME TO smart_board_school_events")
            cols = set()
        if cols and "remote_id" not in cols:
            conn.execute("ALTER TABLE school_events ADD COLUMN remote_id TEXT DEFAULT ''")
        if "remote_synced" not in cols:
            conn.execute("ALTER TABLE school_events ADD COLUMN remote_synced INTEGER DEFAULT 0")

        # Rebuild the remote index after the column migration.
        conn.execute("DROP INDEX IF EXISTS idx_school_events_remote")
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_school_events_remote "
            "ON school_events(remote_id) WHERE COALESCE(remote_id,'')<>''"
        )
        conn.commit()
    except sqlite3.DatabaseError:
        # Let the normal connection path report the real database error if
        # SQLite cannot repair the legacy schema safely.
        conn.rollback()
        raise


def get_connection():
    conn = sqlite3.connect(DATABASE_NAME, timeout=30.0)
    conn.execute('PRAGMA busy_timeout=30000')
    _repair_schema_before_wal(conn)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    teacher_cols = {r[1] for r in conn.execute('PRAGMA table_info(teachers)').fetchall()}
    if teacher_cols and 'employee_code' not in teacher_cols:
        conn.execute("ALTER TABLE teachers ADD COLUMN employee_code TEXT DEFAULT ''")
    # Core schemas for final operational modules. CREATE IF NOT EXISTS is non-destructive.
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS teacher_exam_slots(
        id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_id INTEGER, class_id INTEGER, class_name TEXT,
        exam_date_shamsi TEXT NOT NULL DEFAULT '', start_time_shamsi TEXT NOT NULL DEFAULT '', end_time_shamsi TEXT NOT NULL DEFAULT '',
        coordinated INTEGER DEFAULT 0, secure_mode INTEGER DEFAULT 1, created_at_shamsi TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS payment_offers(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, amount INTEGER NOT NULL DEFAULT 0,
        target_type TEXT NOT NULL, target_value TEXT DEFAULT '', description TEXT DEFAULT '', active INTEGER DEFAULT 1,
        manual_amount INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, created_at_shamsi TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS payment_attempts(
        id INTEGER PRIMARY KEY AUTOINCREMENT, offer_id INTEGER, student_id INTEGER, payer_username TEXT, payer_role TEXT,
        amount INTEGER NOT NULL, masked_card TEXT DEFAULT '', status TEXT DEFAULT 'pending', gateway_ref TEXT DEFAULT '',
        description TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, created_at_shamsi TEXT DEFAULT ''
    );
    """)
    conn.commit()
    return conn


# =========================================================
# ساخت جداول اصلی سیستم
# =========================================================

def create_tables():

    conn = get_connection()
    cursor = conn.cursor()

    # =====================================================
    # کاربران
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT,
            permissions TEXT
        )
    """)

    cursor.execute("""
        INSERT OR IGNORE INTO users
        (username, password, role, permissions)
        VALUES
        ('admin', '1234', 'manager', 'all')
    """)

    # لینک هویت کاربر به پرونده اصلی دانش‌آموز/دبیر/کارمند
    user_cols = {r[1] for r in cursor.execute("PRAGMA table_info(users)").fetchall()}
    for col, typ in {
        "linked_student_id": "INTEGER",
        "linked_teacher_id": "INTEGER",
        "linked_staff_id": "INTEGER",
        "display_name": "TEXT DEFAULT ''",
    }.items():
        if col not in user_cols:
            cursor.execute(f"ALTER TABLE users ADD COLUMN {col} {typ}")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_student ON users(linked_student_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_teacher ON users(linked_teacher_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_staff ON users(linked_staff_id)")

    # =====================================================
    # دانش‌آموزان
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            national_code TEXT,
            student_code TEXT,
            grade TEXT,
            class_name TEXT,
            phone TEXT,
            parent_phone TEXT,
            photo TEXT,
            father_name TEXT,
            mother_name TEXT,
            birth_date TEXT,
            email TEXT,
            address TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # دبیران
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teachers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            national_code TEXT,
            phone TEXT,
            email TEXT,
            subject TEXT,
            grades TEXT,
            description TEXT
        )
    """)

    teacher_cols = {r[1] for r in cursor.execute("PRAGMA table_info(teachers)").fetchall()}
    if "source_staff_id" not in teacher_cols:
        cursor.execute("ALTER TABLE teachers ADD COLUMN source_staff_id INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_teachers_source_staff ON teachers(source_staff_id)")

    # =====================================================
    # کارکنان
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS staff(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            role TEXT,
            phone TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # کلاس‌های آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_classes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            subject TEXT,
            lesson TEXT,
            teacher TEXT,
            grade TEXT,
            class_name TEXT,
            duration INTEGER DEFAULT 0,
            pages INTEGER DEFAULT 1,
            record INTEGER DEFAULT 0,
            smart_board INTEGER DEFAULT 1,
            quiz INTEGER DEFAULT 1,
            camera INTEGER DEFAULT 1,
            microphone INTEGER DEFAULT 1,
            start_time TEXT,
            end_time TEXT,
            status TEXT DEFAULT 'pending',
            created_at TEXT
        )
    """)

    # =====================================================
    # تکمیل جدول‌های قدیمی
    # =====================================================

    cursor.execute(
        "PRAGMA table_info(online_classes)"
    )

    columns = [
        row[1]
        for row in cursor.fetchall()
    ]

    online_columns = {

        "title": "TEXT",

        "subject": "TEXT",

        "lesson": "TEXT",

        "teacher": "TEXT",

        "grade": "TEXT",

        "class_name": "TEXT",

        "duration": "INTEGER DEFAULT 0",

        "pages": "INTEGER DEFAULT 1",

        "record": "INTEGER DEFAULT 0",

        "smart_board": "INTEGER DEFAULT 1",

        "quiz": "INTEGER DEFAULT 1",

        "camera": "INTEGER DEFAULT 1",

        "microphone": "INTEGER DEFAULT 1",

        "start_time": "TEXT",

        "end_time": "TEXT",

        "status": "TEXT DEFAULT 'pending'",

        "created_at": "TEXT",
    }

    for column, definition in online_columns.items():

        if column not in columns:

            cursor.execute(
                f"""
                ALTER TABLE online_classes
                ADD COLUMN {column} {definition}
                """
            )

    # =====================================================
    # حضور و غیاب آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER,
            student_id INTEGER,
            join_time TEXT,
            leave_time TEXT,
            status TEXT,
            last_activity TEXT
        )
    """)

    # =====================================================
    # کوییز آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_quizzes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER,
            title TEXT,
            subject TEXT,
            duration INTEGER DEFAULT 0,
            teacher TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # نمرات
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS grades(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            teacher_id INTEGER,
            subject TEXT,
            exam_name TEXT,
            score REAL,
            description TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # حضور و غیاب
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            date TEXT,
            status TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # تکالیف
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assignments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            teacher_id INTEGER,
            title TEXT,
            description TEXT,
            status TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # پیام‌ها
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT,
            receiver TEXT,
            text TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # مسیریابی پایدار پیام‌ها بین همه پنل‌ها
    # =====================================================
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS message_targets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_value TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_message_targets_lookup ON message_targets(target_type,target_value)")

    # =====================================================
    # حسابداری مالی
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            balance INTEGER DEFAULT 0,
            created_at TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_type TEXT NOT NULL,
            title TEXT NOT NULL,
            amount INTEGER DEFAULT 0,
            category TEXT,
            description TEXT,
            transaction_date TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_donations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            donor_name TEXT,
            amount INTEGER DEFAULT 0,
            description TEXT,
            donation_date TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_extra(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            student_name TEXT,
            amount INTEGER DEFAULT 0,
            description TEXT,
            payment_date TEXT
        )
    """)

    # =====================================================
    # دسترسی‌های سیستم
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS parent_meetings(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            teacher_id INTEGER NOT NULL,
            parent_phone TEXT DEFAULT '',
            reason TEXT NOT NULL DEFAULT '',
            meeting_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY(teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS permissions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            module TEXT NOT NULL,
            allowed INTEGER DEFAULT 0,
            UNIQUE(role, module)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quiz_questions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quiz_id INTEGER, question TEXT NOT NULL,
            option1 TEXT DEFAULT '', option2 TEXT DEFAULT '', option3 TEXT DEFAULT '', option4 TEXT DEFAULT '',
            correct_answer TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # =====================================================
    # ذخیره تغییرات جداول اصلی
    # =====================================================

    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS parent_children(parent_username TEXT NOT NULL, student_id INTEGER NOT NULL, PRIMARY KEY(parent_username,student_id));
    CREATE TABLE IF NOT EXISTS executive_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,grade TEXT,teacher TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS seating(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,seat_no TEXT,exam TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,title TEXT,code TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS student_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,card_type TEXT,code TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS report_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,term TEXT,average REAL,description TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,category TEXT,quantity INTEGER,location TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS archive_items(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,student_id INTEGER,location TEXT,description TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS executive_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,status TEXT,description TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS counseling_followups(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,subject TEXT,description TEXT,status TEXT,created_at TEXT);
    """)

    # =====================================================
    # فعالیت‌ها، ثبت‌نام، پرداخت، کارت و پرونده دانش‌آموز
    # =====================================================
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS student_registrations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        activity_id INTEGER NOT NULL,
        activity_title TEXT NOT NULL,
        activity_kind TEXT NOT NULL,
        fee INTEGER NOT NULL DEFAULT 0,
        payment_status TEXT NOT NULL DEFAULT 'pending',
        payment_url TEXT DEFAULT '',
        payment_reference TEXT DEFAULT '',
        registration_code TEXT NOT NULL UNIQUE,
        registered_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_student_registrations_student ON student_registrations(student_id);
    CREATE TABLE IF NOT EXISTS payment_transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        registration_id INTEGER,
        amount INTEGER NOT NULL,
        gateway TEXT NOT NULL DEFAULT 'psp',
        authority TEXT DEFAULT '',
        reference TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        paid_at TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS student_files(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL UNIQUE,
        medical_notes TEXT DEFAULT '',
        educational_notes TEXT DEFAULT '',
        disciplinary_notes TEXT DEFAULT '',
        family_notes TEXT DEFAULT '',
        attachments TEXT DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS class_cards(
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, class_name TEXT, code TEXT UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS exam_cards(
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, exam_name TEXT, code TEXT UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS class_seats(
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, class_name TEXT, seat_no TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(class_name,seat_no)
    );
    CREATE TABLE IF NOT EXISTS exam_seats(
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, exam_name TEXT, seat_no TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(exam_name,seat_no)
    );
    """)
    # Preserve compatibility with existing cultural_items databases.
    try:
        cursor.execute("PRAGMA table_info(cultural_items)")
        cultural_cols={r[1] for r in cursor.fetchall()}
        if 'fee' not in cultural_cols:
            cursor.execute("ALTER TABLE cultural_items ADD COLUMN fee INTEGER DEFAULT 0")
    except Exception:
        pass

    # =====================================================
    # کلاس مجازی: گزارش، راستی‌آزمایی حضور و تحلیل هوشمند
    # =====================================================
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS online_class_sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        started_at TEXT NOT NULL,
        ended_at TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS online_presence_checks(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        session_id INTEGER,
        student_id INTEGER NOT NULL,
        checkpoint_no INTEGER NOT NULL,
        scheduled_at TEXT NOT NULL,
        shown_at TEXT DEFAULT '',
        responded_at TEXT DEFAULT '',
        response TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        UNIQUE(class_id, session_id, student_id, checkpoint_no)
    );
    CREATE TABLE IF NOT EXISTS online_class_activity(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        session_id INTEGER,
        student_id INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        event_time TEXT NOT NULL,
        metadata TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS online_class_ai_reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        student_id INTEGER,
        session_id INTEGER,
        report TEXT NOT NULL,
        risk_level TEXT NOT NULL DEFAULT 'normal',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS online_class_notifications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        recipient TEXT NOT NULL,
        recipient_role TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL,
        read_at TEXT DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_online_presence_class_student ON online_presence_checks(class_id, student_id);
    CREATE INDEX IF NOT EXISTS idx_online_activity_class_student ON online_class_activity(class_id, student_id);
    CREATE INDEX IF NOT EXISTS idx_online_notifications_recipient ON online_class_notifications(recipient, recipient_role);
    """)

    # =====================================================
    # پرونده انضباطی دانش‌آموزان
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS discipline_records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            teacher_id INTEGER,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            priority TEXT DEFAULT 'normal',
            status TEXT DEFAULT 'pending',
            created_at TEXT NOT NULL
        )
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_discipline_student
        ON discipline_records(student_id)
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS discipline_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL UNIQUE, description TEXT DEFAULT '',
            deduction REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        )
    """)
    existing = {r[1] for r in cursor.execute("PRAGMA table_info(discipline_records)").fetchall()}
    for col, typ in {"item_id":"INTEGER","deduction":"REAL DEFAULT 0","actor_username":"TEXT DEFAULT ''","actor_role":"TEXT DEFAULT ''","note":"TEXT DEFAULT ''"}.items():
        if col not in existing: cursor.execute(f"ALTER TABLE discipline_records ADD COLUMN {col} {typ}")
    cursor.execute("""CREATE TABLE IF NOT EXISTS discipline_settings(
        id INTEGER PRIMARY KEY CHECK(id=1), base_score REAL NOT NULL DEFAULT 20, updated_at TEXT NOT NULL)""")
    cursor.execute("INSERT OR IGNORE INTO discipline_settings(id,base_score,updated_at) VALUES(1,20,datetime('now'))")

    cursor.execute("""CREATE TABLE IF NOT EXISTS surveys(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'draft', audience TEXT NOT NULL DEFAULT 'students_parents',
        start_at TEXT DEFAULT '', end_at TEXT DEFAULT '', created_by TEXT DEFAULT 'admin', created_at TEXT NOT NULL)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS survey_questions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, survey_id INTEGER NOT NULL, question TEXT NOT NULL,
        question_type TEXT NOT NULL DEFAULT 'text', options TEXT DEFAULT '', required INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS survey_responses(
        id INTEGER PRIMARY KEY AUTOINCREMENT, survey_id INTEGER NOT NULL, respondent_username TEXT NOT NULL,
        respondent_role TEXT NOT NULL, student_id INTEGER, submitted_at TEXT NOT NULL,
        UNIQUE(survey_id,respondent_username,respondent_role,student_id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS survey_answers(
        id INTEGER PRIMARY KEY AUTOINCREMENT, response_id INTEGER NOT NULL, question_id INTEGER NOT NULL, answer TEXT DEFAULT '')""")

    conn.commit()
    conn.close()


# =========================================================
# اجرای مستقیم فایل
# =========================================================

if __name__ == "__main__":

    create_tables()

    print(
        "School database initialized successfully."
    )


# =========================================================
# دریافت پرونده‌های مشاوره
# =========================================================

def get_counseling_files():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            id,
            student_id,
            subject,
            notes,
            status,
            created_at
        FROM counseling_files
        ORDER BY id DESC
    """)

    rows = cursor.fetchall()

    conn.close()

    return rows


# =========================================================
# پیگیری مشاوره
# =========================================================

def add_followup(
    student_id,
    subject,
    notes,
    followup_date,
    status="در حال پیگیری",
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_followups
        (
            student_id,
            subject,
            notes,
            status,
            followup_date,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        subject,
        notes,
        status,
        followup_date,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# هدایت تحصیلی
# =========================================================

def add_guidance(
    student_id,
    grade,
    interest,
    aptitude,
    recommendation,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_guidance
        (
            student_id,
            grade,
            interest,
            aptitude,
            recommendation,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        grade,
        interest,
        aptitude,
        recommendation,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id

# =========================================================
# ارتباط با والدین
# =========================================================

def add_parent_contact(
    student_id,
    parent_name,
    message,
    contact_date,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_parent_contacts
        (
            student_id,
            parent_name,
            message,
            contact_date,
            created_at
        )
        VALUES (?, ?, ?, ?, ?)
    """, (
        student_id,
        parent_name,
        message,
        contact_date,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# آموزش خانواده
# =========================================================

def add_family_education(
    title,
    content,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_family_education
        (
            title,
            content,
            created_at
        )
        VALUES (?, ?, ?)
    """, (
        title,
        content,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# تابلو مشاوره
# =========================================================

def add_bulletin(
    title,
    content,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_bulletins
        (
            title,
            content,
            created_at
        )
        VALUES (?, ?, ?)
    """, (
        title,
        content,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# ارجاع
# =========================================================

def add_referral(
    student_id,
    referred_to,
    subject,
    description,
    status="باز",
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_referrals
        (
            student_id,
            referred_to,
            subject,
            status,
            description,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        referred_to,
        subject,
        status,
        description,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id