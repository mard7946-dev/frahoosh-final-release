"""Persistent application settings schema for Frahoosh."""
from database.db import get_connection

def create_settings_tables():
    conn = get_connection()
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS school_settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS application_settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT '',
            value_type TEXT DEFAULT 'text',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS virtual_server_config(
            id INTEGER PRIMARY KEY CHECK(id=1),
            server_url TEXT NOT NULL DEFAULT '',
            api_key TEXT NOT NULL DEFAULT '',
            capacity INTEGER NOT NULL DEFAULT 700,
            enabled INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS server_sync_settings(
            id INTEGER PRIMARY KEY CHECK(id=1),
            provider TEXT NOT NULL DEFAULT 'supabase',
            enabled INTEGER NOT NULL DEFAULT 0,
            last_sync_at TEXT DEFAULT '',
            last_error TEXT DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        conn.execute("INSERT OR IGNORE INTO virtual_server_config(id) VALUES(1)")
        conn.execute("INSERT OR IGNORE INTO server_sync_settings(id) VALUES(1)")
        conn.commit()
    finally:
        conn.close()
