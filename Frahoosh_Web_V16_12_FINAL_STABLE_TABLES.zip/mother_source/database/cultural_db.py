"""Persistent database layer for Frahoosh cultural/educational activities."""
from __future__ import annotations
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path


def db_path() -> Path:
    configured = os.environ.get("FRAHOOSH_DB_PATH")
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(__file__).resolve().parents[1] / "school.db"


@contextmanager
def connect():
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        initialize(conn)
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def initialize(conn: sqlite3.Connection | None = None):
    own = conn is None
    if own:
        path = db_path(); path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(path))
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS cultural_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL,
        title TEXT NOT NULL,
        student_name TEXT,
        details TEXT,
        fee INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_cultural_items_kind ON cultural_items(kind);
    CREATE INDEX IF NOT EXISTS idx_cultural_items_created ON cultural_items(created_at);
    """)
    try:
        cols={r[1] for r in conn.execute('PRAGMA table_info(cultural_items)').fetchall()}
        if 'fee' not in cols: conn.execute('ALTER TABLE cultural_items ADD COLUMN fee INTEGER DEFAULT 0')
    except Exception: pass
    if own:
        conn.commit(); conn.close()


def list_items(kind: str):
    with connect() as conn:
        return conn.execute(
            "SELECT id,title,student_name,details,fee,status,created_at FROM cultural_items WHERE kind=? ORDER BY id DESC",
            (kind,),
        ).fetchall()


def add_item(kind: str, title: str, student_name: str = "", details: str = "") -> int:
    title = title.strip()
    if not title:
        raise ValueError("عنوان الزامی است")
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO cultural_items(kind,title,student_name,details) VALUES(?,?,?,?)",
            (kind, title, student_name.strip(), details.strip()),
        )
        return int(cur.lastrowid)


def delete_item(item_id: int):
    with connect() as conn:
        conn.execute("DELETE FROM cultural_items WHERE id=?", (int(item_id),))


def update_item(item_id: int, title: str, student_name: str = "", details: str = "", status: str = "active"):
    title = title.strip()
    if not title:
        raise ValueError("عنوان الزامی است")
    with connect() as conn:
        conn.execute(
            "UPDATE cultural_items SET title=?,student_name=?,details=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (title, student_name.strip(), details.strip(), status, int(item_id)),
        )


def create_cultural_tables():
    initialize()
