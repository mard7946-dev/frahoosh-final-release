"""Complete Frahoosh v16.8 application schema.

This module only creates/migrates missing tables and columns. It does not
replace the existing SQLite database and is safe for existing v16.x data.
"""
from database.db import get_connection


def _ensure_columns(c, table, columns):
    table_exists = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
    if not table_exists:
        return
    existing = {r[1] for r in c.execute(f'PRAGMA table_info("{table}")').fetchall()}
    for name, definition in columns.items():
        if name not in existing:
            c.execute(f'ALTER TABLE "{table}" ADD COLUMN "{name}" {definition}')


def create_complete_schema():
    c = get_connection()
    try:
        c.executescript("""
        /* ---------- school / management ---------- */
        CREATE TABLE IF NOT EXISTS school_profile(
            id INTEGER PRIMARY KEY CHECK(id=1),
            school_name TEXT DEFAULT '',
            school_code TEXT DEFAULT '',
            principal_name TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            address TEXT DEFAULT '',
            academic_year TEXT DEFAULT '',
            logo_path TEXT DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP, request_date_shamsi TEXT DEFAULT ''
        );
        INSERT OR IGNORE INTO school_profile(id) VALUES(1);

        CREATE TABLE IF NOT EXISTS executive_operations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            operation_type TEXT DEFAULT '', title TEXT NOT NULL,
            student_id INTEGER, class_name TEXT DEFAULT '',
            description TEXT DEFAULT '', status TEXT DEFAULT 'در انتظار',
            operation_date TEXT DEFAULT '', created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS executive_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, report_type TEXT DEFAULT '',
            student_id INTEGER, class_name TEXT DEFAULT '',
            payload TEXT DEFAULT '{}', report_date TEXT DEFAULT '',
            created_by TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS teacher_classes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER, teacher_name TEXT DEFAULT '', subject TEXT DEFAULT '',
            grade TEXT DEFAULT '', class_name TEXT DEFAULT '', active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- educational / teacher ---------- */
        CREATE TABLE IF NOT EXISTS teacher_attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL, teacher_id INTEGER,
            class_name TEXT DEFAULT '', subject TEXT DEFAULT '',
            attendance_date TEXT DEFAULT '', status TEXT DEFAULT '',
            description TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS teacher_exams(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER, title TEXT NOT NULL, subject TEXT DEFAULT '',
            grade TEXT DEFAULT '', class_name TEXT DEFAULT '',
            exam_type TEXT DEFAULT 'آزمون', exam_date TEXT DEFAULT '',
            duration INTEGER DEFAULT 45, description TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS teacher_activities(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER, student_id INTEGER,
            title TEXT NOT NULL, activity_type TEXT DEFAULT '',
            subject TEXT DEFAULT '', score REAL, description TEXT DEFAULT '',
            activity_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS educational_activities(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, subject TEXT DEFAULT '', grade TEXT DEFAULT '',
            class_name TEXT DEFAULT '', teacher_id INTEGER, student_id INTEGER,
            description TEXT DEFAULT '', activity_date TEXT DEFAULT '',
            status TEXT DEFAULT 'active', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- full grade model ---------- */
        CREATE TABLE IF NOT EXISTS grade_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL, teacher_id INTEGER,
            subject TEXT DEFAULT '', title TEXT DEFAULT '',
            grade_type TEXT DEFAULT 'custom', term TEXT DEFAULT '',
            score REAL, max_score REAL DEFAULT 20,
            description TEXT DEFAULT '', grade_date TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_grade_items_student ON grade_items(student_id,subject,term);

        /* Upgrade canonical grades table without replacing it. */



        /* ---------- canonical student grades / report model ---------- */
        CREATE TABLE IF NOT EXISTS student_grades(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            teacher_id INTEGER,
            subject TEXT DEFAULT '',
            class_name TEXT DEFAULT '',
            assessment_type TEXT DEFAULT 'custom',
            assessment_title TEXT DEFAULT '',
            score REAL,
            coefficient REAL DEFAULT 1,
            grade_date TEXT DEFAULT '',
            grade_date_shamsi TEXT DEFAULT '',
            description TEXT DEFAULT '',
            term TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_student_grades_student ON student_grades(student_id,subject,term);
        CREATE INDEX IF NOT EXISTS idx_student_grades_date ON student_grades(grade_date_shamsi);
        CREATE TABLE IF NOT EXISTS grade_visibility(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            grade_id INTEGER NOT NULL UNIQUE,
            released_by TEXT DEFAULT '',
            released_at_shamsi TEXT DEFAULT '',
            released INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS online_class_teachers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL,
            teacher_id INTEGER, teacher_name TEXT DEFAULT '', UNIQUE(class_id,teacher_id)
        );
        CREATE TABLE IF NOT EXISTS online_class_students(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL, student_name TEXT DEFAULT '', UNIQUE(class_id,student_id)
        );
        CREATE TABLE IF NOT EXISTS online_class_settings(
            class_id INTEGER PRIMARY KEY, public_chat_enabled INTEGER DEFAULT 0,
            private_chat_enabled INTEGER DEFAULT 1, board_enabled INTEGER DEFAULT 1,
            file_share_enabled INTEGER DEFAULT 1, media_enabled INTEGER DEFAULT 1,
            quiz_enabled INTEGER DEFAULT 1, camera_enabled INTEGER DEFAULT 1,
            microphone_enabled INTEGER DEFAULT 1, screen_share_enabled INTEGER DEFAULT 1,
            updated_at_shamsi TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS online_class_chat(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL,
            sender_id INTEGER, sender_role TEXT DEFAULT '', sender_name TEXT DEFAULT '',
            recipient_student_id INTEGER, is_private INTEGER DEFAULT 0,
            message TEXT NOT NULL, sent_at_shamsi TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS online_class_board_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL,
            actor_id INTEGER, actor_role TEXT DEFAULT '', event_type TEXT NOT NULL,
            payload TEXT DEFAULT '{}', event_date_shamsi TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS report_card_snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            term TEXT DEFAULT '',
            academic_year TEXT DEFAULT '',
            average REAL DEFAULT 0,
            report_json TEXT DEFAULT '{}',
            generated_date_shamsi TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- smart board content / quizzes / class activities ---------- */
        CREATE TABLE IF NOT EXISTS smart_board_content(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, content TEXT DEFAULT '',
            class_id INTEGER, teacher_id INTEGER,
            content_date_shamsi TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS smart_board_quizzes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, question TEXT NOT NULL,
            option_a TEXT DEFAULT '', option_b TEXT DEFAULT '',
            option_c TEXT DEFAULT '', option_d TEXT DEFAULT '',
            correct_option TEXT DEFAULT '', class_id INTEGER, teacher_id INTEGER,
            quiz_date_shamsi TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS smart_board_activities(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, activity_text TEXT DEFAULT '',
            class_id INTEGER, teacher_id INTEGER,
            activity_date_shamsi TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- cultural / activities ---------- */
        CREATE TABLE IF NOT EXISTS competitions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, category TEXT DEFAULT '',
            start_date TEXT DEFAULT '', end_date TEXT DEFAULT '',
            status TEXT DEFAULT 'فعال', description TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS cultural_activity_registrations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            activity_id INTEGER, activity_title TEXT NOT NULL,
            activity_kind TEXT DEFAULT '', student_id INTEGER,
            student_name TEXT DEFAULT '', fee INTEGER DEFAULT 0,
            payment_status TEXT DEFAULT 'pending', registration_code TEXT DEFAULT '',
            registration_date TEXT DEFAULT '', status TEXT DEFAULT 'active', payment_record_id INTEGER DEFAULT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS cultural_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, report_type TEXT DEFAULT '',
            activity_id INTEGER, payload TEXT DEFAULT '{}',
            report_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, payment_record_id INTEGER DEFAULT NULL
        );

        /* ---------- schedules / exams ---------- */
        CREATE TABLE IF NOT EXISTS weekly_schedule(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher TEXT NOT NULL DEFAULT '', hours REAL DEFAULT 0,
            grade TEXT DEFAULT '', class_count INTEGER DEFAULT 1,
            subject TEXT DEFAULT '', bell_pattern TEXT DEFAULT '',
            class_names TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS generated_weekly_schedule(
            id INTEGER PRIMARY KEY AUTOINCREMENT, source_id INTEGER,
            teacher TEXT DEFAULT '', subject TEXT DEFAULT '', grade TEXT DEFAULT '',
            class_name TEXT DEFAULT '', weekday TEXT DEFAULT '', bell TEXT DEFAULT '',
            week_index INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS exam_schedule(
            id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL DEFAULT '',
            grade TEXT NOT NULL DEFAULT '', start_date TEXT DEFAULT '', end_date TEXT DEFAULT '',
            weight TEXT DEFAULT 'متوسط', exam_date TEXT DEFAULT '', duration INTEGER DEFAULT 45,
            exam_start_time TEXT DEFAULT '13:10', exam_end_time TEXT DEFAULT '13:55',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- parent/student read models ---------- */
        CREATE TABLE IF NOT EXISTS parent_dashboard_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, parent_username TEXT NOT NULL,
            student_id INTEGER, event_type TEXT NOT NULL, source_table TEXT DEFAULT '',
            source_id INTEGER, title TEXT DEFAULT '', payload TEXT DEFAULT '{}',
            seen_at TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS student_dashboard_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL,
            student_id INTEGER, event_type TEXT NOT NULL, source_table TEXT DEFAULT '',
            source_id INTEGER, title TEXT DEFAULT '', payload TEXT DEFAULT '{}',
            seen_at TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_parent_dashboard_user ON parent_dashboard_events(parent_username,seen_at);
        CREATE INDEX IF NOT EXISTS idx_student_dashboard_user ON student_dashboard_events(username,seen_at);

        /* ---------- finance / payments ---------- */
        CREATE TABLE IF NOT EXISTS payment_records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER, parent_username TEXT DEFAULT '',
            title TEXT NOT NULL, amount INTEGER DEFAULT 0,
            payment_type TEXT DEFAULT '', gateway TEXT DEFAULT '',
            authority TEXT DEFAULT '', reference TEXT DEFAULT '',
            status TEXT DEFAULT 'pending', payment_date TEXT DEFAULT '',
            description TEXT DEFAULT '', payment_date_shamsi TEXT DEFAULT '', parent_name TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_payment_records_student ON payment_records(student_id,status);

        /* ---------- smart board ---------- */
        CREATE TABLE IF NOT EXISTS smart_board_whiteboards(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            content TEXT DEFAULT '', class_id INTEGER, teacher_id INTEGER,
            board_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS smart_board_files(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            file_path TEXT NOT NULL, file_type TEXT DEFAULT '',
            class_id INTEGER, teacher_id INTEGER, description TEXT DEFAULT '',
            uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS smart_board_media(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            media_path TEXT NOT NULL, media_type TEXT DEFAULT '',
            class_id INTEGER, teacher_id INTEGER, description TEXT DEFAULT '',
            uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS smart_board_interactive_tools(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            tool_type TEXT DEFAULT '', configuration TEXT DEFAULT '{}',
            class_id INTEGER, teacher_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- AI ---------- */
        CREATE TABLE IF NOT EXISTS ai_questions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT DEFAULT '',
            role TEXT DEFAULT '', question TEXT NOT NULL, answer TEXT DEFAULT '',
            student_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            answered_at TEXT DEFAULT '', answer_date_shamsi TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS ai_assistant_sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT DEFAULT '',
            role TEXT DEFAULT '', title TEXT DEFAULT '', context TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            request_date_shamsi TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS ai_educational_analysis(
            id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER,
            teacher_id INTEGER, subject TEXT DEFAULT '', period TEXT DEFAULT '',
            analysis TEXT DEFAULT '', score REAL, risk_level TEXT DEFAULT 'normal',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, analysis_date_shamsi TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS ai_smart_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            report_type TEXT DEFAULT '', target_type TEXT DEFAULT '', target_id INTEGER,
            report TEXT DEFAULT '', created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, report_date_shamsi TEXT DEFAULT ''
        );

        /* ---------- settings / backup ---------- */
        CREATE TABLE IF NOT EXISTS account_settings(
            username TEXT PRIMARY KEY, display_name TEXT DEFAULT '',
            phone TEXT DEFAULT '', email TEXT DEFAULT '', preferences TEXT DEFAULT '{}',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS backup_records(
            id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT NOT NULL,
            backup_type TEXT DEFAULT 'local', size_bytes INTEGER DEFAULT 0,
            status TEXT DEFAULT 'created', created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        /* ---------- unified inbox/message ---------- */
        CREATE TABLE IF NOT EXISTS message_delivery(
            id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER NOT NULL,
            username TEXT NOT NULL, received_at TEXT DEFAULT '', seen_at TEXT DEFAULT '',
            UNIQUE(message_id,username)
        );
        CREATE INDEX IF NOT EXISTS idx_message_delivery_user ON message_delivery(username,seen_at);
        CREATE TABLE IF NOT EXISTS audience_presets(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
            targets_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS event_audiences(
            id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL,
            target_type TEXT NOT NULL, target_value TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(event_id,target_type,target_value)
        );
        """)

        # The SQL script above intentionally leaves canonical grades migrations
        # to Python so existing installations keep every old column/value.
        _ensure_columns(c, 'student_grades', {
            'class_name':'TEXT DEFAULT ""', 'assessment_type':'TEXT DEFAULT "custom"',
            'assessment_title':'TEXT DEFAULT ""', 'coefficient':'REAL DEFAULT 1',
            'grade_date_shamsi':'TEXT DEFAULT ""', 'term':'TEXT DEFAULT ""',
            'updated_at':'TEXT DEFAULT CURRENT_TIMESTAMP'
        })
        _ensure_columns(c, 'ai_questions', {'answer_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'ai_assistant_sessions', {'request_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'ai_educational_analysis', {'analysis_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'ai_smart_reports', {'report_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'payment_records', {'payment_date_shamsi':'TEXT DEFAULT ""','parent_name':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'smart_board_content', {'content_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'smart_board_quizzes', {'quiz_date_shamsi':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'smart_board_activities', {'activity_date_shamsi':'TEXT DEFAULT ""'})

        _ensure_columns(c, 'cultural_activity_registrations', {'payment_record_id':'INTEGER'})
        _ensure_columns(c, 'grades', {
            'grade_type':'TEXT DEFAULT "custom"', 'term':'TEXT DEFAULT ""',
            'max_score':'REAL DEFAULT 20', 'grade_date':'TEXT DEFAULT ""',
            'title':'TEXT DEFAULT ""', 'assessment_date':'TEXT DEFAULT ""'
        })
        _ensure_columns(c, 'teacher_attendance', {
            'teacher_id':'INTEGER', 'class_name':'TEXT DEFAULT ""', 'subject':'TEXT DEFAULT ""',
            'attendance_date':'TEXT DEFAULT ""', 'description':'TEXT DEFAULT ""', 'created_at':'TEXT DEFAULT CURRENT_TIMESTAMP'
        })
        _ensure_columns(c, 'attendance', {
            'teacher_id':'INTEGER', 'subject':'TEXT DEFAULT ""',
            'class_name':'TEXT DEFAULT ""', 'attendance_date':'TEXT DEFAULT ""'
        })
        _ensure_columns(c, 'assignments', {'due_date':'TEXT DEFAULT ""','subject':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'report_cards', {'grade_level':'TEXT DEFAULT ""','academic_year':'TEXT DEFAULT ""','report_date':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'payment_transactions', {'parent_username':'TEXT DEFAULT ""','payment_date':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'student_registrations', {'registration_date':'TEXT DEFAULT ""','status':'TEXT DEFAULT "active"'})
        c.execute('''CREATE TABLE IF NOT EXISTS lesson_plans(
            id INTEGER PRIMARY KEY AUTOINCREMENT, teacher_id INTEGER, teacher_name TEXT DEFAULT '',
            subject TEXT DEFAULT '', grade TEXT DEFAULT '', class_name TEXT DEFAULT '', title TEXT DEFAULT '',
            content TEXT DEFAULT '', session_date TEXT DEFAULT '', lesson_title TEXT DEFAULT '',
            description TEXT DEFAULT '', plan_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        _ensure_columns(c, 'teachers', {'mobile':'TEXT DEFAULT ""','lessons':'TEXT DEFAULT ""','employment_status':'TEXT DEFAULT "فعال"'})
        _ensure_columns(c, 'assets', {'archived':'INTEGER DEFAULT 0'})
        _ensure_columns(c, 'executive_requests', {'role':'TEXT DEFAULT ""'})
        _ensure_columns(c, 'assignments', {'class_name':'TEXT DEFAULT ""','teacher_id':'INTEGER','student_id':'INTEGER','title':'TEXT DEFAULT ""','created_at':'TEXT DEFAULT CURRENT_TIMESTAMP'})
        _ensure_columns(c, 'smart_board_school_events', {'event_time':'TEXT DEFAULT ""'})

        c.execute("CREATE INDEX IF NOT EXISTS idx_grades_student_type ON grades(student_id,grade_type,term)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_teacher_attendance_student ON teacher_attendance(student_id,attendance_date)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_competitions_dates ON competitions(start_date,end_date)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_exam_schedule_grade_date ON exam_schedule(grade,exam_date)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_weekly_schedule_grade ON weekly_schedule(grade,class_names)")
        _ensure_columns(c, "online_classes", {
            "created_at_shamsi":"TEXT DEFAULT ''", "start_time_shamsi":"TEXT DEFAULT ''", "end_time_shamsi":"TEXT DEFAULT ''"
        })
        _ensure_columns(c, "student_grades", {"manager_released":"INTEGER DEFAULT 0"})
        _ensure_columns(c, "online_class_settings", {"updated_at_shamsi":"TEXT DEFAULT ''"})
        c.commit()
    finally:
        c.close()
