"""Persistent database tables for Frahoosh AI features."""
from database.db import get_connection

def create_ai_tables():
    conn = get_connection()
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS ai_analysis_runs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_type TEXT NOT NULL,
            target_type TEXT DEFAULT '',
            target_id INTEGER,
            input_payload TEXT DEFAULT '{}',
            result_text TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS ai_recommendations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            category TEXT NOT NULL,
            recommendation TEXT NOT NULL,
            priority TEXT DEFAULT 'normal',
            status TEXT DEFAULT 'open',
            created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS ai_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            report_type TEXT DEFAULT '',
            payload TEXT DEFAULT '{}',
            created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ai_analysis_target ON ai_analysis_runs(target_type,target_id);
        CREATE INDEX IF NOT EXISTS idx_ai_recommendations_student ON ai_recommendations(student_id,status);
        CREATE INDEX IF NOT EXISTS idx_ai_reports_type ON ai_reports(report_type,created_at);
        """)
        conn.commit()
    finally:
        conn.close()
