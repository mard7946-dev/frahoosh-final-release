import sqlite3

DATABASE_NAME = "school.db"


# =========================================================
# اتصال به دیتابیس
# =========================================================

def get_connection():
    return sqlite3.connect(DATABASE_NAME)


# =========================================================
# ساخت جداول اصلی سیستم
# =========================================================

def create_tables():

    conn = get_connection()
    cursor = conn.cursor()

    # =====================================================
    # کاربران
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT,
            permissions TEXT
        )
    """)

    cursor.execute("""
        INSERT OR IGNORE INTO users
        (username, password, role, permissions)
        VALUES
        ('admin', '1234', 'manager', 'all')
    """)

    # =====================================================
    # دانش‌آموزان
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            national_code TEXT,
            student_code TEXT,
            grade TEXT,
            class_name TEXT,
            phone TEXT,
            parent_phone TEXT,
            photo TEXT,
            father_name TEXT,
            mother_name TEXT,
            birth_date TEXT,
            email TEXT,
            address TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # دبیران
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teachers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            national_code TEXT,
            phone TEXT,
            email TEXT,
            subject TEXT,
            grades TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # کارکنان
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS staff(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT,
            last_name TEXT,
            role TEXT,
            phone TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # کلاس‌های آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_classes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            subject TEXT,
            lesson TEXT,
            teacher TEXT,
            grade TEXT,
            class_name TEXT,
            duration INTEGER DEFAULT 0,
            pages INTEGER DEFAULT 1,
            record INTEGER DEFAULT 0,
            smart_board INTEGER DEFAULT 1,
            quiz INTEGER DEFAULT 1,
            camera INTEGER DEFAULT 1,
            microphone INTEGER DEFAULT 1,
            start_time TEXT,
            end_time TEXT,
            status TEXT DEFAULT 'pending',
            created_at TEXT
        )
    """)

    # =====================================================
    # تکمیل جدول‌های قدیمی
    # =====================================================

    cursor.execute(
        "PRAGMA table_info(online_classes)"
    )

    columns = [
        row[1]
        for row in cursor.fetchall()
    ]

    online_columns = {

        "title": "TEXT",

        "subject": "TEXT",

        "lesson": "TEXT",

        "teacher": "TEXT",

        "grade": "TEXT",

        "class_name": "TEXT",

        "duration": "INTEGER DEFAULT 0",

        "pages": "INTEGER DEFAULT 1",

        "record": "INTEGER DEFAULT 0",

        "smart_board": "INTEGER DEFAULT 1",

        "quiz": "INTEGER DEFAULT 1",

        "camera": "INTEGER DEFAULT 1",

        "microphone": "INTEGER DEFAULT 1",

        "start_time": "TEXT",

        "end_time": "TEXT",

        "status": "TEXT DEFAULT 'pending'",

        "created_at": "TEXT",
    }

    for column, definition in online_columns.items():

        if column not in columns:

            cursor.execute(
                f"""
                ALTER TABLE online_classes
                ADD COLUMN {column} {definition}
                """
            )

    # =====================================================
    # حضور و غیاب آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER,
            student_id INTEGER,
            join_time TEXT,
            leave_time TEXT,
            status TEXT,
            last_activity TEXT
        )
    """)

    # =====================================================
    # کوییز آنلاین
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS online_quizzes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER,
            title TEXT,
            subject TEXT,
            duration INTEGER DEFAULT 0,
            teacher TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # نمرات
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS grades(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            teacher_id INTEGER,
            subject TEXT,
            exam_name TEXT,
            score REAL,
            description TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # حضور و غیاب
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            date TEXT,
            status TEXT,
            description TEXT
        )
    """)

    # =====================================================
    # تکالیف
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assignments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            teacher_id INTEGER,
            title TEXT,
            description TEXT,
            status TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # پیام‌ها
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT,
            receiver TEXT,
            text TEXT,
            created_at TEXT
        )
    """)

    # =====================================================
    # حسابداری مالی
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            balance INTEGER DEFAULT 0,
            created_at TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_type TEXT NOT NULL,
            title TEXT NOT NULL,
            amount INTEGER DEFAULT 0,
            category TEXT,
            description TEXT,
            transaction_date TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_donations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            donor_name TEXT,
            amount INTEGER DEFAULT 0,
            description TEXT,
            donation_date TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS finance_extra(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            student_name TEXT,
            amount INTEGER DEFAULT 0,
            description TEXT,
            payment_date TEXT
        )
    """)

    # =====================================================
    # دسترسی‌های سیستم
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS permissions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            module TEXT NOT NULL,
            allowed INTEGER DEFAULT 0,
            UNIQUE(role, module)
        )
    """)

    # =====================================================
    # ذخیره تغییرات جداول اصلی
    # =====================================================

    conn.commit()
    conn.close()


# =========================================================
# اجرای مستقیم فایل
# =========================================================

if __name__ == "__main__":

    create_tables()

    print(
        "School database initialized successfully."
    )


# =========================================================
# دریافت پرونده‌های مشاوره
# =========================================================

def get_counseling_files():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            id,
            student_id,
            subject,
            notes,
            status,
            created_at
        FROM counseling_files
        ORDER BY id DESC
    """)

    rows = cursor.fetchall()

    conn.close()

    return rows


# =========================================================
# پیگیری مشاوره
# =========================================================

def add_followup(
    student_id,
    subject,
    notes,
    followup_date,
    status="در حال پیگیری",
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_followups
        (
            student_id,
            subject,
            notes,
            status,
            followup_date,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        subject,
        notes,
        status,
        followup_date,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# هدایت تحصیلی
# =========================================================

def add_guidance(
    student_id,
    grade,
    interest,
    aptitude,
    recommendation,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_guidance
        (
            student_id,
            grade,
            interest,
            aptitude,
            recommendation,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        grade,
        interest,
        aptitude,
        recommendation,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id

# =========================================================
# ارتباط با والدین
# =========================================================

def add_parent_contact(
    student_id,
    parent_name,
    message,
    contact_date,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_parent_contacts
        (
            student_id,
            parent_name,
            message,
            contact_date,
            created_at
        )
        VALUES (?, ?, ?, ?, ?)
    """, (
        student_id,
        parent_name,
        message,
        contact_date,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# آموزش خانواده
# =========================================================

def add_family_education(
    title,
    content,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_family_education
        (
            title,
            content,
            created_at
        )
        VALUES (?, ?, ?)
    """, (
        title,
        content,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# تابلو مشاوره
# =========================================================

def add_bulletin(
    title,
    content,
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_bulletins
        (
            title,
            content,
            created_at
        )
        VALUES (?, ?, ?)
    """, (
        title,
        content,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id


# =========================================================
# ارجاع
# =========================================================

def add_referral(
    student_id,
    referred_to,
    subject,
    description,
    status="باز",
    created_at=""
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO counseling_referrals
        (
            student_id,
            referred_to,
            subject,
            status,
            description,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        referred_to,
        subject,
        status,
        description,
        created_at
    ))

    conn.commit()

    record_id = cursor.lastrowid

    conn.close()

    return record_id