"""Persistent cross-panel school messaging and audience routing."""
import sqlite3
from datetime import datetime
from pathlib import Path
DB = Path(__file__).resolve().parents[1] / 'school.db'

def _conn():
    c=sqlite3.connect(DB, timeout=30.0)
    c.execute('PRAGMA busy_timeout=30000'); c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA foreign_keys=ON')
    return c

def ensure_tables():
    c=_conn()
    c.execute("CREATE TABLE IF NOT EXISTS message_targets(id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER NOT NULL, target_type TEXT NOT NULL, target_value TEXT, created_at TEXT NOT NULL)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_message_targets ON message_targets(target_type,target_value)")
    c.execute('''CREATE TABLE IF NOT EXISTS message_delivery(id INTEGER PRIMARY KEY AUTOINCREMENT,message_id INTEGER NOT NULL,username TEXT NOT NULL,received_at TEXT DEFAULT '',seen_at TEXT DEFAULT '',UNIQUE(message_id,username))''')
    c.execute("CREATE INDEX IF NOT EXISTS idx_message_delivery_user ON message_delivery(username,seen_at)")
    c.commit(); c.close()

def send(sender, text, target_type='school', target_value='all', title='', audiences=None):
    ensure_tables()
    text=(text or '').strip()
    if not text:
        raise ValueError('متن پیام خالی است')
    token=_token(target_type,target_value)
    now=datetime.now().isoformat(timespec='seconds')
    c=_conn()
    try:
        cur=c.execute(
            'INSERT INTO messages(sender,receiver,text,created_at) VALUES(?,?,?,?)',
            (sender or 'سیستم فراهوش',token,text,now)
        )
        mid=cur.lastrowid
        c.execute(
            'INSERT INTO message_targets(message_id,target_type,target_value,created_at) VALUES(?,?,?,?)',
            (mid,target_type,str(target_value or ''),now)
        )
        try:
            from .unified_event_service import _student_accounts, _school_accounts
            rec=[]
            if target_type=='school':
                rec=_school_accounts(c)
            elif target_type=='role':
                rec=[r[0] for r in c.execute('SELECT username FROM users WHERE lower(role)=lower(?)',(str(target_value),)).fetchall()]
            elif target_type=='student' and str(target_value).isdigit():
                rec=_student_accounts(c,int(target_value))
            elif target_type=='class':
                for rr in c.execute('SELECT id FROM students WHERE class_name=?',(str(target_value),)).fetchall():
                    rec += _student_accounts(c,rr[0])
            elif target_type=='parent':
                rec=[r[0] for r in c.execute("SELECT username FROM users WHERE lower(role) in ('parent','parents','اولیا','ولی')").fetchall()]
            for u in dict.fromkeys(rec):
                c.execute('INSERT OR IGNORE INTO message_delivery(message_id,username) VALUES(?,?)',(mid,u))
        except Exception:
            pass
        c.commit()
    except Exception:
        c.rollback(); raise
    finally:
        c.close()

    # Mirror every manually sent message into the unified event hub so it is
    # visible from manager/vice/advisor/teacher/parent/student inboxes.
    try:
        from .unified_event_service import publish
        publish(
            'messages', mid, title or 'پیام مدرسه',
            {'text': text, 'receiver': token, 'sender': sender or 'سیستم فراهوش'},
            target_type, target_value, sender or '', audiences=audiences
        )
    except Exception:
        # The legacy messages table remains authoritative if the event hub
        # cannot initialize on an old database.
        pass
    return mid

def _token(t,v):
    t=(t or 'school').strip().lower(); v=str(v or 'all').strip()
    return {'school':'school:all','role':f'role:{v}','class':f'class:{v}','student':f'student:{v}','group':f'group:{v}','parent':f'role:{v}'}.get(t,f'{t}:{v}')

def visible_for_student(c, student_id, username=''):
    c.execute('SELECT student_code,national_code,class_name,grade FROM students WHERE id=?',(student_id,)); r=c.fetchone()
    vals=[str(x) for x in (username,student_id) if x]
    if r:
        vals += [str(x) for x in r if x]
        cls=r[2] or ''; grade=r[3] or ''
        if cls: vals += [f'class:{cls}']
        if grade and cls: vals += [f'class:{grade}:{cls}']
    vals += ['school:all','role:students','role:student','group:students']
    return list(dict.fromkeys(vals))

def visible_for_parent(c, username, student_id=None):
    vals=[username,'role:parents','role:parent','group:parents','school:all']
    sids=[]
    if student_id: sids.append(student_id)
    if username:
        try:
            sids += [r[0] for r in c.execute('SELECT student_id FROM parent_children WHERE parent_username=?',(username,)).fetchall()]
        except Exception: pass
    for sid in dict.fromkeys(sids):
        c.execute('SELECT student_code,national_code,class_name,grade FROM students WHERE id=?',(sid,)); r=c.fetchone()
        vals.append(f'student:{sid}')
        if r:
            vals += [str(x) for x in r[:2] if x]
            if r[2]: vals.append(f'class:{r[2]}')
            if r[3] and r[2]: vals.append(f'class:{r[3]}:{r[2]}')
    return list(dict.fromkeys(map(str,vals)))

def visible_for_teacher(c, teacher_id=None, username=''):
    vals=[username,'role:teachers','role:teacher','group:teachers','school:all']
    if teacher_id:
        vals += [f'teacher:{teacher_id}']
        # teacher's classes from the canonical class tables when available
        for table,col in [('teacher_classes','teacher_id'),('executive_classes','teacher')]:
            try:
                if col=='teacher_id': rows=c.execute('SELECT class_name FROM teacher_classes WHERE teacher_id=?',(teacher_id,)).fetchall()
                else: rows=c.execute('SELECT name FROM executive_classes WHERE teacher=?',(str(teacher_id),)).fetchall()
                for r in rows:
                    if r[0]: vals.append(f'class:{r[0]}')
            except Exception: pass
    return list(dict.fromkeys(map(str,vals)))


def message_delivery_status(message_id):
    ensure_tables()
    c=_conn()
    try:
        rows=c.execute("SELECT username,received_at,seen_at FROM message_delivery WHERE message_id=? ORDER BY username",(message_id,)).fetchall()
        return [{'username':r[0],'status':'دیده شد' if r[2] else ('دریافت شد' if r[1] else 'در انتظار دریافت'),'received_at':r[1],'seen_at':r[2]} for r in rows]
    finally: c.close()

def mark_message_received(username,message_id):
    ensure_tables(); c=_conn()
    try:
        c.execute("INSERT OR IGNORE INTO message_delivery(message_id,username,received_at) VALUES(?,?,?)",(message_id,username,datetime.now().isoformat(timespec='seconds')))
        c.execute("UPDATE message_delivery SET received_at=COALESCE(NULLIF(received_at,''),?) WHERE message_id=? AND username=?",(datetime.now().isoformat(timespec='seconds'),message_id,username)); c.commit()
    finally: c.close()

def mark_message_seen(username,message_id):
    ensure_tables(); c=_conn()
    try:
        stamp=datetime.now().isoformat(timespec='seconds')
        c.execute("INSERT OR IGNORE INTO message_delivery(message_id,username,received_at,seen_at) VALUES(?,?,?,?)",(message_id,username,stamp,stamp))
        c.execute("UPDATE message_delivery SET received_at=COALESCE(NULLIF(received_at,''),?), seen_at=? WHERE message_id=? AND username=?",(stamp,stamp,message_id,username)); c.commit()
    finally: c.close()
