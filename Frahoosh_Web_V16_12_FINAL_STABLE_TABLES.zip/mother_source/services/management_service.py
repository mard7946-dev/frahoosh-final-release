from __future__ import annotations

import csv
import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any
from services.core_bootstrap import bootstrap

DB_PATH = Path(__file__).resolve().parents[1] / "school.db"


class ManagementService:
    DB_PATH = DB_PATH
    """Persistent data service for the school management panel."""

    ROLES = ("مدیر", "معاون آموزشی", "معاون پرورشی", "اجرایی", "دبیر", "مشاور", "والد", "دانش‌آموز")

    @staticmethod
    def connect() -> sqlite3.Connection:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    @staticmethod
    def _ensure_schema(conn: sqlite3.Connection) -> None:
        statements = [
            """CREATE TABLE IF NOT EXISTS school_settings (
                key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS school_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT, request_type TEXT NOT NULL,
                requester TEXT NOT NULL, role TEXT NOT NULL DEFAULT '', description TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'در انتظار', created_at TEXT NOT NULL, updated_at TEXT
            )""",
            """CREATE TABLE IF NOT EXISTS weekly_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT, teacher TEXT NOT NULL, hours REAL NOT NULL DEFAULT 0,
                grade TEXT NOT NULL DEFAULT '', class_count INTEGER NOT NULL DEFAULT 1, subject TEXT NOT NULL,
                bell_pattern TEXT NOT NULL, class_names TEXT DEFAULT '', created_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS generated_weekly_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT, source_id INTEGER, teacher TEXT NOT NULL, subject TEXT NOT NULL,
                grade TEXT NOT NULL DEFAULT '', class_name TEXT DEFAULT '', weekday TEXT NOT NULL, bell TEXT NOT NULL,
                week_index INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS exam_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, grade TEXT NOT NULL,
                start_date TEXT NOT NULL, end_date TEXT NOT NULL, weight TEXT NOT NULL DEFAULT 'متوسط',
                exam_date TEXT NOT NULL, duration INTEGER NOT NULL DEFAULT 45, exam_start_time TEXT NOT NULL DEFAULT '13:10', exam_end_time TEXT NOT NULL DEFAULT '13:55', created_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS competitions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
                start_date TEXT NOT NULL, end_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'فعال',
                description TEXT DEFAULT '', created_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS virtual_server_config (
                id INTEGER PRIMARY KEY CHECK(id=1), server_url TEXT NOT NULL DEFAULT '',
                api_key TEXT NOT NULL DEFAULT '', capacity INTEGER NOT NULL DEFAULT 700,
                enabled INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
            )""",
        ]
        for statement in statements:
            conn.execute(statement)
        # Safe migrations for databases created by earlier Frahoosh versions.
        cols = {r[1] for r in conn.execute("PRAGMA table_info(exam_schedule)").fetchall()}
        if "exam_start_time" not in cols:
            conn.execute("ALTER TABLE exam_schedule ADD COLUMN exam_start_time TEXT NOT NULL DEFAULT '13:10'")
        if "exam_end_time" not in cols:
            conn.execute("ALTER TABLE exam_schedule ADD COLUMN exam_end_time TEXT NOT NULL DEFAULT '13:55'")
        conn.commit()

    @classmethod
    def initialize(cls) -> None:
        bootstrap()
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            # Keep the existing manager login stable and remove duplicate manager rows.
            rows = conn.execute("SELECT id,username,password FROM users WHERE role='manager' ORDER BY id").fetchall()
            if rows:
                keep = rows[0][0]
                conn.execute("DELETE FROM users WHERE role='manager' AND id<>?", (keep,))
                # Preserve the established manager credentials (admin/1234 in the desktop build).
                username = rows[0][1] or "admin"
                password = rows[0][2] or "1234"
                conflict = conn.execute("SELECT id FROM users WHERE username=? AND id<>?", (username, keep)).fetchone()
                if conflict: conn.execute("DELETE FROM users WHERE id=?", (conflict[0],))
                conn.execute("UPDATE users SET username=?,password=?,role='manager',permissions='all' WHERE id=?", (username,password,keep))
            else:
                conn.execute("INSERT OR IGNORE INTO users(username,password,role,permissions) VALUES(?,?,?,?)", ("admin","1234","manager","all"))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @classmethod
    def stats(cls) -> dict[str, int]:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            return {
                "students": conn.execute("SELECT COUNT(*) FROM students").fetchone()[0],
                "teachers": conn.execute("SELECT COUNT(*) FROM teachers").fetchone()[0],
                "classes": conn.execute("SELECT COUNT(*) FROM online_classes").fetchone()[0],
                "live_classes": conn.execute("SELECT COUNT(*) FROM online_classes WHERE status='live'").fetchone()[0],
                "pending_requests": conn.execute("SELECT COUNT(*) FROM school_requests WHERE status='در انتظار'").fetchone()[0],
                "announcements": conn.execute("SELECT COUNT(*) FROM smart_board_messages").fetchone()[0],
            }
        finally:
            conn.close()

    @classmethod
    def users(cls):
        conn = cls.connect()
        try:
            return conn.execute(
                "SELECT id,username,role,permissions FROM users ORDER BY id DESC"
            ).fetchall()
        finally:
            conn.close()

    @classmethod
    def create_user(cls, username: str, role: str, password: str = "", permissions: str = "") -> int:
        username = username.strip()
        if not username:
            raise ValueError("نام کاربری الزامی است")
        if not password:
            password = "1234"
        if not permissions:
            permissions = "all" if role in ("مدیر", "manager") else role
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            existing = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            if existing:
                raise ValueError("این نام کاربری قبلاً ثبت شده است")
            cur = conn.execute(
                "INSERT INTO users(username,password,role,permissions) VALUES(?,?,?,?)",
                (username, password, role, permissions),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    @classmethod
    def delete_user(cls, user_id: int) -> None:
        conn = cls.connect()
        try:
            row = conn.execute("SELECT username,role FROM users WHERE id=?", (user_id,)).fetchone()
            if not row:
                return
            if row[0] == "0053409531" or row[1] == "manager":
                raise ValueError("کاربر اصلی مدیر قابل حذف نیست")
            conn.execute("DELETE FROM users WHERE id=?", (user_id,))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def set_password(cls, user_id: int, password: str) -> None:
        if not password:
            raise ValueError("رمز عبور نمی‌تواند خالی باشد")
        conn = cls.connect()
        try:
            conn.execute("UPDATE users SET password=? WHERE id=?", (password, user_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def generated_password(first_name: str, national_code: str) -> str:
        first = (first_name or "").strip()
        code = "".join(ch for ch in (national_code or "") if ch.isdigit())
        if not first or not code:
            raise ValueError("نام و کد ملی برای تولید رمز لازم است")
        return first[0].lower() + code

    @classmethod
    def ensure_person_login(cls, first_name: str, national_code: str, role: str) -> tuple[str, str]:
        password = cls.generated_password(first_name, national_code)
        username = "".join(ch for ch in national_code if ch.isdigit())
        if len(username) < 8:
            raise ValueError("کد ملی معتبر نیست")
        conn = cls.connect()
        try:
            row = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            if row:
                user_id = int(row[0])
                conn.execute("UPDATE users SET password=?,role=? WHERE id=?", (password, role, user_id))
            else:
                cur = conn.execute("INSERT INTO users(username,password,role,permissions) VALUES(?,?,?,?)",
                                   (username, password, role, role))
                user_id = int(cur.lastrowid)
            # Keep student/teacher accounts linked to their source record.
            if role in ("student", "دانش‌آموز", "دانش آموز", "دبیر", "teacher", "معلم"):
                if role in ("student", "دانش‌آموز", "دانش آموز"):
                    conn.execute("UPDATE users SET linked_student_id=(SELECT id FROM students WHERE national_code=? OR student_code=? LIMIT 1) WHERE id=?", (national_code, national_code, user_id))
                else:
                    conn.execute("UPDATE users SET linked_teacher_id=(SELECT id FROM teachers WHERE national_code=? OR phone=? LIMIT 1) WHERE id=?", (national_code, national_code, user_id))
            conn.commit()
        finally:
            conn.close()
        return username, password

    @classmethod
    def announcements(cls):
        conn = cls.connect()
        try:
            return conn.execute(
                "SELECT id,title,message,priority,publish_date,created_by FROM smart_board_messages ORDER BY id DESC"
            ).fetchall()
        finally:
            conn.close()

    @classmethod
    def add_announcement(cls, title: str, message: str, priority: str, created_by: str) -> int:
        if not title.strip() or not message.strip():
            raise ValueError("عنوان و متن اطلاعیه الزامی است")
        conn = cls.connect()
        try:
            cur = conn.execute(
                "INSERT INTO smart_board_messages(title,message,priority,publish_date,created_by) VALUES(?,?,?,?,?)",
                (title.strip(), message.strip(), priority, datetime.now().strftime("%Y-%m-%d"), created_by or "مدیریت"),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    @classmethod
    def delete_announcement(cls, item_id: int) -> None:
        conn = cls.connect()
        try:
            conn.execute("DELETE FROM smart_board_messages WHERE id=?", (item_id,))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def weekly_entries(cls):
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            return conn.execute("SELECT id,teacher,hours,grade,class_count,subject,bell_pattern,class_names FROM weekly_schedule ORDER BY id DESC").fetchall()
        finally:
            conn.close()

    @classmethod
    def add_weekly_entry(cls, teacher: str, hours: float, grade: str, class_count: int, subject: str, pattern: str, class_names: str) -> int:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            cur = conn.execute(
                "INSERT INTO weekly_schedule(teacher,hours,grade,class_count,subject,bell_pattern,class_names,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (teacher.strip(), float(hours), grade.strip(), int(class_count), subject.strip(), pattern.strip(), class_names.strip(), cls._now()),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    @classmethod
    def delete_weekly_entry(cls, item_id: int) -> None:
        conn = cls.connect()
        try:
            conn.execute("DELETE FROM weekly_schedule WHERE id=?", (item_id,))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def generate_weekly_schedule(cls) -> int:
        """Generate a compact weekly schedule from the manager's entered teacher data."""
        days = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه"]
        bells = ["زنگ اول", "زنگ دوم", "زنگ سوم", "زنگ چهارم", "زنگ پنجم", "زنگ ششم"]
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            rows = conn.execute("SELECT id,teacher,hours,grade,class_count,subject,bell_pattern,class_names FROM weekly_schedule ORDER BY id").fetchall()
            conn.execute("DELETE FROM generated_weekly_schedule")
            created = 0
            cursor = 0
            for source_id, teacher, hours, grade, class_count, subject, pattern, class_names in rows:
                names = [x.strip() for x in (class_names or '').replace('،', ',').split(',') if x.strip()]
                if not names:
                    names = ['']
                try:
                    target = max(1, int(round(float(hours))))
                except Exception:
                    target = 1
                if 'دو زنگ' in pattern:
                    target = max(target, 2)
                elif 'یکی در میان' in pattern:
                    target = max(target, 2)
                for n in range(target):
                    day = days[(cursor + n) % len(days)]
                    bell = bells[(cursor + n) % len(bells)]
                    cname = names[n % len(names)]
                    conn.execute("INSERT INTO generated_weekly_schedule(source_id,teacher,subject,grade,class_name,weekday,bell,week_index,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                                 (source_id, teacher, subject, grade, cname, day, bell, (n // len(days)) + 1, cls._now()))
                    # Canonical teacher/class link: management is the source of truth.
                    conn.execute("CREATE TABLE IF NOT EXISTS teacher_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,subject TEXT,grade TEXT,class_name TEXT,active INTEGER DEFAULT 1,created_at TEXT)")
                    tr = conn.execute("SELECT id FROM teachers WHERE trim(first_name||' '||last_name)=? LIMIT 1", (teacher.strip(),)).fetchone()
                    tid = tr[0] if tr else None
                    if cname:
                        exists = conn.execute("SELECT id FROM teacher_classes WHERE teacher_name=? AND COALESCE(subject,'')=? AND COALESCE(grade,'')=? AND class_name=? LIMIT 1", (teacher,subject,grade,cname)).fetchone()
                        if not exists:
                            conn.execute("INSERT INTO teacher_classes(teacher_id,teacher_name,subject,grade,class_name,active,created_at) VALUES(?,?,?,?,?,?,?)", (tid,teacher,subject,grade,cname,1,cls._now()))
                    created += 1
                cursor += 1
            conn.commit()
            return created
        finally:
            conn.close()

    @classmethod
    def generated_weekly_entries(cls):
        conn=cls.connect()
        try:
            cls._ensure_schema(conn)
            return conn.execute("SELECT teacher,subject,grade,class_name,weekday,bell,week_index FROM generated_weekly_schedule ORDER BY weekday,bell,teacher").fetchall()
        finally:
            conn.close()

    @classmethod
    def exam_entries(cls):
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            return conn.execute(
                "SELECT id,subject,grade,start_date,end_date,weight,exam_date,duration,exam_start_time,exam_end_time "
                "FROM exam_schedule ORDER BY exam_date ASC, exam_start_time ASC, id ASC"
            ).fetchall()
        finally:
            conn.close()

    @staticmethod
    def _duration_for_weight(weight: str) -> int:
        return {"ساده": 30, "متوسط": 45, "سخت": 60}.get(weight, 45)

    @staticmethod
    def _minutes(hhmm: str) -> int:
        h, m = map(int, hhmm.split(':'))
        return h * 60 + m

    @staticmethod
    def _hhmm(minutes: int) -> str:
        return f"{minutes // 60:02d}:{minutes % 60:02d}"

    @classmethod
    def _exam_slots(cls, school_start: str = "13:00", school_end: str = "17:10"):
        # Candidate starts are spread through the school day in 10-minute steps.
        # 13:10, 14:50, ... naturally emerge, while shorter exams can use later slots.
        start = cls._minutes(school_start) + 10
        end = cls._minutes(school_end)
        return list(range(start, end + 1, 10))

    @classmethod
    def add_exam(cls, subject: str, grade: str, start_date: str, end_date: str, weight: str, exam_date: str = "", duration: int | None = None) -> int:
        if not subject.strip() or not grade.strip():
            raise ValueError("درس و پایه الزامی است")
        if weight not in ("ساده", "متوسط", "سخت"):
            raise ValueError("سطح آزمون باید ساده، متوسط یا سخت باشد")
        duration = cls._duration_for_weight(weight)
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            # The date/time are always generated by the scheduler; caller values are ignored.
            chosen_date, start_time, end_time = cls._find_exam_slot(conn, start_date, end_date, weight, grade, duration)
            cur = conn.execute(
                "INSERT INTO exam_schedule(subject,grade,start_date,end_date,weight,exam_date,duration,exam_start_time,exam_end_time,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (subject.strip(), grade.strip(), start_date.strip(), end_date.strip(), weight, chosen_date, duration, start_time, end_time, cls._now()),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    @classmethod
    def _find_exam_slot(cls, conn, start_date: str, end_date: str, weight: str, grade: str, duration: int):
        from datetime import date, timedelta
        start = date.fromisoformat(start_date); end = date.fromisoformat(end_date)
        if end < start:
            raise ValueError("بازه زمانی نامعتبر است")
        existing = conn.execute("SELECT exam_date,exam_start_time,exam_end_time,grade FROM exam_schedule").fetchall()
        occupied = {(r[0], r[1], r[2]) for r in existing}
        # Prefer balanced days and varied start times.
        day_index = 0
        d = start
        while d <= end:
            ds = d.isoformat()
            slots = cls._exam_slots()
            # Rotate starts by day so exams are not always at the same hour.
            rotation = (day_index * 10) % len(slots) if slots else 0
            slots = slots[rotation:] + slots[:rotation]
            for sm in slots:
                em = sm + duration
                if em > cls._minutes("17:10"):
                    continue
                st, et = cls._hhmm(sm), cls._hhmm(em)
                if (ds, st, et) in occupied:
                    continue
                # Avoid overlapping exams for the same grade.
                conflict = False
                for ed, es, ee, eg in existing:
                    if ed != ds or eg != grade:
                        continue
                    a, b = cls._minutes(es), cls._minutes(ee)
                    if sm < b and em > a:
                        conflict = True; break
                if not conflict:
                    return ds, st, et
            d += timedelta(days=1); day_index += 1
        raise ValueError("در این بازه زمانی فضای کافی برای زمان‌بندی این امتحان وجود ندارد")

    @classmethod
    def delete_exam(cls, item_id: int) -> None:
        conn = cls.connect()
        try:
            conn.execute("DELETE FROM exam_schedule WHERE id=?", (item_id,))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def suggest_exam_date(cls, start_date: str, end_date: str, weight: str, grade: str = "") -> str:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            duration = cls._duration_for_weight(weight)
            chosen, _, _ = cls._find_exam_slot(conn, start_date, end_date, weight, grade, duration)
            return chosen
        finally:
            conn.close()

    @classmethod
    def auto_schedule_exams(cls) -> int:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            rows = conn.execute(
                "SELECT id,start_date,end_date,weight,grade FROM exam_schedule "
                "ORDER BY CASE weight WHEN 'سخت' THEN 0 WHEN 'متوسط' THEN 1 ELSE 2 END,id"
            ).fetchall()
            conn.execute("UPDATE exam_schedule SET exam_date='',exam_start_time='',exam_end_time=''")
            scheduled = 0
            for item_id, start_s, end_s, weight, grade in rows:
                duration = cls._duration_for_weight(weight)
                chosen, st, et = cls._find_exam_slot(conn, start_s, end_s, weight, grade, duration)
                conn.execute("UPDATE exam_schedule SET exam_date=?,duration=?,exam_start_time=?,exam_end_time=? WHERE id=?", (chosen,duration,st,et,item_id))
                scheduled += 1
            conn.commit(); return scheduled
        finally:
            conn.close()

    @classmethod
    def school_exam_timetable(cls, exam_start: str, exam_duration: int):
        """Return the remaining school-day teaching blocks after an exam.
        Defaults: 13:00-17:10, three 70-minute lessons, two 15-minute breaks.
        """
        school_start, school_end = 13*60, 17*60+10
        start = cls._minutes(exam_start); end = start + int(exam_duration)
        if start < school_start or end > school_end:
            raise ValueError("زمان امتحان خارج از ساعت مدرسه است")
        blocks=[]; cursor=school_start
        if cursor < start: blocks.append((cls._hhmm(cursor), cls._hhmm(start), "زمان قبل از امتحان"))
        cursor=end
        lesson=1; breaks=0
        while cursor < school_end and lesson <= 3:
            lesson_end=min(cursor+70, school_end)
            blocks.append((cls._hhmm(cursor), cls._hhmm(lesson_end), f"زنگ آموزشی {lesson}"))
            cursor=lesson_end; lesson += 1
            if cursor < school_end and lesson <= 3:
                br_end=min(cursor+15, school_end)
                blocks.append((cls._hhmm(cursor), cls._hhmm(br_end), f"زنگ تفریح {breaks+1}")); cursor=br_end; breaks += 1
        return blocks

    @classmethod
    def competitions(cls):
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            return conn.execute("SELECT id,title,category,start_date,end_date,status,description FROM competitions ORDER BY id DESC").fetchall()
        finally:
            conn.close()

    @classmethod
    def add_competition(cls, title: str, category: str, start_date: str, end_date: str, description: str) -> int:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            cur = conn.execute(
                "INSERT INTO competitions(title,category,start_date,end_date,description,created_at) VALUES(?,?,?,?,?,?)",
                (title.strip(), category.strip(), start_date.strip(), end_date.strip(), description.strip(), cls._now()),
            )
            # Publish manager-created competitions to the same activity source
            # consumed by the student/parent panels.
            conn.execute("CREATE TABLE IF NOT EXISTS cultural_items(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,student_name TEXT DEFAULT '',details TEXT DEFAULT '',fee INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            conn.execute("INSERT INTO cultural_items(kind,title,details,fee,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                         ('competition', title.strip(), description.strip(), 0, 'active', cls._now(), cls._now()))
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()

    @classmethod
    def delete_competition(cls, item_id: int) -> None:
        conn = cls.connect()
        try:
            conn.execute("DELETE FROM competitions WHERE id=?", (item_id,))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def save_setting(cls, key: str, value: str) -> None:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            conn.execute("INSERT INTO school_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", (key, value, cls._now()))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def get_setting(cls, key: str, default: str = "") -> str:
        conn = cls.connect()
        try:
            row = conn.execute("SELECT value FROM school_settings WHERE key=?", (key,)).fetchone()
            return row[0] if row else default
        finally:
            conn.close()

    @classmethod
    def save_virtual_server(cls, url: str, api_key: str, capacity: int, enabled: bool) -> None:
        if capacity < 1 or capacity > 700:
            raise ValueError("ظرفیت باید بین ۱ تا ۷۰۰ باشد")
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            conn.execute("INSERT INTO virtual_server_config(id,server_url,api_key,capacity,enabled,updated_at) VALUES(1,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET server_url=excluded.server_url,api_key=excluded.api_key,capacity=excluded.capacity,enabled=excluded.enabled,updated_at=excluded.updated_at", (url.strip(), api_key.strip(), int(capacity), int(enabled), cls._now()))
            conn.commit()
        finally:
            conn.close()

    @classmethod
    def virtual_server(cls) -> tuple[str, str, int, bool]:
        conn = cls.connect()
        try:
            cls._ensure_schema(conn)
            row = conn.execute("SELECT server_url,api_key,capacity,enabled FROM virtual_server_config WHERE id=1").fetchone()
            return (row[0], row[1], int(row[2]), bool(row[3])) if row else ("", "", 700, False)
        finally:
            conn.close()
