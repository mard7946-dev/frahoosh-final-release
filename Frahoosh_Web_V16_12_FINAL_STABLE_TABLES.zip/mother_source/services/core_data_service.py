"""Central cross-panel data helpers for Frahoosh v15.8."""
import sqlite3
from pathlib import Path
from utils.jalali import iso_to_jalali

DB = Path(__file__).resolve().parents[1] / 'school.db'

def connect():
    c = sqlite3.connect(DB, timeout=30.0)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA foreign_keys=ON')
    return c

def ensure():
    with connect() as c:
        c.execute("CREATE TABLE IF NOT EXISTS cultural_items(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,student_name TEXT DEFAULT '',details TEXT DEFAULT '',fee INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'active',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cultural_kind_status ON cultural_items(kind,status)")
        c.execute("CREATE TABLE IF NOT EXISTS student_registrations(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,activity_id INTEGER NOT NULL,activity_title TEXT NOT NULL,activity_kind TEXT NOT NULL,fee INTEGER NOT NULL DEFAULT 0,payment_status TEXT NOT NULL DEFAULT 'pending',payment_url TEXT DEFAULT '',payment_reference TEXT DEFAULT '',registration_code TEXT NOT NULL UNIQUE,registered_at TEXT NOT NULL)")

def resolve_student(username=None, student_id=None):
    ensure()
    with connect() as c:
        if student_id:
            r=c.execute('SELECT * FROM students WHERE id=?',(int(student_id),)).fetchone()
            return dict(r) if r else None
        if not username: return None
        u=str(username).strip()
        user=c.execute('SELECT * FROM users WHERE username=? LIMIT 1',(u,)).fetchone()
        if user:
            sid=user['linked_student_id'] if 'linked_student_id' in user.keys() else None
            if sid:
                r=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
                if r:return dict(r)
        digits=''.join(ch for ch in u if ch.isdigit())
        r=c.execute('SELECT * FROM students WHERE national_code IN (?,?) OR student_code IN (?,?) LIMIT 1',(u,digits,u,digits)).fetchone()
        if r and user:
            try:c.execute('UPDATE users SET linked_student_id=? WHERE id=?',(r['id'],user['id']))
            except sqlite3.OperationalError: pass
            c.commit()
        return dict(r) if r else None

def student_id(username=None, student_id_value=None):
    r=resolve_student(username, student_id_value); return r['id'] if r else None

def jalali(value): return iso_to_jalali(value)
