"""Optional cloud sync bridge for Frahoosh.

The local SQLite database remains authoritative/offline-first. When Supabase
credentials are configured, school events are pushed to the cloud and inboxes
pull events addressed to the current account.
"""
from __future__ import annotations
import json, os, urllib.parse, urllib.request, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_FILE = ROOT / "server_config.json"


def _config():
    data = {}
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    return {
        "url": (os.getenv("FRAHOOSH_SUPABASE_URL") or data.get("url") or "").rstrip("/"),
        "key": os.getenv("FRAHOOSH_SUPABASE_PUBLISHABLE_KEY") or os.getenv("FRAHOOSH_SUPABASE_ANON_KEY") or data.get("publishable_key") or data.get("anon_key") or "",
        "school_id": os.getenv("FRAHOOSH_SCHOOL_ID") or data.get("school_id") or "frahoosh-school",
        "school_token": os.getenv("FRAHOOSH_SCHOOL_TOKEN") or data.get("school_token") or "",
        "timeout": int(os.getenv("FRAHOOSH_SYNC_TIMEOUT", data.get("timeout", 8))),
    }


def configured():
    c = _config()
    return bool(c["url"] and c["key"] and c["school_token"])


def status():
    c = _config()
    return {"configured": configured(), "url": c["url"], "school_id": c["school_id"]}


def _request(method, path, payload=None, query=None):
    c = _config()
    if not configured():
        return None
    url = c["url"] + "/rest/v1/" + path
    if query:
        url += "?" + urllib.parse.urlencode(query, doseq=True)
    headers = {
        "apikey": c["key"],
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-School-Token": c["school_token"],
        "Prefer": "resolution=merge-duplicates",
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=c["timeout"]) as res:
        raw = res.read().decode("utf-8")
        return json.loads(raw) if raw else []


def push_event(event, recipients):
    if not configured():
        return False
    c = _config()
    row = {
        "school_id": c["school_id"],
        "school_token_hash": hashlib.sha256(c["school_token"].encode("utf-8")).hexdigest(),
        "local_event_id": int(event["id"]),
        "source_table": event.get("source_table", ""),
        "source_id": event.get("source_id"),
        "event_type": event.get("event_type", ""),
        "title": event.get("title", ""),
        "payload": json.loads(event.get("payload") or "{}") if isinstance(event.get("payload"), str) else (event.get("payload") or {}),
        "actor_username": event.get("actor_username", ""),
        "created_at": event.get("created_at"),
        "audience_type": event.get("audience_type", ""),
        "audience_value": event.get("audience_value", ""),
        "recipient_usernames": list(dict.fromkeys(str(x) for x in recipients if x)),
    }
    _request("POST", "frahoosh_events", [row], query={"on_conflict": "school_id,local_event_id"})
    return True


def push_pending(username=None, limit=200):
    if not configured():
        return 0
    from .unified_event_service import conn, recipients_for_event
    count = 0
    with conn() as db:
        rows = db.execute("SELECT * FROM school_events WHERE COALESCE(remote_synced,0)=0 ORDER BY id LIMIT ?", (limit,)).fetchall()
        for event in rows:
            rec = recipients_for_event(db, event)
            if username and username not in rec:
                continue
            try:
                push_event(dict(event), rec)
                db.execute("UPDATE school_events SET remote_synced=1 WHERE id=?", (event["id"],))
                count += 1
            except Exception:
                # Offline-first: failed cloud sync never blocks local school use.
                continue
        db.commit()
    return count


def pull_for_user(username, limit=200):
    if not configured() or not username:
        return 0
    c = _config()
    from .unified_event_service import conn, ensure_schema, _materialize_receipts
    ensure_schema()
    query = {
        "school_id": "eq." + c["school_id"],
        "recipient_usernames": "cs.{" + str(username).replace("}", "") + "}",
        "order": "id.desc",
        "limit": str(limit),
    }
    try:
        rows = _request("GET", "frahoosh_events", query=query) or []
    except Exception:
        return 0
    added = 0
    with conn() as db:
        for r in rows:
            remote_id = r.get("id")
            exists = db.execute("SELECT id FROM school_events WHERE remote_id=?", (remote_id,)).fetchone()
            if exists:
                continue
            payload = json.dumps(r.get("payload") or {}, ensure_ascii=False)
            cur = db.execute("""INSERT INTO school_events
                (source_table,source_id,event_type,title,payload,actor_username,created_at,audience_type,audience_value,remote_id,remote_synced)
                VALUES(?,?,?,?,?,?,?,?,?,?,1)""",
                (r.get("source_table",""), r.get("source_id"), r.get("event_type",""), r.get("title",""), payload,
                 r.get("actor_username",""), r.get("created_at") or "", r.get("audience_type",""), r.get("audience_value",""), remote_id, 1))
            eid = cur.lastrowid
            db.execute("INSERT OR IGNORE INTO event_receipts(event_id,username,received_at) VALUES(?,?,CURRENT_TIMESTAMP)", (eid, username))
            added += 1
        db.commit()
    return added


def sync_user(username):
    """Push local events then pull events for one account."""
    pushed = push_pending(username=username)
    pulled = pull_for_user(username)
    return {"pushed": pushed, "pulled": pulled, "configured": configured()}
