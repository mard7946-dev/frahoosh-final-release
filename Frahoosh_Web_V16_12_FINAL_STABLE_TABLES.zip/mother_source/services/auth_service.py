import sqlite3
from pathlib import Path
from services.data_link_service import ensure_schema, resolve

DB_NAME = Path(__file__).resolve().parents[1] / "school.db"

class AuthService:
    @staticmethod
    def login(username, password):
        ensure_schema()
        conn = sqlite3.connect(DB_NAME)
        try:
            row = conn.execute("SELECT id,username,role,permissions FROM users WHERE username=? AND password=? LIMIT 1", (username.strip(), password)).fetchone()
            if not row:
                return None
            user = resolve(row[1]) or {"id": row[0], "username": row[1], "role": row[2], "permissions": row[3] or ""}
            user.update({"id": row[0], "username": row[1], "full_name": user.get("display_name") or row[1], "role": row[2], "permissions": row[3] or ""})
            return user
        finally:
            conn.close()


    @staticmethod
    def change_password(username, old_password, new_password):
        conn=sqlite3.connect(DB_NAME)
        try:
            row=conn.execute("SELECT id FROM users WHERE username=? AND password=?",(username.strip(),old_password)).fetchone()
            if not row:return False
            conn.execute("UPDATE users SET password=? WHERE id=?",(new_password,row[0])); conn.commit(); return True
        finally: conn.close()


    @staticmethod
    def admin_reset_password(admin_username, admin_password, username, new_password):
        """Admin-authorized password reset; never resets without authenticating admin."""
        if not all(str(x or '').strip() for x in (admin_username, admin_password, username, new_password)) or len(str(new_password)) < 4:
            return False
        conn=sqlite3.connect(DB_NAME)
        try:
            admin=conn.execute("SELECT role FROM users WHERE username=? AND password=? LIMIT 1",(admin_username.strip(),admin_password)).fetchone()
            if not admin or admin[0] not in ('manager','admin'):
                return False
            cur=conn.execute("UPDATE users SET password=? WHERE username=?",(new_password,username.strip()))
            conn.commit(); return cur.rowcount > 0
        finally:
            conn.close()
