"""Central identity/data linkage for Frahoosh panels.

All panels use the same school.db and resolve their authenticated identity
through the users table. This keeps student/teacher/parent records linked
without duplicating core data in individual panels.
"""
from pathlib import Path
import sqlite3

DB_PATH = Path(__file__).resolve().parents[1] / "school.db"


def connection():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def ensure_schema():
    with connection() as c:
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()}
        additions = {
            "linked_student_id": "INTEGER",
            "linked_teacher_id": "INTEGER",
            "linked_staff_id": "INTEGER",
            "display_name": "TEXT DEFAULT ''",
        }
        for name, typ in additions.items():
            if name not in cols:
                c.execute(f"ALTER TABLE users ADD COLUMN {name} {typ}")
        c.execute("CREATE INDEX IF NOT EXISTS idx_users_student ON users(linked_student_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_users_teacher ON users(linked_teacher_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_users_staff ON users(linked_staff_id)")


def resolve(username):
    """Return authenticated user plus the linked domain record."""
    ensure_schema()
    with connection() as c:
        user = c.execute("SELECT * FROM users WHERE username=? LIMIT 1", (str(username).strip(),)).fetchone()
        if not user:
            return None
        data = dict(user)
        role = (data.get("role") or "").lower()
        if role in {"student", "دانش‌آموز", "دانش آموز"}:
            sid = data.get("linked_student_id")
            if not sid:
                username = str(data.get("username") or "").strip()
                digits = "".join(ch for ch in username if ch.isdigit())
                sid_row = c.execute(
                    "SELECT id FROM students WHERE student_code=? OR national_code=? OR student_code=? OR national_code=? LIMIT 1",
                    (username, username, digits, digits),
                ).fetchone()
                sid = sid_row[0] if sid_row else None
            # If the account was created from the student record but the link
            # column was not populated, repair the link automatically.
            if sid and not data.get("linked_student_id"):
                c.execute("UPDATE users SET linked_student_id=? WHERE id=?", (sid, data["id"]))
                data["linked_student_id"] = sid
            data["student_id"] = sid
            if sid:
                row = c.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
                data["student"] = dict(row) if row else None
        elif role in {"teacher", "دبیر", "معلم"}:
            tid = data.get("linked_teacher_id")
            if not tid:
                row = c.execute("SELECT id FROM teachers WHERE national_code=? OR phone=? LIMIT 1", (data["username"], data["username"])).fetchone()
                tid = row[0] if row else None
            data["teacher_id"] = tid
            if tid:
                row = c.execute("SELECT * FROM teachers WHERE id=?", (tid,)).fetchone()
                data["teacher"] = dict(row) if row else None
        elif role in {"staff", "کارمند", "معاون", "executive", "manager"}:
            sid = data.get("linked_staff_id")
            if sid:
                row = c.execute("SELECT * FROM staff WHERE id=?", (sid,)).fetchone()
                data["staff"] = dict(row) if row else None
        return data


def link_student_user(user_id, student_id):
    ensure_schema()
    with connection() as c:
        c.execute("UPDATE users SET linked_student_id=? WHERE id=?", (student_id, user_id))
        c.commit()


def link_teacher_user(user_id, teacher_id):
    ensure_schema()
    with connection() as c:
        c.execute("UPDATE users SET linked_teacher_id=? WHERE id=?", (teacher_id, user_id))
        c.commit()


def link_parent_child(parent_username, student_id):
    ensure_schema()
    with connection() as c:
        c.execute("CREATE TABLE IF NOT EXISTS parent_children(parent_username TEXT NOT NULL, student_id INTEGER NOT NULL, PRIMARY KEY(parent_username,student_id))")
        c.execute("INSERT OR IGNORE INTO parent_children(parent_username,student_id) VALUES(?,?)", (str(parent_username).strip(), int(student_id)))
        c.commit()


def student_for_username(username):
    data = resolve(username)
    return data.get("student_id") if data else None


def teacher_for_username(username):
    data = resolve(username)
    return data.get("teacher_id") if data else None
