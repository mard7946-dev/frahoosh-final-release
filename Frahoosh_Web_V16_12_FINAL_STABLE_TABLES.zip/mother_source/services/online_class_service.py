import os
import sqlite3
import random
from datetime import datetime, timedelta
from utils.jalali import iso_to_jalali

from database.db import DATABASE_NAME


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _shamsi_now():
    return iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))


def _dt(value):
    try:
        return datetime.fromisoformat(str(value))
    except Exception:
        return datetime.now()


class OnlineClassService:
    @staticmethod
    def get_connection():
        c = sqlite3.connect(DATABASE_NAME)
        c.row_factory = sqlite3.Row
        return c

    @staticmethod
    def ensure_schema():
        c = OnlineClassService.get_connection()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS online_class_sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL,
            started_at TEXT NOT NULL, ended_at TEXT DEFAULT '', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS online_presence_checks(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL, session_id INTEGER,
            student_id INTEGER NOT NULL, checkpoint_no INTEGER NOT NULL, scheduled_at TEXT NOT NULL,
            shown_at TEXT DEFAULT '', responded_at TEXT DEFAULT '', response TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL, UNIQUE(class_id,session_id,student_id,checkpoint_no));
        CREATE TABLE IF NOT EXISTS online_class_activity(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL, session_id INTEGER,
            student_id INTEGER NOT NULL, event_type TEXT NOT NULL, event_time TEXT NOT NULL, metadata TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS online_class_ai_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL, student_id INTEGER,
            session_id INTEGER, report TEXT NOT NULL, risk_level TEXT NOT NULL DEFAULT 'normal', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS online_class_notifications(
            id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER NOT NULL, student_id INTEGER NOT NULL,
            recipient TEXT NOT NULL, recipient_role TEXT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL,
            created_at TEXT NOT NULL, read_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS online_class_teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,teacher_id INTEGER,teacher_name TEXT DEFAULT '',UNIQUE(class_id,teacher_id));
        CREATE TABLE IF NOT EXISTS online_class_students(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,student_id INTEGER NOT NULL,student_name TEXT DEFAULT '',UNIQUE(class_id,student_id));
        CREATE TABLE IF NOT EXISTS online_class_settings(class_id INTEGER PRIMARY KEY,public_chat_enabled INTEGER DEFAULT 0,private_chat_enabled INTEGER DEFAULT 1,board_enabled INTEGER DEFAULT 1,file_share_enabled INTEGER DEFAULT 1,media_enabled INTEGER DEFAULT 1,quiz_enabled INTEGER DEFAULT 1,camera_enabled INTEGER DEFAULT 1,microphone_enabled INTEGER DEFAULT 1,screen_share_enabled INTEGER DEFAULT 1,updated_at_shamsi TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS online_class_chat(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,sender_id INTEGER,sender_role TEXT DEFAULT '',sender_name TEXT DEFAULT '',recipient_student_id INTEGER,is_private INTEGER DEFAULT 0,message TEXT NOT NULL,sent_at_shamsi TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS online_class_board_events(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,actor_id INTEGER,actor_role TEXT DEFAULT '',event_type TEXT NOT NULL,payload TEXT DEFAULT '{}',event_date_shamsi TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        c.commit(); c.close()

    @staticmethod
    def auto_close_expired():
        OnlineClassService.ensure_schema()
        now=_now(); c=OnlineClassService.get_connection()
        rows=c.execute("SELECT id,end_time FROM online_classes WHERE status IN ('approved','live') AND end_time IS NOT NULL AND end_time!=''").fetchall()
        changed=0
        for r in rows:
            try:
                if _dt(r['end_time']) <= datetime.now():
                    c.execute("UPDATE online_classes SET status='finished' WHERE id=?",(r['id'],)); c.execute("UPDATE online_class_sessions SET ended_at=? WHERE class_id=? AND ended_at=''",(now,r['id'])); changed+=1
            except Exception:
                pass
        c.commit(); c.close(); return changed

    @staticmethod
    def get_all_classes():
        c=OnlineClassService.get_connection(); rows=c.execute("SELECT id,lesson,subject,teacher,grade,class_name,start_time,end_time,status,created_at FROM online_classes ORDER BY id DESC").fetchall(); c.close(); return rows

    @staticmethod
    def get_student_classes(grade, class_name, student_id=None):
        OnlineClassService.auto_close_expired(); OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection()
        if student_id:
            rows=c.execute("""SELECT oc.id,COALESCE(NULLIF(oc.lesson,''),NULLIF(oc.subject,''),'کلاس آنلاین') title,COALESCE(NULLIF(oc.subject,''),NULLIF(oc.lesson,''),'---') subject,oc.teacher,oc.start_time_shamsi start_time,oc.end_time_shamsi end_time,oc.status FROM online_classes oc JOIN online_class_students cs ON cs.class_id=oc.id WHERE cs.student_id=? AND oc.status IN ('approved','live') ORDER BY oc.id DESC""",(student_id,)).fetchall()
        else:
            rows=c.execute("""SELECT oc.id,COALESCE(NULLIF(oc.lesson,''),NULLIF(oc.subject,''),'کلاس آنلاین') title,COALESCE(NULLIF(oc.subject,''),NULLIF(oc.lesson,''),'---') subject,oc.teacher,oc.start_time_shamsi start_time,oc.end_time_shamsi end_time,oc.status FROM online_classes oc JOIN online_class_students cs ON cs.class_id=oc.id JOIN students s ON s.id=cs.student_id WHERE s.grade=? AND s.class_name=? AND oc.status IN ('approved','live') ORDER BY oc.id DESC""",(grade,class_name)).fetchall()
        c.close(); return rows

    @staticmethod
    def get_active_classes():
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); rows=c.execute("SELECT id,lesson,subject,teacher,grade,class_name,start_time_shamsi start_time,end_time_shamsi end_time,status FROM online_classes WHERE status IN ('approved','live') ORDER BY id DESC").fetchall(); c.close(); return rows

    @staticmethod
    def get_teacher_classes(teacher, teacher_id=None):
        OnlineClassService.auto_close_expired(); OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection()
        if teacher_id:
            rows=c.execute("SELECT oc.id,oc.lesson,oc.subject,oc.teacher,oc.grade,oc.class_name,oc.start_time_shamsi start_time,oc.end_time_shamsi end_time,oc.status FROM online_classes oc JOIN online_class_teachers ct ON ct.class_id=oc.id WHERE ct.teacher_id=? ORDER BY oc.id DESC",(teacher_id,)).fetchall()
        else:
            rows=c.execute("SELECT oc.id,oc.lesson,oc.subject,oc.teacher,oc.grade,oc.class_name,oc.start_time_shamsi start_time,oc.end_time_shamsi end_time,oc.status FROM online_classes oc JOIN online_class_teachers ct ON ct.class_id=oc.id WHERE ct.teacher_name=? ORDER BY oc.id DESC",(teacher,)).fetchall()
        c.close(); return rows

    @staticmethod
    def get_teacher_active_classes(teacher, teacher_id=None):
        rows=OnlineClassService.get_teacher_classes(teacher,teacher_id); return [r for r in rows if r['status'] in ('approved','live')]

    @staticmethod
    def get_class_by_id(class_id):
        c=OnlineClassService.get_connection(); row=c.execute("SELECT * FROM online_classes WHERE id=?",(class_id,)).fetchone(); c.close(); return row

    @staticmethod
    def update_status(class_id,status):
        c=OnlineClassService.get_connection(); cur=c.execute("UPDATE online_classes SET status=? WHERE id=?",(status,class_id)); c.commit(); c.close(); return cur.rowcount>0
    @staticmethod
    def approve_class(class_id): return OnlineClassService.update_status(class_id,'approved')

    @staticmethod
    def start_class(class_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); now=_now(); c.execute("UPDATE online_classes SET status='live',start_time=COALESCE(NULLIF(start_time,''),?),start_time_shamsi=? WHERE id=?",(now,_shamsi_now(),class_id)); cur=c.execute("INSERT INTO online_class_sessions(class_id,started_at,created_at) VALUES(?,?,?)",(class_id,now,now)); sid=cur.lastrowid; c.commit(); c.close(); return sid

    @staticmethod
    def finish_class(class_id):
        OnlineClassService.ensure_schema(); now=_now(); c=OnlineClassService.get_connection(); c.execute("UPDATE online_classes SET status='finished',end_time=?,end_time_shamsi=? WHERE id=?",(now,_shamsi_now(),class_id)); c.execute("UPDATE online_class_sessions SET ended_at=? WHERE class_id=? AND ended_at=''",(now,class_id)); c.commit(); c.close(); return True
    @staticmethod
    def cancel_class(class_id): return OnlineClassService.update_status(class_id,'cancelled')
    @staticmethod
    def is_class_live(class_id):
        c=OnlineClassService.get_connection(); r=c.execute("SELECT status FROM online_classes WHERE id=?",(class_id,)).fetchone(); c.close(); return bool(r and r['status']=='live')
    @staticmethod
    def get_attendance_count(class_id):
        c=OnlineClassService.get_connection(); r=c.execute("SELECT COUNT(*) n FROM online_attendance WHERE class_id=? AND status='present'",(class_id,)).fetchone(); c.close(); return int(r['n'])

    @staticmethod
    def _active_session(c,class_id):
        r=c.execute("SELECT id,started_at FROM online_class_sessions WHERE class_id=? AND ended_at='' ORDER BY id DESC LIMIT 1",(class_id,)).fetchone()
        if r:return r
        now=_now(); cur=c.execute("INSERT INTO online_class_sessions(class_id,started_at,created_at) VALUES(?,?,?)",(class_id,now,now)); c.commit(); return c.execute("SELECT id,started_at FROM online_class_sessions WHERE id=?",(cur.lastrowid,)).fetchone()

    @staticmethod
    def _schedule_checkpoints(c,class_id,student_id,session_id,started_at,duration_minutes=60):
        base=_dt(started_at); duration=max(20,int(duration_minutes or 60));
        # دو نقطه متفاوت و تصادفی، با فاصله حداقل 5 دقیقه و قبل از پایان کلاس
        upper=max(12,duration-5); points=sorted(random.sample(range(5,upper),2)) if upper>6 else [5,min(10,duration-1)]
        for no,minute in enumerate(points,1):
            when=(base+timedelta(minutes=minute)).strftime('%Y-%m-%d %H:%M:%S')
            c.execute("INSERT OR IGNORE INTO online_presence_checks(class_id,session_id,student_id,checkpoint_no,scheduled_at,created_at) VALUES(?,?,?,?,?,?)",(class_id,session_id,student_id,no,when,_now()))

    @staticmethod
    def student_join(class_id,student_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); now=_now(); session=OnlineClassService._active_session(c,class_id); cls=c.execute("SELECT duration FROM online_classes WHERE id=?",(class_id,)).fetchone(); duration=cls['duration'] if cls else 60
        existing=c.execute("SELECT id FROM online_attendance WHERE class_id=? AND student_id=?",(class_id,student_id)).fetchone()
        if existing:c.execute("UPDATE online_attendance SET join_time=COALESCE(NULLIF(join_time,''),?),status='present',last_activity=? WHERE id=?",(now,now,existing['id']))
        else:c.execute("INSERT INTO online_attendance(class_id,student_id,join_time,status,last_activity) VALUES(?,?,?,?,?)",(class_id,student_id,now,'present',now))
        c.execute("INSERT INTO online_class_activity(class_id,session_id,student_id,event_type,event_time) VALUES(?,?,?,?,?)",(class_id,session['id'],student_id,'join',now))
        OnlineClassService._schedule_checkpoints(c,class_id,student_id,session['id'],session['started_at'],duration); c.commit(); c.close(); return True

    @staticmethod
    def student_leave(class_id,student_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); now=_now(); c.execute("UPDATE online_attendance SET leave_time=?,last_activity=? WHERE class_id=? AND student_id=?",(now,now,class_id,student_id)); r=c.execute("SELECT id FROM online_class_sessions WHERE class_id=? AND ended_at='' ORDER BY id DESC LIMIT 1",(class_id,)).fetchone(); c.execute("INSERT INTO online_class_activity(class_id,session_id,student_id,event_type,event_time) VALUES(?,?,?,?,?)",(class_id,r['id'] if r else None,student_id,'leave',now)); c.commit(); c.close(); return True

    @staticmethod
    def due_presence_check(class_id,student_id):
        OnlineClassService.ensure_schema(); now=_now(); c=OnlineClassService.get_connection(); row=c.execute("SELECT * FROM online_presence_checks WHERE class_id=? AND student_id=? AND response='pending' AND scheduled_at<=? ORDER BY checkpoint_no LIMIT 1",(class_id,student_id,now)).fetchone();
        if row:c.execute("UPDATE online_presence_checks SET shown_at=? WHERE id=? AND shown_at=''",(now,row['id'])); c.commit()
        c.close(); return row

    @staticmethod
    def respond_presence(check_id,confirmed):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); now=_now(); row=c.execute("SELECT * FROM online_presence_checks WHERE id=?",(check_id,)).fetchone();
        if not row:c.close(); return False
        response='confirmed' if confirmed else 'absent'; c.execute("UPDATE online_presence_checks SET response=?,responded_at=? WHERE id=?",(response,now,check_id)); c.execute("INSERT INTO online_class_activity(class_id,session_id,student_id,event_type,event_time,metadata) VALUES(?,?,?,?,?,?)",(row['class_id'],row['session_id'],row['student_id'],'presence_check_'+response,now,str(row['checkpoint_no'])))
        if not confirmed: OnlineClassService._notify_absence(c,row['class_id'],row['student_id'])
        c.commit(); c.close(); return True

    @staticmethod
    def _notify_absence(c,class_id,student_id):
        now=_now(); s=c.execute("SELECT first_name,last_name,parent_phone,class_name FROM students WHERE id=?",(student_id,)).fetchone(); name=(f"{s['first_name'] or ''} {s['last_name'] or ''}").strip() if s else str(student_id); msg=f"راستی‌آزمایی حضور دانش‌آموز {name} در کلاس مجازی تأیید نشد.";
        recipients=[]
        if s and s['parent_phone']: recipients.append((s['parent_phone'],'parent'))
        # حساب‌های والد مرتبط با این دانش‌آموز نیز پیام را در پنل خود می‌بینند.
        try:
            linked = c.execute("SELECT parent_username FROM parent_children WHERE student_id=?",(student_id,)).fetchall()
            recipients += [(r['parent_username'],'parent') for r in linked if r['parent_username']]
        except Exception:
            pass
        recipients += [('معاون آموزشی','vice'),('مدیر','manager')]
        # حذف گیرنده‌های تکراری
        recipients = list(dict.fromkeys(recipients))
        for rec,role in recipients:c.execute("INSERT INTO online_class_notifications(class_id,student_id,recipient,recipient_role,title,message,created_at) VALUES(?,?,?,?,?,?,?)",(class_id,student_id,rec,role,'هشدار حضور کلاس مجازی',msg,now))
        # همچنین برای مرکز پیام برنامه
        c.execute("INSERT INTO messages(sender,receiver,text,created_at) VALUES(?,?,?,?)",('سیستم کلاس مجازی','/'.join(r[0] for r in recipients),msg,now))

    @staticmethod
    def get_class_report(class_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); rows=c.execute("""SELECT a.student_id, s.first_name||' '||s.last_name student_name,a.join_time,a.leave_time,a.status,
        SUM(CASE WHEN p.response='confirmed' THEN 1 ELSE 0 END) confirmed_checks,
        SUM(CASE WHEN p.response='absent' THEN 1 ELSE 0 END) missed_checks,
        COUNT(p.id) total_checks
        FROM online_attendance a LEFT JOIN students s ON s.id=a.student_id
        LEFT JOIN online_presence_checks p ON p.class_id=a.class_id AND p.student_id=a.student_id
        WHERE a.class_id=? GROUP BY a.student_id,a.join_time,a.leave_time,a.status""",(class_id,)).fetchall(); c.close(); return rows

    @staticmethod
    def ai_analyze_class(class_id):
        rows=OnlineClassService.get_class_report(class_id); result=[]
        for r in rows:
            total=int(r['total_checks'] or 0); missed=int(r['missed_checks'] or 0); confirmed=int(r['confirmed_checks'] or 0)
            if missed: risk='high'; text='نیازمند پیگیری: راستی‌آزمایی حضور تأیید نشده است.'
            elif total and confirmed==total: risk='normal'; text='حضور در کلاس پایدار و راستی‌آزمایی‌ها تأیید شده است.'
            else: risk='medium'; text='نیازمند پایش بیشتر حضور.'
            result.append({'student_id':r['student_id'],'student_name':r['student_name'],'risk_level':risk,'report':text,'confirmed':confirmed,'missed':missed,'join_time':r['join_time'],'leave_time':r['leave_time']})
        c=OnlineClassService.get_connection(); now=_now(); session=c.execute("SELECT id FROM online_class_sessions WHERE class_id=? ORDER BY id DESC LIMIT 1",(class_id,)).fetchone();
        for x in result:c.execute("INSERT INTO online_class_ai_reports(class_id,student_id,session_id,report,risk_level,created_at) VALUES(?,?,?,?,?,?)",(class_id,x['student_id'],session['id'] if session else None,x['report'],x['risk_level'],now))
        c.commit(); c.close(); return result

    @staticmethod
    def log_activity(class_id, event_type, student_id=0, metadata=''):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); now=_now(); session=c.execute("SELECT id FROM online_class_sessions WHERE class_id=? AND ended_at='' ORDER BY id DESC LIMIT 1",(class_id,)).fetchone(); c.execute("INSERT INTO online_class_activity(class_id,session_id,student_id,event_type,event_time,metadata) VALUES(?,?,?,?,?,?)",(class_id,session['id'] if session else None,int(student_id or 0),event_type,now,str(metadata or ''))); c.commit(); c.close(); return True

    @staticmethod
    def set_public_chat(class_id, enabled):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); c.execute("INSERT INTO online_class_settings(class_id,public_chat_enabled,updated_at_shamsi) VALUES(?,?,?) ON CONFLICT(class_id) DO UPDATE SET public_chat_enabled=excluded.public_chat_enabled,updated_at_shamsi=excluded.updated_at_shamsi",(class_id,1 if enabled else 0,_shamsi_now())); c.commit(); c.close(); return True

    @staticmethod
    def chat_settings(class_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); r=c.execute("SELECT * FROM online_class_settings WHERE class_id=?",(class_id,)).fetchone();
        if not r:
            c.execute("INSERT INTO online_class_settings(class_id,updated_at_shamsi) VALUES(?,?)",(class_id,_shamsi_now())); c.commit(); r=c.execute("SELECT * FROM online_class_settings WHERE class_id=?",(class_id,)).fetchone()
        c.close(); return r

    @staticmethod
    def send_public_chat(class_id, sender_id, role, name, message):
        settings=OnlineClassService.chat_settings(class_id)
        if not settings['public_chat_enabled']: return False
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); c.execute("INSERT INTO online_class_chat(class_id,sender_id,sender_role,sender_name,is_private,message,sent_at_shamsi) VALUES(?,?,?,?,0,?,?)",(class_id,sender_id,role,name,message,_shamsi_now())); c.commit(); c.close(); return True

    @staticmethod
    def send_private_chat(class_id, teacher_id, teacher_name, student_id, message):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); c.execute("INSERT INTO online_class_chat(class_id,sender_id,sender_role,sender_name,recipient_student_id,is_private,message,sent_at_shamsi) VALUES(?,?,?,?,?,1,?,?)",(class_id,teacher_id,'teacher',teacher_name,student_id,message,_shamsi_now())); c.commit(); c.close(); return True

    @staticmethod
    def teacher_private_messages(class_id):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); rows=c.execute("SELECT * FROM online_class_chat WHERE class_id=? AND is_private=1 ORDER BY id",(class_id,)).fetchall(); c.close(); return rows

    @staticmethod
    def board_event(class_id, actor_id, role, event_type, payload=''):
        OnlineClassService.ensure_schema(); c=OnlineClassService.get_connection(); c.execute("INSERT INTO online_class_board_events(class_id,actor_id,actor_role,event_type,payload,event_date_shamsi) VALUES(?,?,?,?,?,?)",(class_id,actor_id,role,event_type,str(payload or ''),_shamsi_now())); c.commit(); c.close(); return True

    @staticmethod
    def get_notifications(recipient,role):
        c=OnlineClassService.get_connection(); rows=c.execute("SELECT * FROM online_class_notifications WHERE recipient=? AND recipient_role=? ORDER BY id DESC",(recipient,role)).fetchall(); c.close(); return rows
