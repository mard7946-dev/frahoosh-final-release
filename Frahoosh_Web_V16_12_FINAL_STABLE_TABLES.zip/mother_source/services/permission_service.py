class PermissionService:
    """
    سرویس مدیریت دسترسی فراهوش
    """


    @staticmethod
    def can_access(
        role,
        module
    ):

        # مرحله تست اتصال داشبورد
        # فعلاً همه پنل‌ها نمایش داده می‌شوند
        # بعد از تکمیل جدول مجوزها RBAC واقعی فعال می‌شود

        return True