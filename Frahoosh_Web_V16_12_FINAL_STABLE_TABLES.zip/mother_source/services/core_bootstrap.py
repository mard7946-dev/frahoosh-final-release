"""Single database bootstrap used before any Frahoosh panel opens."""
from pathlib import Path
import sqlite3
DB_PATH=Path(__file__).resolve().parents[1]/'school.db'

def bootstrap():
    c=sqlite3.connect(DB_PATH)
    try:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password TEXT,role TEXT,permissions TEXT);
        CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,first_name TEXT,last_name TEXT,national_code TEXT,student_code TEXT,grade TEXT,class_name TEXT,phone TEXT,parent_phone TEXT,photo TEXT,father_name TEXT,mother_name TEXT,birth_date TEXT,email TEXT,address TEXT,description TEXT);
        CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,first_name TEXT,last_name TEXT,national_code TEXT,phone TEXT,email TEXT,subject TEXT,grades TEXT,description TEXT);
        CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY AUTOINCREMENT,first_name TEXT,last_name TEXT,role TEXT,phone TEXT,description TEXT);
        CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,date TEXT,status TEXT,description TEXT);
        CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,teacher_id INTEGER,subject TEXT,exam_name TEXT,score REAL,description TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher TEXT,class_name TEXT,subject TEXT,title TEXT,description TEXT,status TEXT DEFAULT 'فعال',due_date TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT,receiver TEXT,text TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS online_quizzes(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER,title TEXT,subject TEXT,duration INTEGER DEFAULT 0,teacher TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS online_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,subject TEXT,lesson TEXT,teacher TEXT,grade TEXT,class_name TEXT,duration INTEGER DEFAULT 0,pages INTEGER DEFAULT 1,record INTEGER DEFAULT 0,smart_board INTEGER DEFAULT 1,quiz INTEGER DEFAULT 1,camera INTEGER DEFAULT 1,microphone INTEGER DEFAULT 1,start_time TEXT,end_time TEXT,status TEXT DEFAULT 'pending',created_at TEXT);
        CREATE TABLE IF NOT EXISTS school_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,request_type TEXT,requester TEXT,role TEXT,description TEXT,status TEXT DEFAULT 'در انتظار',created_at TEXT,updated_at TEXT);
        CREATE TABLE IF NOT EXISTS smart_board_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT DEFAULT '',message TEXT DEFAULT '',priority TEXT DEFAULT 'normal',publish_date TEXT,created_by TEXT);
        CREATE TABLE IF NOT EXISTS cultural_items(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,title TEXT,student_name TEXT,details TEXT,fee INTEGER DEFAULT 0,status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS parent_children(parent_username TEXT NOT NULL,student_id INTEGER NOT NULL,PRIMARY KEY(parent_username,student_id));
        CREATE TABLE IF NOT EXISTS generated_weekly_schedule(id INTEGER PRIMARY KEY AUTOINCREMENT,source_id INTEGER,teacher TEXT,subject TEXT,grade TEXT,class_name TEXT,weekday TEXT,bell TEXT,week_index INTEGER DEFAULT 1,created_at TEXT);
        CREATE TABLE IF NOT EXISTS exam_schedule(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT,grade TEXT,start_date TEXT,end_date TEXT,weight TEXT DEFAULT 'متوسط',exam_date TEXT,duration INTEGER DEFAULT 45,exam_start_time TEXT DEFAULT '13:10',exam_end_time TEXT DEFAULT '13:55',created_at TEXT);
        CREATE TABLE IF NOT EXISTS vice_attendance_reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,class_id INTEGER,status TEXT,reviewed_by TEXT,reviewed_at TEXT,note TEXT);
        CREATE TABLE IF NOT EXISTS vice_referrals(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,teacher TEXT,reason TEXT,status TEXT DEFAULT 'pending',note TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS vice_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,date TEXT,status TEXT DEFAULT 'pending',note TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS vice_notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS advisor_workspace(id INTEGER PRIMARY KEY AUTOINCREMENT,section TEXT,student_id INTEGER,title TEXT,description TEXT,status TEXT DEFAULT 'در حال پیگیری',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS quiz_questions(id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,question TEXT,option1 TEXT DEFAULT '',option2 TEXT DEFAULT '',option3 TEXT DEFAULT '',option4 TEXT DEFAULT '',correct_answer TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS quiz_links(id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,token TEXT UNIQUE,allowed_class TEXT,expires_at TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS quiz_schedules(id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,class_name TEXT,start_at TEXT,end_at TEXT);
        CREATE TABLE IF NOT EXISTS teacher_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,subject TEXT,grade TEXT,class_name TEXT,active INTEGER DEFAULT 1,created_at TEXT);
        CREATE TABLE IF NOT EXISTS teacher_attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER,student_id INTEGER,student_name TEXT,status TEXT,note TEXT,recorded_at TEXT,UNIQUE(class_id,student_id));
        CREATE TABLE IF NOT EXISTS lesson_plans(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,subject TEXT,grade TEXT,class_name TEXT,title TEXT,objective TEXT,content TEXT,session_date TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS teacher_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,teacher_id INTEGER,teacher_name TEXT,student_id INTEGER,student_name TEXT,parent_name TEXT,meeting_at TEXT,subject TEXT,status TEXT DEFAULT 'requested',report TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS transport_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,parent_username TEXT,address TEXT,vehicle_type TEXT,origin TEXT,destination TEXT,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS student_registrations(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,activity_id INTEGER,activity_title TEXT,activity_kind TEXT,fee INTEGER DEFAULT 0,payment_status TEXT,registration_code TEXT,registered_at TEXT,payment_url TEXT);
        CREATE TABLE IF NOT EXISTS executive_classes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,grade TEXT,teacher TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS seating(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,seat_no TEXT,exam TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,title TEXT,code TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS student_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,card_type TEXT,code TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS report_cards(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,term TEXT,average REAL,description TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS student_grades(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,teacher_id INTEGER,subject TEXT DEFAULT '',class_name TEXT DEFAULT '',assessment_type TEXT DEFAULT 'custom',assessment_title TEXT DEFAULT '',score REAL,coefficient REAL DEFAULT 1,grade_date TEXT DEFAULT '',grade_date_shamsi TEXT DEFAULT '',description TEXT DEFAULT '',term TEXT DEFAULT '',manager_released INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS grade_visibility(id INTEGER PRIMARY KEY AUTOINCREMENT,grade_id INTEGER NOT NULL UNIQUE,released_by TEXT DEFAULT '',released_at_shamsi TEXT DEFAULT '',released INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,category TEXT,quantity INTEGER,location TEXT,created_at TEXT,archived INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS archive_items(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,student_id INTEGER,location TEXT,description TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS executive_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,requester TEXT,status TEXT,description TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS discipline_records(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,title TEXT,deduction REAL DEFAULT 0,status TEXT,created_at TEXT,note TEXT);
        CREATE TABLE IF NOT EXISTS parent_meetings(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,teacher_id INTEGER DEFAULT 0,parent_phone TEXT DEFAULT '',reason TEXT DEFAULT '',meeting_date TEXT,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS finance_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,description TEXT,amount REAL,type TEXT,account TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS finance_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,balance REAL DEFAULT 0,description TEXT);
        ''')
        # migrations for older tables used by the integrated panels
        migrations={
            'assignments': {'student_id':'INTEGER','teacher_id':'INTEGER','class_name':'TEXT','subject':'TEXT','title':'TEXT','description':'TEXT','status':"TEXT DEFAULT 'فعال'",'due_date':'TEXT','teacher':'TEXT','created_at':'TEXT'},
            'grades': {'student_id':'INTEGER','teacher_id':'INTEGER','subject':'TEXT','exam_name':'TEXT','score':'REAL','description':'TEXT','created_at':'TEXT'},
            'messages': {'sender':'TEXT','receiver':'TEXT','text':'TEXT','created_at':'TEXT'},
            'staff': {'role':'TEXT','phone':'TEXT','description':'TEXT'},
            'executive_requests': {'role':"TEXT DEFAULT ''"},
            'assets': {'archived':'INTEGER DEFAULT 0'},
            'online_quizzes': {'class_id':'INTEGER','title':'TEXT','subject':'TEXT','duration':'INTEGER DEFAULT 0','teacher':'TEXT','created_at':'TEXT'},
            'transport_requests': {'created_at':'TEXT'},
            'student_registrations': {'payment_url':'TEXT','payment_reference':'TEXT'},
            'discipline_records': {'student_id':'INTEGER','title':'TEXT','deduction':'REAL DEFAULT 0','status':'TEXT','created_at':'TEXT','note':'TEXT'},
            'parent_meetings': {'student_id':'INTEGER','teacher_id':'INTEGER','parent_phone':'TEXT','reason':'TEXT','meeting_date':'TEXT','status':"TEXT DEFAULT 'pending'",'created_at':'TEXT'},
            'online_classes': {'created_at_shamsi':"TEXT DEFAULT ''",'start_time_shamsi':"TEXT DEFAULT ''",'end_time_shamsi':"TEXT DEFAULT ''"},
            'student_grades': {'manager_released':'INTEGER DEFAULT 0'},
        }
        for table,cols in migrations.items():
            have={r[1] for r in c.execute(f'PRAGMA table_info({table})')}
            for col,typ in cols.items():
                if col not in have:c.execute(f'ALTER TABLE {table} ADD COLUMN {col} {typ}')
        c.executescript("""
        CREATE TABLE IF NOT EXISTS online_class_teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,teacher_id INTEGER,teacher_name TEXT DEFAULT '',UNIQUE(class_id,teacher_id));
        CREATE TABLE IF NOT EXISTS online_class_students(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,student_id INTEGER NOT NULL,student_name TEXT DEFAULT '',UNIQUE(class_id,student_id));
        CREATE TABLE IF NOT EXISTS online_class_settings(class_id INTEGER PRIMARY KEY,public_chat_enabled INTEGER DEFAULT 0,private_chat_enabled INTEGER DEFAULT 1,board_enabled INTEGER DEFAULT 1,file_share_enabled INTEGER DEFAULT 1,media_enabled INTEGER DEFAULT 1,quiz_enabled INTEGER DEFAULT 1,camera_enabled INTEGER DEFAULT 1,microphone_enabled INTEGER DEFAULT 1,screen_share_enabled INTEGER DEFAULT 1,updated_at_shamsi TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS online_class_chat(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,sender_id INTEGER,sender_role TEXT DEFAULT '',sender_name TEXT DEFAULT '',recipient_student_id INTEGER,is_private INTEGER DEFAULT 0,message TEXT NOT NULL,sent_at_shamsi TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS online_class_board_events(id INTEGER PRIMARY KEY AUTOINCREMENT,class_id INTEGER NOT NULL,actor_id INTEGER,actor_role TEXT DEFAULT '',event_type TEXT NOT NULL,payload TEXT DEFAULT '{}',event_date_shamsi TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS grade_visibility(id INTEGER PRIMARY KEY AUTOINCREMENT,grade_id INTEGER NOT NULL UNIQUE,released_by TEXT DEFAULT '',released_at_shamsi TEXT DEFAULT '',released INTEGER DEFAULT 0);
        """)
        # migrations for users/teachers and common fields
        for table,cols in {'users':{'linked_student_id':'INTEGER','linked_teacher_id':'INTEGER','linked_staff_id':'INTEGER','display_name':"TEXT DEFAULT ''"},'teachers':{'source_staff_id':'INTEGER'}}.items():
            have={r[1] for r in c.execute(f'PRAGMA table_info({table})')}
            for col,typ in cols.items():
                if col not in have:c.execute(f'ALTER TABLE {table} ADD COLUMN {col} {typ}')
        c.execute("INSERT OR IGNORE INTO users(username,password,role,permissions) VALUES('admin','1234','manager','all')")
        c.commit()
    finally:c.close()

# Unified cross-panel event hub: every student-centric or school-wide insert
# becomes visible to the accounts/persons/classes entitled to receive it.
try:
    from .unified_event_service import ensure_schema as ensure_unified_event_schema
    ensure_unified_event_schema()
except Exception:
    pass
