"""Central audience selection and account resolution for Frahoosh.

All cross-panel records can use the same audience vocabulary.  The UI stores
only audience descriptors; delivery is resolved to user accounts at publish
and again when an inbox is opened, so changing a student's parent link does
not require rewriting historical records.
"""
from datetime import datetime
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parents[1] / "school.db"

AUDIENCE_OPTIONS = [
    ("student", "دانش‌آموز"),
    ("class", "کلاس"),
    ("manager", "مدیر"),
    ("teacher", "دبیر"),
    ("vice", "معاون"),
    ("advisor", "مشاوره"),
    ("class_parents", "اولیای کلاس"),
    ("student_parents", "اولیای دانش‌آموز"),
    ("school_parents", "اولیای کل مدرسه"),
    ("grade_students", "دانش‌آموزان پایه"),
    ("school_students", "دانش‌آموزان کل مدرسه"),
    ("school_staff", "مدیر و عوامل مدرسه"),
    ("school_all", "کل مدرسه"),
]

ROLE_MAP = {
    "manager": {"manager", "مدیر", "مدیریت"},
    "teacher": {"teacher", "teachers", "دبیر", "دبیران", "معلم"},
    "vice": {"vice", "معاون", "معاونت", "معاون آموزشی", "معاون اجرایی", "معاون پرورشی", "staff"},
    "advisor": {"advisor", "counselor", "مشاور", "مشاوره"},
    "parent": {"parent", "parents", "اولیا", "ولی", "والد"},
    "student": {"student", "students", "دانش‌آموز", "دانش‌آموزان", "دانش آموز"},
}


def connect():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=30000")
    return c


def ensure_schema():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS audience_presets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            targets_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS event_audiences(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_value TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            UNIQUE(event_id,target_type,target_value)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_event_audiences_event ON event_audiences(event_id)")


def normalize_targets(targets):
    """Accept tuples, dicts or the result of AudienceSelectorDialog."""
    out = []
    for item in targets or []:
        if isinstance(item, dict):
            t = str(item.get("type", "")).strip()
            v = str(item.get("value", "")).strip()
        else:
            t = str(item[0]).strip() if len(item) else ""
            v = str(item[1]).strip() if len(item) > 1 else ""
        if t and (t, v) not in out:
            out.append((t, v))
    return out


def _users_by_role(c, role):
    aliases = {x.lower() for x in ROLE_MAP.get(role, {role})}
    rows = c.execute("SELECT username,role FROM users WHERE COALESCE(username,'')<>''").fetchall()
    return [r["username"] for r in rows if str(r["role"] or "").lower() in aliases]


def _student_accounts(c, sid):
    # A student event must reach the student's account and every linked parent.
    # Support both identity links used by older Frahoosh databases:
    # users.linked_student_id and parent_children.
    out = [r["username"] for r in c.execute(
        "SELECT username FROM users WHERE linked_student_id=? AND COALESCE(username,'')<>''", (sid,)
    ).fetchall()]
    try:
        out += [r["parent_username"] for r in c.execute(
            "SELECT parent_username FROM parent_children WHERE student_id=?", (sid,)
        ).fetchall() if r["parent_username"]]
    except sqlite3.Error:
        pass
    try:
        out += [r["username"] for r in c.execute(
            "SELECT username FROM users WHERE lower(COALESCE(role,'')) IN ('parent','parents','اولیا','ولی','والد') AND linked_student_id=? AND COALESCE(username,'')<>''",
            (sid,)
        ).fetchall()]
    except sqlite3.Error:
        pass
    return list(dict.fromkeys(out))


def _student_ids_for_class(c, value):
    rows = c.execute("SELECT id FROM students WHERE class_name=?", (value,)).fetchall()
    return [r["id"] for r in rows]


def _student_ids_for_grade(c, value):
    rows = c.execute("SELECT id FROM students WHERE grade=? OR CAST(grade AS TEXT)=?", (value, str(value))).fetchall()
    return [r["id"] for r in rows]


def resolve_targets(targets, connection=None):
    ensure_schema()
    own = connection is None
    c = connection or connect()
    try:
        out = []
        for t, v in normalize_targets(targets):
            if t == "student" and str(v).isdigit():
                out += _student_accounts(c, int(v))
            elif t == "class":
                for sid in _student_ids_for_class(c, v):
                    out += _student_accounts(c, sid)
            elif t == "student_parents" and str(v).isdigit():
                out += [u for u in _student_accounts(c, int(v)) if u]
                # _student_accounts also contains the student's own account;
                # remove it for the parent-only audience.
                try:
                    student_users = {r["username"] for r in c.execute(
                        "SELECT username FROM users WHERE linked_student_id=? AND lower(COALESCE(role,'')) IN ('student','students','دانش‌آموز','دانش آموز','دانش‌آموزان')", (int(v),)
                    ).fetchall()}
                    out = [u for u in out if u not in student_users]
                except sqlite3.Error:
                    pass
            elif t == "class_parents":
                for sid in _student_ids_for_class(c, v):
                    out += [r["parent_username"] for r in c.execute(
                        "SELECT parent_username FROM parent_children WHERE student_id=?", (sid,)
                    ).fetchall() if r["parent_username"]]
            elif t == "grade_students":
                for sid in _student_ids_for_grade(c, v):
                    out += _student_accounts(c, sid)
            elif t == "school_students":
                for r in c.execute("SELECT id FROM students").fetchall():
                    out += _student_accounts(c, r["id"])
            elif t == "school_parents":
                out += _users_by_role(c, "parent")
            elif t in ROLE_MAP:
                out += _users_by_role(c, t)
            elif t == "school_staff":
                for role in ("manager", "teacher", "vice", "advisor"):
                    out += _users_by_role(c, role)
            elif t == "school_all":
                out += [r["username"] for r in c.execute(
                    "SELECT username FROM users WHERE COALESCE(username,'')<>''"
                ).fetchall()]
        return list(dict.fromkeys(out))
    finally:
        if own:
            c.close()


def labels_for_targets(targets):
    labels = dict(AUDIENCE_OPTIONS)
    return [labels.get(t, t) + (f" ({v})" if v else "") for t, v in normalize_targets(targets)]


def begin_capture(source_table, targets, connection=None):
    """Arm the next INSERT/UPDATE trigger. Pass the same DB connection used
    for the final write when possible; this makes the selection transactional."""
    ensure_schema()
    payload = __import__("json").dumps(normalize_targets(targets), ensure_ascii=False)
    own = connection is None
    c = connection or connect()
    try:
        c.execute("CREATE TABLE IF NOT EXISTS audience_capture(source_table TEXT PRIMARY KEY, targets_json TEXT NOT NULL, created_at TEXT NOT NULL)")
        c.execute("INSERT INTO audience_capture(source_table,targets_json,created_at) VALUES(?,?,?) ON CONFLICT(source_table) DO UPDATE SET targets_json=excluded.targets_json,created_at=excluded.created_at", (source_table,payload,datetime.now().isoformat(timespec='seconds')))
        if own: c.commit()
    finally:
        if own: c.close()

def end_capture(source_table):
    try:
        with connect() as c: c.execute("DELETE FROM audience_capture WHERE source_table=?", (source_table,))
    except sqlite3.Error:
        pass
