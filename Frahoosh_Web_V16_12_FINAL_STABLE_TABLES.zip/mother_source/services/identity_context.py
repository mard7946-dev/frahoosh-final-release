"""Single authenticated-identity context for Frahoosh.

Panels should use the logged-in username/account as their source of truth.
Database primary keys remain internal implementation details and are resolved
only inside this service.
"""
from .data_link_service import resolve

_CURRENT = None


def set_current_user(username):
    global _CURRENT
    _CURRENT = resolve(str(username or '').strip()) if username else None
    return _CURRENT


def current_user():
    return _CURRENT


def current_student():
    u = _CURRENT or {}
    return u.get('student')


def current_teacher():
    u = _CURRENT or {}
    return u.get('teacher')


def student_record(username=None):
    u = resolve(username) if username else (_CURRENT or {})
    return u.get('student') if u else None


def teacher_record(username=None):
    u = resolve(username) if username else (_CURRENT or {})
    return u.get('teacher') if u else None
