from datetime import datetime

class NotificationService:

    _notifications = []

    @classmethod
    def add(
        cls,
        title,
        message,
        receiver_role,
        sender=None,
        priority="عادی"
    ):

        cls._notifications.append({

            "title": title,

            "message": message,

            "receiver_role": receiver_role,

            "sender": sender,

            "priority": priority,

            "time": datetime.now(),

            "read": False

        })

    @classmethod
    def get_notifications(cls, receiver_role):

        return [

            n

            for n in cls._notifications

            if n["receiver_role"] == receiver_role

        ]

    @classmethod
    def mark_as_read(cls, index):

        if 0 <= index < len(cls._notifications):

            cls._notifications[index]["read"] = True