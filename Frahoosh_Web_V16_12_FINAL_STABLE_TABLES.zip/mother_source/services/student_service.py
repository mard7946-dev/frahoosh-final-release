import sqlite3
from datetime import datetime


from database.db import DATABASE_NAME


class OnlineClassService:

    # =====================================================
    # اتصال به دیتابیس
    # =====================================================

    @staticmethod
    def get_connection():
        return sqlite3.connect(DATABASE_NAME)

    # =====================================================
    # دریافت همه کلاس‌ها
    # =====================================================

    @staticmethod
    def get_all_classes():

        conn = None

        try:
            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    lesson,
                    subject,
                    teacher,
                    grade,
                    class_name,
                    start_time,
                    end_time,
                    status,
                    created_at
                FROM online_classes
                ORDER BY id DESC
            """)

            return cursor.fetchall()

        except Exception as e:

            print(
                "GET ALL CLASSES ERROR:",
                e
            )

            return []

        finally:

            if conn:
                conn.close()

    # =====================================================
    # کلاس‌های دانش‌آموز
    #
    # پشتیبانی از:
    # الف
    # کلاس الف
    # خالی بودن نام کلاس
    # =====================================================

    @staticmethod
    def get_student_classes(
        grade,
        class_name
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            class_name = str(
                class_name or ""
            ).strip()

            grade = str(
                grade or ""
            ).strip()

            normalized_class = class_name

            if normalized_class.startswith("کلاس "):

                normalized_class = normalized_class[6:].strip()

            else:

                normalized_class = normalized_class

            cursor.execute("""
                SELECT
                    id,

                    CASE
                        WHEN lesson IS NOT NULL
                             AND lesson != ''
                        THEN lesson

                        WHEN subject IS NOT NULL
                             AND subject != ''
                        THEN subject

                        ELSE 'کلاس آنلاین'
                    END,

                    CASE
                        WHEN subject IS NOT NULL
                             AND subject != ''
                        THEN subject

                        WHEN lesson IS NOT NULL
                             AND lesson != ''
                        THEN lesson

                        ELSE '---'
                    END,

                    teacher,
                    start_time,
                    end_time,
                    status

                FROM online_classes

                WHERE grade = ?

                AND (
                    class_name = ?
                    OR class_name = ?
                    OR class_name = ?
                    OR class_name = ''
                    OR class_name IS NULL
                )

                AND status IN (
                    'approved',
                    'live'
                )

                ORDER BY
                    start_time ASC,
                    id DESC
            """, (
                grade,
                class_name,
                "کلاس " + class_name,
                normalized_class
            ))

            rows = cursor.fetchall()

            print(
                "STUDENT ONLINE CLASSES:",
                rows
            )

            return rows

        except Exception as e:

            print(
                "GET STUDENT CLASSES ERROR:",
                e
            )

            return []

        finally:

            if conn:conn.close()

    # =====================================================
    # تمام کلاس‌های فعال
    # =====================================================

    @staticmethod
    def get_active_classes():

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    lesson,
                    subject,
                    teacher,
                    grade,
                    class_name,
                    start_time,
                    end_time,
                    status
                FROM online_classes
                WHERE status IN (
                    'approved',
                    'live'
                )
                ORDER BY
                    start_time ASC,
                    id DESC
            """)

            return cursor.fetchall()

        except Exception as e:

            print(
                "GET ACTIVE CLASSES ERROR:",
                e
            )

            return []

        finally:

            if conn:
                conn.close()

    # =====================================================
    # دریافت یک کلاس
    # =====================================================

    @staticmethod
    def get_class_by_id(
        class_id
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    lesson,
                    subject,
                    teacher,
                    grade,
                    class_name,
                    start_time,
                    end_time,
                    status
                FROM online_classes
                WHERE id = ?
            """, (
                class_id,
            ))

            return cursor.fetchone()

        except Exception as e:

            print(
                "GET CLASS ERROR:",
                e
            )

            return None

        finally:

            if conn:
                conn.close()

    # =====================================================
    # کلاس‌های دبیر
    # =====================================================

    @staticmethod
    def get_teacher_classes(
        teacher
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    lesson,
                    subject,
                    teacher,
                    grade,
                    class_name,
                    start_time,
                    end_time,
                    status
                FROM online_classes
                WHERE teacher = ?
                ORDER BY
                    start_time DESC,
                    id DESC
            """, (
                teacher,
            ))

            rows = cursor.fetchall()

            print(
                "TEACHER ONLINE CLASSES:",
                rows
            )

            return rows

        except Exception as e:

            print(
                "GET TEACHER CLASSES ERROR:",
                e
            )

            return []

        finally:

            if conn:
                conn.close()

    # =====================================================
    # کلاس‌های فعال دبیر
    # =====================================================

    @staticmethod
    def get_teacher_active_classes(
        teacher
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    lesson,
                    subject,
                    teacher,
                    grade,
                    class_name,
                    start_time,
                    end_time,
                    status
                FROM online_classes
                WHERE teacher = ?
                AND status IN (
                    'approved',
                    'live'
                )
                ORDER BY
                    start_time ASC,
                    id DESC
            """, (
                teacher,
            ))

            return cursor.fetchall()

        except Exception as e:

            print(
                "GET TEACHER ACTIVE CLASSES ERROR:",
                e
            )

            return []

        finally:

            if conn:
                conn.close()

    # =====================================================
    # تغییر وضعیت کلاس
    # =====================================================

    @staticmethod
    def update_status(
        class_id,
        status
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE online_classes
                SET status = ?
                WHERE id = ?
            """, (
                status,
                class_id
            ))

            conn.commit()

            print(
                "ONLINE CLASS STATUS:",
                class_id,
                status
            )

            return cursor.rowcount > 0

        except Exception as e:

            print(
                "UPDATE STATUS ERROR:",
                e
            )

            if conn:

                try:
                    conn.rollback()
                except Exception:
                    pass

            return False

        finally:

            if conn:
                conn.close()

    # =====================================================
    # تأیید کلاس توسط مدیریت
    # =====================================================

    @staticmethod
    def approve_class(
        class_id
    ):

        return OnlineClassService.update_status(
            class_id,
            "approved"
        )

    # =====================================================
    # شروع کلاس توسط دبیر
    # =====================================================

    @staticmethod
    def start_class(
        class_id
    ):

        return OnlineClassService.update_status(
            class_id,
            "live"
        )

    # =====================================================
    # پایان کلاس
    # =====================================================

    @staticmethod
    def finish_class(
        class_id
    ):

        return OnlineClassService.update_status(
            class_id,
            "finished"
        )

    # =====================================================
    # لغو کلاس
    # =====================================================

    @staticmethod
    def cancel_class(
        class_id
    ):

        return OnlineClassService.update_status(
            class_id,
            "cancelled"
        )

    # =====================================================
    # بررسی فعال بودن کلاس
    # =====================================================

    @staticmethod
    def is_class_live(
        class_id
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT status
                FROM online_classes
                WHERE id = ?
            """, (
                class_id,
            ))

            row = cursor.fetchone()

            if not row:
                return False

            return row[0] == "live"

        except Exception as e:

            print(
                "IS CLASS LIVE ERROR:",
                e
            )

            return False

        finally:

            if conn:
                conn.close()

    # =====================================================
    # تعداد حاضرین
    # =====================================================

    @staticmethod
    def get_attendance_count(
        class_id
    ):

        conn = None

        try:
            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT COUNT(*)
                FROM online_attendance
                WHERE class_id = ?
                AND status = 'present'
            """, (
                class_id,
            ))

            row = cursor.fetchone()

            return row[0] if row else 0

        except Exception as e:

            print(
                "GET ATTENDANCE COUNT ERROR:",
                e
            )

            return 0

        finally:

            if conn:
                conn.close()

    # =====================================================
    # ورود دانش‌آموز به کلاس
    # =====================================================

    @staticmethod
    def student_join(
        class_id,
        student_id
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            now = datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            cursor.execute("""
                SELECT id
                FROM online_attendance
                WHERE class_id = ?
                AND student_id = ?
            """, (
                class_id,
                student_id
            ))

            existing = cursor.fetchone()

            if existing:

                cursor.execute("""
                    UPDATE online_attendance
                    SET
                        join_time = ?,
                        status = 'present',
                        last_activity = ?
                    WHERE id = ?
                """, (
                    now,
                    now,
                    existing[0]
                ))

            else:

                cursor.execute("""
                    INSERT INTO online_attendance
                    (
                        class_id,
                        student_id,
                        join_time,
                        status,
                        last_activity
                    )
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    class_id,
                    student_id,
                    now,
                    "present",
                    now
                ))

            conn.commit()

            return True

        except Exception as e:

            print(
                "STUDENT JOIN ERROR:",
                e
            )

            if conn:

                try:
                    conn.rollback()
                except Exception:
                    pass

            return False

        finally:

            if conn:
                conn.close()

    # =====================================================
    # خروج دانش‌آموز
    # =====================================================

    @staticmethod
    def student_leave(
        class_id,
        student_id
    ):

        conn = None

        try:

            conn = OnlineClassService.get_connection()
            cursor = conn.cursor()

            now = datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

            cursor.execute("""
                UPDATE online_attendance
                SET
                    leave_time = ?,
                    last_activity = ?
                WHERE class_id = ?
                AND student_id = ?
            """, (
                now,
                now,
                class_id,
                student_id
            ))

            conn.commit()

            return True

        except Exception as e:

            print(
                "STUDENT LEAVE ERROR:",
                e
            )

            return False

        finally:

            if conn:
                conn.close()