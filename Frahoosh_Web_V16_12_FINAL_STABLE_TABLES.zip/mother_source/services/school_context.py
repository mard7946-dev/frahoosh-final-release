from pathlib import Path
import sqlite3
from config import SCHOOL_NAME, SCHOOL_YEAR

DB = Path(__file__).resolve().parents[1] / "school.db"

def connection():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def ensure():
    with connection() as c:
        c.execute("CREATE TABLE IF NOT EXISTS school_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        c.execute("INSERT OR IGNORE INTO school_settings(key,value) VALUES('school_name',?)",(SCHOOL_NAME,))
        c.execute("INSERT OR IGNORE INTO school_settings(key,value) VALUES('school_year',?)",(SCHOOL_YEAR,))

def school_info():
    ensure()
    with connection() as c:
        rows={r['key']:r['value'] for r in c.execute("SELECT key,value FROM school_settings").fetchall()}
    return {'name':rows.get('school_name') or SCHOOL_NAME,'year':rows.get('school_year') or SCHOOL_YEAR}

def student_info(student_id):
    if not student_id: return None
    with connection() as c:
        r=c.execute("SELECT * FROM students WHERE id=?",(int(student_id),)).fetchone()
    return dict(r) if r else None
