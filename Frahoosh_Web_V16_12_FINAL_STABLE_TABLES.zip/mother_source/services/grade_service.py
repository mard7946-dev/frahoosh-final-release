# -*- coding: utf-8 -*-
"""Canonical grade service for Frahoosh."""
import json, sqlite3
from datetime import datetime
from utils.jalali import iso_to_jalali

ASSESSMENT_TYPES = ("کوییز","شفاهی","کتبی","میان‌ترم","پایان‌ترم","پروژه","فعالیت کلاسی","custom")

def _db():
    from database.db import get_connection
    return get_connection()

def save_grade(student_id, teacher_id, subject, class_name, assessment_type,
               assessment_title, score, coefficient=1, term="", description="",
               grade_date=None):
    grade_date = grade_date or datetime.now().strftime("%Y-%m-%d")
    sh = iso_to_jalali(grade_date)
    with _db() as c:
        c.execute("""INSERT INTO student_grades
        (student_id,teacher_id,subject,class_name,assessment_type,assessment_title,score,
         coefficient,grade_date,grade_date_shamsi,description,term,manager_released,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)""",
        (student_id,teacher_id,subject or "",class_name or "",assessment_type or "custom",
         assessment_title or "",float(score),float(coefficient or 1),grade_date,sh,
         description or "",term or ""))
        # Legacy table is kept synchronized for existing reports/modules.
        c.execute("""INSERT INTO grades(student_id,teacher_id,subject,exam_name,score,description,created_at)
                     VALUES(?,?,?,?,?,?,?)""",
                  (student_id,teacher_id,subject or "",assessment_title or "",float(score),
                   description or "",grade_date))
        c.commit()

def student_average(student_id, term=None):
    with _db() as c:
        q="SELECT SUM(score*coefficient)/NULLIF(SUM(coefficient),0) FROM student_grades WHERE student_id=?"
        args=[student_id]
        if term:
            q+=" AND term=?"; args.append(term)
        return c.execute(q,args).fetchone()[0] or 0

def subject_averages(student_id, term=None):
    with _db() as c:
        q="""SELECT subject, ROUND(SUM(score*coefficient)/NULLIF(SUM(coefficient),0),2) avg_score,
                    COUNT(*) count FROM student_grades WHERE student_id=?"""
        args=[student_id]
        if term: q+=" AND term=?"; args.append(term)
        q+=" GROUP BY subject ORDER BY subject"
        return c.execute(q,args).fetchall()

def generate_report_card(student_id, term="", academic_year=""):
    rows=subject_averages(student_id,term)
    avg=student_average(student_id,term)
    payload={r[0] or "بدون درس":{"average":r[1],"count":r[2]} for r in rows}
    sh=iso_to_jalali(datetime.now().strftime("%Y-%m-%d"))
    with _db() as c:
        c.execute("""INSERT INTO report_card_snapshots(student_id,term,academic_year,average,report_json,generated_date_shamsi)
                     VALUES(?,?,?,?,?,?)""",(student_id,term,academic_year,float(avg),json.dumps(payload,ensure_ascii=False),sh))
        c.commit()
    return {"student_id":student_id,"average":round(float(avg),2),"subjects":payload,"generated_date_shamsi":sh}

def release_grade(grade_id, released_by):
    from utils.jalali import iso_to_jalali
    sh=iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
    with _db() as c:
        c.execute("UPDATE student_grades SET manager_released=1,updated_at=CURRENT_TIMESTAMP WHERE id=?",(grade_id,))
        c.execute("INSERT INTO grade_visibility(grade_id,released_by,released_at_shamsi,released) VALUES(?,?,?,1) ON CONFLICT(grade_id) DO UPDATE SET released_by=excluded.released_by,released_at_shamsi=excluded.released_at_shamsi,released=1",(grade_id,released_by,sh))
        c.commit()
    return True

def growth_trend(student_id):
    with _db() as c:
        return c.execute("""SELECT grade_date_shamsi,
            ROUND(SUM(score*coefficient)/NULLIF(SUM(coefficient),0),2) avg_score
            FROM student_grades WHERE student_id=? GROUP BY grade_date_shamsi ORDER BY id""",(student_id,)).fetchall()
