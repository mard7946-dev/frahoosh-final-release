"""Unified cross-panel school event and message hub.

This module is the single routing layer for Frahoosh.  Student-scoped events
reach the student, the linked parents, and school staff.  School events can
reach the whole school or an explicit role/class/student.  The routing is
account based, so national/student/teacher IDs are internal links rather than
message destinations.
"""
from pathlib import Path
from datetime import datetime
import sqlite3, json
from .audience_service import ensure_schema as ensure_audience_schema, normalize_targets, resolve_targets

DB = Path(__file__).resolve().parents[1] / "school.db"

STUDENT_TABLES = {
    "grades": ("نمره جدید", "student_id"),
    "assignments": ("تکلیف جدید", "student_id"),
    "attendance": ("حضور و غیاب جدید", "student_id"),
    "discipline_records": ("رویداد انضباطی/تشویقی", "student_id"),
    "report_cards": ("کارنامه جدید", "student_id"),
    "counseling_followups": ("پیگیری مشاوره جدید", "student_id"),
    "parent_meetings": ("جلسه/درخواست جلسه جدید", "student_id"),
    "student_registrations": ("ثبت‌نام فعالیت/مسابقه", "student_id"),
    "certificates": ("گواهی جدید", "student_id"),
    "student_cards": ("کارت دانش‌آموزی جدید", "student_id"),
    "class_cards": ("کارت کلاس جدید", "student_id"),
    "class_seats": ("جایگاه کلاس تغییر کرد", "student_id"),
    "exam_cards": ("کارت امتحان جدید", "student_id"),
    "exam_seats": ("صندلی امتحان جدید", "student_id"),
    "payment_transactions": ("تراکنش مالی جدید", "student_id"),
    "vice_referrals": ("ارجاع جدید", "student_id"),
    "vice_attendance_reviews": ("بررسی حضور و غیاب جدید", "student_id"),
    "advisor_workspace": ("ثبت مشاوره/پرونده جدید", "student_id"),
    "archive_items": ("مدرک/بایگانی جدید", "student_id"),
    "student_files": ("پرونده دانش‌آموز به‌روزرسانی شد", "student_id"),
    "online_attendance": ("حضور کلاس مجازی تغییر کرد", "student_id"),
    "online_class_activity": ("فعالیت کلاس مجازی جدید", "student_id"),
    "online_class_ai_reports": ("گزارش هوش مصنوعی کلاس", "student_id"),
    "online_presence_checks": ("حضورسنجی آنلاین جدید", "student_id"),
    "teacher_attendance": ("حضور و غیاب ثبت شد", "student_id"),
    "seating": ("شماره صندلی جدید", "student_id"),
    "teacher_meetings": ("جلسه دبیر و خانواده", "student_id"),
    "cultural_activity_registrations": ("ثبت نام فعالیت جدید", "student_id"),
}
SCHOOL_TABLES = {
    "competitions": ("مسابقه/جشنواره جدید", "school"),
    "cultural_items": ("فعالیت فرهنگی/پرورشی جدید", "school"),
    "exam_schedule": ("برنامه امتحانات جدید", "school"),
    "weekly_schedule": ("برنامه هفتگی جدید", "school"),
    "generated_weekly_schedule": ("برنامه هفتگی جدید", "school"),
    "smart_board_messages": ("اطلاعیه تابلو هوشمند", "school"),
    "surveys": ("نظرسنجی جدید", "school"),
    "online_classes": ("کلاس مجازی جدید", "school"),
    "vice_notifications": ("اطلاع‌رسانی معاونت جدید", "school"),
    "transport_requests": ("درخواست سرویس مدرسه", "school"),
    "school_requests": ("درخواست مدرسه جدید", "school"),
    "executive_requests": ("درخواست اجرایی جدید", "school"),
    "vice_meetings": ("جلسه معاونت جدید", "school"),
    "teacher_classes": ("کلاس دبیر تغییر کرد", "school"),
    "lesson_plans": ("طرح درس جدید", "school"),
    "teacher_exams": ("آزمون دبیر جدید", "school"),
    "executive_operations": ("امور اجرایی جدید", "school"),
    "executive_reports": ("گزارش اجرایی جدید", "school"),
    "cultural_reports": ("گزارش پرورشی جدید", "school"),
    "ai_smart_reports": ("گزارش هوشمند جدید", "school"),
    "smart_board_files": ("فایل جدید تابلو هوشمند", "school"),
    "smart_board_media": ("رسانه جدید تابلو هوشمند", "school"),
    "smart_board_interactive_tools": ("ابزار تعاملی جدید", "school"),
    "online_quizzes": ("آزمون آنلاین جدید", "school"),
}

ROLE_ALIASES = {
    "manager": {"manager", "مدیر", "مدیریت"},
    "vice": {"vice", "معاون", "معاونت", "معاون آموزشی", "معاون اجرایی", "معاون پرورشی", "staff"},
    "teacher": {"teacher", "teachers", "دبیر", "دبیران", "معلم"},
    "advisor": {"advisor", "counselor", "مشاور", "مشاوره"},
    "parent": {"parent", "parents", "اولیا", "ولی", "والد"},
    "student": {"student", "students", "دانش‌آموز", "دانش آموز", "دانش‌آموزان"},
}
STAFF_ROLES = {"manager", "vice", "teacher", "advisor"}

def _repair_schema_before_wal(c):
    """Repair legacy school_events before enabling WAL."""
    table = c.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='school_events'"
    ).fetchone()
    if not table:
        return
    cols = {row[1] for row in c.execute("PRAGMA table_info(school_events)").fetchall()}
    if "remote_id" not in cols:
        c.execute("ALTER TABLE school_events ADD COLUMN remote_id TEXT DEFAULT ''")
    if "remote_synced" not in cols:
        c.execute("ALTER TABLE school_events ADD COLUMN remote_synced INTEGER DEFAULT 0")
    c.execute("DROP INDEX IF EXISTS idx_school_events_remote")
    c.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_school_events_remote "
        "ON school_events(remote_id) WHERE COALESCE(remote_id,'')<>''"
    )
    c.commit()


def conn():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=30000")
    _repair_schema_before_wal(c)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c

def now():
    return datetime.now().isoformat(timespec="seconds")

def _role_match_sql(role_key):
    aliases = sorted(ROLE_ALIASES.get(role_key, {role_key}))
    return "lower(COALESCE(role,'')) IN (" + ",".join("?" for _ in aliases) + ")", aliases

def _role_users(c, role_key):
    clause, args = _role_match_sql(role_key)
    return [r["username"] for r in c.execute(
        f"SELECT username FROM users WHERE COALESCE(username,'')<>'' AND {clause}", args
    ).fetchall()]

def ensure_schema():
    with conn() as c:
        # Repair the historical Smart Board collision: if school_events is a
        # calendar table rather than the unified event hub, move it aside.
        existing = c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='school_events'").fetchone()
        if existing:
            cols = {r["name"] for r in c.execute("PRAGMA table_info(school_events)").fetchall()}
            if "source_table" not in cols and "event_date" in cols:
                c.execute("ALTER TABLE school_events RENAME TO smart_board_school_events")
        c.execute("""CREATE TABLE IF NOT EXISTS school_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_table TEXT NOT NULL, source_id INTEGER,
            event_type TEXT NOT NULL, title TEXT NOT NULL,
            payload TEXT DEFAULT '{}', actor_username TEXT DEFAULT '',
            created_at TEXT NOT NULL, audience_type TEXT DEFAULT 'student',
            audience_value TEXT DEFAULT '',
            remote_id TEXT DEFAULT '',
            remote_synced INTEGER DEFAULT 0
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS event_receipts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL, username TEXT NOT NULL,
            received_at TEXT DEFAULT '', seen_at TEXT DEFAULT '',
            UNIQUE(event_id, username)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_school_events_source ON school_events(source_table,source_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_event_receipts_user ON event_receipts(username,seen_at)")
        # Upgrade older local databases without destroying existing data.
        cols = {r["name"] for r in c.execute("PRAGMA table_info(school_events)").fetchall()}
        if "remote_id" not in cols:
            c.execute("ALTER TABLE school_events ADD COLUMN remote_id TEXT DEFAULT ''")
        if "remote_synced" not in cols:
            c.execute("ALTER TABLE school_events ADD COLUMN remote_synced INTEGER DEFAULT 0")
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_school_events_remote ON school_events(remote_id) WHERE COALESCE(remote_id,'')<>''")
        c.execute("CREATE TABLE IF NOT EXISTS audience_capture(source_table TEXT PRIMARY KEY, targets_json TEXT NOT NULL, created_at TEXT NOT NULL)")
        _install_triggers(c)
        ensure_audience_schema()

def _payload_expr(cols, prefix="NEW"):
    # Keep the full changed row in the event, making the inbox useful for
    # grades, attendance, meetings, competitions, etc.
    pairs = []
    for col in cols:
        pairs.append(repr(col))
        pairs.append(f'{prefix}."{col}"')
    return "json_object(" + ",".join(pairs) + ")" if pairs else "'{}'"

def _install_triggers(c):
    for t, (title, _) in {**STUDENT_TABLES, **SCHOOL_TABLES}.items():
        exists = c.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)
        ).fetchone()
        if not exists:
            continue
        cols = [r["name"] for r in c.execute(f'PRAGMA table_info("{t}")').fetchall()]
        is_student = t in STUDENT_TABLES
        if is_student and "student_id" not in cols:
            continue
        audience = "student" if is_student else "school"
        name_i = "trg_event_i_" + t
        name_u = "trg_event_u_" + t
        legacy = "trg_event_" + t
        c.execute(f'DROP TRIGGER IF EXISTS "{legacy}"')
        c.execute(f'DROP TRIGGER IF EXISTS "{name_i}"')
        c.execute(f'DROP TRIGGER IF EXISTS "{name_u}"')
        payload = _payload_expr(cols)
        if audience == "student":
            aud_expr = "COALESCE(CAST(NEW.student_id AS TEXT),'')"
        else:
            aud_expr = "'all'"
        capture_exists = f"EXISTS(SELECT 1 FROM audience_capture WHERE source_table='{t}')"
        capture_value = f"COALESCE((SELECT targets_json FROM audience_capture WHERE source_table='{t}'),'')"
        c.execute(f"""CREATE TRIGGER "{name_i}" AFTER INSERT ON "{t}" BEGIN
            INSERT INTO school_events(source_table,source_id,event_type,title,payload,created_at,audience_type,audience_value)
            VALUES('{t}',NEW.id,'data_insert','{title}',{payload},CURRENT_TIMESTAMP,
              CASE WHEN {capture_exists} THEN 'explicit' ELSE '{audience}' END,
              CASE WHEN {capture_exists} THEN {capture_value} ELSE {aud_expr} END);
        END""")
        c.execute(f"""CREATE TRIGGER "{name_u}" AFTER UPDATE ON "{t}" BEGIN
            INSERT INTO school_events(source_table,source_id,event_type,title,payload,created_at,audience_type,audience_value)
            VALUES('{t}',NEW.id,'data_update','{title} - به‌روزرسانی', {payload},CURRENT_TIMESTAMP,
              CASE WHEN {capture_exists} THEN 'explicit' ELSE '{audience}' END,
              CASE WHEN {capture_exists} THEN {capture_value} ELSE {aud_expr} END);
        END""")

def _student_accounts(c, sid):
    out = [r["username"] for r in c.execute(
        "SELECT username FROM users WHERE linked_student_id=? AND COALESCE(username,'')<>''", (sid,)
    ).fetchall()]
    try:
        out += [r["parent_username"] for r in c.execute(
            "SELECT parent_username FROM parent_children WHERE student_id=?", (sid,)
        ).fetchall() if r["parent_username"]]
    except Exception:
        pass
    try:
        out += [r["username"] for r in c.execute(
            "SELECT username FROM users WHERE lower(COALESCE(role,'')) IN ('parent','parents','اولیا','ولی','والد') AND linked_student_id=? AND COALESCE(username,'')<>''", (sid,)
        ).fetchall()]
    except Exception:
        pass
    return list(dict.fromkeys(out))

def _school_accounts(c):
    return [r["username"] for r in c.execute(
        "SELECT username FROM users WHERE COALESCE(username,'')<>''"
    ).fetchall()]

def recipients_for_event(c, event):
    audience = (event["audience_type"] or "").lower()
    value = str(event["audience_value"] or "")
    # Explicit audience selections always win over automatic routing.
    try:
        selected = c.execute(
            "SELECT target_type,target_value FROM event_audiences WHERE event_id=? ORDER BY id",
            (event["id"],)
        ).fetchall()
        if selected:
            return resolve_targets([(r["target_type"], r["target_value"]) for r in selected], c)
    except sqlite3.Error:
        pass
    if audience == "explicit":
        try:
            targets = json.loads(value) if value else []
            return resolve_targets(targets, c)
        except Exception:
            return []
    if audience == "student" and value.isdigit():
        # Student + linked parents + ALL school staff.
        out = _student_accounts(c, int(value))
        for role in STAFF_ROLES:
            out += _role_users(c, role)
        return list(dict.fromkeys(out))
    if audience == "class":
        rows = c.execute("SELECT id FROM students WHERE class_name=?", (value,)).fetchall()
        out = []
        for r in rows:
            out += _student_accounts(c, r["id"])
        for role in STAFF_ROLES:
            out += _role_users(c, role)
        return list(dict.fromkeys(out))
    if audience == "role":
        # target value can be a canonical key or a Persian role.
        key = next((k for k, vals in ROLE_ALIASES.items() if value.lower() in {x.lower() for x in vals}), value)
        return _role_users(c, key)
    if audience == "school":
        return _school_accounts(c)
    if audience == "parent":
        return _role_users(c, "parent")
    return []

def _materialize_receipts(c, event):
    for username in recipients_for_event(c, event):
        c.execute(
            "INSERT OR IGNORE INTO event_receipts(event_id,username) VALUES(?,?)",
            (event["id"], username)
        )

def _ensure_all_receipts(c):
    rows = c.execute("SELECT * FROM school_events ORDER BY id DESC LIMIT 2000").fetchall()
    for event in rows:
        _materialize_receipts(c, event)

def inbox(username, limit=100, unread_only=False):
    ensure_schema()
    try:
        from .remote_sync_service import sync_user
        sync_user(username)
    except Exception:
        pass
    with conn() as c:
        _ensure_all_receipts(c)
        sql = """SELECT e.*,er.received_at,er.seen_at
                 FROM school_events e JOIN event_receipts er ON er.event_id=e.id
                 WHERE er.username=?"""
        args = [username]
        if unread_only:
            sql += " AND COALESCE(er.seen_at,'')=''"
        sql += " ORDER BY e.id DESC LIMIT ?"
        args.append(limit)
        rows = c.execute(sql, args).fetchall()
        result = [dict(r) for r in rows]
        stamp = now()
        for x in result:
            if not x.get("received_at"):
                c.execute(
                    "UPDATE event_receipts SET received_at=? WHERE event_id=? AND username=?",
                    (stamp, x["id"], username)
                )
                x["received_at"] = stamp
        c.commit()
        return result

def inbox_for_role(role_key, limit=100, unread_only=False):
    ensure_schema()
    with conn() as c:
        users = _role_users(c, role_key)
        if not users:
            return []
        _ensure_all_receipts(c)
        placeholders = ",".join("?" for _ in users)
        sql = f"""SELECT e.*, MIN(er.received_at) received_at, MIN(er.seen_at) seen_at
                  FROM school_events e JOIN event_receipts er ON er.event_id=e.id
                  WHERE er.username IN ({placeholders})"""
        args = list(users)
        if unread_only:
            sql += " AND COALESCE(er.seen_at,'')=''"
        sql += " GROUP BY e.id ORDER BY e.id DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in c.execute(sql, args).fetchall()]

def mark_seen(username, event_id):
    ensure_schema()
    with conn() as c:
        stamp = now()
        c.execute(
            "INSERT OR IGNORE INTO event_receipts(event_id,username,received_at,seen_at) VALUES(?,?,?,?)",
            (event_id, username, stamp, stamp)
        )
        c.execute(
            "UPDATE event_receipts SET received_at=COALESCE(NULLIF(received_at,''),?),seen_at=? "
            "WHERE event_id=? AND username=?",
            (stamp, stamp, event_id, username)
        )
        c.commit()

def sender_delivery(event_id):
    ensure_schema()
    with conn() as c:
        rows = c.execute(
            "SELECT username,received_at,seen_at FROM event_receipts WHERE event_id=? ORDER BY username",
            (event_id,)
        ).fetchall()
        return [{"username":r["username"],
                 "status":"دیده شد" if r["seen_at"] else ("دریافت شد" if r["received_at"] else "در انتظار دریافت"),
                 "received_at":r["received_at"],"seen_at":r["seen_at"]} for r in rows]

def publish(source_table, source_id, title, payload=None, audience_type="school",
            audience_value="all", actor_username="", audiences=None):
    """Publish one event. If audiences is supplied, it is the authoritative
    recipient list selected by the user before final publication."""
    ensure_schema()
    selected = normalize_targets(audiences or [])
    with conn() as c:
        cur = c.execute(
            """INSERT INTO school_events(source_table,source_id,event_type,title,payload,
               actor_username,created_at,audience_type,audience_value)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (source_table, source_id, "manual", title,
             json.dumps(payload or {}, ensure_ascii=False), actor_username, now(),
             "explicit" if selected else audience_type,
             json.dumps(selected, ensure_ascii=False) if selected else str(audience_value or ""))
        )
        eid = cur.lastrowid
        if selected:
            stamp = now()
            for t, v in selected:
                c.execute(
                    "INSERT OR IGNORE INTO event_audiences(event_id,target_type,target_value,created_at) VALUES(?,?,?,?)",
                    (eid, t, v, stamp)
                )
        event = {"id": eid, "audience_type": "explicit" if selected else audience_type,
                 "audience_value": json.dumps(selected, ensure_ascii=False) if selected else audience_value}
        _materialize_receipts(c, event)
        c.commit()
        return eid


def publish_selected(source_table, source_id, title, payload=None, audiences=None, actor_username=""):
    return publish(source_table, source_id, title, payload, audiences=audiences, actor_username=actor_username)
