from __future__ import annotations
import csv
import sqlite3
from pathlib import Path
from datetime import datetime

DB = Path(__file__).resolve().parents[1] / 'school.db'


def snapshot():
    conn = sqlite3.connect(DB)
    tables = [
        ('students','دانش‌آموزان'),('teachers','دبیران'),('staff','کارکنان'),
        ('grades','نمرات'),('attendance','حضور و غیاب'),('assignments','تکالیف'),
        ('online_classes','کلاس‌های مجازی'),('online_quizzes','آزمون‌های آنلاین'),
        ('quiz_questions','سؤالات آزمون'),('student_registrations','ثبت‌نام فعالیت‌ها'),
        ('payment_transactions','تراکنش‌های پرداخت'),('executive_classes','کلاس‌ها'),
        ('seating','شماره صندلی'),('student_cards','کارت‌ها'),('certificates','گواهی‌ها'),
        ('report_cards','کارنامه‌ها'),('assets','اموال'),('archive_items','بایگانی'),
        ('executive_requests','درخواست‌ها'),('counseling_followups','پرونده‌های مشاوره'),
    ]
    out=[]
    for name,label in tables:
        exists=conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(name,)).fetchone()
        count=conn.execute(f'SELECT COUNT(*) FROM {name}').fetchone()[0] if exists else 0
        out.append((label,count))
    conn.close(); return out


def save_csv(path: str):
    rows=snapshot()
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(['شاخص','تعداد','تاریخ'])
        now=datetime.now().isoformat(timespec='seconds')
        for label,count in rows:w.writerow([label,count,now])
    return path
