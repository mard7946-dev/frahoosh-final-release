from database.db import get_connection


class DashboardService:
    """
    سرویس اطلاعات آماری داشبورد فراهوش
    """

    @staticmethod
    def get_statistics():

        conn = get_connection()

        try:

            cursor = conn.cursor()


            # تعداد دانش آموزان
            cursor.execute(
                """
                SELECT COUNT(*)
                FROM students
                """
            )

            students = cursor.fetchone()[0]



            # تعداد دبیران
            cursor.execute(
                """
                SELECT COUNT(*)
                FROM teachers
                """
            )

            teachers = cursor.fetchone()[0]



            # تعداد کلاس های آنلاین
            cursor.execute(
                """
                SELECT COUNT(*)
                FROM online_classes
                """
            )

            classes = cursor.fetchone()[0]



            # حضور امروز
            cursor.execute(
                """
                SELECT
                COUNT(*)
                FROM attendance
                WHERE status='حاضر'
                """
            )

            present = cursor.fetchone()[0]



            cursor.execute(
                """
                SELECT COUNT(*)
                FROM attendance
                """
            )

            total_attendance = cursor.fetchone()[0]



            if total_attendance > 0:

                attendance = int(
                    (present / total_attendance) * 100
                )

            else:

                attendance = 0



            return {

                "students": str(students),

                "teachers": str(teachers),

                "classes": str(classes),

                "attendance": f"{attendance}%"

            }



        finally:

            conn.close()

            print("DashboardService LOADED")