from PySide6.QtWidgets import QHBoxLayout,QPushButton,QLineEdit,QMessageBox,QDialog,QFormLayout,QDialogButtonBox
from PySide6.QtCore import Qt

def add_toolbar(widget, layout, home_callback=None, edit_callback=None, title=''):
    bar=QHBoxLayout()
    search=QLineEdit(); search.setPlaceholderText('جستجو...')
    bar.addWidget(search)
    if edit_callback:
        b=QPushButton('ویرایش'); b.clicked.connect(lambda: edit_callback()); bar.addWidget(b)
    if home_callback:
        b=QPushButton('بازگشت به صفحه اصلی'); b.clicked.connect(home_callback); bar.addWidget(b)
    layout.insertLayout(0,bar)
    widget._panel_search=search
    return search

def edit_dialog(parent,title,fields,values=None):
    d=QDialog(parent); d.setWindowTitle(title); f=QFormLayout(d); widgets={}
    for key,label in fields:
        w=QLineEdit(); w.setText('' if values is None else str(values.get(key,'') or '')); widgets[key]=w; f.addRow(label,w)
    box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); f.addWidget(box); box.accepted.connect(d.accept); box.rejected.connect(d.reject)
    return d,widgets
