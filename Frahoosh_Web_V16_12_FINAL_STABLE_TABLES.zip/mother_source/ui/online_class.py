from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QColorDialog,
    QMessageBox,
    QComboBox,
    QListWidget,
    QTextEdit,
    QSpinBox,
)

from PySide6.QtCore import Qt, QTimer

from ui.smart_board import SmartBoard
from ui.online_quiz import OnlineQuiz
from ui.smart_attendance import SmartAttendance
from ui.activity_analysis import ActivityAnalysis


class OnlineClassRoom(QWidget):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("کلاس آنلاین هوشمند فراهوش")

        self.setLayoutDirection(Qt.RightToLeft)

        self.pen_color = "#000000"
        self.pages_limit = 10
        self.current_page = 1

        self.setup_ui()
        self.start_monitoring()


    def setup_ui(self):

        main_layout = QVBoxLayout()
        main_layout.setSpacing(10)


        # ---------------- HEADER ----------------

        header = QFrame()
        header.setObjectName("header")

        header_layout = QHBoxLayout(header)


        self.title = QLabel(
            "کلاس آنلاین هوشمند فراهوش"
        )

        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)


        self.status = QLabel(
            "وضعیت کلاس: آماده شروع"
        )

        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)


        header_layout.addWidget(self.status)
        header_layout.addWidget(self.title)



        main_layout.addWidget(header)



        # ---------------- CONTROL PANEL ----------------


        control_panel = QFrame()

        control_layout = QHBoxLayout(control_panel)



        self.start_btn = QPushButton(
            "شروع کلاس"
        )

        self.end_btn = QPushButton(
            "پایان کلاس"
        )


        self.color_btn = QPushButton(
            "انتخاب رنگ قلم"
        )


        self.page_counter = QLabel(
            "صفحه 1 از 10"
        )


        self.page_box = QSpinBox()
        self.page_box.setRange(
            1,
            10
        )



        control_layout.addWidget(
            self.end_btn
        )

        control_layout.addWidget(
            self.start_btn
        )

        control_layout.addWidget(
            self.color_btn
        )

        control_layout.addWidget(
            self.page_counter
        )

        control_layout.addWidget(
            self.page_box
        )


        main_layout.addWidget(
            control_panel
        )



        # ---------------- MAIN AREA ----------------


        body_layout = QHBoxLayout()



        # تخته هوشمند

        self.board = SmartBoard()

        board_frame = QFrame()

        board_layout = QVBoxLayout(
            board_frame
        )

        board_layout.addWidget(
            self.board
        )



        # پنل سمت راست

        side_panel = QFrame()

        side_layout = QVBoxLayout(
            side_panel
        )


        self.users_list = QListWidget()

        self.users_list.addItem(
            "لیست کاربران کلاس"
        )


        self.message_box = QTextEdit()

        self.message_box.setPlaceholderText(
            "پیام برای کلاس..."
        )



        side_layout.addWidget(
            QLabel("دانش‌آموزان حاضر")
        )

        side_layout.addWidget(
            self.users_list
        )


        side_layout.addWidget(
            self.message_box
        )



        body_layout.addWidget(
            side_panel
        )


        body_layout.addWidget(
            board_frame
        )



        main_layout.addLayout(
            body_layout
        )



        self.setLayout(
            main_layout
        )



        self.connect_events()




    # ---------------- EVENTS ----------------

    def connect_events(self):

        self.start_btn.clicked.connect(
            self.start_class
        )

        self.end_btn.clicked.connect(
            self.end_class
        )

        self.color_btn.clicked.connect(
            self.change_pen_color
        )


        self.page_box.valueChanged.connect(
            self.change_page
        )



    # ---------------- START CLASS ----------------

    def start_class(self):

        self.status.setText(
            "وضعیت کلاس: در حال برگزاری 🟢"
        )


        self.users_list.clear()

        self.users_list.addItem(
            "مدیر کلاس"
        )

        self.users_list.addItem(
            "دانش‌آموزان متصل..."
        )


        QMessageBox.information(
            self,
            "شروع کلاس",
            "کلاس آنلاین فراهوش آغاز شد"
        )



        self.class_time = 0



    # ---------------- END CLASS ----------------

    def end_class(self):

        self.status.setText(
            "وضعیت کلاس: پایان یافته 🔴"
        )


        QMessageBox.information(
            self,
            "پایان کلاس",
            "کلاس آنلاین به پایان رسید"
        )



    # ---------------- PEN COLOR ----------------

    def change_pen_color(self):

        color = QColorDialog.getColor()


        if color.isValid():

            self.pen_color = color.name()


            try:

                self.board.set_pen_color(
                    self.pen_color
                )

            except:

                pass



    # ---------------- PAGE MANAGEMENT ----------------

    def change_page(self, value):

        self.current_page = value


        self.page_counter.setText(
            f"صفحه {value} از {self.pages_limit}"
        )


        try:

            self.board.change_page(
                value
            )

        except:

            pass



    # ---------------- CLASS MONITORING ----------------

    def start_monitoring(self):

        self.timer = QTimer()


        self.timer.timeout.connect(
            self.monitor_class
        )


        self.timer.start(
            60000
        )



    def monitor_class(self):

        try:

            self.class_time += 1


        except:

            self.class_time = 0



        # بعد از 50 دقیقه کلاس بسته شود

        if self.class_time >= 50:

            self.end_class()


    # ---------------- ONLINE QUIZ ----------------

    def open_quiz(self):

        try:

            self.quiz_window = OnlineQuiz()

            self.quiz_window.show()


        except Exception as e:

            QMessageBox.warning(
                self,
                "خطای آزمون",
                str(e)
            )



    # ---------------- SMART ATTENDANCE ----------------

    def open_attendance(self):

        try:

            self.attendance_window = SmartAttendance()

            self.attendance_window.show()


        except Exception as e:

            QMessageBox.warning(
                self,
                "خطای حضور و غیاب",
                str(e)
            )



    # ---------------- ACTIVITY ANALYSIS ----------------

    def open_activity_analysis(self):

        try:

            self.activity_window = ActivityAnalysis()

            self.activity_window.show()


        except Exception as e:

            QMessageBox.warning(
                self,
                "خطای تحلیل فعالیت",
                str(e)
            )



    # ---------------- STUDENT ACTIVITY MONITOR ----------------

    def check_students_activity(self):

        """
        بررسی وضعیت فعالیت دانش آموزان

        در نسخه اولیه:
        - دانش آموز فعال
        - دانش آموز کم فعالیت
        - دانش آموز آفلاین

        در نسخه بعدی به هوش مصنوعی وصل می‌شود.
        """


        inactive_students = []


        # نمونه اولیه داده

        if len(inactive_students) > 0:


            for student in inactive_students:


                self.users_list.addItem(
                    f"⚠ {student} غیرفعال است"
                )



    # ---------------- REPORT TO SCHOOL ----------------

    def send_class_report(self):

        report = {

            "class":
            "کلاس آنلاین فراهوش",

            "duration":
            self.class_time,

            "pages":
            self.current_page,

            "students":
            self.users_list.count()

        }



        print(
            "CLASS REPORT:",
            report
        )



    # ---------------- CLOSE SESSION ----------------

    def close_session(self):

        self.send_class_report()


        self.status.setText(
            "جلسه ذخیره و بسته شد"
        )


        try:

            self.timer.stop()

        except:

            pass



    # ---------------- STYLE ----------------

    def setStyleSheet(self):

        self.setStyleSheet("""

        QWidget {

            font-family: Tahoma;
            font-size: 14px;

        }


        QFrame {

            border-radius: 12px;

        }


        QPushButton {

            padding: 8px;
            border-radius: 8px;

        }


        QListWidget {

            padding: 5px;

        }

        """)


    # ---------------- SMART BOARD TOOLS ----------------

    def enable_pen(self):

        try:

            self.board.set_mode(
                "pen"
            )

        except:

            pass



    def enable_eraser(self):

        try:

            self.board.set_mode(
                "eraser"
            )

        except:

            pass



    def draw_line(self):

        try:

            self.board.set_mode(
                "line"
            )

        except:

            pass



    def draw_rectangle(self):

        try:

            self.board.set_mode(
                "rectangle"
            )

        except:

            pass



    def draw_circle(self):

        try:

            self.board.set_mode(
                "circle"
            )

        except:

            pass



    def draw_triangle(self):

        try:

            self.board.set_mode(
                "triangle"
            )

        except:

            pass



    # ---------------- WHITEBOARD SAVE ----------------


    def save_board_page(self):

        try:

            file_name = (
                f"online_board_page_{self.current_page}.png"
            )


            self.board.save_image(
                file_name
            )


            QMessageBox.information(
                self,
                "ذخیره تخته",
                "صفحه تخته ذخیره شد"
            )


        except Exception as e:


            QMessageBox.warning(
                self,
                "خطا",
                str(e)
            )



    # ---------------- CLEAR PAGE ----------------


    def clear_current_page(self):

        try:

            self.board.clear_page()


        except:

            pass



    # ---------------- UNDO / REDO ----------------


    def undo_board(self):

        try:

            self.board.undo()


        except:

            pass



    def redo_board(self):

        try:

            self.board.redo()


        except:

            pass



    # ---------------- EMOJI EDUCATIONAL TOOLS ----------------


    def add_math_symbol(self, symbol):

        try:

            self.board.add_text(
                symbol
            )

        except:

            pass



    # ---------------- SESSION DATA ----------------


    def get_session_info(self):

        return {

            "title":
            "کلاس آنلاین هوشمند فراهوش",


            "page":
            self.current_page,


            "max_pages":
            self.pages_limit,


            "time":
            self.class_time,


            "students":
            self.users_list.count()

        }
    
    # ---------------- TOOLBAR CREATION ----------------

    def create_board_toolbar(self):

        toolbar = QFrame()

        toolbar_layout = QVBoxLayout(
            toolbar
        )


        toolbar_title = QLabel(
            "ابزارهای تخته هوشمند"
        )

        toolbar_title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        toolbar_layout.addWidget(
            toolbar_title
        )



        # قلم

        self.pen_btn = QPushButton(
            "🖊 قلم"
        )

        self.pen_btn.clicked.connect(
            self.enable_pen
        )



        # پاک کن

        self.eraser_btn = QPushButton(
            "🧽 پاک‌کن"
        )

        self.eraser_btn.clicked.connect(
            self.enable_eraser
        )



        # خط

        self.line_btn = QPushButton(
            "📏 خط"
        )

        self.line_btn.clicked.connect(
            self.draw_line
        )



        # مربع

        self.rect_btn = QPushButton(
            "⬜ مربع"
        )

        self.rect_btn.clicked.connect(
            self.draw_rectangle
        )



        # دایره

        self.circle_btn = QPushButton(
            "⭕ دایره"
        )

        self.circle_btn.clicked.connect(
            self.draw_circle
        )



        # مثلث

        self.triangle_btn = QPushButton(
            "🔺 مثلث"
        )

        self.triangle_btn.clicked.connect(
            self.draw_triangle
        )



        # ذخیره

        self.save_btn = QPushButton(
            "💾 ذخیره صفحه"
        )

        self.save_btn.clicked.connect(
            self.save_board_page
        )



        # پاک کردن

        self.clear_btn = QPushButton(
            "🗑 پاک کردن"
        )

        self.clear_btn.clicked.connect(
            self.clear_current_page
        )



        # برگشت

        self.undo_btn = QPushButton(
            "↩ برگشت"
        )

        self.undo_btn.clicked.connect(
            self.undo_board
        )



        # جلو

        self.redo_btn = QPushButton(
            "↪ جلو"
        )

        self.redo_btn.clicked.connect(
            self.redo_board
        )



        buttons = [

            self.pen_btn,
            self.eraser_btn,
            self.line_btn,
            self.rect_btn,
            self.circle_btn,
            self.triangle_btn,
            self.save_btn,
            self.clear_btn,
            self.undo_btn,
            self.redo_btn

        ]



        for btn in buttons:

            toolbar_layout.addWidget(
                btn
            )



        return toolbar



    # ---------------- EXTRA CLASS BUTTONS ----------------


    def create_class_tools(self):

        tools = QFrame()

        layout = QHBoxLayout(
            tools
        )


        self.quiz_btn = QPushButton(
            "📝 آزمون آنلاین"
        )

        self.quiz_btn.clicked.connect(
            self.open_quiz
        )



        self.attendance_btn = QPushButton(
            "👥 حضور و غیاب هوشمند"
        )

        self.attendance_btn.clicked.connect(
            self.open_attendance
        )



        self.analysis_btn = QPushButton(
            "📊 تحلیل فعالیت"
        )

        self.analysis_btn.clicked.connect(
            self.open_activity_analysis
        )



        layout.addWidget(
            self.analysis_btn
        )


        layout.addWidget(
            self.attendance_btn
        )


        layout.addWidget(
            self.quiz_btn
        )


        return tools
    

    # ---------------- UPDATE MAIN LAYOUT ----------------

    def build_professional_layout(self):

        container = QFrame()

        container_layout = QHBoxLayout(
            container
        )


        # ابزارهای تخته

        toolbar = self.create_board_toolbar()


        # خود تخته

        board_area = QFrame()

        board_layout = QVBoxLayout(
            board_area
        )


        board_layout.addWidget(
            self.board
        )



        # پنل اطلاعات کلاس

        info_panel = QFrame()

        info_layout = QVBoxLayout(
            info_panel
        )


        info_title = QLabel(
            "مدیریت کلاس آنلاین"
        )


        self.connection_status = QLabel(
            "اتصال: آماده"
        )


        self.student_count = QLabel(
            "تعداد کاربران: 0"
        )


        self.class_clock = QLabel(
            "زمان کلاس: 00:00"
        )



        info_layout.addWidget(
            info_title
        )

        info_layout.addWidget(
            self.connection_status
        )

        info_layout.addWidget(
            self.student_count
        )

        info_layout.addWidget(
            self.class_clock
        )



        info_layout.addStretch()



        # ترتیب RTL

        container_layout.addWidget(
            info_panel
        )


        container_layout.addWidget(
            board_area,
            5
        )


        container_layout.addWidget(
            toolbar
        )


        return container



    # ---------------- CLOCK UPDATE ----------------

    def update_class_clock(self):

        try:

            minutes = self.class_time // 60

            seconds = self.class_time % 60


            self.class_clock.setText(
                f"زمان کلاس: {minutes:02}:{seconds:02}"
            )


        except:

            pass



    # ---------------- UPDATE USERS ----------------

    def update_student_count(self):

        try:

            count = self.users_list.count()


            self.student_count.setText(
                f"تعداد کاربران: {count}"
            )


        except:

            pass



    # ---------------- CLASS SECURITY ----------------

    def check_connection(self):

        """
        بررسی وضعیت اتصال کاربران

        در نسخه اولیه:
        وضعیت آماده

        در نسخه کامل:
        اتصال شبکه و سرور مدرسه
        """

        self.connection_status.setText(
            "اتصال: فعال 🟢"
        )