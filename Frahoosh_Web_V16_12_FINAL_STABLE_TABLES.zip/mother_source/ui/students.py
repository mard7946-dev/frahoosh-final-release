from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QFileDialog,
    QMessageBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

from database.db import get_connection

import os
import shutil

print("RUNNING NEW STUDENTS FILE")



class Students(QWidget):

    def save_student(self):
        print("SAVE STUDENT FOUND")

    def __init__(self):

        super().__init__()


        self.setWindowTitle(
            "مدیریت دانش‌آموزان فراهوش"
        )


        self.resize(
            1350,
            750
        )


        self.old_code = None


        self.photo_path = ""


        self.ui()



    def ui(self):


        layout = QVBoxLayout(self)



        title = QLabel(
            """
            👨‍🎓 مدیریت دانش‌آموزان
            <span style="color:#239f40;">فرا</span>
            <span style="color:#333333;">هو</span>
            <span style="color:#da0000;">ش</span>
            """
        )

        title.setTextFormat(Qt.RichText)   


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setStyleSheet("""
        QLabel {
            font-family: Tahoma;
            font-size:28px;
            color:#0D47A1;
            font-weight:bold;
            padding:15px;
        }
    """)


        layout.addWidget(
            title
        )



        # =========================
        # فیلدهای اطلاعات دانش آموز
        # =========================


        self.inputs = []


        fields = [

            "نام",

            "نام خانوادگی",

            "کد ملی",

            "شماره دانش‌آموزی",

            "تاریخ تولد",

            "پایه",

            "کلاس",

            "نام پدر",

            "نام مادر",

            "تلفن ولی",

            "ایمیل",

            "شماره صندلی کلاس",

            "آدرس",

            "توضیحات"

        ]



        form = QGridLayout()



        row = 0

        col = 0



        for field in fields:


            box = QLineEdit()


            box.setPlaceholderText(
                field
            )


            box.setMinimumHeight(
                35
            )


            box.setStyleSheet("""
            QLineEdit {
                font-family: Tahoma;
                font-size:14px;
                padding:8px;
                border:1px solid #90CAF9;
                border-radius:8px;
                background:#FAFAFA;
            }

            QLineEdit:focus {
                border:2px solid #1976D2;
            }
        """)


            self.inputs.append(
                box
            )


            form.addWidget(
                box,
                row,
                col
            )



            col += 1



            if col == 2:

                col = 0

                row += 1



        layout.addLayout(
            form
        )



        # =========================
        # بخش عکس
        # =========================


        photo_layout = QHBoxLayout()



        self.photo_label = QLabel(
            "بدون عکس"
        )


        self.photo_label.setFixedSize(
            120,
            120
        )


        self.photo_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.photo_label.setStyleSheet("""
            border:2px solid #2196F3;
            border-radius:12px;
            background:#eeeeee;
        """)



        photo_btn = QPushButton(
            "🖼 انتخاب عکس"
        )


        photo_btn.clicked.connect(
            self.select_photo
        )



        photo_layout.addWidget(
            self.photo_label
        )


        photo_layout.addWidget(
            photo_btn
        )


        photo_layout.addStretch()



        layout.addLayout(
            photo_layout
        )



        # =========================
        # دکمه‌های عملیات
        # =========================

        button_layout = QHBoxLayout()


        save_btn = QPushButton("💾 ثبت دانش‌آموز")
        save_btn.clicked.connect(self.save_student)


        edit_btn = QPushButton("✏️ ویرایش")
        edit_btn.clicked.connect(self.update_student)


        excel_btn = QPushButton("📥 ورود از Excel")
        excel_btn.clicked.connect(self.import_excel)


        clear_btn = QPushButton("🧹 پاک کردن")
        clear_btn.clicked.connect(self.clear_form)


        # =========================
        # طراحی حرفه‌ای دکمه‌ها
        # =========================

        save_btn.setStyleSheet("""
        QPushButton {
            background-color: #27ae60;
            color: white;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        QPushButton:hover {
            background-color: #2ecc71;
        }
        """)


        edit_btn.setStyleSheet("""
        QPushButton {
            background-color: #2980b9;
            color: white;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        QPushButton:hover {
            background-color: #3498db;
        }
        """)


        excel_btn.setStyleSheet("""
        QPushButton {
            background-color: #f39c12;
            color: white;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        QPushButton:hover {
            background-color: #f1c40f;
        }
        """)


        clear_btn.setStyleSheet("""
        QPushButton {
            background-color: #c0392b;
            color: white;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        QPushButton:hover {
            background-color: #e74c3c;
        }
        """)

        for btn in [
            save_btn,
            edit_btn,
            excel_btn,
            clear_btn
        ]:

            btn.setFixedWidth(150)
            btn.setMinimumHeight(45)
            button_layout.addWidget(btn)


        layout.addLayout(button_layout)



    def import_excel(self):

        file, _ = QFileDialog.getOpenFileName(
            self,
            "انتخاب فایل Excel",
            "",
            "Excel Files (*.xlsx)"
        )


        if not file:
            return


        try:

            import openpyxl


            wb = openpyxl.load_workbook(
                file
            )

            sheet = wb.active


            conn = get_connection()

            cursor = conn.cursor()


            for row in sheet.iter_rows(
                min_row=2,
                values_only=True
            ):

                cursor.execute("""
                INSERT INTO students
                (
                first_name,
                last_name,
                national_code,
                student_code,
                grade,
                class_name,
                father_name,
                parent_phone
                )
                VALUES (?,?,?,?,?,?,?,?)
                """, row[:8])


            conn.commit()

            conn.close()


            QMessageBox.information(
                self,
                "موفق",
                "دانش‌آموزان از Excel وارد شدند"
            )


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                str(e)
            )



        # =========================
        # جدول دانش آموزان
        # =========================


        self.table = QTableWidget()


        self.table.setColumnCount(
            15
        )

        # =========================
        # طراحی حرفه‌ای جدول
        # =========================

        self.table.setStyleSheet("""
        QTableWidget {
            font-family: Tahoma;
            font-size: 13px;
            background-color: #ffffff;
            border: 1px solid #90CAF9;
            border-radius: 8px;
        }

        QTableWidget::item {
            padding: 6px;
        }

        QHeaderView::section {
            background-color: #1565C0;
            color: white;
            font-size: 14px;
            font-weight: bold;
            padding: 8px;
            border: none;
        }

        QTableWidget::item:selected {
            background-color: #BBDEFB;
            color: black;
        }
        """)


        self.table.verticalHeader().setDefaultSectionSize(35)


        self.table.setHorizontalHeaderLabels(

            [

                "نام",

                "نام خانوادگی",

                "کد ملی",

                "شماره دانش‌آموزی",

                "تولد",

                "پایه",

                "کلاس",

                "نام پدر",

                "نام مادر",

                "تلفن ولی",

                "ایمیل",

                "صندلی",

                "آدرس",

                "توضیحات",

                "عکس"

            ]

        )



        self.table.cellClicked.connect(
            self.select_row
        )


        self.table.horizontalHeader().setStretchLastSection(
            True
        )


        layout.addWidget(
            self.table
        )


        self.load_students()

    # =========================
    # انتخاب عکس دانش آموز
    # =========================


    def select_photo(self):


        file, _ = QFileDialog.getOpenFileName(

            self,

            "انتخاب عکس دانش‌آموز",

            "",

            "Images (*.png *.jpg *.jpeg)"

        )



        if file:


            os.makedirs(

                "students_images",

                exist_ok=True

            )



            filename = os.path.basename(
                file
            )



            destination = os.path.join(

                "students_images",

                filename

            )



            shutil.copy(

                file,

                destination

            )



            self.photo_path = destination



            pixmap = QPixmap(

                destination

            )



            self.photo_label.setPixmap(

                pixmap.scaled(

                    110,

                    110,

                    Qt.KeepAspectRatio

                )

            )



    # =========================
    # ثبت دانش آموز
    # =========================


    def add_student(self):


        con = get_connection()

        cur = con.cursor()



        cur.execute(

            """

            INSERT INTO students

            (

            first_name,

            last_name,

            national_code,

            student_code,

            birth_date,

            grade,

            class_name,

            father_name,

            mother_name,

            parent_phone,

            address,

            email,

            photo,

            description,

            seat_number

            )


            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)

            """,


            (

            self.inputs[0].text(),

            self.inputs[1].text(),

            self.inputs[2].text(),

            self.inputs[3].text(),

            self.inputs[4].text(),

            self.inputs[5].text(),

            self.inputs[6].text(),

            self.inputs[7].text(),

            self.inputs[8].text(),

            self.inputs[9].text(),

            self.inputs[12].text(),

            self.inputs[10].text(),

            self.photo_path,

            self.inputs[13].text(),

            self.inputs[11].text()

            )

        )



        con.commit()


        con.close()



        self.load_students()



        QMessageBox.information(

            self,

            "فراهوش",

            "دانش‌آموز با موفقیت ثبت شد"

        )


    def save_student(self):
        self.add_student()


    def clear_form(self):

        for item in self.inputs:
            item.clear()

        self.photo_path = ""



    # =========================
    # نمایش اطلاعات در جدول
    # =========================


    def load_students(self):


        con = get_connection()

        cur = con.cursor()



        cur.execute(

            """

            SELECT

            first_name,

            last_name,

            national_code,

            student_code,

            birth_date,

            grade,

            class_name,

            father_name,

            mother_name,

            parent_phone,

            email,

            seat_number,

            address,

            description,

            photo

            FROM students

            """

        )


        data = cur.fetchall()



        con.close()



        self.table.clearContents()



        self.table.setRowCount(

            len(data)

        )



        for row, item in enumerate(data):


            for col, value in enumerate(item):


                self.table.setItem(

                    row,

                    col,

                    QTableWidgetItem(

                        str(value)

                    )

                )

    # =========================
    # انتخاب سطر جدول
    # =========================

    def select_row(self, row, col):

        self.old_code = self.table.item(
            row,
            2
        ).text()

        for i in range(14):

            self.inputs[i].setText(
                self.table.item(row, i).text()
            )

        photo = self.table.item(
            row,
            14
        ).text()

        if photo and os.path.exists(photo):

            pixmap = QPixmap(photo)

            self.photo_label.setPixmap(

                pixmap.scaled(

                    110,

                    110,

                    Qt.KeepAspectRatio

                )

            )

            self.photo_path = photo



    # =========================
    # ویرایش
    # =========================

    def edit_student(self):

        if not self.old_code:

            QMessageBox.warning(

                self,

                "فراهوش",

                "ابتدا یک دانش‌آموز را انتخاب کنید."

            )

            return


        QMessageBox.information(

            self,

            "فراهوش",

            "اطلاعات را تغییر دهید و سپس روی «ثبت تغییرات» کلیک کنید."

        )



    # =========================
    # ثبت تغییرات
    # =========================

    def update_student(self):

        if not self.old_code:

            return


        con = get_connection()

        cur = con.cursor()


        cur.execute(

            """

            UPDATE students SET

            first_name=?,

            last_name=?,

            national_code=?,

            student_code=?,

            birth_date=?,

            grade=?,

            class_name=?,

            father_name=?,

            mother_name=?,

            parent_phone=?,

            address=?,

            email=?,

            photo=?,

            description=?,

            seat_number=?

            WHERE national_code=?

            """,

            (

                self.inputs[0].text(),

                self.inputs[1].text(),

                self.inputs[2].text(),

                self.inputs[3].text(),

                self.inputs[4].text(),

                self.inputs[5].text(),

                self.inputs[6].text(),

                self.inputs[7].text(),

                self.inputs[8].text(),

                self.inputs[9].text(),

                self.inputs[12].text(),

                self.inputs[10].text(),

                self.photo_path,

                self.inputs[13].text(),

                self.inputs[11].text(),

                self.old_code

            )

        )


        con.commit()

        con.close()


        self.load_students()


        QMessageBox.information(

            self,

            "فراهوش",

            "تغییرات با موفقیت ذخیره شد."

        )



    # =========================
    # حذف دانش آموز
    # =========================

    def delete_student(self):

        if not self.old_code:

            return


        answer = QMessageBox.question(

            self,

            "حذف دانش‌آموز",

            "آیا از حذف این دانش‌آموز اطمینان دارید؟"

        )


        if answer == QMessageBox.Yes:


            con = get_connection()

            cur = con.cursor()


            cur.execute(

                """

                DELETE FROM students

                WHERE national_code=?

                """,

                (

                    self.old_code,

                )

            )


            con.commit()

            con.close()


            self.load_students()


            self.old_code = None

            self.photo_path = ""


            self.photo_label.clear()

            self.photo_label.setText(

                "بدون عکس"

            )


            for box in self.inputs:

                box.clear()