from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QHBoxLayout,
    QFrame,
    QListWidget,
    QListWidgetItem
)

from PySide6.QtCore import Qt




class ParticipantsPanel(QWidget):


    def __init__(self):

        super().__init__()



        self.setMinimumWidth(
            280
        )



        self.students = {}



        self.build_ui()




    # ==================================
    # ساخت رابط
    # ==================================

    def build_ui(self):


        layout = QVBoxLayout(
            self
        )



        title = QLabel(
            "👥 شرکت کنندگان کلاس"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setStyleSheet(

            """
            QLabel{

                color:white;

                font-size:18px;

                font-weight:bold;

                background:#102542;

                padding:10px;

                border-radius:10px;

            }
            """

        )


        layout.addWidget(
            title
        )



        self.list = QListWidget()



        layout.addWidget(
            self.list
        )



        self.setStyleSheet(

            """
            QWidget{

                background:#1b263b;

                border-radius:12px;

            }

            QListWidget{

                color:white;

                background:#0d1b2a;

                border-radius:10px;

            }

            """

        )


    # ==================================
    # افزودن دانش آموز
    # ==================================

    def add_student(
            self,
            name
    ):


        if name in self.students:

            return



        self.students[name] = {


            "online": True,


            "microphone": False,


            "camera": False,


            "hand": False,


            "mic_permission": False,


            "camera_permission": False

        }



        self.refresh()




    # ==================================
    # حذف دانش آموز
    # ==================================

    def remove_student(
            self,
            name
    ):


        if name in self.students:


            del self.students[name]


            self.refresh()




    # ==================================
    # بروزرسانی لیست
    # ==================================

    def refresh(self):


        self.list.clear()



        for name, data in self.students.items():


            status = "🟢 آنلاین" if data["online"] else "⚫ آفلاین"


            mic = "🎤" if data["microphone"] else "🔇"


            cam = "📷" if data["camera"] else "🚫"


            hand = "✋" if data["hand"] else ""



            text = (

                f"{name}\n"

                f"{status}  {mic} {cam} {hand}"

            )



            item = QListWidgetItem(
                text
            )


            self.list.addItem(
                item
            )




    # ==================================
    # اجازه میکروفن
    # ==================================

    def allow_microphone(
            self,
            name
    ):


        if name in self.students:


            self.students[name][
                "mic_permission"
            ] = True



            self.students[name][
                "microphone"
            ] = True



            self.refresh()




    # ==================================
    # اجازه دوربین
    # ==================================

    def allow_camera(
            self,
            name
    ):


        if name in self.students:


            self.students[name][
                "camera_permission"
            ] = True



            self.students[name][
                "camera"
            ] = True



            self.refresh()



    # ==================================
    # قطع میکروفن دانش آموز
    # ==================================

    def mute_student(
            self,
            name
    ):


        if name in self.students:


            self.students[name][
                "microphone"
            ] = False



            self.refresh()




    # ==================================
    # قطع دوربین دانش آموز
    # ==================================

    def disable_camera(
            self,
            name
    ):


        if name in self.students:


            self.students[name][
                "camera"
            ] = False



            self.refresh()




    # ==================================
    # تغییر وضعیت دست بالا
    # ==================================

    def set_hand_raise(
            self,
            name,
            value=True
    ):


        if name in self.students:


            self.students[name][
                "hand"
            ] = value



            self.refresh()




    # ==================================
    # تغییر وضعیت آنلاین
    # ==================================

    def set_online_status(
            self,
            name,
            status
    ):


        if name in self.students:


            self.students[name][
                "online"
            ] = status



            self.refresh()




    # ==================================
    # اطلاعات شرکت کنندگان
    # برای کلاس و AI
    # ==================================

    def get_participants_data(
            self
    ):


        return self.students




    # ==================================
    # گزارش فعالیت
    # آماده اتصال AI
    # ==================================

    def activity_report(self):


        report = []



        for name, data in self.students.items():


            report.append(

                {

                    "student": name,


                    "online": data["online"],


                    "microphone": data["microphone"],


                    "camera": data["camera"],


                    "hand": data["hand"]

                }

            )


        return report