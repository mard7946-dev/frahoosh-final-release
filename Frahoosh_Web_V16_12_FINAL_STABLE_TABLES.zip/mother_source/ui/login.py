# ============================================================
# Frahoosh - Login
# صفحه ورود اصلی فراهوش
# ============================================================

from PySide6.QtWidgets import (
    QWidget,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QCheckBox,
    QMessageBox,
    QLabel,
    QFrame,
    QDialog,
    QFormLayout
)

from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QFont, QPixmap

from ui.dashboard import Dashboard
from services.auth_service import AuthService

from config import (
    SYSTEM_TITLE,
    SCHOOL_NAME,
    SCHOOL_YEAR,
    SCHOOL_LOGO
)


class Login(QWidget):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            f"{SYSTEM_TITLE} فراهوش"
        )

        self.setFixedSize(
            1400,
            850
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.settings = QSettings("Frahoosh", "Frahoosh")
        self.init_ui()


    # ========================================================
    # رابط اصلی
    # ========================================================

    def init_ui(self):

        # ====================================================
        # تصویر اصلی کاربر به عنوان پس‌زمینه
        # ====================================================
        # هیچ نوشته/لوگویی در فایل تصویر دستکاری نشده است.
        # تمام اجزای تعاملی و نام مدرسه از کد ساخته می‌شوند.
        from pathlib import Path
        base_dir = Path(__file__).resolve().parent.parent
        bg_path = base_dir / "assets" / "frahoosh_login_background.png"

        self.background = QLabel(self)
        self.background.setGeometry(self.rect())
        self.background.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.background.setScaledContents(True)
        self.background.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

        pixmap = QPixmap(str(bg_path))
        if not pixmap.isNull():
            self.background.setPixmap(pixmap)
        else:
            self.background.setStyleSheet("background:#020b20;")

        # ====================================================
        # لایه پوشاننده نام مدرسه چاپ‌شده در تصویر
        # و نمایش نام مدرسه از config.py
        # ====================================================
        # ====================================================
        # نام مدرسه — کاملاً کدنویسی‌شده و قابل تغییر برای هر مدرسه
        # ====================================================
        self.school_overlay = QLabel(self)
        self.school_overlay.setGeometry(105, 812, 620, 62)
        self.school_overlay.setStyleSheet("""
            QLabel {
                background: rgba(2, 12, 34, 190);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 4px 14px;
                font-family: "B Zar";
                font-size: 21px;
                font-weight: bold;
            }
        """)
        self.school_overlay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.school_overlay.setText(SCHOOL_NAME)

        # ====================================================
        # کادر ورود — کاملاً کدنویسی‌شده
        # ====================================================
        self.login_frame = QFrame(self)
        self.login_frame.setGeometry(790, 135, 455, 590)
        self.login_frame.setObjectName("login_frame")

        layout = QVBoxLayout(self.login_frame)
        layout.setContentsMargins(42, 30, 42, 32)
        layout.setSpacing(13)

        login_title = QLabel("ورود به سامانه")
        login_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        login_title.setStyleSheet("""
            QLabel {
                color: white;
                font-family: "B Zar";
                font-size: 27px;
                font-weight: bold;
            }
        """)
        layout.addWidget(login_title)

        separator = QLabel("━━━━━━━━━━━━  ◇  ━━━━━━━━━━━━")
        separator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        separator.setStyleSheet("""
            QLabel {
                color: #69b9ff;
                font-size: 12px;
            }
        """)
        layout.addWidget(separator)

        self.login_hint = QLabel(SYSTEM_TITLE)
        self.login_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.login_hint.setWordWrap(True)
        self.login_hint.setStyleSheet("""
            QLabel {
                color: #dbeafe;
                font-family: "B Zar";
                font-size: 15px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.login_hint)

        layout.addSpacing(8)

        font = QFont("B Zar", 14, QFont.Bold)

        self.username = QLineEdit()
        self.username.setPlaceholderText("نام کاربری")
        self.username.setFixedHeight(52)
        self.username.setFont(font)
        self.username.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.username)

        self.password = QLineEdit()
        self.password.setPlaceholderText("رمز عبور")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setFixedHeight(52)
        self.password.setFont(font)
        self.password.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.password.returnPressed.connect(self.login)
        layout.addWidget(self.password)

        self.remember = QCheckBox("مرا بخاطر بسپار")
        self.remember.setFont(font)
        self.remember.setStyleSheet("""
            QCheckBox {
                color: #e5f0ff;
                font-family: "B Zar";
                font-weight: bold;
            }
            QCheckBox::indicator {
                width: 20px;
                height: 20px;
            }
        """)

        saved_user = self.settings.value("username", "")
        self.username.setText(saved_user)
        self.remember.setChecked(bool(saved_user))
        layout.addWidget(self.remember)

        self.login_btn = QPushButton("ورود به سامانه")
        self.login_btn.setFixedHeight(54)
        self.login_btn.setFont(font)
        self.login_btn.clicked.connect(self.login)
        layout.addWidget(self.login_btn)

        self.recover_btn = QPushButton("بازیابی رمز عبور")
        self.recover_btn.setFixedHeight(40)
        self.recover_btn.setFont(QFont("B Zar", 12, QFont.Bold))
        self.recover_btn.clicked.connect(self.recover_password)
        layout.addWidget(self.recover_btn)

        self.change_btn = QPushButton("تغییر رمز عبور")
        self.change_btn.setFixedHeight(40)
        self.change_btn.setFont(QFont("B Zar", 12, QFont.Bold))
        self.change_btn.clicked.connect(self.change_password)
        layout.addWidget(self.change_btn)

        layout.addStretch()

        self.setStyleSheet("""
            QFrame#login_frame {
                background: rgba(4, 20, 48, 235);
                border-radius: 22px;
                border: 1px solid rgba(112, 184, 255, 170);
            }

            QLineEdit {
                background: rgba(4, 24, 55, 235);
                color: #ffffff;
                border: 1px solid #367bc2;
                border-radius: 10px;
                padding-right: 14px;
                padding-left: 14px;
                font-family: "B Zar";
                selection-background-color: #1769aa;
            }

            QLineEdit:focus {
                border: 2px solid #4aa9ff;
            }

            QLineEdit::placeholder {
                color: #a8c4df;
            }

            QPushButton {
                background: #1769e0;
                color: #ffffff;
                border: 1px solid #3e96ff;
                border-radius: 10px;
                font-family: "B Zar";
                font-weight: bold;
            }

            QPushButton:hover {
                background: #2581ff;
            }

            QPushButton:pressed {
                background: #0d4fac;
            }

            QCheckBox {
                color: #e5f0ff;
                font-family: "B Zar";
                font-weight: bold;
            }
        """)

        self.background.lower()
        self.school_overlay.raise_()
        self.login_frame.raise_()

    # ========================================================
    # ورود
    # ========================================================

    def login(self):

        username = self.username.text().strip()

        password = self.password.text().strip()


        if not username or not password:

            QMessageBox.warning(
                self,
                "ورود",
                "نام کاربری و رمز عبور را وارد کنید."
            )

            return


        try:

            user = AuthService.login(
                username,
                password
            )


            if user:

                if self.remember.isChecked(): self.settings.setValue("username", username)
                else: self.settings.remove("username")

                self.dashboard = Dashboard(
                    username=user["username"],
                    role=user["role"]
                )

                self.dashboard.show()

                self.close()

            else:

                QMessageBox.warning(
                    self,
                    "خطای ورود",
                    "نام کاربری یا رمز عبور اشتباه است."
                )


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ورود",
                str(e)
            )


    # ========================================================
    # تغییر رمز
    # ========================================================
    def change_password(self):
        d=QDialog(self); d.setWindowTitle("تغییر رمز عبور"); f=QFormLayout(d)
        u=QLineEdit(self.username.text().strip()); old=QLineEdit(); old.setEchoMode(QLineEdit.Password); new=QLineEdit(); new.setEchoMode(QLineEdit.Password); confirm=QLineEdit(); confirm.setEchoMode(QLineEdit.Password)
        f.addRow("نام کاربری",u); f.addRow("رمز فعلی",old); f.addRow("رمز جدید",new); f.addRow("تکرار رمز جدید",confirm); b=QPushButton("ذخیره رمز جدید"); f.addWidget(b); b.clicked.connect(d.accept)
        if d.exec()!=QDialog.Accepted:return
        if not u.text().strip() or not old.text() or not new.text() or new.text()!=confirm.text() or len(new.text())<4:
            QMessageBox.warning(self,"تغییر رمز","اطلاعات را بررسی کنید؛ رمز جدید حداقل ۴ کاراکتر و تکرار آن یکسان باشد."); return
        if AuthService.change_password(u.text().strip(),old.text(),new.text()): QMessageBox.information(self,"تغییر رمز","رمز عبور با موفقیت تغییر کرد.")
        else: QMessageBox.warning(self,"تغییر رمز","نام کاربری یا رمز فعلی اشتباه است.")

    # ========================================================
    # بازیابی رمز
    # ========================================================

    def recover_password(self):
        d=QDialog(self); d.setWindowTitle("بازیابی رمز عبور - تأیید مدیر"); f=QFormLayout(d)
        user=QLineEdit(); admin=QLineEdit(); admin.setEchoMode(QLineEdit.Password); new=QLineEdit(); new.setEchoMode(QLineEdit.Password); confirm=QLineEdit(); confirm.setEchoMode(QLineEdit.Password)
        f.addRow("نام کاربری",user); f.addRow("نام کاربری مدیر",admin); f.addRow("رمز مدیر",admin)
        # The first admin field is intentionally renamed below; keep one clear form field per value.
        f.removeRow(admin)
        admin_user=QLineEdit(); admin_pass=QLineEdit(); admin_pass.setEchoMode(QLineEdit.Password)
        f.addRow("نام کاربری مدیر",admin_user); f.addRow("رمز مدیر",admin_pass); f.addRow("رمز جدید",new); f.addRow("تکرار رمز جدید",confirm)
        b=QPushButton("بازیابی و ذخیره رمز"); f.addWidget(b); b.clicked.connect(d.accept)
        if d.exec()!=QDialog.Accepted:return
        if not user.text().strip() or not admin_user.text().strip() or not admin_pass.text() or len(new.text())<4 or new.text()!=confirm.text():
            QMessageBox.warning(self,"بازیابی رمز","اطلاعات ناقص است یا رمز جدید معتبر نیست."); return
        if AuthService.admin_reset_password(admin_user.text(),admin_pass.text(),user.text(),new.text()):
            QMessageBox.information(self,"بازیابی رمز","رمز عبور با تأیید مدیر با موفقیت تغییر کرد.")
        else:
            QMessageBox.warning(self,"بازیابی رمز","تأیید مدیر یا نام کاربری مقصد صحیح نیست.")