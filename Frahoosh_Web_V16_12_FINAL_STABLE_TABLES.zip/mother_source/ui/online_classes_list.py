from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QMessageBox,
)

from PySide6.QtCore import Qt

from ui.online_class_room import OnlineClassRoom
from services.online_class_service import OnlineClassService




class OnlineClassesList(QWidget):


    def __init__(self):

        super().__init__()



        self.setWindowTitle(
            "🎥 کلاس‌های مجازی فراهوش"
        )



        self.resize(
            900,
            600
        )



        self.create_ui()





    # =====================================
    # ساخت صفحه کلاس‌ها
    # =====================================


    def create_ui(self):


        main_layout = QVBoxLayout(
            self
        )



        title = QLabel(
            "🎥 کلاس‌های آنلاین"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        main_layout.addWidget(
            title
        )



        self.classes_layout = QVBoxLayout()



        main_layout.addLayout(
            self.classes_layout
        )



        self.load_classes()





    # =====================================
    # بارگذاری کلاس‌ها
    # =====================================


    def load_classes(self):
        # کلاس‌ها باید از دیتابیس و اتصال واقعی دانش‌آموز/دبیر خوانده شوند؛
        # هیچ دادهٔ نمایشی در پنل باقی نمی‌ماند.
        try:
            OnlineClassService.ensure_schema()
            classes = OnlineClassService.get_active_classes()
        except Exception as exc:
            QMessageBox.critical(self, "خطای کلاس‌های مجازی", str(exc))
            classes = []

        while self.classes_layout.count():
            item = self.classes_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for row in classes:
            self.add_class_card(row)

        if not classes:
            self.classes_layout.addWidget(QLabel("کلاس مجازی فعالی برای این کاربر یافت نشد."))


    # =====================================
    # ساخت کارت کلاس
    # =====================================


    def add_class_card(
            self,
            class_data
    ):


        class_id = class_data["id"] if hasattr(class_data, "keys") else class_data[0]
        subject = (class_data["subject"] or class_data["lesson"] or "کلاس آنلاین") if hasattr(class_data, "keys") else class_data[1]
        grade = class_data["grade"] if hasattr(class_data, "keys") else class_data[2]



        card = QFrame()


        card.setFrameShape(
            QFrame.StyledPanel
        )



        layout = QHBoxLayout(
            card
        )



        info = QLabel(
            f"📚 {subject}  |  پایه {grade}"
        )


        info.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        enter_button = QPushButton(
            "🚀 ورود به کلاس"
        )



        enter_button.clicked.connect(lambda checked=False, cid=class_id: self.open_class_room(cid))



        layout.addWidget(
            info
        )


        layout.addWidget(
            enter_button
        )



        self.classes_layout.addWidget(
            card
        )







    # =====================================
    # ورود به اتاق کلاس
    # =====================================


    def open_class_room(self, class_id):
        try:
            self.class_room = OnlineClassRoom(class_id=class_id)
            self.class_room.show()
        except Exception as exc:
            QMessageBox.critical(self, "خطای ورود به کلاس", str(exc))



        self.class_room = OnlineClassRoom()



        self.class_room.show()



    # =====================================
    # پیام خطا
    # =====================================


    def show_error(
            self,
            message
    ):


        QMessageBox.warning(
            self,
            "خطا",
            message
        )





    # =====================================
    # بستن صفحه
    # =====================================


    def closeEvent(
            self,
            event
    ):


        event.accept()


        
            