from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QTableWidget,
    QTableWidgetItem,
)

from PySide6.QtCore import Qt





class ActivityAnalysis(QWidget):


    def __init__(self):

        super().__init__()


        self.setWindowTitle(
            "📊 تحلیل فعالیت کلاس آنلاین فراهوش"
        )


        self.resize(
            1000,
            650
        )


        self.students = [

            "دانش آموز ۱",
            "دانش آموز ۲",
            "دانش آموز ۳",
            "دانش آموز ۴"

        ]


        self.create_ui()





    # =====================================
    # ساخت رابط کاربری
    # =====================================


    def create_ui(self):


        main_layout = QVBoxLayout(
            self
        )


        title = QLabel(
            "📊 گزارش هوشمند فعالیت دانش آموزان"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        main_layout.addWidget(
            title
        )


        self.table = QTableWidget()


        self.table.setColumnCount(
            5
        )


        self.table.setHorizontalHeaderLabels(

            [

                "نام دانش آموز",

                "زمان حضور",

                "فعالیت تخته",

                "نتیجه کوییز",

                "وضعیت"

            ]

        )


        self.table.setRowCount(
            len(self.students)
        )


    # =====================================
        # پر کردن جدول
        # =====================================


        for row, student in enumerate(

            self.students

        ):


            self.table.setItem(

                row,

                0,

                QTableWidgetItem(

                    student

                )

            )



            self.table.setItem(

                row,

                1,

                QTableWidgetItem(

                    "45 دقیقه"

                )

            )



            self.table.setItem(

                row,

                2,

                QTableWidgetItem(

                    "فعال"

                )

            )



            self.table.setItem(

                row,

                3,

                QTableWidgetItem(

                    "18 از 20"

                )

            )



            self.table.setItem(

                row,

                4,

                QTableWidgetItem(

                    "🟢 خوب"

                )

            )





        main_layout.addWidget(

            self.table

        )





        # =====================================
        # بخش آمار
        # =====================================


        stats_layout = QHBoxLayout()



        self.total_label = QLabel(

            "👥 تعداد دانش آموزان: 4"

        )



        self.active_label = QLabel(

            "🟢 فعال: 4"

        )



        self.average_label = QLabel(

            "⏱ میانگین حضور: 45 دقیقه"

        )



        stats_layout.addWidget(

            self.total_label

        )


        stats_layout.addWidget(

            self.active_label

        )


        stats_layout.addWidget(

            self.average_label

        )



        main_layout.addLayout(

            stats_layout

        )





        # =====================================
        # دکمه بروزرسانی
        # =====================================


        refresh_button = QPushButton(

            "🔄 بروزرسانی گزارش"

        )


        refresh_button.clicked.connect(

            self.refresh_report

        )


        main_layout.addWidget(

            refresh_button

        )  


    # =====================================
    # بروزرسانی گزارش
    # =====================================


    def refresh_report(self):


        active_count = 0



        for row in range(

            self.table.rowCount()

        ):


            status_item = self.table.item(

                row,

                4

            )



            if status_item:


                if "خوب" in status_item.text():


                    active_count += 1





        self.active_label.setText(

            f"🟢 فعال: {active_count}"

        )






    # =====================================
    # تحلیل یک دانش آموز
    # =====================================


    def analyze_student(self, row):


        if row < 0:


            return



        self.table.setItem(

            row,

            4,

            QTableWidgetItem(

                "🟡 نیاز به بررسی"

            )

        )