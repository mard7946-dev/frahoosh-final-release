from PySide6.QtWidgets import QWidget
from PySide6.QtGui import (
    QPainter,
    QColor,
    QLinearGradient,
    QFont,
    QPixmap
)
from PySide6.QtCore import Qt, QRect

from config import SCHOOL_NAME


class LoginBackground(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.setMinimumSize(
            1400,
            850
        )


        self.brain = QPixmap(
            "assets/brain.png"
        )


        self.school_font = QFont(
            "B Zar",
            25,
            QFont.Bold
        )


    def paintEvent(self, event):

        painter = QPainter(self)

        painter.setRenderHint(
            QPainter.Antialiasing
        )


        w = self.width()
        h = self.height()

        center = w // 2


        # ======================
        # Background
        # ======================

        gradient = QLinearGradient(
            0,
            0,
            0,
            h
        )

        gradient.setColorAt(
            0,
            QColor("#020617")
        )

        gradient.setColorAt(
            1,
            QColor("#0b1f3a")
        )


        painter.fillRect(
            0,
            0,
            w,
            h,
            gradient
        )


        # ======================
        # Brain Image
        # ======================

        brain_y = 240


        if not self.brain.isNull():

            brain = self.brain.scaled(
                300,
                300,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )


            painter.drawPixmap(
                center - brain.width() // 2,
                brain_y,
                brain
            )


        # ======================
        # School Name
        # ======================

        painter.setFont(
            self.school_font
        )


        painter.setPen(
            QColor("#ffffff")
        )


        painter.drawText(
            QRect(
                0,
                555,
                w,
                50
            ),
            Qt.AlignmentFlag.AlignCenter,
            SCHOOL_NAME
        )


        painter.end()