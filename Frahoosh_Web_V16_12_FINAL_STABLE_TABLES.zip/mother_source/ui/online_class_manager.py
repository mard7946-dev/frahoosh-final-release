import sqlite3
from datetime import datetime
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QComboBox,
    QSpinBox, QPushButton, QTableWidget, QTableWidgetItem, QLabel, QMessageBox,
    QCheckBox, QTimeEdit, QGroupBox, QGridLayout, QHeaderView, QScrollArea
)
from PySide6.QtCore import Qt, QTimer, QTime
from services.online_class_service import OnlineClassService
from utils.jalali import jalali_to_iso
from database.db import DATABASE_NAME


def db():
    c = sqlite3.connect(DATABASE_NAME)
    c.row_factory = sqlite3.Row
    return c


def ensure_online_schema():
    OnlineClassService.ensure_schema()
    with db() as c:
        teacher_cols = {r[1] for r in c.execute('PRAGMA table_info(teachers)')}
        if 'employee_code' not in teacher_cols:
            c.execute("ALTER TABLE teachers ADD COLUMN employee_code TEXT DEFAULT ''")
        cols = {r[1] for r in c.execute('PRAGMA table_info(online_classes)')}
        additions = {
            'created_at_shamsi': "TEXT DEFAULT ''",
            'start_time_shamsi': "TEXT DEFAULT ''",
            'end_time_shamsi': "TEXT DEFAULT ''",
            'teacher_id': 'INTEGER',
            'teacher_code': "TEXT DEFAULT ''",
            'meeting_code': "TEXT DEFAULT ''",
            'manager_approved': 'INTEGER DEFAULT 0',
            'executive_approved': 'INTEGER DEFAULT 0',
            'auto_close': 'INTEGER DEFAULT 1',
            'capacity': 'INTEGER DEFAULT 700',
        }
        for col, typ in additions.items():
            if col not in cols:
                c.execute(f'ALTER TABLE online_classes ADD COLUMN {col} {typ}')
        c.commit()


class OnlineClassManagerPage(QWidget):
    """مدیریت واقعی کلاس آنلاین؛ فرم خوانا، دیتابیس فعال و فعال‌سازی محدود به مدیر/معاون اجرایی."""
    def __init__(self, parent=None, actor_role='manager'):
        super().__init__(parent)
        self.actor_role = actor_role
        self._classes = []
        ensure_online_schema()
        self._build()
        self._fill_teachers()
        self.load()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._auto_close)
        self.timer.start(30000)

    def _build(self):
        self.setLayoutDirection(Qt.RightToLeft)
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(12)

        title = QLabel('🎓 کلاس آنلاین هوشمند فراهوش')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet('font-size:22px;font-weight:bold;padding:8px;')
        root.addWidget(title)
        hint = QLabel('ساخت کلاس، تعیین مخاطب، زمان‌بندی و فعال‌سازی در همین صفحه انجام می‌شود. فقط مدیر یا معاون اجرایی می‌تواند کلاس را فعال کند.')
        hint.setWordWrap(True)
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet('font-size:13px;padding:6px;')
        root.addWidget(hint)

        form_box = QGroupBox('اطلاعات کلاس آنلاین')
        grid = QGridLayout(form_box)
        grid.setHorizontalSpacing(12); grid.setVerticalSpacing(9)

        self.title = QLineEdit(); self.title.setPlaceholderText('مثلاً کلاس ریاضی هشتم')
        self.subject = QLineEdit(); self.subject.setPlaceholderText('نام درس')
        self.teacher = QComboBox(); self.teacher.setMinimumWidth(250)
        self.teacher.currentIndexChanged.connect(self._teacher_changed)
        self.teacher_id = QLineEdit(); self.teacher_id.setReadOnly(True)
        self.teacher_code = QLineEdit(); self.teacher_code.setReadOnly(True)
        self.grade = QLineEdit(); self.grade.setReadOnly(True)
        self.cls = QComboBox(); self.cls.setMinimumWidth(250)
        self.date = QLineEdit(); self.date.setPlaceholderText('1405/06/04')
        self.start = QTimeEdit(QTime(8, 0)); self.start.setDisplayFormat('HH:mm')
        self.end = QTimeEdit(QTime(9, 30)); self.end.setDisplayFormat('HH:mm')
        self.duration = QSpinBox(); self.duration.setRange(15, 300); self.duration.setValue(90); self.duration.setSuffix(' دقیقه')
        self.capacity = QSpinBox(); self.capacity.setRange(1, 700); self.capacity.setValue(40); self.capacity.setSuffix(' نفر')
        self.auto = QCheckBox('پس از زمان پایان، کلاس خودکار بسته شود'); self.auto.setChecked(True)

        fields = [
            ('عنوان کلاس', self.title, 0, 0), ('درس', self.subject, 0, 2),
            ('دبیر', self.teacher, 1, 0), ('شناسه دبیر', self.teacher_id, 1, 2),
            ('کد دبیر', self.teacher_code, 2, 0), ('پایه', self.grade, 2, 2),
            ('کلاس مخاطب', self.cls, 3, 0), ('تاریخ شمسی', self.date, 3, 2),
            ('زمان شروع', self.start, 4, 0), ('زمان پایان', self.end, 4, 2),
            ('مدت کلاس', self.duration, 5, 0), ('ظرفیت', self.capacity, 5, 2),
        ]
        for label, widget, row, col in fields:
            grid.addWidget(QLabel(label), row, col)
            grid.addWidget(widget, row, col + 1)
        grid.addWidget(self.auto, 6, 0, 1, 4)
        root.addWidget(form_box)

        settings_box = QGroupBox('ویژگی‌های کلاس هوشمند')
        sg = QGridLayout(settings_box)
        self.board = QCheckBox('تخته آموزشی'); self.board.setChecked(True)
        self.files = QCheckBox('اشتراک فایل'); self.files.setChecked(True)
        self.media = QCheckBox('تصویر و ویدئو'); self.media.setChecked(True)
        self.quiz = QCheckBox('آزمون کوتاه'); self.quiz.setChecked(True)
        self.camera = QCheckBox('دوربین'); self.camera.setChecked(True)
        self.mic = QCheckBox('میکروفون'); self.mic.setChecked(True)
        self.screen = QCheckBox('اشتراک صفحه'); self.screen.setChecked(True)
        self.chat = QCheckBox('چت عمومی'); self.chat.setChecked(False)
        for i, w in enumerate((self.board,self.files,self.media,self.quiz,self.camera,self.mic,self.screen,self.chat)):
            sg.addWidget(w, i//4, i%4)
        root.addWidget(settings_box)

        bar = QHBoxLayout()
        self.create_btn = QPushButton('➕ ساخت کلاس')
        self.approve_btn = QPushButton('🔐 فعال‌سازی کلاس انتخاب‌شده')
        self.finish_btn = QPushButton('⏹ بستن کلاس')
        self.refresh_btn = QPushButton('🔄 تازه‌سازی')
        self.create_btn.clicked.connect(self.create)
        self.approve_btn.clicked.connect(self.approve)
        self.finish_btn.clicked.connect(self.finish)
        self.refresh_btn.clicked.connect(self.load)
        for b in (self.create_btn,self.approve_btn,self.finish_btn,self.refresh_btn):
            b.setMinimumHeight(40); bar.addWidget(b)
        root.addLayout(bar)

        self.table = QTableWidget(0, 14)
        self.table.setHorizontalHeaderLabels(['شناسه','عنوان','درس','دبیر','شناسه دبیر','کد دبیر','پایه','کلاس','تاریخ شروع','زمان شروع','زمان پایان','مدت','وضعیت','تأیید'])
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        root.addWidget(self.table, 1)
        self.setStyleSheet('''
            QGroupBox{font-weight:bold;border:1px solid #B7C7E6;border-radius:10px;margin-top:10px;padding:10px;}
            QGroupBox::title{subcontrol-origin:margin;right:12px;padding:0 6px;}
            QLabel{font-size:13px;}
            QLineEdit,QComboBox,QSpinBox,QTimeEdit{min-height:32px;padding:4px 7px;background:white;border:1px solid #AAB7CF;border-radius:6px;}
            QTableWidget{background:white;gridline-color:#D8DEE9;font-size:12px;}
            QPushButton{min-height:38px;padding:5px 12px;border-radius:7px;}
        ''')

    def _fill_teachers(self):
        with db() as c:
            rows = c.execute("SELECT id,first_name,last_name,COALESCE(employee_code,'') employee_code FROM teachers ORDER BY last_name,first_name").fetchall()
        self.teacher.blockSignals(True); self.teacher.clear()
        self.teacher.addItem('انتخاب دبیر', None)
        for r in rows:
            name = f"{r['first_name'] or ''} {r['last_name'] or ''}".strip()
            self.teacher.addItem(name, {'id':r['id'],'code':r['employee_code'] or ''})
        self.teacher.blockSignals(False)
        self._teacher_changed()

    def _teacher_changed(self):
        data = self.teacher.currentData()
        self.teacher_id.setText(str(data['id']) if data else '')
        self.teacher_code.setText(str(data['code']) if data else '')
        self.cls.clear(); self.grade.clear()
        if not data: return
        with db() as c:
            rows = c.execute("SELECT DISTINCT grade,class_name,subject FROM teacher_classes WHERE teacher_id=? ORDER BY grade,class_name", (data['id'],)).fetchall()
        for r in rows:
            self.cls.addItem(f"{r['grade']} | {r['class_name']}", {'grade':r['grade'],'class_name':r['class_name'],'subject':r['subject'] or ''})
        if rows:
            self._class_changed(0)
        else:
            with db() as c:
                rows = c.execute("SELECT DISTINCT grade,class_name FROM students WHERE grade IS NOT NULL AND class_name IS NOT NULL ORDER BY grade,class_name").fetchall()
            for r in rows:self.cls.addItem(f"{r['grade']} | {r['class_name']}", {'grade':r['grade'],'class_name':r['class_name'],'subject':''})
            self._class_changed(0)

    def _class_changed(self, index):
        data = self.cls.itemData(index) if index >= 0 else None
        if data:
            self.grade.setText(str(data['grade']))
            if not self.subject.text().strip() and data.get('subject'): self.subject.setText(data['subject'])

    def _teacher_row(self):
        data = self.teacher.currentData()
        if not data: return None
        with db() as c:return c.execute('SELECT id,first_name,last_name FROM teachers WHERE id=?',(data['id'],)).fetchone()

    def create(self):
        cls_data=self.cls.currentData(); tr=self._teacher_row()
        required=(self.title.text().strip(),self.subject.text().strip(),tr,cls_data,self.date.text().strip())
        if not all(required): return QMessageBox.warning(self,'کلاس آنلاین','عنوان، درس، دبیر، کلاس مخاطب و تاریخ شمسی الزامی است.')
        try:
            iso_date=jalali_to_iso(self.date.text().strip())
            st=self.start.time().toString('HH:mm'); en=self.end.time().toString('HH:mm')
            if st>=en: raise ValueError('زمان پایان باید بعد از زمان شروع باشد.')
            if self.duration.value() > int((QTime.fromString(en,'HH:mm').secsTo(QTime.fromString(st,'HH:mm')) * -1)/60):
                raise ValueError('مدت کلاس نمی‌تواند از فاصله زمانی شروع تا پایان بیشتر باشد.')
            now=datetime.now(); start_iso=f'{iso_date} {st}:00'; end_iso=f'{iso_date} {en}:00'; sh=self.date.text().strip()
            with db() as c:
                cur=c.execute('''INSERT INTO online_classes(title,subject,lesson,teacher,teacher_id,teacher_code,grade,class_name,duration,start_time,end_time,start_time_shamsi,end_time_shamsi,created_at,created_at_shamsi,status,manager_approved,executive_approved,auto_close,capacity,meeting_code)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (self.title.text().strip(),self.subject.text().strip(),self.subject.text().strip(),self.teacher.currentText(),tr['id'],self.teacher_code.text().strip(),cls_data['grade'],cls_data['class_name'],self.duration.value(),start_iso,end_iso,sh+' '+st,sh+' '+en,now.strftime('%Y-%m-%d %H:%M:%S'),sh,'pending',0,0,int(self.auto.isChecked()),self.capacity.value(),f'FRA-{int(now.timestamp())}'))
                cid=cur.lastrowid
                c.execute('INSERT OR IGNORE INTO online_class_teachers(class_id,teacher_id,teacher_name) VALUES(?,?,?)',(cid,tr['id'],self.teacher.currentText()))
                students=c.execute('SELECT id,first_name,last_name FROM students WHERE grade=? AND class_name=?',(cls_data['grade'],cls_data['class_name'])).fetchall()
                for s in students:c.execute('INSERT OR IGNORE INTO online_class_students(class_id,student_id,student_name) VALUES(?,?,?)',(cid,s['id'],f"{s['first_name'] or ''} {s['last_name'] or ''}".strip()))
                c.execute('''INSERT OR REPLACE INTO online_class_settings(class_id,public_chat_enabled,private_chat_enabled,board_enabled,file_share_enabled,media_enabled,quiz_enabled,camera_enabled,microphone_enabled,screen_share_enabled,updated_at_shamsi)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(cid,int(self.chat.isChecked()),1,int(self.board.isChecked()),int(self.files.isChecked()),int(self.media.isChecked()),int(self.quiz.isChecked()),int(self.camera.isChecked()),int(self.mic.isChecked()),int(self.screen.isChecked()),sh))
                c.commit()
            self.load(); QMessageBox.information(self,'کلاس آنلاین','کلاس با موفقیت ساخته شد و تا زمان فعال‌سازی در وضعیت انتظار قرار گرفت.')
        except Exception as e: QMessageBox.critical(self,'خطای ساخت کلاس',str(e))

    def selected(self):
        r=self.table.currentRow()
        if r<0:return None
        try:return int(self.table.item(r,0).text())
        except Exception:return None

    def approve(self):
        if self.actor_role not in ('manager','executive'):
            return QMessageBox.warning(self,'دسترسی','فقط مدیر و معاون اجرایی مجاز به فعال‌سازی کلاس هستند.')
        cid=self.selected()
        if not cid:return QMessageBox.warning(self,'کلاس آنلاین','یک کلاس را از جدول انتخاب کنید.')
        with db() as c:
            if self.actor_role=='manager': c.execute('UPDATE online_classes SET manager_approved=1,status=\'approved\' WHERE id=?',(cid,))
            else: c.execute('UPDATE online_classes SET executive_approved=1,status=\'approved\' WHERE id=?',(cid,))
            c.commit()
        self.load()

    def finish(self):
        cid=self.selected()
        if cid: OnlineClassService.finish_class(cid); self.load()

    def _auto_close(self):
        OnlineClassService.auto_close_expired()
        self.load()

    def load(self):
        ensure_online_schema()
        with db() as c:
            rows=c.execute('''SELECT id,title,subject,teacher,teacher_id,teacher_code,grade,class_name,start_time_shamsi,end_time_shamsi,duration,status,manager_approved,executive_approved
                              FROM online_classes ORDER BY id DESC''').fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            approval='مدیر' if r['manager_approved'] else ('معاون اجرایی' if r['executive_approved'] else 'در انتظار')
            vals=[r['id'],r['title'],r['subject'],r['teacher'],r['teacher_id'],r['teacher_code'],r['grade'],r['class_name'],r['start_time_shamsi'].split(' ')[0] if r['start_time_shamsi'] else '',r['start_time_shamsi'].split(' ')[1] if r['start_time_shamsi'] and ' ' in r['start_time_shamsi'] else '',r['end_time_shamsi'].split(' ')[1] if r['end_time_shamsi'] and ' ' in r['end_time_shamsi'] else '',r['duration'],r['status'],approval]
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
