import os
import sqlite3


from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPixmap


from PySide6.QtWidgets import (

    QWidget,

    QLabel,

    QLineEdit,

    QTextEdit,

    QPushButton,

    QVBoxLayout,

    QHBoxLayout,

    QGridLayout,

    QFrame,

    QFileDialog,

    QMessageBox,

    QTableWidget,

    QTableWidgetItem,

    QHeaderView,

    QComboBox,

)



from database.db import DATABASE_NAME as DB_NAME



class Staff(QWidget):


    def __init__(self):

        super().__init__()


        self.photo_path = ""

        self.selected_staff_id = None


        self.setup_database()

        self.build_ui()

        self.load_staff()





    # =====================================================
    # دیتابیس کارکنان
    # =====================================================


    def setup_database(self):


        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute("""

        CREATE TABLE IF NOT EXISTS staff(

            id INTEGER PRIMARY KEY AUTOINCREMENT,


            first_name TEXT,


            last_name TEXT,


            national_code TEXT,


            personnel_code TEXT,


            mobile TEXT,


            phone TEXT,


            email TEXT,


            position TEXT,


            employment_status TEXT,


            access_level TEXT,


            description TEXT,


            photo TEXT


        )

        """)



        conn.commit()

        conn.close()






    # =====================================================
    # ساخت رابط کاربری
    # =====================================================


    def build_ui(self):


        self.main_layout = QHBoxLayout(self)


        self.main_layout.setContentsMargins(

            15,

            15,

            15,

            15

        )



        self.main_layout.setSpacing(

            15

        )



        # ---------------------------
        # فرم اطلاعات
        # ---------------------------


        self.form_frame = QFrame()


        self.form_frame.setMinimumWidth(

            430

        )


        self.form_layout = QGridLayout(

            self.form_frame

        )



        title = QLabel(

            "مدیریت هوشمند کارکنان فراهوش"

        )


        title.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        title.setFont(

            QFont(

                "B Nazanin",

                18,

                QFont.Bold

            )

        )



        self.form_layout.addWidget(

            title,

            0,

            0,

            1,

            3

        )




        # عکس


        self.photo_label = QLabel()


        self.photo_label.setFixedSize(

            150,

            180

        )


        self.photo_label.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        self.photo_label.setStyleSheet("""

        QLabel{

            border:2px solid #cccccc;

            border-radius:10px;

            background:white;

        }

        """)



        self.photo_button = QPushButton(

            "انتخاب عکس"

        )


        self.photo_button.clicked.connect(

            self.select_photo

        )



        self.form_layout.addWidget(

            self.photo_label,

            1,

            0,

            5,

            1

        )


        self.form_layout.addWidget(

            self.photo_button,

            6,

            0

        )




        # فیلدها


        self.first_name = QLineEdit()

        self.last_name = QLineEdit()

        self.national_code = QLineEdit()

        self.personnel_code = QLineEdit()

        self.mobile = QLineEdit()

        self.phone = QLineEdit()

        self.email = QLineEdit()




        self.position = QComboBox()


        self.position.addItems([


            "مدیر",


            "معاون آموزشی",


            "معاون اجرایی",


            "معاون پرورشی",


            "مشاور",


            "مسئول فناوری",


            "حسابدار",


            "خدمتگزار",


            "نگهبان",


            "سایر"


        ])




        self.status = QComboBox()


        self.status.addItems([


            "رسمی",


            "پیمانی",


            "قراردادی",


            "آزاد"


        ])




        self.access = QComboBox()


        self.access.addItems([


            "مدیر کامل",


            "معاون",


            "کارمند",


            "فقط مشاهده"


        ])



    # =====================================================
    # چیدمان فیلدها
    # =====================================================


        row = 1


        fields = [

            ("نام", self.first_name),

            ("نام خانوادگی", self.last_name),

            ("کد ملی", self.national_code),

            ("کد پرسنلی", self.personnel_code),

            ("موبایل", self.mobile),

            ("تلفن", self.phone),

            ("ایمیل", self.email),

            ("سمت", self.position),

            ("وضعیت همکاری", self.status),

            ("سطح دسترسی", self.access),

        ]



        for title, widget in fields:


            self.form_layout.addWidget(

                QLabel(title),

                row,

                1

            )


            self.form_layout.addWidget(

                widget,

                row,

                2

            )


            row += 1




        # -------------------------
        # توضیحات
        # -------------------------


        self.form_layout.addWidget(

            QLabel("توضیحات"),

            row,

            1

        )



        self.description = QTextEdit()



        self.description.setMinimumHeight(

            90

        )



        self.form_layout.addWidget(

            self.description,

            row,

            2

        )



        row += 1




        # -------------------------
        # دکمه ها
        # -------------------------


        buttons = QHBoxLayout()



        self.save_btn = QPushButton(

            "💾 ثبت"

        )


        self.edit_btn = QPushButton(

            "✏️ ویرایش"

        )


        self.delete_btn = QPushButton(

            "🗑 حذف"

        )


        self.clear_btn = QPushButton(

            "🆕 جدید"

        )



        self.save_btn.clicked.connect(

            self.save_staff

        )


        self.edit_btn.clicked.connect(

            self.update_staff

        )


        self.delete_btn.clicked.connect(

            self.delete_staff

        )


        self.clear_btn.clicked.connect(

            self.clear_form

        )



        buttons.addWidget(

            self.save_btn

        )


        buttons.addWidget(

            self.edit_btn

        )


        buttons.addWidget(

            self.delete_btn

        )


        buttons.addWidget(

            self.clear_btn

        )



        self.form_layout.addLayout(

            buttons,

            row,

            0,

            1,

            3

        )



        self.main_layout.addWidget(

            self.form_frame,

            2

        )





    # =====================================================
    # جدول کارکنان
    # =====================================================



        self.table_frame = QFrame()



        table_layout = QVBoxLayout(

            self.table_frame

        )



        table_title = QLabel(

            "لیست کارکنان"

        )


        table_title.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        table_title.setFont(

            QFont(

                "B Nazanin",

                16,

                QFont.Bold

            )

        )



        table_layout.addWidget(

            table_title

        )




        self.search = QLineEdit()



        self.search.setPlaceholderText(

            "جستجو نام، نام خانوادگی یا کد پرسنلی..."

        )



        self.search.textChanged.connect(

            self.search_staff

        )



        table_layout.addWidget(

            self.search

        )




        self.table = QTableWidget()



        self.table.setColumnCount(

            7

        )



        self.table.setHorizontalHeaderLabels([


            "کد",


            "نام",


            "نام خانوادگی",


            "کد پرسنلی",


            "سمت",


            "موبایل",


            "دسترسی"


        ])




        self.table.horizontalHeader().setSectionResizeMode(

            QHeaderView.Stretch

        )



        self.table.setSelectionBehavior(

            QTableWidget.SelectRows

        )



        self.table.setEditTriggers(

            QTableWidget.NoEditTriggers

        )



        self.table.cellClicked.connect(

            self.select_staff

        )



        table_layout.addWidget(

            self.table

        )



        self.staff_count = QLabel(

            "تعداد کارکنان : 0"

        )



        self.staff_count.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )



        table_layout.addWidget(

            self.staff_count

        )



        self.main_layout.addWidget(

            self.table_frame,

            3

        )



    # =====================================================
    # انتخاب عکس کارکن
    # =====================================================


    def select_photo(self):


        file_name, _ = QFileDialog.getOpenFileName(

            self,

            "انتخاب عکس کارمند",

            "",

            "Images (*.png *.jpg *.jpeg)"

        )



        if file_name:


            self.photo_path = file_name


            pixmap = QPixmap(

                file_name

            )



            self.photo_label.setPixmap(

                pixmap.scaled(

                    150,

                    180,

                    Qt.KeepAspectRatio,

                    Qt.SmoothTransformation

                )

            )





    # =====================================================
    # بارگذاری کارکنان
    # =====================================================


    def load_staff(self):


        conn = sqlite3.connect(

            DB_NAME

        )


        cursor = conn.cursor()



        cursor.execute(

            "SELECT * FROM staff ORDER BY last_name"

        )



        rows = cursor.fetchall()



        conn.close()



        self.table.setRowCount(

            0

        )



        for r, data in enumerate(rows):


            self.table.insertRow(

                r

            )



            values = [


                data[0],


                data[1],


                data[2],


                data[4],


                data[8],


                data[5],


                data[10]


            ]



            for c, value in enumerate(values):


                self.table.setItem(

                    r,

                    c,

                    QTableWidgetItem(

                        str(value or "")

                    )

                )



        self.staff_count.setText(

            f"تعداد کارکنان : {len(rows)}"

        )





    # =====================================================
    # جستجوی کارکنان
    # =====================================================


    def search_staff(self):


        text = self.search.text().strip()



        for row in range(

            self.table.rowCount()

        ):


            found = False



            for col in range(

                self.table.columnCount()

            ):


                item = self.table.item(

                    row,

                    col

                )



                if item and text in item.text():


                    found = True



            self.table.setRowHidden(

                row,

                not found

            )





    # =====================================================
# ثبت کارمند
# =====================================================


    def save_staff(self):


        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute("""

        INSERT INTO staff(

            first_name,

            last_name,

            national_code,

            personnel_code,

            mobile,

            phone,

            email,

            position,

            employment_status,

            access_level,

            description,

            photo

        )

        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)

        """, (

            self.first_name.text(),

            self.last_name.text(),

            self.national_code.text(),

            self.personnel_code.text(),

            self.mobile.text(),

            self.phone.text(),

            self.email.text(),

            self.position.currentText(),

            self.status.currentText(),

            self.access.currentText(),

            self.description.toPlainText(),

            self.photo_path

        ))



        conn.commit()

        conn.close()



        QMessageBox.information(

            self,

            "ثبت اطلاعات",

            "کارمند با موفقیت ثبت شد."

        )



        self.clear_form()

        self.load_staff()





    # =====================================================
    # انتخاب کارمند از جدول
    # =====================================================


    def select_staff(self, row, column):


        item = self.table.item(
            row,
            0
        )


        if not item:

            return



        self.selected_staff_id = int(
            item.text()
        )



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute(

            "SELECT * FROM staff WHERE id=?",

            (self.selected_staff_id,)

        )


        staff = cursor.fetchone()


        conn.close()



        if not staff:

            return



        self.first_name.setText(
            staff[1] or ""
        )

        self.last_name.setText(
            staff[2] or ""
        )

        self.national_code.setText(
            staff[3] or ""
        )

        self.personnel_code.setText(
            staff[4] or ""
        )

        self.mobile.setText(
            staff[5] or ""
        )

        self.phone.setText(
            staff[6] or ""
        )

        self.email.setText(
            staff[7] or ""
        )

        self.position.setCurrentText(
            staff[8] or ""
        )

        self.status.setCurrentText(
            staff[9] or ""
        )

        self.access.setCurrentText(
            staff[10] or ""
        )

        self.description.setPlainText(
            staff[11] or ""
        )



        self.photo_path = staff[12] or ""



        if self.photo_path and os.path.exists(
            self.photo_path
        ):

            pix = QPixmap(
                self.photo_path
            )


            self.photo_label.setPixmap(

                pix.scaled(

                    150,

                    180,

                    Qt.KeepAspectRatio,

                    Qt.SmoothTransformation

                )

            )





    # =====================================================
    # ویرایش کارمند
    # =====================================================


    def update_staff(self):


        if self.selected_staff_id is None:


            QMessageBox.warning(

                self,

                "توجه",

                "ابتدا یک کارمند را انتخاب کنید."

            )

            return



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute("""

        UPDATE staff SET

            first_name=?,

            last_name=?,

            national_code=?,

            personnel_code=?,

            mobile=?,

            phone=?,

            email=?,

            position=?,

            employment_status=?,

            access_level=?,

            description=?,

            photo=?

        WHERE id=?

        """, (

            self.first_name.text(),

            self.last_name.text(),

            self.national_code.text(),

            self.personnel_code.text(),

            self.mobile.text(),

            self.phone.text(),

            self.email.text(),

            self.position.currentText(),

            self.status.currentText(),

            self.access.currentText(),

            self.description.toPlainText(),

            self.photo_path,

            self.selected_staff_id

        ))



        conn.commit()

        conn.close()



        QMessageBox.information(

            self,

            "ویرایش",

            "اطلاعات کارمند به‌روزرسانی شد."

        )


        self.load_staff()





    # =====================================================
    # حذف کارمند
    # =====================================================


    def delete_staff(self):


        if self.selected_staff_id is None:


            QMessageBox.warning(

                self,

                "توجه",

                "ابتدا یک کارمند را انتخاب کنید."

            )

            return



        result = QMessageBox.question(

            self,

            "حذف",

            "آیا از حذف این کارمند مطمئن هستید؟"

        )



        if result != QMessageBox.Yes:

            return



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute(

            "DELETE FROM staff WHERE id=?",

            (self.selected_staff_id,)

        )



        conn.commit()

        conn.close()



        self.load_staff()

        self.clear_form()





    # =====================================================
    # پاک کردن فرم
    # =====================================================


    def clear_form(self):


        self.selected_staff_id = None


        self.photo_path = ""



        self.first_name.clear()

        self.last_name.clear()

        self.national_code.clear()

        self.personnel_code.clear()

        self.mobile.clear()

        self.phone.clear()

        self.email.clear()

        self.description.clear()



        self.position.setCurrentIndex(0)

        self.status.setCurrentIndex(0)

        self.access.setCurrentIndex(0)



        self.photo_label.clear()