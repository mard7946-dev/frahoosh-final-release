from pages.student.panel import Panel as OperationalStudentPanel

class StudentPanel(OperationalStudentPanel):
    """Backward-compatible entry point for the old student panel import.
    It now opens the same operational, database-backed student panel instead
    of a decorative button-only screen.
    """
    def __init__(self, parent=None, student_id=None, username=None):
        super().__init__(parent=parent, student_id=student_id, username=username)
