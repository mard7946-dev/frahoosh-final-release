import sqlite3, re
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLineEdit,QComboBox,QSpinBox,QPushButton,QTableWidget,QTableWidgetItem,QLabel,QMessageBox,QCheckBox
from PySide6.QtCore import Qt
from utils.jalali import iso_to_jalali
from database.db import DATABASE_NAME

DB=DATABASE_NAME
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def ensure_payment_schema():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS payment_offers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          amount INTEGER NOT NULL DEFAULT 0, target_type TEXT NOT NULL,
          target_value TEXT DEFAULT '', description TEXT DEFAULT '',
          active INTEGER DEFAULT 1, manual_amount INTEGER DEFAULT 0,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP, created_at_shamsi TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS payment_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, offer_id INTEGER, student_id INTEGER,
          payer_username TEXT, payer_role TEXT, amount INTEGER NOT NULL,
          masked_card TEXT DEFAULT '', status TEXT DEFAULT 'pending',
          gateway_ref TEXT DEFAULT '', description TEXT DEFAULT '',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP, created_at_shamsi TEXT DEFAULT ''
        );
        """)

class PaymentManagerPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); ensure_payment_schema(); self._build(); self.load()
    def _build(self):
        l=QVBoxLayout(self); l.addWidget(QLabel('مدیریت پرداخت آنلاین | تعریف مبالغ و مخاطبان'))
        f=QHBoxLayout(); self.title=QLineEdit(); self.title.setPlaceholderText('عنوان پرداخت')
        self.amount=QSpinBox(); self.amount.setRange(0,999999999); self.amount.setSuffix(' تومان')
        self.target=QComboBox(); self.target.addItems(['دانش‌آموز','کلاس','اولیای دانش‌آموز','اولیای کل'])
        self.value=QLineEdit(); self.value.setPlaceholderText('شناسه دانش‌آموز یا نام کلاس؛ برای کل اولیا خالی')
        self.desc=QLineEdit(); self.desc.setPlaceholderText('شرح پرداخت (توسط مدیر)')
        self.manual=QCheckBox('مبلغ دستی مجاز باشد')
        add=QPushButton('فعال‌سازی پرداخت'); add.clicked.connect(self.add)
        for x in (self.title,self.amount,self.target,self.value,self.desc,self.manual,add): f.addWidget(x)
        l.addLayout(f)
        self.table=QTableWidget(0,8); self.table.setHorizontalHeaderLabels(['ID','عنوان','مبلغ','مخاطب','هدف','شرح','فعال','مبلغ دستی']); l.addWidget(self.table)
        bar=QHBoxLayout(); toggle=QPushButton('فعال/غیرفعال'); delete=QPushButton('حذف'); bar.addWidget(toggle);bar.addWidget(delete);l.addLayout(bar)
        toggle.clicked.connect(self.toggle);delete.clicked.connect(self.delete)
    def load(self):
        with db() as c: rows=c.execute('SELECT id,title,amount,target_type,target_value,description,active,manual_amount FROM payment_offers ORDER BY id DESC').fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r[k] for k in ('id','title','amount','target_type','target_value','description','active','manual_amount')]
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def add(self):
        if not self.title.text().strip() or self.amount.value()<=0:
            QMessageBox.warning(self,'پرداخت','عنوان و مبلغ الزامی است.'); return
        now=datetime.now(); sh=iso_to_jalali(now.strftime('%Y-%m-%d'))
        with db() as c:
            c.execute('INSERT INTO payment_offers(title,amount,target_type,target_value,description,active,manual_amount,created_at,created_at_shamsi) VALUES(?,?,?,?,?,?,?,?,?)',
                      (self.title.text().strip(),self.amount.value(),self.target.currentText(),self.value.text().strip(),self.desc.text().strip(),1,int(self.manual.isChecked()),now.strftime('%Y-%m-%d %H:%M:%S'),sh));c.commit()
        self.load()
    def selected(self):
        r=self.table.currentRow(); return int(self.table.item(r,0).text()) if r>=0 else None
    def toggle(self):
        oid=self.selected()
        if oid is None:return
        with db() as c:c.execute('UPDATE payment_offers SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?',(oid,));c.commit()
        self.load()
    def delete(self):
        oid=self.selected()
        if oid is None:return
        with db() as c:c.execute('DELETE FROM payment_offers WHERE id=?',(oid,));c.commit()
        self.load()

class OnlinePaymentPage(QWidget):
    def __init__(self,parent=None,username='',role='parent',student_id=None):
        super().__init__(parent); ensure_payment_schema(); self.username=username; self.role=role; self.student_id=student_id; self._offers=[]; self._build(); self.load()
    def load_student(self,sid):
        self.student_id=sid
        self.load()
    def _build(self):
        l=QVBoxLayout(self); l.addWidget(QLabel('💳 پرداخت آنلاین | درگاه آماده اتصال'))
        self.info=QLabel('اطلاعات کارت و رمز پویا فقط برای ارسال به درگاه استفاده می‌شوند و در دیتابیس ذخیره نمی‌شوند.'); self.info.setWordWrap(True); l.addWidget(self.info)
        self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['ID','عنوان','مبلغ','مخاطب','شرح','وضعیت']); l.addWidget(self.table)
        form=QFormLayout(); self.card=QLineEdit();self.card.setPlaceholderText('شماره کارت ۱۶ رقمی');self.card.setMaxLength(19)
        self.amount=QLineEdit();self.amount.setReadOnly(True);self.cv2=QLineEdit();self.cv2.setEchoMode(QLineEdit.Password);self.cv2.setPlaceholderText('CVV2')
        self.otp=QLineEdit();self.otp.setEchoMode(QLineEdit.Password);self.otp.setPlaceholderText('رمز پویا')
        self.captcha=QLineEdit();self.captcha.setPlaceholderText('عبارت امنیتی');self.desc=QLineEdit();self.desc.setReadOnly(True)
        form.addRow('شماره کارت',self.card);form.addRow('مبلغ',self.amount);form.addRow('CVV2',self.cv2);form.addRow('رمز پویا',self.otp);form.addRow('عبارت امنیتی',self.captcha);form.addRow('شرح پرداخت',self.desc);l.addLayout(form)
        b=QPushButton('دریافت رمز پویا');b.clicked.connect(lambda:QMessageBox.information(self,'رمز پویا','این دکمه آماده اتصال به سرویس رسمی بانک/درگاه است؛ در نسخه متصل، درخواست OTP از درگاه ارسال می‌شود.'));l.addWidget(b)
        pay=QPushButton('ادامه به درگاه پرداخت');pay.clicked.connect(self.pay);l.addWidget(pay)
        self.table.itemSelectionChanged.connect(self.select_offer)
    def load(self):
        with db() as c:
            rows=c.execute('SELECT * FROM payment_offers WHERE active=1 ORDER BY id DESC').fetchall()
            st=c.execute('SELECT grade,class_name FROM students WHERE id=?',(self.student_id,)).fetchone() if self.student_id else None
            parent_ids=set()
            if self.role=='parent' and self.student_id:
                for r in c.execute('SELECT student_id FROM parent_children WHERE parent_username=?',(self.username,)).fetchall(): parent_ids.add(str(r['student_id']))
        visible=[]
        for r in rows:
            t=r['target_type'];v=str(r['target_value'] or '').strip()
            ok = (t=='دانش‌آموز' and self.student_id is not None and v==str(self.student_id))                  or (t=='کلاس' and st is not None and v==str(st['class_name'] or ''))                  or (t=='اولیای دانش‌آموز' and self.role=='parent' and v in parent_ids)                  or (t=='اولیای کل' and self.role=='parent')
            if ok: visible.append(r)
        self._offers=visible; self.table.setRowCount(len(visible))
        for i,r in enumerate(visible):
            vals=[r['id'],r['title'],r['amount'],r['target_type'],r['description'],'فعال']
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def select_offer(self):
        r=self.table.currentRow()
        if r<0:return
        offer=self._offers[r]; self.amount.setText(str(offer['amount']));self.amount.setReadOnly(not bool(offer['manual_amount']));self.desc.setText(offer['description'] or offer['title'])
        self._selected=offer
    def pay(self):
        offer=getattr(self,'_selected',None)
        if not offer:return QMessageBox.warning(self,'پرداخت','ابتدا یک مورد پرداخت را انتخاب کنید.')
        card=re.sub(r'\D','',self.card.text())
        if len(card)!=16:return QMessageBox.warning(self,'پرداخت','شماره کارت باید ۱۶ رقمی باشد.')
        if not self.cv2.text().strip() or not self.otp.text().strip() or not self.captcha.text().strip():return QMessageBox.warning(self,'پرداخت','CVV2، رمز پویا و عبارت امنیتی الزامی است.')
        amount=int(offer['amount']) if not offer['manual_amount'] else int(re.sub(r'\D','',self.amount.text() or '0'))
        sh=iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
        with db() as c:
            c.execute('INSERT INTO payment_attempts(offer_id,student_id,payer_username,payer_role,amount,masked_card,status,description,created_at_shamsi) VALUES(?,?,?,?,?,?,?,?,?)',
                      (offer['id'],self.student_id,self.username,self.role,amount,'*'*12+card[-4:],'pending_gateway',offer['description'] or offer['title'],sh));c.commit()
        self.cv2.clear();self.otp.clear()
        QMessageBox.information(self,'درگاه پرداخت','درخواست پرداخت ثبت شد. فقط اتصال Gateway رسمی (مثلاً PSP/شاپرک) باقی مانده است.')
