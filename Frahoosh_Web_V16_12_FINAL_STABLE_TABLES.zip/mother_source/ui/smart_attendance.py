from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
)

from PySide6.QtCore import Qt, QTimer





class SmartAttendance(QWidget):


    def __init__(self):

        super().__init__()



        self.setWindowTitle(
            "🤖 حضور و غیاب هوشمند فراهوش"
        )



        self.resize(
            900,
            600
        )



        self.students = [

            "دانش آموز ۱",
            "دانش آموز ۲",
            "دانش آموز ۳",
            "دانش آموز ۴"

        ]



        self.create_ui()



        self.start_monitor()




    # =====================================
    # ساخت رابط
    # =====================================


    def create_ui(self):


        main_layout = QVBoxLayout(
            self
        )



        title = QLabel(
            "🤖 سیستم حضور و غیاب هوشمند کلاس"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        main_layout.addWidget(
            title
        )



        self.table = QTableWidget()



        self.table.setColumnCount(
            4
        )



        self.table.setHorizontalHeaderLabels(

            [

                "نام دانش آموز",

                "وضعیت",

                "زمان ورود",

                "آخرین فعالیت"

            ]

        )



        self.table.setRowCount(
            len(self.students)
        )



    # =====================================
        # پر کردن جدول
        # =====================================


        for row, student in enumerate(
            self.students
        ):


            self.table.setItem(
                row,
                0,
                QTableWidgetItem(
                    student
                )
            )



            self.table.setItem(
                row,
                1,
                QTableWidgetItem(
                    "🔴 غایب"
                )
            )



            self.table.setItem(
                row,
                2,
                QTableWidgetItem(
                    "-"
                )
            )



            self.table.setItem(
                row,
                3,
                QTableWidgetItem(
                    "-"
                )
            )



        main_layout.addWidget(
            self.table
        )



        # =====================================
        # دکمه ها
        # =====================================


        button_layout = QHBoxLayout()



        enter_button = QPushButton(
            "🟢 ثبت حضور"
        )


        enter_button.clicked.connect(
            self.mark_present
        )



        exit_button = QPushButton(
            "🔴 ثبت خروج"
        )


        exit_button.clicked.connect(
            self.mark_exit
        )



        check_button = QPushButton(
            "🔍 بررسی فعالیت"
        )


        check_button.clicked.connect(
            self.check_activity
        )



        button_layout.addWidget(
            enter_button
        )


        button_layout.addWidget(
            exit_button
        )


        button_layout.addWidget(
            check_button
        )



        main_layout.addLayout(
            button_layout
        )





    # =====================================
    # ثبت حضور
    # =====================================


    def mark_present(self):


        row = (
            self.table.currentRow()
        )



        if row >= 0:


            self.table.setItem(

                row,

                1,

                QTableWidgetItem(
                    "🟢 حاضر"
                )

            )



            self.table.setItem(

                row,

                2,

                QTableWidgetItem(
                    "اکنون"
                )

            )



    # =====================================
    # ثبت خروج
    # =====================================


    def mark_exit(self):


        row = (
            self.table.currentRow()
        )



        if row >= 0:


            self.table.setItem(

                row,

                1,

                QTableWidgetItem(
                    "⚫ خارج شده"
                )

            )


    # =====================================
    # بررسی فعالیت دانش آموزان
    # =====================================


    def check_activity(self):


        inactive_count = 0



        for row in range(
            self.table.rowCount()
        ):


            status_item = (
                self.table.item(
                    row,
                    1
                )
            )



            if status_item:


                if (
                    "حاضر"
                    in
                    status_item.text()
                ):


                    self.table.setItem(

                        row,

                        3,

                        QTableWidgetItem(
                            "فعال"
                        )

                    )



                else:


                    inactive_count += 1



        QMessageBox.information(

            self,

            "گزارش فعالیت",

            f"تعداد افراد بدون فعالیت: {inactive_count}"

        )






    # =====================================
    # شروع بررسی خودکار
    # =====================================


    def start_monitor(self):


        self.timer = QTimer(
            self
        )


        self.timer.timeout.connect(
            self.auto_check
        )


        # هر 60 ثانیه

        self.timer.start(
            60000
        )






    # =====================================
    # بررسی خودکار
    # =====================================


    def auto_check(self):


        for row in range(

            self.table.rowCount()

        ):


            status = self.table.item(

                row,

                1

            )



            if status:


                if (
                    "حاضر"
                    in
                    status.text()
                ):


                    self.table.setItem(

                        row,

                        3,

                        QTableWidgetItem(

                            "🟡 در حال بررسی"

                        )

                    )