from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QFrame, QTabWidget, QStackedWidget
from PySide6.QtCore import Qt, QTimer
import re
from ui.complete_module_pages import CompleteTabs, executive_specs, teacher_specs, ai_specs, smart_specs
from ui.payment_gateway import OnlinePaymentPage, PaymentManagerPage
from teacher.exam_scheduler import ExamSchedulerPage

class TypewriterLabel(QLabel):
    def __init__(self, text, parent=None, interval=42):
        super().__init__(parent); self._full_text=text; self._index=0; self._interval=interval
        self._timer=QTimer(self); self._timer.timeout.connect(self._tick)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter); self.setWordWrap(True); self.setText("")
    def start(self): self._index=0; self.setText(""); self._timer.start(self._interval)
    def _tick(self):
        self._index += 1; self.setText(self._full_text[:self._index])
        if self._index >= len(self._full_text): self._timer.stop(); self.full_text_finished()
    def full_text_finished(self): pass

PANEL_ITEMS={
"مدیریت":["مدیریت کاربران و کارکنان","کلاس آنلاین","برنامه هفتگی و برنامه امتحانات","گزارش‌ها و آمار","تنظیمات مدرسه"],
"معاونت اجرایی":["دانش‌آموزان","کلاس‌ها","کارکنان","پرونده‌ها","امور اجرایی","گزارش‌ها"],
"معاونت آموزشی":["حضور و غیاب","ارجاعات آموزشی","جلسات","اطلاع‌رسانی","امتحانات","بانک سؤال","گزارش‌های آموزشی"],
"معاونت پرورشی":["فعالیت‌های فرهنگی","مسابقات","برنامه‌های پرورشی","ثبت‌نام فعالیت‌ها","گزارش‌های پرورشی"],
"مشاور":["پرونده مشاوره","جلسات","پیگیری دانش‌آموز","ارجاعات","هدایت تحصیلی","گزارش مشاوره"],
"دبیران":["کلاس‌های من","نمرات و کارنامه","تکالیف","حضور و غیاب","آزمون‌ها","طرح درس","جلسات","گزارش‌ها"],
"دانش‌آموزان":["انتخاب و اطلاعات من","کارنامه و نمرات","تکالیف","پیام‌ها","حضور و غیاب","مسابقات و فعالیت‌ها","برنامه هفتگی","امتحانات","گزارش عملکرد","کلاس آنلاین","پرداخت آنلاین"],
"اولیا":["انتخاب دانش‌آموز","اطلاعات دانش‌آموز","کارنامه و نمرات","حضور و غیاب","تکالیف و فعالیت‌های آموزشی","پیام‌ها و اطلاعیه‌ها","برنامه هفتگی و امتحانات","جلسات با دبیران","پرداخت‌ها و امور مالی","پرداخت آنلاین","فعالیت‌های فرهنگی و پرورشی"],
"مالی":["پرداخت‌ها","تراکنش‌ها","حساب‌ها","گزارش مالی","تنظیمات پرداخت آنلاین"],"تابلو هوشمند":["تخته آموزشی","فایل‌ها","تصاویر و ویدئوها","ابزارهای تعاملی"],
"هوش مصنوعی":["دستیار هوشمند","تحلیل آموزشی","گزارش هوشمند","پرسش و پاسخ"],"تنظیمات":["تنظیمات حساب","تنظیمات مدرسه","پشتیبان‌گیری"]}
PANEL_HINTS={
"مدیریت":"آیا می‌دانید؟ با پنل مدیریت فراهوش می‌توانید امور آموزشی، اجرایی، اداری و عملکرد مدرسه را یکپارچه مدیریت و کنترل کنید.",
"معاونت اجرایی":"آیا می‌دانید؟ پنل اجرایی امکان مدیریت منظم اطلاعات دانش‌آموزان، کلاس‌ها، کارکنان، پرونده‌ها و امور اجرایی مدرسه را فراهم می‌کند.",
"معاونت آموزشی":"آیا می‌دانید؟ پنل آموزشی برای مدیریت کلاس‌ها، حضور و غیاب، امتحانات، ارجاعات و عملکرد آموزشی دانش‌آموزان طراحی شده است.",
"معاونت پرورشی":"آیا می‌دانید؟ با پنل پرورشی می‌توانید فعالیت‌های فرهنگی، مسابقات، برنامه‌های تربیتی و مشارکت دانش‌آموزان را پیگیری کنید.",
"مشاور":"آیا می‌دانید؟ پنل مشاور برای ثبت و پیگیری پرونده‌های مشاوره، جلسات، ارجاعات و روند هدایت تحصیلی دانش‌آموزان در اختیار شماست.",
"دبیران":"آیا می‌دانید؟ در پنل اختصاصی دبیر می‌توانید کلاس‌ها، نمرات، تکالیف، حضور و غیاب، آزمون‌ها و برنامه‌های آموزشی خود را مدیریت کنید.",
"دانش‌آموزان":"آیا می‌دانید؟ دانش‌آموز می‌تواند در هر ساعت از شبانه‌روز به نمرات، تکالیف، پیام‌ها، برنامه‌ها، مسابقات و وضعیت آموزشی خود دسترسی داشته باشد.",
"اولیا":"آیا می‌دانید؟ شما می‌توانید در هر ساعت از شبانه‌روز با سیستم هوشمند دبیرستان سردار شهید حاجی‌زاده ۲ در ارتباط باشید و از وضعیت آموزشی، تحصیلی، انضباطی و فعالیت‌های فرزندتان مطلع شوید.",
"مالی":"آیا می‌دانید؟ پنل مالی امکان پیگیری پرداخت‌ها، تراکنش‌ها، حساب‌ها و گزارش‌های مالی مدرسه را فراهم می‌کند.",
"تابلو هوشمند":"آیا می‌دانید؟ تابلو هوشمند امکان ارائه محتوای آموزشی، فایل‌ها، تصاویر، ویدئوها و ابزارهای تعاملی را فراهم می‌کند.",
"هوش مصنوعی":"آیا می‌دانید؟ هوش مصنوعی فراهوش می‌تواند در تحلیل اطلاعات، گزارش‌گیری و پاسخ‌گویی هوشمند به کاربران مدرسه کمک کند.",
"تنظیمات":"آیا می‌دانید؟ تنظیمات فراهوش برای مدیریت حساب، مدرسه و نگهداری امن اطلاعات در اختیار شماست."}
ITEM_ALIASES={
"مدیریت":{"مدیریت کاربران و کارکنان":["users","کاربران","کارکنان"],"کلاس آنلاین":["virtual","کلاس آنلاین","کلاس مجازی"],"برنامه هفتگی و برنامه امتحانات":["planning","برنامه هفتگی","برنامه امتحانات","امتحان"],"گزارش‌ها و آمار":["reports","گزارش"],"تنظیمات مدرسه":["settings","تنظیمات"]},
"معاونت اجرایی":{"دانش‌آموزان":["students","دانش‌آموزان"],"کلاس‌ها":["مدیریت کلاس‌ها","کلاس"],"کارکنان":["staff","کارکنان"],"پرونده‌ها":["پرونده دانش‌آموزی","archive","بایگانی"],"امور اجرایی":["درخواست‌ها","اموال","گواهی‌ها","کارت‌ها"],"گزارش‌ها":["گزارش‌ها","گزارش"]},
"معاونت آموزشی":{"حضور و غیاب":["attendance","حضور"],"ارجاعات آموزشی":["referrals","ارجاع"],"جلسات":["meetings","جلسه"],"اطلاع‌رسانی":["notifications","اطلاع"],"امتحانات":["exams","امتحان"],"بانک سؤال":["questions","سؤال","سوال"],"گزارش‌های آموزشی":["reports","گزارش"]},
"معاونت پرورشی":{"فعالیت‌های فرهنگی":["ceremonies","festivals","talents","quran","فعالیت","فرهنگی"],"مسابقات":["competitions","مسابقات"],"برنامه‌های پرورشی":["ceremonies","trips","پرورشی"],"ثبت‌نام فعالیت‌ها":["registrations","registration","ثبت‌نام","activities"],"گزارش‌های پرورشی":["reports","گزارش"]},
"مشاور":{"پرونده مشاوره":["file","پرونده"],"جلسات":["parent_meeting","جلسه"],"پیگیری دانش‌آموز":["follow","پیگیری"],"ارجاعات":["referral","ارجاع"],"هدایت تحصیلی":["guidance","هدایت"],"گزارش مشاوره":["reports","گزارش"]},
"دبیران":{"کلاس‌های من":["classes","کلاس"],"نمرات و کارنامه":["grades","نمرات","کارنامه"],"تکالیف":["assignments","تکلیف"],"حضور و غیاب":["attendance","حضور"],"آزمون‌ها":["quiz","آزمون"],"طرح درس":["lesson","طرح درس"],"جلسات":["meetings","جلسه"],"گزارش‌ها":["reports","گزارش"]},
"دانش‌آموزان":{"انتخاب و اطلاعات من":["profile","اطلاعات","پروفایل"],"کارنامه و نمرات":["grades","نمرات","کارنامه"],"تکالیف":["assignments","تکلیف"],"پیام‌ها":["messages","پیام"],"حضور و غیاب":["attendance","حضور"],"مسابقات و فعالیت‌ها":["activities","مسابقات","فعالیت"],"برنامه هفتگی":["schedule","weekly","برنامه"],"امتحانات":["exams","exam","امتحان"],"گزارش عملکرد":["reports","گزارش"],"کلاس آنلاین":["online","کلاس آنلاین","کلاس مجازی"],"پرداخت آنلاین":["payment","پرداخت آنلاین","پرداخت"],"برنامه هفتگی":["schedule","weekly","برنامه هفتگی"],"امتحانات":["exams","exam","امتحان"]},
"اولیا":{"انتخاب دانش‌آموز":["چندفرزندی","انتخاب"],"اطلاعات دانش‌آموز":["اطلاعات دانش‌آموز"],"کارنامه و نمرات":["کارنامه و نمرات"],"حضور و غیاب":["انضباطی","حضور","انضباط"],"تکالیف و فعالیت‌های آموزشی":["تکلیف","فعالیت"],"پیام‌ها و اطلاعیه‌ها":["پیام‌های مدرسه","پیام","اطلاع"],"برنامه هفتگی و امتحانات":["برنامه هفتگی","برنامه امتحانات"],"جلسات با دبیران":["درخواست ملاقات","جلسات"],"پرداخت‌ها و امور مالی":["پرداخت"],"فعالیت‌های فرهنگی و پرورشی":["فرهنگی","نظرسنجی","فعالیت"]},
"مالی":{"پرداخت‌ها":["payment","پرداخت"],"تراکنش‌ها":["transaction","تراکنش"],"حساب‌ها":["account","حساب"],"گزارش مالی":["report","گزارش"]},
"تابلو هوشمند":{"تخته آموزشی":["تخته آموزشی","board","تخته"],"فایل‌ها":["فایل‌ها","file","فایل"],"تصاویر و ویدئوها":["تصاویر و ویدئوها","media","تصویر","ویدئو"],"ابزارهای تعاملی":["ابزارهای تعاملی","interactive","ابزار"]},
"هوش مصنوعی":{"دستیار هوشمند":["دستیار هوشمند","assistant","دستیار"],"تحلیل آموزشی":["تحلیل آموزشی","analysis","تحلیل"],"گزارش هوشمند":["گزارش هوشمند","report","گزارش"],"پرسش و پاسخ":["پرسش و پاسخ","chat","qa","پرسش"]},
"تنظیمات":{"تنظیمات حساب":["account","حساب"],"تنظیمات مدرسه":["school","مدرسه"],"پشتیبان‌گیری":["backup","پشتیبان"]}}

class PanelAccordionShell(QWidget):
    """Final stable shell: selecting an item opens only that item's real page."""
    def __init__(self,panel,panel_name,school_name,role_label=None,background="#e8f1ff",parent=None):
        super().__init__(parent); self.panel=panel; self.panel_name=panel_name; self.school_name=school_name; self.role_label=role_label or panel_name; self.background=background
        self._expanded=False; self._entered=False; self._menu_buttons=[]; self._restore_info=None
        self.setObjectName("panel_accordion_shell"); self._build(); self._start_welcome()
    def _build(self):
        self.setStyleSheet(f'''QWidget#panel_accordion_shell{{background:{self.background};border-radius:18px;}} QFrame#welcome_card{{background:rgba(255,255,255,235);border:1px solid rgba(30,41,59,35);border-radius:18px;}} QLabel#welcome_text{{color:#172033;font-family:"B Nazanin";font-size:22px;font-weight:bold;padding:14px 22px;}} QLabel#panel_hint{{color:#334155;font-family:"B Nazanin";font-size:16px;padding:8px 18px 12px;}} QPushButton#enter_button{{background:#0f766e;color:white;border:0;border-radius:12px;padding:12px 28px;font-family:"B Nazanin";font-size:17px;font-weight:bold;}} QPushButton#enter_button:disabled{{background:#94a3b8;}} QFrame#accordion_header{{background:rgba(255,255,255,242);border:1px solid rgba(30,41,59,38);border-radius:14px;}} QPushButton#accordion_button{{background:transparent;color:#172033;border:0;padding:10px 16px;font-family:"B Nazanin";font-size:19px;font-weight:bold;text-align:right;}} QFrame#menu_frame{{background:rgba(255,255,255,185);border-radius:12px;}} QPushButton#menu_button{{background:rgba(255,255,255,220);color:#172033;border:1px solid rgba(30,41,59,25);border-radius:10px;padding:10px 14px;font-family:"B Nazanin";font-size:16px;text-align:right;}} QFrame#detail_header{{background:rgba(255,255,255,235);border-radius:12px;}} QPushButton#back_button{{background:transparent;border:0;font-size:15px;padding:7px 12px;}} QFrame#panel_content{{background:transparent;border:0;}}''')
        root=QVBoxLayout(self); root.setContentsMargins(10,8,10,8); root.setSpacing(8)
        self.welcome_card=QFrame(); self.welcome_card.setObjectName("welcome_card"); wl=QVBoxLayout(self.welcome_card); wl.setContentsMargins(16,12,16,12); wl.setSpacing(8)
        self.welcome=TypewriterLabel(f"کاربر عزیز، به پنل {self.role_label} فراهوش {self.school_name} خوش آمدید."); self.welcome.setObjectName("welcome_text"); wl.addWidget(self.welcome)
        self.enter=QPushButton("وارد پنل شوید"); self.enter.setObjectName("enter_button"); self.enter.setMinimumHeight(48); self.enter.setEnabled(False); self.enter.clicked.connect(self.enter_panel); wl.addWidget(self.enter); root.addWidget(self.welcome_card)
        self.accordion_header=QFrame(); self.accordion_header.setObjectName("accordion_header"); hl=QVBoxLayout(self.accordion_header); hl.setContentsMargins(4,4,4,4); hl.setSpacing(3)
        self.accordion_button=QPushButton(); self.accordion_button.setObjectName("accordion_button"); self.accordion_button.setMinimumHeight(50); self.accordion_button.clicked.connect(self.toggle_panel); hl.addWidget(self.accordion_button)
        self.menu_frame=QFrame(); self.menu_frame.setObjectName("menu_frame"); ml=QVBoxLayout(self.menu_frame); ml.setContentsMargins(8,6,8,8); ml.setSpacing(6)
        self.hint=TypewriterLabel(PANEL_HINTS.get(self.panel_name,"آیا می‌دانید؟ پنل اختصاصی فراهوش برای دسترسی سریع و منظم به اطلاعات مدرسه طراحی شده است."),interval=34); self.hint.setObjectName("panel_hint"); self.hint.setWordWrap(True); self.hint.setAlignment(Qt.AlignmentFlag.AlignRight); ml.addWidget(self.hint); self.hint.full_text_finished=self._hint_finished
        for label in PANEL_ITEMS.get(self.panel_name,["ورود به امکانات پنل"]):
            btn=QPushButton(f"›  {label}"); btn.setObjectName("menu_button"); btn.setMinimumHeight(44); btn.setVisible(False); btn.clicked.connect(lambda checked=False,text=label:self.open_item(text)); ml.addWidget(btn); self._menu_buttons.append(btn)
        self.menu_frame.setVisible(False); hl.addWidget(self.menu_frame); self.accordion_header.setVisible(False); root.addWidget(self.accordion_header)
        self.detail_header=QFrame(); self.detail_header.setObjectName("detail_header"); dl=QVBoxLayout(self.detail_header); dl.setContentsMargins(8,4,8,4); dl.setSpacing(0); self.detail_title=QLabel(""); self.detail_title.setObjectName("panel_hint"); self.detail_title.setAlignment(Qt.AlignmentFlag.AlignRight); dl.addWidget(self.detail_title); self.back_button=QPushButton("← بازگشت به فهرست پنل"); self.back_button.setObjectName("back_button"); self.back_button.clicked.connect(self.close_item); dl.addWidget(self.back_button); self.detail_header.setVisible(False); root.addWidget(self.detail_header)
        self.content_frame=QFrame(); self.content_frame.setObjectName("panel_content"); self.content_frame.setLayout(QVBoxLayout()); self.content_frame.layout().setContentsMargins(0,0,0,0); self.content_frame.setVisible(False); root.addWidget(self.content_frame,1)
    def _start_welcome(self): self.welcome.full_text_finished=self._welcome_finished; self.welcome.start()
    def _welcome_finished(self): self.enter.setEnabled(True)
    def enter_panel(self):
        self._entered=True; self._expanded=True; self.welcome_card.setVisible(False); self.accordion_header.setVisible(True); self._update_arrow(); self.menu_frame.setVisible(True); self.detail_header.setVisible(False); self.content_frame.setVisible(False)
        for b in self._menu_buttons:b.setVisible(False)
        self._reveal_menu_with_hint()
    def _reveal_menu_with_hint(self):
        self.hint.start(); count=max(1,len(self._menu_buttons)); n=max(1,len(self.hint._full_text))
        for i,b in enumerate(self._menu_buttons): QTimer.singleShot(max(1,int(n*(i+1)/count))*self.hint._interval,lambda x=b:x.setVisible(True))
    def _hint_finished(self):
        for b in self._menu_buttons:b.setVisible(True)
    def _update_arrow(self): self.accordion_button.setText(("▼" if self._expanded else "▸")+f"  پنل اختصاصی {self.role_label} فراهوش")
    def toggle_panel(self):
        if not self._entered:return
        self._expanded=not self._expanded; self._update_arrow(); self.menu_frame.setVisible(self._expanded)
        if self._expanded:self._reveal_menu_one_by_one()
        else:
            self.hint._timer.stop()
            for b in self._menu_buttons:b.setVisible(False)
    def _reveal_menu_one_by_one(self):
        for i,b in enumerate(self._menu_buttons):QTimer.singleShot(120*i,lambda x=b:x.setVisible(True))
    @staticmethod
    def _norm(v): return re.sub(r'\s+',' ',str(v or '').lower().replace('ي','ی').replace('ك','ک').replace('‌',' ')).strip()
    def _find_target(self,label):
        aliases=[self._norm(x) for x in ITEM_ALIASES.get(self.panel_name,{}).get(label,[label])]
        pages=getattr(self.panel,'pages',None)
        if isinstance(pages,dict):
            for key,w in pages.items():
                nk=self._norm(key)
                if any(a==nk or a in nk or nk in a for a in aliases): return ('stack',self._owner_stack(w),w,key)
            for key,w in pages.items():
                title=self._norm(getattr(w,'title',''))
                if title and any(a in title or title in a for a in aliases): return ('stack',self._owner_stack(w),w,key)
        for tabs in self.panel.findChildren(QTabWidget):
            for i in range(tabs.count()):
                title=self._norm(tabs.tabText(i))
                if any(a in title or title in a for a in aliases): return ('tab',tabs,tabs.widget(i),i,tabs.tabText(i))
        for stack in self.panel.findChildren(QStackedWidget):
            for i in range(stack.count()):
                w=stack.widget(i); text=self._norm(w.objectName())+' '+self._norm(w.__class__.__name__)
                if any(a in text for a in aliases): return ('stack',stack,w,i)
        return None
    def _owner_stack(self,w):
        for s in self.panel.findChildren(QStackedWidget):
            if s.indexOf(w)>=0:return s
        return None
    def _clear_content(self):
        while self.content_frame.layout().count():
            it=self.content_frame.layout().takeAt(0); w=it.widget()
            if w:w.setParent(None)
    def _context_value(self, name, default=None):
        p = self
        seen = set()
        while p is not None and id(p) not in seen:
            seen.add(id(p))
            if hasattr(p, name):
                value = getattr(p, name)
                if value not in (None, ''):
                    return value
            p = p.parent() if hasattr(p, 'parent') else None
        return default

    def _special_page(self, label):
        # Critical routes: these labels must never fall back to the generic
        # "page not found" message or to a decorative/empty nested widget.
        routes = {
            "معاونت اجرایی": {
                "کلاس‌ها": (executive_specs(), "معاونت اجرایی | کلاس‌ها"),
                "امور اجرایی": ([executive_specs()[1]], "معاونت اجرایی | امور اجرایی"),
                "گزارش‌ها": ([executive_specs()[2]], "معاونت اجرایی | گزارش‌ها"),
            },
            "دبیران": {
                "حضور و غیاب": ([teacher_specs()[0]], "دبیر | حضور و غیاب"),
                "آزمون‌ها": (ExamSchedulerPage(self._context_value("teacher_id"), self._context_value("teacher_name", ""), self), "دبیر | آزمون‌ها | زمان‌بندی سه‌گانه"),
            },
            "دانش‌آموزان": {
                "مسابقات و فعالیت‌ها": ([('مسابقات و فعالیت‌ها','student_registrations',
                    [('id','شناسه'),('student_id','دانش‌آموز'),('activity_title','فعالیت'),('activity_kind','نوع'),('fee','هزینه'),('payment_status','وضعیت پرداخت'),('registration_code','کد'),('registered_at','تاریخ ثبت')], []),], "دانش‌آموز | مسابقات و فعالیت‌ها"),
                "برنامه هفتگی": ([('برنامه هفتگی','weekly_schedule',
                    [('id','شناسه'),('teacher','دبیر'),('subject','درس'),('grade','پایه'),('hours','ساعت'),('bell_pattern','زنگ'),('class_names','کلاس‌ها')], []),], "دانش‌آموز | برنامه هفتگی"),
                "امتحانات": ([('امتحانات','exam_schedule',
                    [('id','شناسه'),('subject','درس'),('grade','پایه'),('exam_date','تاریخ امتحان'),('duration','مدت'),('weight','ضریب')], []),], "دانش‌آموز | امتحانات"),
                "گزارش عملکرد": ([('گزارش عملکرد','report_cards',
                    [('id','شناسه'),('student_id','دانش‌آموز'),('term','نوبت'),('average','معدل'),('description','توضیحات'),('created_at','تاریخ ثبت')], []),], "دانش‌آموز | گزارش عملکرد"),
                "پرداخت آنلاین": (OnlinePaymentPage(self, self._context_value("current_username", "student"), "student", self._context_value("current_student_id")), "دانش‌آموز | پرداخت آنلاین"),
            },
            "اولیا": {
                "پرداخت آنلاین": (OnlinePaymentPage(self, self._context_value("current_username", "parent"), "parent", self._context_value("selected_student_id")), "اولیا | پرداخت آنلاین"),
            },
            "مالی": {
                "تنظیمات پرداخت آنلاین": (PaymentManagerPage(self), "مالی | تنظیمات پرداخت آنلاین"),
            },
            "تابلو هوشمند": {
                "تخته آموزشی": ([smart_specs()[1]], "تابلو هوشمند | تخته آموزشی"),
            },
            "هوش مصنوعی": {
                "دستیار هوشمند": ([ai_specs()[0]], "هوش مصنوعی | دستیار هوشمند"),
                "تحلیل آموزشی": ([ai_specs()[2]], "هوش مصنوعی | تحلیل آموزشی"),
                "گزارش هوشمند": ([ai_specs()[3]], "هوش مصنوعی | گزارش هوشمند"),
                "پرسش و پاسخ": ([ai_specs()[1]], "هوش مصنوعی | پرسش و پاسخ"),
            },
        }
        route=routes.get(self.panel_name,{}).get(label)
        if not route: return None
        target,title=route
        if isinstance(target, QWidget):
            return target
        specs=target
        # Student pages are read-only; the other requested operational modules
        # remain editable.
        readonly=self.panel_name == "دانش‌آموزان"
        return CompleteTabs(specs,title,self,readonly=readonly)

    def open_item(self,label):
        self._clear_content(); self._restore_info=None
        special=self._special_page(label)
        if special is not None:
            w=special
            self.content_frame.layout().addWidget(w); w.show()
        else:
            target=self._find_target(label)
            if target is None:
                msg=QLabel(f"بخش «{label}» صفحه مستقلی برای نمایش اطلاعات ندارد."); msg.setAlignment(Qt.AlignmentFlag.AlignCenter); msg.setWordWrap(True); self.content_frame.layout().addWidget(msg)
            else:
                kind=target[0]
                if kind=='tab':
                    _,tabs,w,index,title=target; tabs.removeTab(index); self._restore_info=('tab',tabs,w,index,title)
                else:
                    _,stack,w,key=target; idx=stack.indexOf(w); stack.removeWidget(w); self._restore_info=('stack',stack,w,idx)
                w.setParent(self.content_frame); self.content_frame.layout().addWidget(w); w.show()
                for fn in ('load','reload'):
                    if hasattr(w,fn):
                        try:getattr(w,fn)()
                        except Exception:pass
                        break
        self.detail_title.setText(f"{self.panel_name}  ›  {label}"); self.detail_header.setVisible(True); self.menu_frame.setVisible(False); self.content_frame.setVisible(True); self._expanded=False; self._update_arrow()
    def close_item(self):
        self._clear_content(); r=self._restore_info
        if r:
            if r[0]=='tab': _,tabs,w,index,title=r; w.setParent(tabs); tabs.insertTab(index,w,title); tabs.setCurrentWidget(w)
            else: _,stack,w,index=r; w.setParent(stack); stack.insertWidget(index,w); stack.setCurrentWidget(w)
        self._restore_info=None; self.content_frame.setVisible(False); self.detail_header.setVisible(False); self._expanded=True; self._update_arrow(); self.menu_frame.setVisible(True); self._reveal_menu_with_hint()
