from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QTableWidget,
    QFrame
)

from PySide6.QtCore import Qt


class BaseModule(QWidget):

    def __init__(self, title):

        super().__init__()

        self.setWindowTitle(title)

        self.setMinimumSize(1100, 650)

        self.setLayoutDirection(Qt.RightToLeft)

        self.create_ui(title)



    def create_ui(self, title):

        main_layout = QVBoxLayout(self)


        # ==========================
        # عنوان ماژول
        # ==========================

        header = QLabel(title)

        header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        header.setStyleSheet("""
            font-size:28px;
            font-weight:bold;
            color:#1565C0;
            padding:15px;
        """)


        main_layout.addWidget(header)



        # ==========================
        # نوار ابزار
        # ==========================

        toolbar = QHBoxLayout()


        self.search_box = QLineEdit()

        self.search_box.setPlaceholderText(
            "جستجو ..."
        )

        self.search_box.setMinimumHeight(40)



        self.add_button = QPushButton("➕ افزودن")

        self.edit_button = QPushButton("✏️ ویرایش")

        self.delete_button = QPushButton("🗑 حذف")

        self.excel_button = QPushButton("📥 اکسل")



        toolbar.addWidget(self.search_box)

        toolbar.addWidget(self.add_button)

        toolbar.addWidget(self.edit_button)

        toolbar.addWidget(self.delete_button)

        toolbar.addWidget(self.excel_button)



        main_layout.addLayout(toolbar)



        # ==========================
        # جدول
        # ==========================

        frame = QFrame()

        frame_layout = QVBoxLayout(frame)


        self.table = QTableWidget()


        self.table.setAlternatingRowColors(True)


        frame_layout.addWidget(self.table)


        main_layout.addWidget(frame)



        # ==========================
        # ظاهر
        # ==========================

        self.setStyleSheet("""

            QWidget {

                background:#f5f7fb;
                font-family:Tahoma;

            }


            QLineEdit {

                background:white;
                border:1px solid #ccc;
                border-radius:8px;
                padding:8px;
                font-size:15px;

            }


            QPushButton {

                background:#1565C0;
                color:white;
                border-radius:8px;
                padding:10px;
                font-size:14px;

            }


            QPushButton:hover {

                background:#0D47A1;

            }


            QTableWidget {

                background:white;
                border-radius:10px;
                font-size:14px;

            }

        """)