# ui/theme.py
# تم مرکزی سامانه مدیریت هوشمند مدرسه فراهوش


FARAHOOSH_THEME = """

/* فونت کلی برنامه */
* {
    font-family: "B Zar";
    font-size: 14px;
    color: black;
}


/* پس زمینه اصلی */
QWidget {
    background-color: #f8fafc;
    color: black;
}


/* کارت ها و باکس ها */
QFrame {
    background-color: #f59e0b;
    border-radius: 15px;
    padding: 12px;
}


/* عنوان ها و نوشته ها */
QLabel {
    color: black;
    font-weight: bold;
}


/* دکمه های اصلی */
QPushButton {
    background-color: #16a34a;
    color: black;
    border-radius: 10px;
    padding: 8px 15px;
    font-weight: bold;
}


/* جلوگیری از سفید شدن متن دکمه */
QPushButton:hover {
    background-color: #15803d;
    color: black;
}


QPushButton:pressed {
    background-color: #166534;
    color: black;
}


/* دکمه های خاص */
QToolButton {
    background-color: #16a34a;
    color: black;
    border-radius: 10px;
    padding: 8px 15px;
    font-weight: bold;
}


QToolButton:hover {
    background-color: #15803d;
    color: black;
}


/* ورودی ها */
QLineEdit,
QTextEdit,
QPlainTextEdit,
QComboBox {

    background-color: white;
    color: black;
    border: 2px solid #16a34a;
    border-radius: 8px;
    padding: 6px;
}


/* لیست ها */
QListWidget,
QListView {

    background-color: white;
    color: black;
}


/* جدول ها */
QTableWidget,
QTableView {

    background-color: white;
    color: black;
    gridline-color: #999999;
}


/* تب ها */
QTabWidget::pane {
    background-color: white;
}


QTabBar::tab {

    background-color: #16a34a;
    color: black;
    padding: 8px 15px;
    border-radius: 8px;
}


"""


def apply_theme(app):
    app.setStyleSheet(FARAHOOSH_THEME)

    print("FARAHOOSH THEME LOADED")