from PySide6.QtWidgets import QWidget, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit, QPushButton, QListWidget, QListWidgetItem, QMessageBox
from PySide6.QtCore import Qt
from services.audience_service import AUDIENCE_OPTIONS, normalize_targets

class AudienceSelectorDialog(QDialog):
    """Reusable audience selector shown before final publication."""
    def __init__(self, parent=None, defaults=None, title="تعیین مخاطبان قبل از ثبت نهایی"):
        super().__init__(parent)
        self.setWindowTitle(title); self.resize(560, 520); self.setLayoutDirection(Qt.RightToLeft)
        self._targets = normalize_targets(defaults or [])
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("مخاطبان را انتخاب کنید. بدون انتخاب مخاطب، ثبت نهایی انجام نمی‌شود."))
        row = QHBoxLayout(); self.kind = QComboBox(); self.value = QLineEdit(); self.value.setPlaceholderText("شناسه دانش‌آموز، نام کلاس یا پایه")
        self.add_btn = QPushButton("افزودن مخاطب"); self.add_btn.clicked.connect(self.add_target)
        row.addWidget(self.kind); row.addWidget(self.value); row.addWidget(self.add_btn); lay.addLayout(row)
        self.kind.addItems([label for _, label in AUDIENCE_OPTIONS]); self.kind.currentIndexChanged.connect(self._update_hint); self._update_hint()
        self.list = QListWidget(); lay.addWidget(self.list); self._refresh()
        buttons = QHBoxLayout(); self.ok = QPushButton("تأیید مخاطبان و ثبت نهایی"); cancel = QPushButton("انصراف")
        self.ok.clicked.connect(self.accept_checked); cancel.clicked.connect(self.reject); buttons.addWidget(cancel); buttons.addWidget(self.ok); lay.addLayout(buttons)

    def _type(self): return AUDIENCE_OPTIONS[self.kind.currentIndex()][0]
    def _update_hint(self):
        t = self._type()
        self.value.setEnabled(t in {"student","class","student_parents","class_parents","grade_students"})
        hints = {"student":"شناسه داخلی دانش‌آموز را وارد کنید", "class":"نام دقیق کلاس را وارد کنید", "grade_students":"پایه را وارد کنید (مثلاً هفتم)", "student_parents":"شناسه داخلی دانش‌آموز را وارد کنید", "class_parents":"نام دقیق کلاس را وارد کنید"}
        self.value.setPlaceholderText(hints.get(t, "این مخاطب نیاز به مقدار ندارد"))

    def add_target(self):
        t = self._type(); v = self.value.text().strip() if self.value.isEnabled() else ""
        if t in {"student","student_parents"} and not v.isdigit():
            QMessageBox.warning(self,"مخاطب","برای این گزینه شناسه عددی دانش‌آموز لازم است."); return
        if t in {"class","class_parents","grade_students"} and not v:
            QMessageBox.warning(self,"مخاطب","مقدار مخاطب را وارد کنید."); return
        item=(t,v)
        if item not in self._targets: self._targets.append(item); self._refresh()
        self.value.clear()

    def _refresh(self):
        self.list.clear()
        labels=dict(AUDIENCE_OPTIONS)
        for idx,(t,v) in enumerate(self._targets):
            text=labels.get(t,t) + (f" — {v}" if v else "")
            item=QListWidgetItem(text); item.setData(Qt.UserRole,idx); self.list.addItem(item)

    def remove_selected(self):
        pass

    def accept_checked(self):
        if not self._targets:
            QMessageBox.warning(self,"مخاطب","حداقل یک مخاطب را انتخاب کنید."); return
        self.accept()

    def targets(self): return list(self._targets)

class AudienceDropdownWidget(QWidget):
    """Inline audience picker: the recipient menu is visible before final save."""
    def __init__(self, parent=None, defaults=None, title='مخاطب قبل از ثبت نهایی'):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        self._targets = normalize_targets(defaults or [])
        lay=QVBoxLayout(self)
        lay.addWidget(QLabel(title))
        row=QHBoxLayout()
        self.kind=QComboBox(); self.value=QComboBox(); self.value.setEditable(True)
        self.value.setPlaceholderText('انتخاب/وارد کردن مقدار')
        self.add_btn=QPushButton('افزودن')
        row.addWidget(self.kind,2); row.addWidget(self.value,2); row.addWidget(self.add_btn,1)
        lay.addLayout(row)
        self.list=QListWidget(); self.list.setMaximumHeight(110); lay.addWidget(self.list)
        self.remove_btn=QPushButton('حذف مخاطب انتخاب‌شده'); lay.addWidget(self.remove_btn)
        self.kind.addItems([label for _,label in AUDIENCE_OPTIONS])
        self.kind.currentIndexChanged.connect(self._refresh_value)
        self.add_btn.clicked.connect(self.add_target)
        self.remove_btn.clicked.connect(self.remove_selected)
        self._refresh_value()
        self._refresh_list()

    def _type(self): return AUDIENCE_OPTIONS[self.kind.currentIndex()][0]
    def _refresh_value(self):
        t=self._type(); self.value.clear(); self.value.setEnabled(t in {'student','class','student_parents','class_parents','grade_students'})
        if t in {'student','student_parents'}:
            try:
                import sqlite3
                from pathlib import Path
                db=Path(__file__).resolve().parents[1]/'school.db'
                c=sqlite3.connect(db); rows=c.execute("SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name").fetchall(); c.close()
                for sid,fn,ln,code in rows: self.value.addItem(f'{fn} {ln} | {code or sid}', str(sid))
            except Exception: pass
        elif t in {'class','class_parents'}:
            try:
                import sqlite3
                from pathlib import Path
                db=Path(__file__).resolve().parents[1]/'school.db'
                c=sqlite3.connect(db); rows=c.execute("SELECT DISTINCT class_name FROM students WHERE COALESCE(class_name,'')<>'' ORDER BY class_name").fetchall(); c.close()
                for (v,) in rows: self.value.addItem(str(v), str(v))
            except Exception: pass
        elif t=='grade_students':
            try:
                import sqlite3
                from pathlib import Path
                db=Path(__file__).resolve().parents[1]/'school.db'
                c=sqlite3.connect(db); rows=c.execute("SELECT DISTINCT grade FROM students WHERE COALESCE(grade,'')<>'' ORDER BY grade").fetchall(); c.close()
                for (v,) in rows: self.value.addItem(str(v), str(v))
            except Exception: pass
        else:
            self.value.addItem('همه افراد این گروه','')

    def add_target(self):
        t=self._type(); v=str(self.value.currentData() if self.value.currentData() is not None else self.value.currentText()).strip()
        if t in {'student','student_parents'} and not v.isdigit():
            QMessageBox.warning(self,'مخاطب','یک دانش‌آموز را از منو انتخاب کنید.'); return
        if t in {'class','class_parents','grade_students'} and not v:
            QMessageBox.warning(self,'مخاطب','مقدار مخاطب را انتخاب کنید.'); return
        item=(t,v)
        if item not in self._targets: self._targets.append(item); self._refresh_list()

    def remove_selected(self):
        r=self.list.currentRow()
        if r>=0: self._targets.pop(r); self._refresh_list()

    def _refresh_list(self):
        self.list.clear(); labels=dict(AUDIENCE_OPTIONS)
        for t,v in self._targets:
            self.list.addItem(labels.get(t,t)+(f' — {v}' if v else ''))

    def targets(self): return list(self._targets)
