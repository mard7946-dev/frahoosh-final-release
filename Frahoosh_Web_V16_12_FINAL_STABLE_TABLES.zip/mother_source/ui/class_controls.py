# =====================================================
# Frahoosh Online Classroom
# Class Controls
# کنترل های پایین کلاس آنلاین
# =====================================================


from PySide6.QtWidgets import (
    QWidget,
    QPushButton,
    QHBoxLayout,
    QLabel
)


from PySide6.QtCore import Qt



class ClassControls(QWidget):


    def __init__(self):


        super().__init__()



        # وضعیت ابزارها


        self.microphone = False


        self.camera = False


        self.hand_raise = False


        self.screen_share = False



        self.build_ui()




    # =================================================
    # ساخت رابط کاربری
    # =================================================

    def build_ui(self):


        self.setStyleSheet(
            """

            QWidget {

                background:#202124;
                border-radius:15px;

            }


            QPushButton {

                background:#303134;
                color:white;

                border-radius:10px;

                padding:10px;

                font-size:14px;

            }


            QPushButton:hover {

                background:#454545;

            }


            QLabel {

                color:white;

                font-size:15px;

            }

            """
        )



        layout = QHBoxLayout()



        layout.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        self.title = QLabel(
            "کنترل کلاس"
        )


        layout.addWidget(
            self.title
        )



        # -----------------------------
        # دکمه میکروفن
        # -----------------------------


        self.mic_button = QPushButton(
            "🎤 میکروفن"
        )


        self.mic_button.clicked.connect(
            self.toggle_microphone
        )



        layout.addWidget(
            self.mic_button
        )



        # -----------------------------
        # دکمه دوربین
        # -----------------------------


        self.camera_button = QPushButton(
            "📷 دوربین"
        )


        self.camera_button.clicked.connect(
            self.toggle_camera
        )



        layout.addWidget(
            self.camera_button
        )



        self.setLayout(
            layout
        )



    # -----------------------------
        # دکمه دست بالا
        # -----------------------------


        self.hand_button = QPushButton(
            "✋ دست بالا"
        )


        self.hand_button.clicked.connect(
            self.toggle_hand
        )


        layout.addWidget(
            self.hand_button
        )



        # -----------------------------
        # دکمه اشتراک صفحه
        # -----------------------------


        self.screen_button = QPushButton(
            "🖥 اشتراک صفحه"
        )


        self.screen_button.clicked.connect(
            self.toggle_screen_share
        )


        layout.addWidget(
            self.screen_button
        )



        # -----------------------------
        # دکمه تخته
        # -----------------------------


        self.board_button = QPushButton(
            "📚 تخته"
        )


        layout.addWidget(
            self.board_button
        )



        # -----------------------------
        # دکمه چت
        # -----------------------------


        self.chat_button = QPushButton(
            "💬 گفتگو"
        )


        layout.addWidget(
            self.chat_button
        )



        # -----------------------------
        # دکمه خروج
        # -----------------------------


        self.exit_button = QPushButton(
            "🚪 خروج"
        )


        layout.addWidget(
            self.exit_button
        )




    # =================================================
    # تغییر وضعیت میکروفن
    # =================================================

    def toggle_microphone(
        self
    ):


        self.microphone = not self.microphone



        if self.microphone:


            self.mic_button.setText(
                "🎤 میکروفن روشن"
            )


        else:


            self.mic_button.setText(
                "🔇 میکروفن خاموش"
            )



        return self.microphone




    # =================================================
    # تغییر وضعیت دوربین
    # =================================================

    def toggle_camera(
        self
    ):


        self.camera = not self.camera



        if self.camera:


            self.camera_button.setText(
                "📷 دوربین روشن"
            )


        else:


            self.camera_button.setText(
                "📷 دوربین خاموش"
            )



        return self.camera
    


    # =================================================
    # تغییر وضعیت دست بالا
    # =================================================

    def toggle_hand(
        self
    ):


        self.hand_raise = not self.hand_raise



        if self.hand_raise:


            self.hand_button.setText(
                "✋ دست بالا فعال"
            )


        else:


            self.hand_button.setText(
                "✋ دست پایین"
            )



        return self.hand_raise




    # =================================================
    # تغییر وضعیت اشتراک صفحه
    # =================================================

    def toggle_screen_share(
        self
    ):


        self.screen_share = not self.screen_share



        if self.screen_share:


            self.screen_button.setText(
                "🖥 اشتراک فعال"
            )


        else:


            self.screen_button.setText(
                "🖥 اشتراک صفحه"
            )



        return self.screen_share




    # =================================================
    # گرفتن وضعیت کامل کنترل‌ها
    # =================================================

    def get_status(
        self
    ):


        return {


            "microphone":

                self.microphone,


            "camera":

                self.camera,


            "hand_raise":

                self.hand_raise,


            "screen_share":

                self.screen_share

        }




    # =================================================
    # تنظیم وضعیت از بیرون
    # =================================================

    def set_status(
        self,
        data
    ):


        self.microphone = data.get(
            "microphone",
            False
        )


        self.camera = data.get(
            "camera",
            False
        )


        self.hand_raise = data.get(
            "hand_raise",
            False
        )


        self.screen_share = data.get(
            "screen_share",
            False
        )



        # بروزرسانی متن‌ها


        self.mic_button.setText(

            "🎤 میکروفن روشن"
            if self.microphone
            else
            "🔇 میکروفن خاموش"

        )


        self.camera_button.setText(

            "📷 دوربین روشن"
            if self.camera
            else
            "📷 دوربین خاموش"

        )


        self.hand_button.setText(

            "✋ دست بالا فعال"
            if self.hand_raise
            else
            "✋ دست پایین"

        )


        self.screen_button.setText(

            "🖥 اشتراک فعال"
            if self.screen_share
            else
            "🖥 اشتراک صفحه"

        )