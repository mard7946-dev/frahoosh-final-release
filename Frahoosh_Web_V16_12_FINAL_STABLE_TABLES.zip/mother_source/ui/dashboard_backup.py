from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QMessageBox
)

from PySide6.QtCore import Qt

import qtawesome as qta


from ui.students import Students



class Dashboard(QWidget):


    def __init__(self):

        super().__init__()



        self.setWindowTitle(
            "فراهوش | مدیریت هوشمند مدرسه"
        )



        self.resize(
            1200,
            750
        )



        # ==========================
        # لایه اصلی
        # ==========================


        self.main_layout = QHBoxLayout()



        self.setLayout(
            self.main_layout
        )



        # ==========================
        # بخش محتوا
        # ==========================


        self.content_layout = QVBoxLayout()



        self.content_widget = QWidget()


        self.content_widget.setLayout(
            self.content_layout
        )



        # ==========================
        # بخش منو
        # ==========================


        self.menu_layout = QVBoxLayout()



        self.menu_widget = QWidget()


        self.menu_widget.setLayout(
            self.menu_layout
        )



        # ==========================
        # ساخت بخش ها
        # ==========================


        self.create_logo()



        self.create_menu()



        self.main_layout.addWidget(
            self.content_widget,
            4
        )



        self.main_layout.addWidget(
            self.menu_widget,
            1
        )



        self.set_style()



        self.show_home()





    # ==========================
    # لوگو
    # ==========================


    def create_logo(self):


        logo = QLabel(
            "فراهوش"
        )


        logo.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        logo.setStyleSheet("""

        QLabel{

            color:#1565C0;

            font-size:40px;

            font-weight:bold;

            padding:20px;

        }

        """)



        self.menu_layout.addWidget(
            logo
        )



        title = QLabel(
            "سامانه مدیریت هوشمند مدرسه"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.menu_layout.addWidget(
            title
        )



    # ==========================
    # منوی اصلی
    # ==========================


    def create_menu(self):


        self.create_button(

            "👨‍🎓 دانش‌آموزان",

            "fa5s.user-graduate",

            self.open_students

        )



        self.create_button(

            "🎓 پنل دانش‌آموز",

            "fa5s.id-card",

            self.open_student_panel

        )



        modules = [


            ("👨‍🏫 کارکنان",
             "fa5s.users"),


            ("👨‍👩‍👦 اولیا",
             "fa5s.user-friends"),


            ("📚 آموزش",
             "fa5s.book"),


            ("📝 نمرات",
             "fa5s.chart-line"),


            ("📅 حضور و غیاب",
             "fa5s.calendar-check"),


            ("❤️ مشاوره",
             "fa5s.heart"),


            ("🏆 نام‌آوران",
             "fa5s.trophy"),


            ("💰 امور مالی",
             "fa5s.wallet"),


            ("⚙️ تنظیمات",
             "fa5s.cog")

        ]



        for text, icon in modules:


            self.create_button(

                text,

                icon

            )
        
    # ==========================
    # ساخت دکمه منو
    # ==========================


    def create_button(

            self,

            text,

            icon,

            function=None

    ):


        button = QPushButton(

            text

        )


        button.setIcon(

            qta.icon(

                icon

            )

        )


        button.setMinimumHeight(

            48

        )


        if function:


            button.clicked.connect(

                function

            )


        self.menu_layout.addWidget(

            button

        )



        return button





    # ==========================
    # صفحه اصلی
    # ==========================


    def show_home(self):


        self.clear_content()



        title = QLabel(

            "به سامانه فراهوش خوش آمدید"

        )


        title.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        title.setStyleSheet("""

        QLabel{

            color:#1565C0;

            font-size:30px;

            font-weight:bold;

            padding:30px;

        }

        """)



        self.content_layout.addWidget(

            title

        )



        info = QLabel(

            """
            مدیریت هوشمند مدرسه

            تمامی بخش‌های مدرسه از این سامانه مدیریت خواهد شد.

            """

        )


        info.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        info.setStyleSheet("""

        QLabel{

            font-size:18px;

            color:#555;

        }

        """)



        self.content_layout.addWidget(

            info

        )





    # ==========================
    # پاک کردن محتوا
    # ==========================


    def clear_content(self):


        while self.content_layout.count():


            item = self.content_layout.takeAt(0)



            widget = item.widget()



            if widget:


                widget.deleteLater()





    # ==========================
    # باز کردن دانش‌آموزان
    # ==========================


    def open_students(self):


        self.clear_content()


        try:

            self.students_page = Students()


            self.content_layout.addWidget(

                self.students_page

            )


        except Exception as e:


            print("STUDENTS ERROR:")

            print(e)


            error = QLabel(

                str(e)

            )


            error.setAlignment(

                Qt.AlignmentFlag.AlignCenter

            )


            self.content_layout.addWidget(

                error

            )





    # ==========================
    # پنل دانش‌آموز
    # ==========================


    def open_student_panel(self):


        self.clear_content()



        title = QLabel(

            "پنل دانش‌آموز"

        )


        title.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        title.setStyleSheet("""

        QLabel{

            color:#1565C0;

            font-size:30px;

            font-weight:bold;

            padding:25px;

        }

        """)



        self.content_layout.addWidget(

            title

        )



        text = QLabel(

            """
            امکانات پنل دانش‌آموز:

            مشاهده کارنامه

            مشاهده غیبت‌ها

            برنامه درسی

            وضعیت آموزشی

            و خدمات دانش‌آموزی

            """

        )


        text.setAlignment(

            Qt.AlignmentFlag.AlignCenter

        )


        text.setStyleSheet("""

        QLabel{

            font-size:18px;

            color:#555;

        }

        """)



        self.content_layout.addWidget(

            text

        )

    # ==========================
    # استایل داشبورد
    # ==========================


def set_style(self):

    self.setStyleSheet("""

    QWidget{
        background:#eef3f8;
        font-family:Tahoma;
        color:#263238;
    }


    /* پنل منو */
    QWidget#menu_widget{

        background:#ffffff;
        border-left:1px solid #dbe3ec;
    }



    QPushButton{

        background:#1976D2;
        color:white;

        border:none;
        border-radius:14px;

        padding:12px;
        margin:6px;

        font-size:14px;

        text-align:right;
    }



    QPushButton:hover{

        background:#0D47A1;

    }



    QPushButton:pressed{

        background:#08306B;

    }



    QLabel{

        color:#263238;
        font-size:15px;

    }


    """)

    