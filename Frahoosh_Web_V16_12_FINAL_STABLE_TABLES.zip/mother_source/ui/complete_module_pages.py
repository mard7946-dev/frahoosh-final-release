import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QTabWidget,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QHBoxLayout,QDialog,QFormLayout,QLineEdit,QTextEdit,QDialogButtonBox
from PySide6.QtCore import Qt
from ui.data_crud import CrudTablePage, db
from utils.jalali import iso_to_jalali

DB=Path(__file__).resolve().parents[1]/'school.db'

def _date_value(v):
    s=str(v or '')
    if not s:return ''
    try:return iso_to_jalali(s[:10]) if len(s)>=10 and s[4]=='-' and s[7]=='-' else s
    except Exception:return s

class ReadTable(CrudTablePage):
    def load(self):
        try: super().load()
        except Exception: pass
        # Convert obvious ISO date columns to Jalali in the visible table.
        for j,(key,_) in enumerate(self.columns):
            if any(x in key.lower() for x in ('date','created_at','updated_at','recorded_at','paid_at','uploaded_at','meeting_at')):
                for i in range(self.table.rowCount()):
                    it=self.table.item(i,j)
                    if it: it.setText(_date_value(it.text()))

class CompleteTabs(QWidget):
    def __init__(self, specs, title='ماژول‌های کامل', parent=None, readonly=False):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft)
        l=QVBoxLayout(self); l.addWidget(QLabel(title)); self.tabs=QTabWidget(); l.addWidget(self.tabs)
        self.pages=[]
        for spec in specs:
            name,table,columns,fields=spec[:4]
            try:
                p=ReadTable(name,table,columns,fields,self,readonly=readonly)
                self.tabs.addTab(p,name); self.pages.append(p)
            except Exception as e:
                p=QWidget(); q=QVBoxLayout(p); q.addWidget(QLabel(f'جدول «{name}»\n{e}')); self.tabs.addTab(p,name)

def teacher_specs():
    return [
      ('حضور و غیاب','teacher_attendance',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher_id','دبیر'),('class_name','کلاس'),('subject','درس'),('attendance_date','تاریخ'),('status','وضعیت'),('description','توضیحات')],[('student_id','دانش‌آموز'),('teacher_id','دبیر'),('class_name','کلاس'),('subject','درس'),('attendance_date','تاریخ'),('status','وضعیت'),('description','توضیحات')]),
      ('آزمون‌ها','teacher_exams',[('id','شناسه'),('teacher_id','دبیر'),('title','عنوان'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('exam_type','نوع'),('exam_date','تاریخ'),('duration','دقیقه')],[('teacher_id','دبیر'),('title','عنوان'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('exam_type','نوع'),('exam_date','تاریخ'),('duration','مدت')]),
      ('تمام نمرات','grade_items',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('grade_type','نوع نمره'),('term','نوبت'),('score','نمره'),('grade_date','تاریخ'),('description','توضیحات')],[('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('grade_type','نوع نمره'),('term','نوبت'),('score','نمره'),('grade_date','تاریخ'),('description','توضیحات')]),
      ('فعالیت‌های آموزشی','educational_activities',[('id','شناسه'),('title','عنوان'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('teacher_id','دبیر'),('student_id','دانش‌آموز'),('activity_date','تاریخ'),('description','توضیحات')],[('title','عنوان'),('subject','درس'),('grade','پایه'),('class_name','کلاس'),('teacher_id','دبیر'),('student_id','دانش‌آموز'),('activity_date','تاریخ'),('description','توضیحات')]),
    ]

def executive_specs():
    return [
      ('کلاس‌ها','executive_classes',[('id','شناسه'),('name','کلاس'),('grade','پایه'),('teacher','دبیر'),('created_at','تاریخ')],[('name','نام کلاس'),('grade','پایه'),('teacher','دبیر')]),
      ('امور اجرایی','executive_operations',[('id','شناسه'),('operation_type','نوع'),('title','عنوان'),('student_id','دانش‌آموز'),('class_name','کلاس'),('status','وضعیت'),('operation_date','تاریخ'),('description','توضیحات')],[('operation_type','نوع'),('title','عنوان'),('student_id','دانش‌آموز'),('class_name','کلاس'),('status','وضعیت'),('operation_date','تاریخ'),('description','توضیحات')]),
      ('گزارش اجرایی','executive_reports',[('id','شناسه'),('title','عنوان'),('report_type','نوع'),('student_id','دانش‌آموز'),('class_name','کلاس'),('report_date','تاریخ'),('created_by','ثبت‌کننده')],[('title','عنوان'),('report_type','نوع'),('student_id','دانش‌آموز'),('class_name','کلاس'),('report_date','تاریخ'),('created_by','ثبت‌کننده')]),
      ('برنامه هفتگی','weekly_schedule',[('id','شناسه'),('teacher','دبیر'),('hours','ساعت'),('grade','پایه'),('class_count','تعداد کلاس'),('subject','درس'),('bell_pattern','زنگ'),('class_names','کلاس‌ها')],[('teacher','دبیر'),('hours','ساعت'),('grade','پایه'),('class_count','تعداد کلاس'),('subject','درس'),('bell_pattern','زنگ'),('class_names','کلاس‌ها')]),
      ('امتحانات','exam_schedule',[('id','شناسه'),('subject','درس'),('grade','پایه'),('exam_date','تاریخ امتحان'),('duration','مدت'),('weight','ضریب')],[('subject','درس'),('grade','پایه'),('exam_date','تاریخ امتحان'),('duration','مدت'),('weight','ضریب')]),
    ]

def cultural_specs():
    return [
      ('ثبت‌نام فعالیت‌ها','cultural_activity_registrations',[('id','شناسه'),('student_id','دانش‌آموز'),('activity_id','فعالیت'),('activity_title','عنوان'),('activity_kind','نوع'),('fee','هزینه'),('payment_status','پرداخت'),('registration_date','تاریخ')],[('student_id','دانش‌آموز'),('activity_id','فعالیت'),('activity_title','عنوان'),('activity_kind','نوع'),('fee','هزینه'),('payment_status','پرداخت'),('registration_date','تاریخ')]),
      ('مسابقات','competitions',[('id','شناسه'),('title','عنوان'),('category','دسته'),('start_date','شروع'),('end_date','پایان'),('status','وضعیت')],[('title','عنوان'),('category','دسته'),('start_date','شروع'),('end_date','پایان'),('status','وضعیت')]),
      ('فعالیت‌ها','cultural_reports',[('id','شناسه'),('title','عنوان'),('report_type','نوع'),('activity_id','فعالیت'),('report_date','تاریخ')],[('title','عنوان'),('report_type','نوع'),('activity_id','فعالیت'),('report_date','تاریخ')]),
    ]

def parent_specs():
    return [
      ('کارنامه و نمرات','grades',[('id','شناسه'),('student_id','دانش‌آموز'),('subject','درس'),('exam_name','ارزشیابی'),('score','نمره'),('grade_type','نوع'),('term','نوبت'),('grade_date','تاریخ')],[],),
      ('حضور و غیاب','attendance',[('id','شناسه'),('student_id','دانش‌آموز'),('date','تاریخ'),('status','وضعیت'),('description','توضیحات')],[]),
      ('تکالیف','assignments',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher','دبیر'),('subject','درس'),('title','عنوان'),('due_date','مهلت'),('status','وضعیت')],[]),
      ('فعالیت‌های آموزشی','educational_activities',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('title','عنوان'),('activity_date','تاریخ'),('description','توضیحات')],[]),
      ('پیام‌ها و اطلاعیه‌ها','school_events',[('id','شناسه'),('event_type','نوع'),('title','عنوان'),('actor_username','فرستنده'),('created_at','تاریخ')],[]),
      ('برنامه هفتگی','weekly_schedule',[('id','شناسه'),('teacher','دبیر'),('subject','درس'),('grade','پایه'),('class_names','کلاس‌ها')],[]),
      ('امتحانات','exam_schedule',[('id','شناسه'),('subject','درس'),('grade','پایه'),('exam_date','تاریخ'),('duration','مدت')],[]),
      ('پرداخت‌ها و امور مالی','payment_records',[('id','شناسه'),('student_id','دانش‌آموز'),('parent_username','ولی'),('title','عنوان'),('amount','مبلغ'),('status','وضعیت'),('payment_date','تاریخ')],[]),
      ('فعالیت‌های فرهنگی و پرورشی','cultural_activity_registrations',[('id','شناسه'),('student_id','دانش‌آموز'),('activity_title','فعالیت'),('activity_kind','نوع'),('payment_status','پرداخت'),('registration_date','تاریخ')],[]),
    ]

def smart_specs():
    return [
      ('محتوای آموزشی','smart_board_content',[('id','شناسه'),('title','عنوان'),('content','محتوا'),('class_id','کلاس'),('teacher_id','دبیر'),('content_date_shamsi','تاریخ شمسی')],[('title','عنوان'),('content','محتوا'),('class_id','کلاس'),('teacher_id','دبیر')]),
      ('تخته آموزشی','smart_board_whiteboards',[('id','شناسه'),('title','عنوان'),('content','محتوا'),('class_id','کلاس'),('teacher_id','دبیر'),('board_date','تاریخ')],[('title','عنوان'),('content','محتوا'),('class_id','کلاس'),('teacher_id','دبیر'),('board_date','تاریخ')]),
      ('فایل‌ها','smart_board_files',[('id','شناسه'),('title','عنوان'),('file_path','مسیر فایل'),('file_type','نوع'),('class_id','کلاس'),('teacher_id','دبیر')],[('title','عنوان'),('file_path','مسیر فایل'),('file_type','نوع'),('class_id','کلاس'),('teacher_id','دبیر')]),
      ('تصاویر و ویدیوها','smart_board_media',[('id','شناسه'),('title','عنوان'),('media_path','مسیر'),('media_type','نوع'),('class_id','کلاس'),('teacher_id','دبیر')],[('title','عنوان'),('media_path','مسیر'),('media_type','نوع'),('class_id','کلاس'),('teacher_id','دبیر')]),
      ('آزمون کوتاه','smart_board_quizzes',[('id','شناسه'),('title','عنوان'),('question','سؤال'),('correct_option','گزینه صحیح'),('class_id','کلاس'),('teacher_id','دبیر'),('quiz_date_shamsi','تاریخ شمسی')],[('title','عنوان'),('question','سؤال'),('correct_option','گزینه صحیح'),('class_id','کلاس'),('teacher_id','دبیر')]),
      ('فعالیت کلاس','smart_board_activities',[('id','شناسه'),('title','عنوان'),('activity_text','شرح'),('class_id','کلاس'),('teacher_id','دبیر'),('activity_date_shamsi','تاریخ شمسی')],[('title','عنوان'),('activity_text','شرح'),('class_id','کلاس'),('teacher_id','دبیر')]),
    ]

def ai_specs():
    return [
      ('دستیار هوشمند','ai_assistant_sessions',[('id','شناسه'),('username','کاربر'),('role','سمت'),('title','عنوان'),('request_date_shamsi','تاریخ شمسی')],[('username','کاربر'),('role','سمت'),('title','عنوان'),('request_date_shamsi','تاریخ شمسی')]),
      ('پرسش و پاسخ','ai_questions',[('id','شناسه'),('username','کاربر'),('role','سمت'),('question','پرسش'),('answer','پاسخ'),('answer_date_shamsi','تاریخ شمسی')],[('username','کاربر'),('role','سمت'),('question','پرسش'),('answer','پاسخ'),('answer_date_shamsi','تاریخ شمسی')]),
      ('تحلیل آموزشی','ai_educational_analysis',[('id','شناسه'),('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('period','دوره'),('score','امتیاز'),('risk_level','ریسک'),('analysis_date_shamsi','تاریخ شمسی')],[('student_id','دانش‌آموز'),('teacher_id','دبیر'),('subject','درس'),('period','دوره'),('score','امتیاز'),('risk_level','ریسک'),('analysis_date_shamsi','تاریخ شمسی')]),
      ('گزارش هوشمند','ai_smart_reports',[('id','شناسه'),('title','عنوان'),('report_type','نوع'),('target_type','هدف'),('target_id','شناسه هدف'),('created_by','ثبت‌کننده'),('report_date_shamsi','تاریخ شمسی')],[('title','عنوان'),('report_type','نوع'),('target_type','هدف'),('target_id','شناسه هدف'),('created_by','ثبت‌کننده'),('report_date_shamsi','تاریخ شمسی')]),
    ]
