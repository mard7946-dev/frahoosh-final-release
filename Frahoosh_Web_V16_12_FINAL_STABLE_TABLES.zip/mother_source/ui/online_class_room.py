import os, sqlite3
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QListWidget,QTextEdit,
    QMessageBox,QDialog,QDialogButtonBox,QFileDialog,QInputDialog,QGroupBox,QLineEdit)
from PySide6.QtCore import Qt, QTimer
from ui.smart_board import SmartBoard
from services.online_class_service import OnlineClassService
from utils.jalali import iso_to_jalali

class PresenceDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('راستی‌آزمایی حضور'); self.setModal(True); self.setLayoutDirection(Qt.RightToLeft)
        l=QVBoxLayout(self); l.addWidget(QLabel('من در کلاس حاضر هستم')); l.addWidget(QLabel('برای ادامه تدریس، حضور خود را تأیید کنید.'))
        b=QDialogButtonBox(QDialogButtonBox.Yes|QDialogButtonBox.No); b.button(QDialogButtonBox.Yes).setText('من در کلاس حاضر هستم'); b.button(QDialogButtonBox.No).setText('عدم تأیید'); b.accepted.connect(self.accept); b.rejected.connect(self.reject); l.addWidget(b)

class OnlineClassRoom(QWidget):
    """کلاس مجازی واقعیِ پنل‌محور: تخته، رسانه، کنترل دسترسی چت و ارتباطات خصوصی."""
    def __init__(self,class_id,student_id=None,teacher_id=None,teacher_name='دبیر',role='student',parent=None):
        super().__init__(parent); self.class_id=class_id; self.student_id=student_id; self.teacher_id=teacher_id; self.teacher_name=teacher_name; self.role=role
        self.camera_on=False; self.mic_on=False; self.screen_on=False; self.hand_up=False
        self.setWindowTitle('کلاس مجازی هوشمند فراهوش'); self.resize(1350,800); self.setLayoutDirection(Qt.RightToLeft)
        OnlineClassService.ensure_schema(); self.build(); self._log('room_open'); self.refresh_chat(); self.refresh_private()
        self.timer=QTimer(self); self.timer.timeout.connect(self.refresh_chat); self.timer.start(2500)

    def _log(self,event,metadata=''):
        try: OnlineClassService.log_activity(self.class_id,event,self.student_id or self.teacher_id or 0,metadata)
        except Exception: pass

    def build(self):
        l=QVBoxLayout(self)
        h=QHBoxLayout(); h.addWidget(QLabel('🎓 کلاس مجازی هوشمند فراهوش')); h.addStretch(); self.status=QLabel('● در حال برگزاری'); h.addWidget(self.status); l.addLayout(h)
        tools=QHBoxLayout()
        self.cam=QPushButton('🎥 دوربین خاموش'); self.mic=QPushButton('🎙 میکروفون خاموش'); self.screen=QPushButton('🖥 اشتراک صفحه'); self.hand=QPushButton('✋ دست بالا'); self.file=QPushButton('📎 فایل آموزشی'); self.quiz=QPushButton('📝 آزمون کوتاه')
        for b,slot in [(self.cam,self.toggle_camera),(self.mic,self.toggle_mic),(self.screen,self.toggle_screen),(self.hand,self.toggle_hand),(self.file,self.share_file),(self.quiz,self.create_quiz)]: b.clicked.connect(slot); tools.addWidget(b)
        if self.role=='teacher':
            self.public=QPushButton('💬 چت عمومی: بسته'); self.public.clicked.connect(self.toggle_public_chat); tools.addWidget(self.public)
            self.private=QPushButton('🔒 پیام‌های خصوصی دبیر'); self.private.clicked.connect(self.show_private); tools.addWidget(self.private)
        else:
            self.public=QPushButton('💬 چت عمومی'); self.public.clicked.connect(self.send_chat); tools.addWidget(self.public)
        l.addLayout(tools)
        center=QHBoxLayout(); board_box=QVBoxLayout(); self.board=SmartBoard(); board_box.addWidget(QLabel('🧑‍🏫 تخته هوشمند')); board_box.addWidget(self.board,4)
        self.board_tools=QTextEdit(); self.board_tools.setPlaceholderText('یادداشت/حل تمرین و محتوای تخته...'); self.board_tools.setMaximumHeight(90); board_box.addWidget(self.board_tools); center.addLayout(board_box,4)
        side=QVBoxLayout(); side.addWidget(QLabel('👥 شرکت‌کنندگان')); self.users=QListWidget(); side.addWidget(self.users,2); self.load_users()
        side.addWidget(QLabel('💬 گفت‌وگوی عمومی')); self.chat_view=QTextEdit(); self.chat_view.setReadOnly(True); side.addWidget(self.chat_view,3)
        if self.role=='student':
            self.private_student=QPushButton('✉️ پیام به دبیر'); self.private_student.clicked.connect(self.send_private_to_teacher); side.addWidget(self.private_student)
        center.addLayout(side,2); l.addLayout(center)
        controls=QHBoxLayout();
        if self.role=='student':
            leave=QPushButton('خروج از کلاس'); leave.clicked.connect(self.leave); controls.addWidget(leave)
        else:
            for text,slot in [('گزارش حضور',self.show_report),('تحلیل هوشمند',self.show_ai),('پایان کلاس',self.finish)]:
                b=QPushButton(text); b.clicked.connect(slot); controls.addWidget(b)
        l.addLayout(controls)

    def load_users(self):
        try:
            with sqlite3.connect(os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))) as c:
                rows=c.execute("SELECT student_name FROM online_class_students WHERE class_id=? ORDER BY student_name",(self.class_id,)).fetchall()
            self.users.clear(); self.users.addItem('👨‍🏫 '+self.teacher_name)
            for r in rows: self.users.addItem('👨‍🎓 '+(r[0] or 'دانش‌آموز'))
        except Exception: self.users.clear(); self.users.addItem('شرکت‌کنندگان کلاس')

    def toggle_camera(self): self.camera_on=not self.camera_on; self.cam.setText('🎥 دوربین روشن' if self.camera_on else '🎥 دوربین خاموش'); self._log('camera_on' if self.camera_on else 'camera_off')
    def toggle_mic(self): self.mic_on=not self.mic_on; self.mic.setText('🎙 میکروفون روشن' if self.mic_on else '🎙 میکروفون خاموش'); self._log('microphone_on' if self.mic_on else 'microphone_off')
    def toggle_screen(self): self.screen_on=not self.screen_on; self.screen.setText('🖥 توقف اشتراک صفحه' if self.screen_on else '🖥 اشتراک صفحه'); self._log('screen_share_on' if self.screen_on else 'screen_share_off')
    def toggle_hand(self): self.hand_up=not self.hand_up; self.hand.setText('✋ پایین آوردن دست' if self.hand_up else '✋ دست بالا'); self._log('hand_raise' if self.hand_up else 'hand_lower')
    def share_file(self):
        path,_=QFileDialog.getOpenFileName(self,'انتخاب فایل آموزشی','','Files (*.pdf *.png *.jpg *.jpeg *.mp4 *.doc *.docx *.ppt *.pptx)')
        if path: OnlineClassService.board_event(self.class_id,self.student_id or self.teacher_id,self.role,'file_share',os.path.basename(path)); self.chat_view.append('📎 فایل آموزشی: '+os.path.basename(path))
    def create_quiz(self):
        text,ok=QInputDialog.getText(self,'آزمون کوتاه','سؤال یا تمرین:')
        if ok and text.strip(): OnlineClassService.board_event(self.class_id,self.student_id or self.teacher_id,self.role,'short_quiz',text.strip()); self.chat_view.append('📝 آزمون کوتاه/تمرین روی کلاس ثبت شد.')
    def toggle_public_chat(self):
        st=OnlineClassService.chat_settings(self.class_id); new=not bool(st['public_chat_enabled']); OnlineClassService.set_public_chat(self.class_id,new); self.public.setText('💬 چت عمومی: باز' if new else '💬 چت عمومی: بسته'); self._log('public_chat_open' if new else 'public_chat_close')
    def send_chat(self):
        text,ok=QInputDialog.getText(self,'چت عمومی','پیام:')
        if ok and text.strip():
            if not OnlineClassService.send_public_chat(self.class_id,self.student_id or self.teacher_id,self.role,'دانش‌آموز' if self.role=='student' else self.teacher_name,text.strip()): QMessageBox.information(self,'چت عمومی','چت عمومی هنوز توسط دبیر باز نشده است.')
    def send_private_to_teacher(self):
        text,ok=QInputDialog.getText(self,'پیام خصوصی','پیام برای دبیر:')
        if ok and text.strip(): OnlineClassService.send_private_chat(self.class_id,self.student_id or 0,'دبیر',self.student_id,text.strip()); self._log('private_message_sent')
    def refresh_chat(self):
        try:
            with OnlineClassService.get_connection() as c:
                rows=c.execute("SELECT sender_name,message,sent_at_shamsi FROM online_class_chat WHERE class_id=? AND is_private=0 ORDER BY id DESC LIMIT 80",(self.class_id,)).fetchall()
            self.chat_view.setPlainText('\n'.join(f"{r['sent_at_shamsi']} | {r['sender_name']}: {r['message']}" for r in reversed(rows)))
        except Exception: pass
    def refresh_private(self):
        if self.role!='teacher': return
        rows=OnlineClassService.teacher_private_messages(self.class_id)
        self._private_cache='\n'.join(f"{r['sent_at_shamsi']} | دانش‌آموز #{r['recipient_student_id']}: {r['message']}" for r in rows)
    def show_private(self): self.refresh_private(); QMessageBox.information(self,'پیام‌های خصوصی دانش‌آموزان',self._private_cache or 'پیام خصوصی جدیدی وجود ندارد.')
    def show_presence_check(self,check):
        if self.role!='student': return
        ok=PresenceDialog(self).exec()==QDialog.Accepted; OnlineClassService.respond_presence(check['id'],ok)
        if not ok: QMessageBox.warning(self,'عدم حضور','حضور شما تأیید نشد و گزارش برای اولیا، معاون و مدیر ارسال شد.')
    def leave(self):
        if self.student_id: OnlineClassService.student_leave(self.class_id,self.student_id)
        self._log('room_close'); self.close()
    def finish(self): OnlineClassService.finish_class(self.class_id); self._log('class_finished'); self.close()
    def show_report(self):
        rows=OnlineClassService.get_class_report(self.class_id); QMessageBox.information(self,'گزارش حضور','\n'.join(f"{r['student_name']} | ورود: {iso_to_jalali(r['join_time']) if r['join_time'] else '-'} | خروج: {iso_to_jalali(r['leave_time']) if r['leave_time'] else '-'} | تأیید {r['confirmed_checks'] or 0} | عدم تأیید {r['missed_checks'] or 0}" for r in rows) or 'رکوردی وجود ندارد.')
    def show_ai(self):
        result=OnlineClassService.ai_analyze_class(self.class_id); QMessageBox.information(self,'تحلیل هوشمند','\n'.join(f"{x['student_name']} | {x['risk_level']} | {x['report']}" for x in result) or 'داده کافی نیست.')
