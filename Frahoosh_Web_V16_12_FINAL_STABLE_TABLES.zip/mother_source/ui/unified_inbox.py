import json
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QComboBox,QLineEdit,QTextEdit,QMessageBox
from PySide6.QtCore import Qt
from utils.date_display import display_datetime

class UnifiedInboxPage(QWidget):
    def __init__(self, username=None, role=None, title="پیام‌ها و رویدادهای یکپارچه", parent=None):
        super().__init__(parent)
        self.username=username or ""
        self.role=role
        self.title_text=title
        self.table=QTableWidget(0,5)
        self.table.setHorizontalHeaderLabels(["نوع","عنوان","فرستنده","جزئیات","تاریخ"])
        lay=QVBoxLayout(self)
        h=QHBoxLayout()
        h.addWidget(QLabel(title))
        h.addStretch()
        refresh=QPushButton("تازه‌سازی")
        refresh.clicked.connect(self.load)
        h.addWidget(refresh)
        lay.addLayout(h); lay.addWidget(self.table)
        self.load()

    def load(self):
        try:
            from services.unified_event_service import inbox, inbox_for_role
            rows = inbox(self.username, 200) if self.username else inbox_for_role(self.role or "teacher", 200)
            self.table.setRowCount(len(rows))
            for i,r in enumerate(rows):
                payload=r.get("payload") or "{}"
                try:
                    data=json.loads(payload)
                    detail=" | ".join(f"{k}: {v}" for k,v in data.items() if v not in ("",None))[:900]
                except Exception:
                    detail=str(payload)[:900]
                vals=[r.get("event_type",""),r.get("title",""),r.get("actor_username","سیستم/پنل"),detail,display_datetime(r.get("created_at",""))]
                for j,v in enumerate(vals):
                    self.table.setItem(i,j,QTableWidgetItem(str(v or "")))
        except Exception as exc:
            self.table.setRowCount(0)
            QMessageBox.warning(self,"پیام‌ها",f"خطا در دریافت پیام‌ها:\n{exc}")

class UnifiedMessengerPage(QWidget):
    """Cross-panel message composer with mandatory explicit audience selection."""
    def __init__(self, sender="سیستم فراهوش", role="manager", parent=None):
        super().__init__(parent); self.sender=sender; self.role=role
        lay=QVBoxLayout(self); lay.addWidget(QLabel(f"ارسال پیام یکپارچه — {sender}"))
        self.title=QLineEdit(); self.title.setPlaceholderText("عنوان پیام")
        self.body=QTextEdit(); self.body.setPlaceholderText("متن پیام")
        from ui.audience_selector import AudienceDropdownWidget
        self.audience_picker=AudienceDropdownWidget(self, [], 'مخاطب پیام — قبل از ثبت نهایی')
        self.send_btn=QPushButton("ارسال و ثبت نهایی")
        self.send_btn.clicked.connect(self.send)
        for w in (self.title,self.body,self.audience_picker,self.send_btn): lay.addWidget(w)
        self.audiences=[]

    def send(self):
        text=self.body.toPlainText().strip()
        if not text:
            QMessageBox.warning(self,"ارسال","متن پیام خالی است."); return
        self.audiences=self.audience_picker.targets()
        if not self.audiences:
            QMessageBox.warning(self,"ارسال","ابتدا مخاطبان را از منوی کشویی انتخاب کنید."); return
        try:
            from services.message_service import send
            send(self.sender,text,'school','all',self.title.text().strip() or 'پیام مدرسه',audiences=self.audiences)
            self.body.clear(); self.title.clear(); self.audiences=[]
            self.audience_picker._targets=[]; self.audience_picker._refresh_list()
            QMessageBox.information(self,"ارسال","پیام با موفقیت ثبت و برای مخاطبان انتخاب‌شده ارسال شد.")
        except Exception as exc:
            QMessageBox.warning(self,"ارسال",str(exc))
