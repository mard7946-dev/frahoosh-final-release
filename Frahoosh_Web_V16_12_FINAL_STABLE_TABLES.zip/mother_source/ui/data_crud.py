import sqlite3
from pathlib import Path
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLineEdit,QTableWidget,QTableWidgetItem,QDialog,QFormLayout,QDialogButtonBox,QMessageBox,QHeaderView,QTextEdit
from PySide6.QtCore import Qt
from ui.audience_selector import AudienceDropdownWidget
from utils.jalali import iso_to_jalali, jalali_to_iso

DB_PATH = Path(__file__).resolve().parents[1] / 'school.db'

def db():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

DATE_KEYS = ("date", "_date", "_at", "_on", "datetime", "time")

def _is_date_key(key):
    k=str(key or '').lower()
    if 'shamsi' in k or k in ('id','created_by','teacher_id','student_id','class_id'): return False
    return k.endswith(DATE_KEYS) or k in {'meeting_at','start_time','end_time'}

def _normalize_digits(value):
    trans=str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')
    return str(value or '').translate(trans)

def _db_date_value(key,value):
    value=_normalize_digits(value).strip()
    if not value or not _is_date_key(key): return value
    # Accept Jalali 1405/06/04 or 1405-06-04 and persist ISO Gregorian.
    if len(value)>=10 and value[0:4].isdigit() and value[4] in '/-' and value[7] in '/-':
        try:
            return jalali_to_iso(value[:10].replace('-','/')) + value[10:]
        except Exception:
            # If it is already Gregorian ISO, keep it. Otherwise reject.
            try:
                y=int(value[:4]);
                if 1900 <= y <= 2100: return value
            except Exception: pass
            raise ValueError(f'تاریخ «{value}» معتبر نیست؛ تاریخ را به صورت شمسی 1405/06/04 وارد کنید.')
    return value

def _display_value(key,value):
    value=str(value or '')
    if _is_date_key(key) and len(value)>=10 and value[4:5]=='-' and value[7:8]=='-':
        return iso_to_jalali(value[:10]) + value[10:]
    return value

class CrudTablePage(QWidget):
    """Reusable real CRUD table: every row is persisted in school.db."""
    def __init__(self,title,table,columns,fields,parent=None,where=None,where_args=(),order='id DESC',readonly=False):
        super().__init__(parent); self.title_text=title; self.table_name=table; self.columns=columns; self.fields=fields; self.where=where; self.where_args=tuple(where_args); self.order=order; self.readonly=readonly
        self.setLayoutDirection(Qt.RightToLeft); self._build(); self.load()
    def _build(self):
        l=QVBoxLayout(self); h=QLineEdit(); h.setPlaceholderText(f'جستجو در {self.title_text}...'); self.search=h; l.addWidget(h)
        bar=QHBoxLayout();
        if not self.readonly:
            self.add_btn=QPushButton('ثبت رکورد'); self.edit_btn=QPushButton('ویرایش'); self.del_btn=QPushButton('حذف')
            for b in (self.add_btn,self.edit_btn,self.del_btn): bar.addWidget(b)
            self.add_btn.clicked.connect(self.add); self.edit_btn.clicked.connect(self.edit); self.del_btn.clicked.connect(self.delete)
        self.refresh_btn=QPushButton('تازه‌سازی'); self.refresh_btn.clicked.connect(self.load); bar.addWidget(self.refresh_btn); l.addLayout(bar)
        self.table=QTableWidget(0,len(self.columns)); self.table.setHorizontalHeaderLabels([x[1] for x in self.columns]); self.table.setSelectionBehavior(QTableWidget.SelectRows); self.table.setEditTriggers(QTableWidget.NoEditTriggers); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); l.addWidget(self.table); h.textChanged.connect(self.load)
    def _rows(self):
        cols=','.join(x[0] for x in self.columns); q=f'SELECT {cols} FROM {self.table_name}'; args=list(self.where_args); clauses=[]
        if self.where: clauses.append(f'({self.where})')
        s=self.search.text().strip()
        if s:
            clauses.append('('+' OR '.join(f'CAST({x[0]} AS TEXT) LIKE ?' for x in self.columns)+')'); args += ['%'+s+'%']*len(self.columns)
        if clauses:q+=' WHERE '+' AND '.join(clauses)
        q+=' ORDER BY '+self.order
        with db() as c:return c.execute(q,args).fetchall()
    def load(self):
        try: rows=self._rows()
        except Exception as e: QMessageBox.critical(self,'خطای جدول',str(e)); return
        self.table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,(key,_) in enumerate(self.columns): self.table.setItem(r,j,QTableWidgetItem(_display_value(key,row[key])))
    def _form(self,title,row=None):
        d=QDialog(self); d.setWindowTitle(title); d.setLayoutDirection(Qt.RightToLeft); f=QFormLayout(d); widgets={}
        for key,label in self.fields:
            w=QTextEdit() if key.endswith('_memo') else QLineEdit()
            if isinstance(w,QTextEdit): w.setMinimumHeight(80); w.setPlainText(str((row or {}).get(self._dbkey(key),'') or ''))
            else:
                w.setText(_display_value(self._dbkey(key),(row or {}).get(self._dbkey(key),'')))
                if _is_date_key(self._dbkey(key)): w.setPlaceholderText('تاریخ شمسی — مثال: 1405/06/04')
            widgets[key]=w; f.addRow(label,w)
        # Every writable module now declares its audience before final save.
        # This is deliberately inside the same dialog so the user cannot save
        # a school action without deciding who should receive/see it.
        picker=AudienceDropdownWidget(d, [], 'مخاطب این ثبت — قبل از ثبت نهایی')
        widgets['__audience__']=picker
        f.addRow('مخاطب', picker)
        box=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); f.addWidget(box); box.accepted.connect(d.accept); box.rejected.connect(d.reject); return d,widgets
    def _dbkey(self,k): return k[:-5] if k.endswith('_memo') else k
    def _val(self,w): return w.toPlainText().strip() if isinstance(w,QTextEdit) else w.text().strip()
    def add(self):
        d,w=self._form('ثبت '+self.title_text)
        if d.exec()!=QDialog.Accepted:return
        picker=w.get('__audience__'); audiences=picker.targets() if picker else []
        if not audiences:
            QMessageBox.warning(self,'ثبت','ابتدا مخاطب این ثبت را مشخص کنید.'); return
        
        try:
            vals=[_db_date_value(k,self._val(w[k])) for k,_ in self.fields]
        except ValueError as e:
            QMessageBox.warning(self,'تاریخ شمسی',str(e)); return
        if any(k in ('title','name','first_name','last_name','subject') and not v for (k,_),v in zip(self.fields,vals)): QMessageBox.warning(self,'ثبت','اطلاعات اصلی را وارد کنید.'); return
        try:
            from services.unified_event_service import ensure_schema, STUDENT_TABLES, SCHOOL_TABLES
            from services.audience_service import begin_capture, end_capture
            ensure_schema()
            with db() as c:
                begin_capture(self.table_name, audiences, c)
                try:
                    cur=c.execute(f"INSERT INTO {self.table_name} ({','.join(self._dbkey(k) for k,_ in self.fields)}) VALUES ({','.join('?' for _ in vals)})",vals)
                    new_id=cur.lastrowid
                    c.commit()
                finally:
                    end_capture(self.table_name)
            # Tables not covered by the central trigger registry still get an
            # event, so every writable module participates in the same inbox.
            if self.table_name not in {**STUDENT_TABLES, **SCHOOL_TABLES}:
                from services.unified_event_service import publish_selected
                payload={self._dbkey(k):v for (k,_),v in zip(self.fields,vals)}
                publish_selected(self.table_name,new_id,'ثبت جدید: '+self.title_text,payload,audiences=audiences)
            try:
                from services.remote_sync_service import push_pending
                push_pending()
            except Exception: pass
            self.load()
        except Exception as e: QMessageBox.critical(self,'ثبت',str(e))
    def edit(self):
        r=self.table.currentRow()
        if r<0:return
        ident=self.table.item(r,0).text(); row={k:self.table.item(r,j).text() if self.table.item(r,j) else '' for j,(k,_) in enumerate(self.columns)}
        d,w=self._form('ویرایش '+self.title_text,row)
        if d.exec()!=QDialog.Accepted:return
        picker=w.get('__audience__'); audiences=picker.targets() if picker else []
        if not audiences:
            QMessageBox.warning(self,'ویرایش','ابتدا مخاطب این تغییر را مشخص کنید.'); return
        
        try:
            vals=[_db_date_value(k,self._val(w[k])) for k,_ in self.fields]
        except ValueError as e:
            QMessageBox.warning(self,'تاریخ شمسی',str(e)); return
        try:
            from services.unified_event_service import ensure_schema, STUDENT_TABLES, SCHOOL_TABLES
            from services.audience_service import begin_capture, end_capture
            ensure_schema()
            with db() as c:
                begin_capture(self.table_name, audiences, c)
                try:
                    c.execute(f"UPDATE {self.table_name} SET {','.join(self._dbkey(k)+'=?' for k,_ in self.fields)} WHERE id=?",vals+[ident]); c.commit()
                finally:
                    end_capture(self.table_name)
            if self.table_name not in {**STUDENT_TABLES, **SCHOOL_TABLES}:
                from services.unified_event_service import publish_selected
                payload={self._dbkey(k):v for (k,_),v in zip(self.fields,vals)}
                publish_selected(self.table_name,int(ident),'به‌روزرسانی: '+self.title_text,payload,audiences=audiences)
            try:
                from services.remote_sync_service import push_pending
                push_pending()
            except Exception: pass
            self.load()
        except Exception as e: QMessageBox.critical(self,'ویرایش',str(e))
    def delete(self):
        r=self.table.currentRow()
        if r<0:return
        ident=self.table.item(r,0).text()
        if QMessageBox.question(self,'حذف','رکورد انتخاب‌شده حذف شود؟',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        try:
            with db() as c:c.execute(f'DELETE FROM {self.table_name} WHERE id=?',(ident,)); c.commit()
            self.load()
        except Exception as e: QMessageBox.critical(self,'حذف',str(e))
