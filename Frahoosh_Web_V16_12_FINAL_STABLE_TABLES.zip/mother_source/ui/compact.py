from PySide6.QtWidgets import QLayout, QVBoxLayout, QHBoxLayout, QPushButton, QToolButton


def compact_button_rows(widget):
    """Turn runs of sibling action buttons into compact horizontal rows.

    Only direct button runs are changed; form fields/tables and nested layouts
    remain untouched. This keeps existing panel behavior while reducing the
    amount of screen space used by action buttons.
    """
    def walk(layout):
        if layout is None:
            return
        i = 0
        while i < layout.count():
            item = layout.itemAt(i)
            child_layout = item.layout() if item else None
            if child_layout:
                walk(child_layout)
                i += 1
                continue
            w = item.widget() if item else None
            if isinstance(w, (QPushButton, QToolButton)):
                start = i
                buttons = []
                while i < layout.count():
                    it = layout.itemAt(i)
                    ww = it.widget() if it else None
                    if not isinstance(ww, (QPushButton, QToolButton)):
                        break
                    buttons.append(ww)
                    i += 1
                if len(buttons) >= 2 and isinstance(layout, QVBoxLayout):
                    row = QHBoxLayout()
                    row.setSpacing(9)
                    for b in buttons:
                        layout.removeWidget(b)
                        row.addWidget(b)
                        b.setMinimumHeight(34)
                        b.setMaximumHeight(38)
                        b.setMinimumWidth(96)
                    layout.insertLayout(start, row)
                    i = start + 1
                continue
            i += 1
    walk(widget.layout())
