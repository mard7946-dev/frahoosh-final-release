from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QFrame,
    QSizePolicy
)

from PySide6.QtCore import Qt

from PySide6.QtGui import QFont

import qtawesome as qta



print("FINAL SIDEBAR LOADED")



class Sidebar(QWidget):


    def __init__(self, page_callback):

        super().__init__()


        self.page_callback = page_callback


        self.setFixedWidth(
            310
        )


        self.create_ui()



    # =====================================================
    # ساخت رابط Sidebar
    # =====================================================


    def create_ui(self):


        self.main_layout = QVBoxLayout(
            self
        )


        self.main_layout.setContentsMargins(
            15,
            15,
            15,
            15
        )


        self.main_layout.setSpacing(
            8
        )



        # -----------------------------
        # بخش لوگو
        # -----------------------------


        logo = QLabel(
            "🧠 فراهوش"
        )


        logo.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        logo.setFont(
            QFont(
                "B Titr",
                26,
                QFont.Bold
            )
        )


        self.main_layout.addWidget(
            logo
        )



        school = QLabel(
            "سامانه مدیریت هوشمند\nدبیرستان"
        )


        school.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        school.setFont(
            QFont(
                "B Nazanin",
                12
            )
        )


        self.main_layout.addWidget(
            school
        )



        line = QFrame()


        line.setFrameShape(
            QFrame.HLine
        )


        self.main_layout.addWidget(
            line
        )



        # -----------------------------
        # منوهای اصلی
        # -----------------------------


        self.create_group(
            "🏫 مدیریت دبیرستان",
            [

                ("اطلاعات دبیرستان", "school"),
                ("مدیریت کلاس‌ها", "classes"),
                ("پایه‌ها و رشته‌ها", "grades_manage"),
                ("تقویم مدرسه", "calendar"),
                ("سال تحصیلی", "school_year"),
                ("تحلیل‌ها و گزارش‌های مدیریتی", "management_reports"),
                ("تایید درخواست‌ها", "requests_center")

            ]
        )



        self.create_group(
            "👨‍🎓 دانش‌آموزان",
            [

                ("مدیریت دانش‌آموزان", "students"),
                ("پنل دانش‌آموز", "student_panel"),
                ("حضور و غیاب", "attendance"),
                ("مشاهده نمرات", "student_grades"),
                ("نمودار عملکرد درسی", "student_chart"),
                ("نمودار عملکرد انضباطی", "discipline_chart"),
                ("پرونده تحصیلی", "student_file")

            ]
        )



        self.create_group(
            "👨‍🏫 دبیران و کارکنان",
            [

                ("مدیریت دبیران", "teachers"),
                ("مدیریت کارکنان", "staff"),
                ("نقش‌ها و دسترسی‌ها", "roles")

            ]
        )


    # =====================================================
        # پنل دبیران
        # =====================================================


        self.create_group(
            "📚 پنل دبیران",
            [

                ("پرونده دبیر", "teacher_file"),
                ("برنامه تدریس", "teacher_schedule"),
                ("کلاس‌های اختصاص داده شده", "teacher_classes"),
                ("دفتر کلاسی", "class_book"),
                ("ثبت گزارش تدریس", "teaching_report"),
                ("مدیریت طرح درس", "lesson_plan"),
                ("لیست ثبت نمرات", "grade_register"),
                ("بانک سوال", "question_bank"),
                ("اشتراک‌گذاری سوالات", "question_share"),
                ("آزمون‌ها", "exams"),
                ("تکالیف", "assignments"),
                ("محتوای آموزشی", "education_content"),
                ("درخواست ملاقات با اولیا", "parent_meeting"),
                ("ارجاع دانش‌آموز به واحد مربوطه", "student_referral")

            ]
        )



        # =====================================================
        # آموزش و یادگیری
        # =====================================================


        self.create_group(
            "🎓 آموزش",
            [

                ("برنامه درسی", "schedule"),
                ("بانک محتوای آموزشی", "content_bank"),
                ("تحلیل آموزشی", "education_analysis")

            ]
        )



        # =====================================================
        # مشاور
        # =====================================================


        self.create_group(
            "🧑‍💼 پنل مشاور",
            [

                ("تابلو اعلانات مشاور", "counselor_board"),
                ("پرونده مشاوره", "counseling_file"),
                ("پیگیری وضعیت دانش‌آموز", "student_follow"),
                ("ارجاع به مدیریت", "refer_management"),
                ("کلاس‌های آموزشی", "counseling_classes"),
                ("آموزش خانواده", "family_training"),
                ("ارتباط با اولیا پس از تایید مدیریت", "parent_contact"),
                ("هدایت تحصیلی", "career_guidance")

            ]
        )



        # =====================================================
        # هوش مصنوعی
        # =====================================================


        self.create_group(
            "🤖 هوش مصنوعی فراهوش",
            [

                ("گزارش هوشمند مدرسه", "ai_school_report"),
                ("تحلیل عملکرد دانش‌آموزان", "ai_students"),
                ("تحلیل حضور و غیاب", "ai_attendance"),
                ("پیشنهادهای آموزشی", "ai_suggestions"),
                ("هشدارهای هوشمند", "ai_alerts"),
                ("دستیار مدیر", "ai_manager")

            ]
        )



        # =====================================================
        # کلاس آنلاین
        # =====================================================


        self.create_group(
            "🎥 کلاس آنلاین",
            [

                ("کلاس‌های مجازی", "online_classes"),
                ("ایجاد کلاس جدید", "create_online"),
                ("اتاق کلاس آنلاین", "online_room"),
                ("تخته هوشمند", "smart_board"),
                ("کوییز آنلاین", "online_quiz"),
                ("گزارش حضور و تحلیل فعالیت", "online_analysis"),
                ("مدیریت میکروفون و دوربین", "media_control"),
                ("گزارش پایان جلسه", "session_report")

            ]
        )


    # =====================================================
        # امور مالی
        # =====================================================


        self.create_group(
            "💰 امور مالی",
            [

                ("پرداخت کلاس‌های فوق برنامه", "extra_payments"),
                ("کمک‌های مردمی خودخواسته", "donations"),
                ("مدیریت پرداخت‌ها", "payments"),
                ("ثبت هزینه‌ها", "expenses"),
                ("ثبت خریدها", "purchases"),
                ("فاکتورها و رسیدها", "invoices"),
                ("صندوق مدرسه", "school_fund"),
                ("گزارش درآمد و هزینه", "financial_reports"),
                ("دستیار حسابداری هوشمند", "accounting_ai"),
                ("فایل پایان سال مالی", "financial_archive")

            ]
        )



        # =====================================================
        # پنل اولیا
        # =====================================================


        self.create_group(
            "👨‍👩‍👧 پنل اولیا",
            [

                ("وضعیت تحصیلی فرزند", "parent_status"),
                ("مشاهده کارنامه پس از تایید مدیریت", "parent_report_card"),
                ("مشاهده نمرات", "parent_grades"),
                ("نمودار عملکرد درسی", "parent_chart"),
                ("نمودار عملکرد انضباطی", "parent_discipline"),
                ("پیام‌های مدرسه", "parent_messages"),
                ("ارتباط با مدرسه پس از تایید مدیریت", "parent_connection")

            ]
        )



        # =====================================================
        # افتخارات دبیرستان
        # =====================================================


        self.create_group(
            "🏆 نام‌آوران دبیرستان",
            [

                ("افتخارات علمی", "honors_science"),
                ("افتخارات فرهنگی", "honors_culture"),
                ("افتخارات ورزشی", "honors_sport"),
                ("جشنواره خوارزمی", "honors_kharazmi"),
                ("دانش‌آموزان برتر", "top_students"),
                ("دبیران برگزیده", "top_teachers")

            ]
        )



        # =====================================================
        # تنظیمات
        # =====================================================


        self.create_group(
            "⚙️ تنظیمات سامانه",
            [

                ("مدیریت کاربران", "users"),
                ("نقش‌ها و سطح دسترسی", "permissions"),
                ("پشتیبان‌گیری", "backup"),
                ("تنظیمات ظاهر", "appearance"),
                ("اطلاعات سامانه", "system_info")

            ]
        )



        self.main_layout.addStretch()



        self.set_style()



    # =====================================================
    # ساخت گروه
    # =====================================================


    def create_group(
            self,
            title,
            items
    ):


        button = QPushButton(
            title + "   ▼"
        )


        button.setMinimumHeight(
            45
        )


        button.setCheckable(
            True
        )


        self.main_layout.addWidget(
            button
        )



        container = QWidget()


        layout = QVBoxLayout(
            container
        )


        layout.setContentsMargins(
            15,
            0,
            0,
            5
        )


        container.setVisible(
            False
        )



        def toggle():


            state = button.isChecked()


            container.setVisible(
                state
            )


            if state:

                button.setText(
                    title + "   ▲"
                )

            else:

                button.setText(
                    title + "   ▼"
                )



        button.clicked.connect(
            toggle
        )



        self.main_layout.addWidget(
            container
        )



        for text, key in items:


            item_button = QPushButton(
                "   " + text
            )


            item_button.setMinimumHeight(
                38
            )


            item_button.clicked.connect(lambda checked=False,
                page=key:
                self.page_callback(page)
            )


            layout.addWidget(
                item_button
            )



    # =====================================================
    # استایل
    # =====================================================


    def set_style(self):


        self.setStyleSheet("""


        QWidget{

            background:#ffffff;

            font-family:B Nazanin;

            font-size:13pt;

        }



        QLabel{

            color:#1b5e20;

        }



        QPushButton{


            background:#f7faf7;

            border:none;

            border-radius:12px;

            padding:9px;

            text-align:right;

        }



        QPushButton:hover{

            background:#dcedc8;

        }



        QPushButton:checked{

            background:#2e7d32;

            color:white;

        }


        """)