import os
import sqlite3


from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPixmap


from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QLineEdit,
    QTextEdit,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QFrame,
    QFileDialog,
    QMessageBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QComboBox,
    QCheckBox,
    QScrollArea,
)


from database.db import DATABASE_NAME as DB_NAME



class Teachers(QWidget):


    def __init__(self):

        super().__init__()


        self.photo_path = ""

        self.selected_teacher_id = None


        self.setup_database()

        self.build_ui()

        self.load_teachers()



    # =====================================================
    # دیتابیس دبیران
    # =====================================================


    def setup_database(self):

        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()


        cursor.execute("""

        CREATE TABLE IF NOT EXISTS teachers(

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            first_name TEXT,

            last_name TEXT,

            national_code TEXT,

            personnel_code TEXT,

            mobile TEXT,

            phone TEXT,

            email TEXT,

            degree TEXT,

            major TEXT,

            employment_status TEXT,

            grades TEXT,

            lessons TEXT,

            description TEXT,

            photo TEXT

        )

        """)


        conn.commit()

        conn.close()



    # =====================================================
    # ساخت رابط کاربری
    # =====================================================


    def build_ui(self):


        self.main_layout = QHBoxLayout(self)

        self.main_layout.setContentsMargins(
            15,
            15,
            15,
            15
        )


        self.main_layout.setSpacing(15)



        # -------------------------
        # فرم اطلاعات
        # -------------------------


        self.form_frame = QFrame()

        self.form_frame.setMinimumWidth(430)


        self.form_layout = QGridLayout(
            self.form_frame
        )


        self.form_layout.setVerticalSpacing(8)



        title = QLabel(
            "مدیریت هوشمند دبیران فراهوش"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Nazanin",
                18,
                QFont.Bold
            )
        )


        self.form_layout.addWidget(
            title,
            0,
            0,
            1,
            3
        )



        # عکس دبیر


        self.photo_label = QLabel()


        self.photo_label.setFixedSize(
            150,
            180
        )


        self.photo_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.photo_label.setStyleSheet("""

        QLabel{

            border:2px solid #cccccc;

            border-radius:10px;

            background:white;

        }

        """)



        self.photo_button = QPushButton(
            "انتخاب عکس"
        )


        self.photo_button.clicked.connect(
            self.select_photo
        )



        self.form_layout.addWidget(
            self.photo_label,
            1,
            0,
            5,
            1
        )


        self.form_layout.addWidget(
            self.photo_button,
            6,
            0
        )



        # فیلدها


        self.first_name = QLineEdit()

        self.last_name = QLineEdit()

        self.national_code = QLineEdit()

        self.personnel_code = QLineEdit()

        self.mobile = QLineEdit()

        self.phone = QLineEdit()

        self.email = QLineEdit()


        self.degree = QComboBox()


        self.degree.addItems([

            "",

            "کارشناسی",

            "کارشناسی ارشد",

            "دکتری"

        ])



        self.major = QLineEdit()



        self.status = QComboBox()


        self.status.addItems([

            "رسمی",

            "پیمانی",

            "حق التدریس",

            "آزاد"

        ])


    # -------------------------
        # اطلاعات اصلی
        # -------------------------

        row = 1


        fields = [

            ("نام", self.first_name),

            ("نام خانوادگی", self.last_name),

            ("کد ملی", self.national_code),

            ("کد پرسنلی", self.personnel_code),

            ("موبایل", self.mobile),

            ("تلفن", self.phone),

            ("ایمیل", self.email),

            ("مدرک تحصیلی", self.degree),

            ("رشته تحصیلی", self.major),

            ("وضعیت همکاری", self.status),

        ]



        for title, widget in fields:


            self.form_layout.addWidget(

                QLabel(title),

                row,

                1

            )


            self.form_layout.addWidget(

                widget,

                row,

                2

            )


            row += 1



        # -------------------------
        # پایه های قابل تدریس
        # -------------------------


        self.form_layout.addWidget(

            QLabel("پایه‌های قابل تدریس"),

            row,

            1

        )



        grade_box = QWidget()


        grade_layout = QVBoxLayout(
            grade_box
        )


        grade_layout.setContentsMargins(
            0,
            0,
            0,
            0
        )


        self.grade_checks = []



        grades = [

            "هفتم",

            "هشتم",

            "نهم",

            "دهم",

            "یازدهم",

            "دوازدهم"

        ]



        for item in grades:


            check = QCheckBox(item)

            self.grade_checks.append(check)

            grade_layout.addWidget(check)



        grade_scroll = QScrollArea()


        grade_scroll.setWidgetResizable(
            True
        )


        grade_scroll.setFixedHeight(
            140
        )


        grade_scroll.setWidget(
            grade_box
        )


        self.form_layout.addWidget(

            grade_scroll,

            row,

            2

        )



        row += 1



        # -------------------------
        # دروس قابل تدریس
        # -------------------------


        self.form_layout.addWidget(

            QLabel("دروس قابل تدریس"),

            row,

            1

        )



        lesson_box = QWidget()


        lesson_layout = QVBoxLayout(
            lesson_box
        )


        lesson_layout.setContentsMargins(
            0,
            0,
            0,
            0
        )



        self.lesson_checks = []



        lessons = [

            "ریاضی",

            "علوم",

            "فارسی",

            "نگارش",

            "عربی",

            "انگلیسی",

            "مطالعات اجتماعی",

            "پیام‌های آسمان",

            "قرآن",

            "فرهنگ و هنر",

            "کار و فناوری",

            "ورزش",

            "فیزیک",

            "شیمی",

            "زیست شناسی",

            "هندسه",

            "حسابان"

        ]



        for item in lessons:


            check = QCheckBox(item)


            self.lesson_checks.append(check)


            lesson_layout.addWidget(
                check
            )



        lesson_scroll = QScrollArea()


        lesson_scroll.setWidgetResizable(
            True
        )


        lesson_scroll.setFixedHeight(
            140
        )


        lesson_scroll.setWidget(
            lesson_box
        )


        self.form_layout.addWidget(

            lesson_scroll,

            row,

            2

        )



        row += 1



        # -------------------------
        # توضیحات
        # -------------------------


        self.form_layout.addWidget(

            QLabel("توضیحات"),

            row,

            1

        )


        self.description = QTextEdit()


        self.description.setMinimumHeight(
            80
        )


        self.form_layout.addWidget(

            self.description,

            row,

            2

        )



        row += 1



        # -------------------------
        # دکمه ها
        # -------------------------


        buttons = QHBoxLayout()



        self.save_btn = QPushButton(
            "💾 ثبت"
        )


        self.edit_btn = QPushButton(
            "✏️ ویرایش"
        )


        self.delete_btn = QPushButton(
            "🗑️ حذف"
        )


        self.clear_btn = QPushButton(
            "🆕 جدید"
        )



        self.save_btn.clicked.connect(
            self.save_teacher
        )


        self.edit_btn.clicked.connect(
            self.update_teacher
        )


        self.delete_btn.clicked.connect(
            self.delete_teacher
        )


        self.clear_btn.clicked.connect(
            self.clear_form
        )



        buttons.addWidget(
            self.save_btn
        )

        buttons.addWidget(
            self.edit_btn
        )

        buttons.addWidget(
            self.delete_btn
        )

        buttons.addWidget(
            self.clear_btn
        )



        self.form_layout.addLayout(

            buttons,

            row,

            0,

            1,

            3

        )



        self.main_layout.addWidget(

            self.form_frame,

            2

        )


    # =====================================================
    # جدول دبیران
    # =====================================================


        self.table_frame = QFrame()


        table_layout = QVBoxLayout(
            self.table_frame
        )


        title = QLabel(
            "لیست دبیران"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Nazanin",
                16,
                QFont.Bold
            )
        )


        table_layout.addWidget(
            title
        )



        self.search = QLineEdit()


        self.search.setPlaceholderText(
            "جستجو نام، نام خانوادگی یا کد پرسنلی..."
        )


        self.search.textChanged.connect(
            self.search_teacher
        )


        table_layout.addWidget(
            self.search
        )



        self.table = QTableWidget()


        self.table.setColumnCount(8)


        self.table.setHorizontalHeaderLabels([

            "کد",

            "نام",

            "نام خانوادگی",

            "کد پرسنلی",

            "پایه",

            "درس",

            "موبایل",

            "وضعیت"

        ])



        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )



        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )



        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )



        self.table.cellClicked.connect(
            self.select_teacher
        )



        table_layout.addWidget(
            self.table
        )



        self.teacher_count = QLabel(
            "تعداد دبیران : 0"
        )


        self.teacher_count.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.teacher_count.setFont(
            QFont(
                "B Nazanin",
                12,
                QFont.Bold
            )
        )


        table_layout.addWidget(
            self.teacher_count
        )



        self.main_layout.addWidget(

            self.table_frame,

            3

        )





    # =====================================================
    # انتخاب عکس
    # =====================================================


    def select_photo(self):


        file_name, _ = QFileDialog.getOpenFileName(

            self,

            "انتخاب عکس دبیر",

            "",

            "Images (*.png *.jpg *.jpeg)"

        )



        if file_name:


            self.photo_path = file_name


            pixmap = QPixmap(
                file_name
            )


            self.photo_label.setPixmap(

                pixmap.scaled(

                    150,

                    180,

                    Qt.KeepAspectRatio,

                    Qt.SmoothTransformation

                )

            )





    # =====================================================
    # بارگذاری دبیران
    # =====================================================


    def load_teachers(self):


        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute(

            "SELECT * FROM teachers ORDER BY last_name"

        )


        rows = cursor.fetchall()


        conn.close()



        self.table.setRowCount(0)



        for r, data in enumerate(rows):


            self.table.insertRow(r)



            values = [

                data[0],

                data[1],

                data[2],

                data[4],

                data[11],

                data[12],

                data[5],

                data[10]

            ]



            for c, value in enumerate(values):


                self.table.setItem(

                    r,

                    c,

                    QTableWidgetItem(

                        str(value or "")

                    )

                )



        self.teacher_count.setText(

            f"تعداد دبیران : {len(rows)}"

        )





    # =====================================================
    # جستجو
    # =====================================================


    def search_teacher(self):


        text = self.search.text().strip()



        for row in range(
            self.table.rowCount()
        ):


            match = False



            for col in range(
                self.table.columnCount()
            ):


                item = self.table.item(
                    row,
                    col
                )



                if item and text in item.text():


                    match = True



            self.table.setRowHidden(

                row,

                not match

            )


    # =====================================================
    # ثبت دبیر جدید
    # =====================================================


    def save_teacher(self):


        grades = ",".join(

            c.text()

            for c in self.grade_checks

            if c.isChecked()

        )


        lessons = ",".join(

            c.text()

            for c in self.lesson_checks

            if c.isChecked()

        )



        conn = sqlite3.connect(
            DB_NAME
        )

        cursor = conn.cursor()



        cursor.execute("""

        INSERT INTO teachers(

            first_name,

            last_name,

            national_code,

            personnel_code,

            mobile,

            phone,

            email,

            degree,

            major,

            employment_status,

            grades,

            lessons,

            description,

            photo

        )

        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)

        """, (

            self.first_name.text(),

            self.last_name.text(),

            self.national_code.text(),

            self.personnel_code.text(),

            self.mobile.text(),

            self.phone.text(),

            self.email.text(),

            self.degree.currentText(),

            self.major.text(),

            self.status.currentText(),

            grades,

            lessons,

            self.description.toPlainText(),

            self.photo_path

        ))



        conn.commit()

        conn.close()



        QMessageBox.information(

            self,

            "ثبت اطلاعات",

            "دبیر با موفقیت ثبت شد."

        )



        self.clear_form()

        self.load_teachers()





    # =====================================================
    # انتخاب دبیر از جدول
    # =====================================================


    def select_teacher(self, row, column):


        item = self.table.item(
            row,
            0
        )


        if not item:

            return



        self.selected_teacher_id = int(

            item.text()

        )



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute(

            "SELECT * FROM teachers WHERE id=?",

            (self.selected_teacher_id,)

        )


        teacher = cursor.fetchone()


        conn.close()



        if not teacher:

            return



        self.first_name.setText(
            teacher[1] or ""
        )

        self.last_name.setText(
            teacher[2] or ""
        )

        self.national_code.setText(
            teacher[3] or ""
        )

        self.personnel_code.setText(
            teacher[4] or ""
        )

        self.mobile.setText(
            teacher[5] or ""
        )

        self.phone.setText(
            teacher[6] or ""
        )

        self.email.setText(
            teacher[7] or ""
        )


        self.degree.setCurrentText(
            teacher[8] or ""
        )


        self.major.setText(
            teacher[9] or ""
        )


        self.status.setCurrentText(
            teacher[10] or ""
        )


        self.description.setPlainText(
            teacher[13] or ""
        )



        grades = (teacher[11] or "").split(",")

        lessons = (teacher[12] or "").split(",")



        for c in self.grade_checks:

            c.setChecked(
                c.text() in grades
            )



        for c in self.lesson_checks:

            c.setChecked(
                c.text() in lessons
            )



        self.photo_path = teacher[14] or ""



        if self.photo_path and os.path.exists(self.photo_path):


            pix = QPixmap(
                self.photo_path
            )


            self.photo_label.setPixmap(

                pix.scaled(

                    150,

                    180,

                    Qt.KeepAspectRatio,

                    Qt.SmoothTransformation

                )

            )





    # =====================================================
    # رایش دبیر
    # =====================================================


    def update_teacher(self):


        if self.selected_teacher_id is None:


            QMessageBox.warning(

                self,

                "توجه",

                "ابتدا یک دبیر را انتخاب کنید."

            )

            return



        grades = ",".join(

            c.text()

            for c in self.grade_checks

            if c.isChecked()

        )


        lessons = ",".join(

            c.text()

            for c in self.lesson_checks

            if c.isChecked()

        )



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute("""

        UPDATE teachers SET

            first_name=?,

            last_name=?,

            national_code=?,

            personnel_code=?,

            mobile=?,

            phone=?,

            email=?,

            degree=?,

            major=?,

            employment_status=?,

            grades=?,

            lessons=?,

            description=?,

            photo=?

        WHERE id=?

        """, (

            self.first_name.text(),

            self.last_name.text(),

            self.national_code.text(),

            self.personnel_code.text(),

            self.mobile.text(),

            self.phone.text(),

            self.email.text(),

            self.degree.currentText(),

            self.major.text(),

            self.status.currentText(),

            grades,

            lessons,

            self.description.toPlainText(),

            self.photo_path,

            self.selected_teacher_id

        ))



        conn.commit()

        conn.close()



        self.load_teachers()



        QMessageBox.information(

            self,

            "ویرایش",

            "اطلاعات دبیر به‌روزرسانی شد."

        )





    # =====================================================
    # حذف دبیر
    # =====================================================


    def delete_teacher(self):


        if self.selected_teacher_id is None:


            QMessageBox.warning(

                self,

                "توجه",

                "ابتدا یک دبیر را انتخاب کنید."

            )

            return



        result = QMessageBox.question(

            self,

            "حذف",

            "آیا از حذف این دبیر مطمئن هستید؟"

        )


        if result != QMessageBox.Yes:

            return



        conn = sqlite3.connect(
            DB_NAME
        )


        cursor = conn.cursor()



        cursor.execute(

            "DELETE FROM teachers WHERE id=?",

            (self.selected_teacher_id,)

        )



        conn.commit()

        conn.close()



        self.load_teachers()

        self.clear_form()





    # =====================================================
    # پاک کردن فرم
    # =====================================================


    def clear_form(self):


        self.selected_teacher_id = None


        self.photo_path = ""



        self.first_name.clear()

        self.last_name.clear()

        self.national_code.clear()

        self.personnel_code.clear()

        self.mobile.clear()

        self.phone.clear()

        self.email.clear()

        self.major.clear()

        self.description.clear()



        self.degree.setCurrentIndex(0)

        self.status.setCurrentIndex(0)



        for c in self.grade_checks:

            c.setChecked(False)



        for c in self.lesson_checks:

            c.setChecked(False)



        self.photo_label.clear()