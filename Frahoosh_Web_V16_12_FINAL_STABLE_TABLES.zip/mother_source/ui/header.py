from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtCore import Qt
from config import APP_NAME, SYSTEM_TITLE, SCHOOL_NAME, SCHOOL_YEAR


class SchoolHeader(QWidget):
    """Header shared by the application pages.

    School identity is read from config.py so the same build can be
    delivered to another school by changing SCHOOL_NAME/SCHOOL_YEAR only.
    """
    def __init__(self, parent=None, compact=False):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(0)

        self.app_name = QLabel(APP_NAME)
        self.system_name = QLabel(SYSTEM_TITLE)
        self.school_name = QLabel(SCHOOL_NAME)
        self.school_year = QLabel(SCHOOL_YEAR)

        for label in (self.app_name, self.system_name, self.school_name, self.school_year):
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setStyleSheet("color:#172033; background:transparent; border:none;")
            layout.addWidget(label)

        self.app_name.setStyleSheet("color:#0f172a; font-size:16px; font-weight:bold; background:transparent; border:none;")
        self.school_name.setStyleSheet("color:#0f4c5c; font-size:13px; font-weight:bold; background:transparent; border:none;")
        self.school_year.setStyleSheet("color:#475569; font-size:10px; background:transparent; border:none;")
        self.system_name.setStyleSheet("color:#334155; font-size:10px; background:transparent; border:none;")

        if compact:
            self.system_name.hide()
            self.school_year.hide()
