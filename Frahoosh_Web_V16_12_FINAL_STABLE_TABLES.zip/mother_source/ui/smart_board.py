from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QListWidget,
    QTextEdit,
    QMessageBox
)

from PySide6.QtCore import Qt



class OnlineClassRoom(QWidget):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("کلاس آنلاین فراهوش")
        self.resize(1100, 750)

        self.setup_ui()


    def setup_ui(self):

        main_layout = QVBoxLayout(self)


        # =========================
        # عنوان کلاس
        # =========================

        title = QLabel(
            "🎓 کلاس آنلاین هوشمند فراهوش"
        )

        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            """
            font-size:24px;
            font-weight:bold;
            padding:15px;
            """
        )

        main_layout.addWidget(title)


        # =========================
        # بخش اطلاعات کلاس
        # =========================

        info_frame = QFrame()

        info_layout = QHBoxLayout(
            info_frame
        )


        self.class_name = QLabel(
            "کلاس: ریاضی پایه هشتم"
        )

        self.teacher_name = QLabel(
            "دبیر: ----"
        )


        info_layout.addWidget(
            self.class_name
        )

        info_layout.addWidget(
            self.teacher_name
        )


        main_layout.addWidget(
            info_frame
        )


        # =========================
        # بخش اصلی کلاس
        # =========================

        content_layout = QHBoxLayout()


        # سمت راست کاربران

        users_frame = QFrame()

        users_layout = QVBoxLayout(
            users_frame
        )


        users_title = QLabel(
            "👥 کاربران حاضر"
        )


        self.users_list = QListWidget()


        users_layout.addWidget(
            users_title
        )

        users_layout.addWidget(
            self.users_list
        )


        content_layout.addWidget(
            users_frame
        )


    # =========================
        # فضای تخته هوشمند
        # =========================

        board_frame = QFrame()

        board_layout = QVBoxLayout(
            board_frame
        )


        board_title = QLabel(
            "🖊️ تخته هوشمند کلاس"
        )

        board_title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.board = SmartBoard()


        board_layout.addWidget(
            board_title
        )

        board_layout.addWidget(
            self.board
        )


        content_layout.addWidget(
            board_frame,
            4
        )


        main_layout.addLayout(
            content_layout
        )


        # =========================
        # کنترل‌های کلاس
        # =========================

        control_layout = QHBoxLayout()


        self.clear_btn = QPushButton(
            "🧹 پاک کردن تخته"
        )

        self.clear_btn.clicked.connect(
            self.clear_board
        )


        self.save_btn = QPushButton(
            "💾 ذخیره صفحه"
        )


        self.quiz_btn = QPushButton(
            "📝 آزمون کوتاه"
        )

        self.quiz_btn.clicked.connect(
            self.create_quiz
        )


        self.end_btn = QPushButton(
            "⛔ پایان کلاس"
        )

        self.end_btn.clicked.connect(
            self.end_class
        )


        control_layout.addWidget(
            self.clear_btn
        )

        control_layout.addWidget(
            self.save_btn
        )

        control_layout.addWidget(
            self.quiz_btn
        )

        control_layout.addWidget(
            self.end_btn
        )


        main_layout.addLayout(
            control_layout
        )



    # =========================
    # پاک کردن تخته
    # =========================

    def clear_board(self):

        self.board.clear()



    # =========================
    # آزمون کوتاه
    # =========================

    def create_quiz(self):
        try:
            from ui.online_quiz import OnlineQuiz
            self.quiz_window=OnlineQuiz(); self.quiz_window.show()
        except Exception as exc:
            QMessageBox.critical(self,"آزمون کوتاه",str(exc))



    # =========================
    # پایان کلاس
    # =========================

    def end_class(self):

        result = QMessageBox.question(
            self,
            "پایان کلاس",
            "آیا می‌خواهید کلاس را پایان دهید؟"
        )


        if result:

            self.close()


    from PySide6.QtWidgets import QWidget
from PySide6.QtGui import (
    QPainter,
    QPen
)
from PySide6.QtCore import (
    Qt,
    QPoint
)


class SmartBoard(QWidget):

    def __init__(self):
        super().__init__()

        self.setMinimumSize(
            600,
            400
        )

        self.setStyleSheet(
            """
            background:white;
            border:2px solid #cccccc;
            """
        )


        self.drawing = False

        self.last_point = QPoint()


        self.pen_color = Qt.black

        self.pen_width = 4


        self.lines = []



    # =====================
    # شروع نقاشی
    # =====================

    def mousePressEvent(self, event):

        if event.button() == Qt.LeftButton:

            self.drawing = True

            self.last_point = event.position().toPoint()



    # =====================
    # حرکت قلم
    # =====================

    def mouseMoveEvent(self, event):

        if self.drawing:

            current_point = (
                event.position()
                .toPoint()
            )


            self.lines.append(
                (
                    self.last_point,
                    current_point,
                    self.pen_color,
                    self.pen_width
                )
            )


            self.last_point = current_point


            self.update()



    # =====================
    # پایان قلم
    # =====================

    def mouseReleaseEvent(self, event):

        if event.button() == Qt.LeftButton:

            self.drawing = False



    # =====================
    # نمایش خطوط
    # =====================

    def paintEvent(self, event):

        painter = QPainter(
            self
        )


        painter.setRenderHint(
            QPainter.Antialiasing
        )


        for line in self.lines:

            start, end, color, width = line


            pen = QPen(
                color,
                width
            )


            painter.setPen(
                pen
            )


            painter.drawLine(
                start,
                end
            )



    # =====================
    # پاک کردن تخته
    # =====================

    def clear(self):

        self.lines.clear()

        self.update()



    # =====================
    # تغییر رنگ قلم
    # =====================

    def set_pen_color(
            self,
            color
    ):

        self.pen_color = color



    # =====================
    # تغییر ضخامت قلم
    # =====================

    def set_pen_width(
            self,
            width
    ):

        self.pen_width = width