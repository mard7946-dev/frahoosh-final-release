import importlib

import qtawesome as qta


from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QFrame,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget, QInputDialog, QMessageBox
)


from PySide6.QtCore import Qt

from PySide6.QtGui import QFont


from services.dashboard_service import DashboardService
from ui.header import SchoolHeader
from ui.compact import compact_button_rows
from ui.panel_shell import PanelAccordionShell
from config import SCHOOL_NAME



# ==================================================
# کارت های داشبورد
# ==================================================

class DashboardCard(QFrame):

    def __init__(
        self,
        title,
        value,
        icon,
        color
    ):

        super().__init__()


        self.setFixedHeight(
            150
        )


        layout = QVBoxLayout(
            self
        )


        layout.setContentsMargins(
            15,
            15,
            15,
            15
        )



        icon_label = QLabel()


        icon_label.setPixmap(
            qta.icon(
                icon
            ).pixmap(
                35,
                35
            )
        )


        icon_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        value_label = QLabel(
            str(value)
        )


        value_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        value_label.setFont(
            QFont(
                "B Zar",
                28,
                QFont.Bold
            )
        )



        title_label = QLabel(
            title
        )


        title_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title_label.setFont(
            QFont(
                "B Zar",
                15
            )
        )



        layout.addWidget(
            icon_label
        )


        layout.addWidget(
            value_label
        )


        layout.addWidget(
            title_label
        )



        self.setStyleSheet(
            f"""
            QFrame {{

                background:white;

                border-radius:18px;

                border-right:5px solid {color};

            }}

            """
        )





# ==================================================
# Sidebar
# ==================================================

class Sidebar(QFrame):

    def __init__(
        self,
        dashboard
    ):

        super().__init__()


        self.dashboard = dashboard


        self.setFixedWidth(
            230
        )


        self.setObjectName(
            "sidebar"
        )


        self.create_ui()




    def create_ui(self):


        layout = QVBoxLayout(
            self
        )


        layout.setContentsMargins(
            15,
            20,
            15,
            20
        )


        layout.setSpacing(
            8
        )



        logo = QLabel(
            "فراهوش"
        )


        logo.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        logo.setFont(
            QFont(
                "B Zar",
                26,
                QFont.Bold
            )
        )
        logo.setStyleSheet("color:#0f172a; background:transparent; border:none;")



        school = QLabel(
            "مدیریت هوشمند دبیرستان"
        )
        school.setStyleSheet("color:#0f172a; background:transparent; font-weight:bold;")


        school.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        school.setFont(
            QFont(
                "B Zar",
                11
            )
        )



        layout.addWidget(
            logo
        )


        layout.addWidget(
            school
        )


        layout.addSpacing(
            20
        )



        menus = [

            ("خانه", "fa5s.home"),

            ("مدیریت", "fa5s.cogs"),

            ("معاونت آموزشی", "fa5s.book"),

            ("معاونت پرورشی", "fa5s.star"),

            ("معاونت اجرایی", "fa5s.briefcase"),

            ("مشاور", "fa5s.user"),

            ("دبیران", "fa5s.chalkboard"),

            ("دانش‌آموزان", "fa5s.users"),

            ("اولیا", "fa5s.user-friends"),

            ("مالی", "fa5s.wallet"),

            ("تابلو هوشمند", "fa5s.desktop"),

            ("هوش مصنوعی", "fa5s.robot"),

            ("تنظیمات", "fa5s.cog"),
            ("صندوق پیام", "fa5s.inbox"),
            ("ارسال پیام", "fa5s.paper-plane"),

        ]



        for name, icon in menus:


            btn = QPushButton(
                name
            )


            btn.setIcon(
                qta.icon(icon
                )
            )


            btn.setMinimumHeight(
                30
            )
            btn.setMaximumHeight(34)


            btn.clicked.connect(
                lambda checked=False,
                page=name:
                self.dashboard.open_page(page)
            )


            layout.addWidget(
                btn
            )



        layout.addStretch()


        self.setLayout(
            layout
        )


        # ==================================================
# داشبورد اصلی فراهوش
# ==================================================

class Dashboard(QWidget):


    def __init__(
        self,
        username=None,
        role=None
    ):

        super().__init__()



        self.username = username or "مدیر سیستم"

        self.role = role or "manager"



        self.loaded_pages = {}



        self.setWindowTitle(
            "فراهوش | مدیریت هوشمند دبیرستان"
        )



        self.setMinimumSize(
            1180,
            720
        )



        self.init_ui()




    # ==================================================
    # ساخت رابط کاربری
    # ==================================================

    def init_ui(self):


        main_layout = QVBoxLayout(
            self
        )



        main_layout.setContentsMargins(
            15,
            15,
            15,
            15
        )



        main_layout.setSpacing(
            15
        )



        # =========================
        # Header
        # =========================

        header = QFrame()


        header.setObjectName(
            "header"
        )


        header.setFixedHeight(
            75
        )



        header_layout = QHBoxLayout(
            header
        )

        identity = SchoolHeader(compact=True)
        header_layout.addWidget(identity)
        header_layout.addStretch()


        title = QLabel(
            "فراهوش | سامانه هوشمند آموزشی یکپارچه"
        )


        title.setFont(
            QFont(
                "B Zar",
                18,
                QFont.Bold
            )
        )



        user = QLabel(
            f"{self.username} | {self.role}"
        )


        user.setFont(
            QFont(
                "B Zar",
                13
            )
        )



        header_layout.addWidget(
            title
        )


        header_layout.addStretch()


        header_layout.addWidget(
            user
        )



        # =========================
        # Body
        # =========================

        body = QHBoxLayout()


        body.setSpacing(
            15
        )



        self.pages = QStackedWidget()



        self.home_page = self.create_home_page()



        self.pages.addWidget(
            self.home_page
        )



        self.sidebar = Sidebar(
            self
        )



        body.addWidget(
            self.pages,
            1
        )



        body.addWidget(
            self.sidebar
        )



        main_layout.addWidget(
            header
        )


        main_layout.addLayout(
            body
        )
        main_layout.addWidget(self.create_global_toolbar())



        self.load_style()




    # ==================================================
    # صفحه خانه
    # ==================================================

    def create_home_page(self):


        page = QWidget()



        layout = QVBoxLayout(
            page
        )



        title = QLabel(
            "داشبورد مدیریتی فراهوش"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )



        title.setFont(
            QFont(
                "B Zar",
                28,
                QFont.Bold
            )
        )



        layout.addWidget(
            title
        )



        cards_layout = QHBoxLayout()



        stats = DashboardService.get_statistics()



        cards = [

            (
                "دانش‌آموزان",
                stats.get("students",0),
                "fa5s.users",
                "#1976D2"
            ),


            (
                "دبیران",
                stats.get("teachers",0),
                "fa5s.chalkboard",
                "#388E3C"
            ),


            (
                "کلاس‌ها",
                stats.get("classes",0),
                "fa5s.school",
                "#F57C00"
            ),


            (
                "حضور امروز",
                stats.get("attendance",0),
                "fa5s.check",
                "#00838F"
            )

        ]



        for item in cards:


            card = DashboardCard(
                item[0],
                item[1],
                item[2],
                item[3]
            )

            cards_layout.addWidget(
                card
            )



        layout.addLayout(
            cards_layout
        )



        layout.addStretch()



        return page


    # ==================================================
    # نوار عملیات مشترک همه پنل‌ها
    # ==================================================
    def create_global_toolbar(self):
        bar=QFrame(); row=QHBoxLayout(bar); row.setContentsMargins(8,4,8,4)
        home=QPushButton("بازگشت به صفحه اصلی"); edit=QPushButton("ویرایش"); change=QPushButton("تغییر رمز عبور")
        home.clicked.connect(lambda:self.pages.setCurrentWidget(self.home_page))
        edit.clicked.connect(self.edit_current)
        change.clicked.connect(self.change_password)
        row.addWidget(home); row.addWidget(edit); row.addWidget(change); row.addStretch(); return bar

    def edit_current(self):
        w=self.pages.currentWidget()
        if hasattr(w,'edit_selected'): w.edit_selected()
        else: QMessageBox.information(self,'ویرایش','این صفحه برای ویرایش مستقیم رکورد انتخاب‌شده آماده نیست؛ از دکمه ویرایش داخل همان بخش استفاده کنید.')

    def change_password(self):
        old,ok=QInputDialog.getText(self,'تغییر رمز','رمز فعلی:')
        if not ok:return
        new,ok=QInputDialog.getText(self,'تغییر رمز','رمز جدید:')
        if not ok or len(new)<6: QMessageBox.warning(self,'تغییر رمز','رمز جدید باید حداقل ۶ کاراکتر باشد.'); return
        confirm,ok=QInputDialog.getText(self,'تغییر رمز','تکرار رمز جدید:')
        if not ok or new!=confirm: QMessageBox.warning(self,'تغییر رمز','تکرار رمز یکسان نیست.'); return
        try:
            from services.auth_service import AuthService
            if AuthService.change_password(self.username,old,new): QMessageBox.information(self,'تغییر رمز','رمز با موفقیت تغییر کرد.')
            else: QMessageBox.warning(self,'تغییر رمز','رمز فعلی نادرست است.')
        except Exception as e: QMessageBox.critical(self,'تغییر رمز',str(e))

    # ==================================================
    # باز کردن صفحات
    # ==================================================

    def open_page(
        self,
        page_name
    ):


        if page_name == "خانه":

            self.pages.setCurrentWidget(
                self.home_page
            )

            return

        # Unified inbox and messenger are available from the main navigation
        # for every authenticated role, so users do not need a second
        # recipient/child selection just to read messages.
        if page_name == "صندوق پیام":
            from ui.unified_inbox import UnifiedInboxPage
            page = UnifiedInboxPage(username=self.username, role=self.role, parent=self)
            self.loaded_pages[page_name] = page
            self.pages.addWidget(page)
            self.pages.setCurrentWidget(page)
            return

        if page_name == "ارسال پیام":
            from ui.unified_inbox import UnifiedMessengerPage
            page = UnifiedMessengerPage(sender=self.username, role=self.role, parent=self)
            self.loaded_pages[page_name] = page
            self.pages.addWidget(page)
            self.pages.setCurrentWidget(page)
            return



        page_paths = {


            "مدیریت":
            "pages.school.panel",


            "معاونت آموزشی":
            "pages.education.panel",


            "معاونت پرورشی":
            "pages.cultural.panel",


            "معاونت اجرایی":
            "executive.panel",


            "مشاور":
            "advisor.panel",


            "دبیران":
            "teacher.panel",


            "دانش‌آموزان":
            "student.panel",


            "مالی":
            "finance.panel",


            "تابلو هوشمند":
            "smart_board.panel",


            "هوش مصنوعی":
            "ai.panel",


            "اولیا":
            "pages.parent.panel",


            "تنظیمات":
            "pages.school.settings"

        }



        path = page_paths.get(
            page_name
        )


        if not path:

            return



        if page_name in self.loaded_pages:


            self.pages.setCurrentWidget(
                self.loaded_pages[page_name]
            )

            return



        try:


            print(
                "TRY IMPORT:",
                path
            )


            module = importlib.import_module(
                path
            )



            Panel = getattr(
                module,
                "Panel"
            )

            # Pass the authenticated identity to panels that support it.
            # This is especially important for the parent and teacher panels.
            # Resolve the authenticated identity once and pass the linked
            # domain record into panels that need a concrete person.
            try:
                from services.data_link_service import resolve
                identity = resolve(self.username) or {}
            except Exception:
                identity = {}

            if page_name == "اولیا":
                try:
                    panel = Panel(username=self.username)
                except TypeError:
                    panel = Panel()
            elif page_name == "دبیران":
                teacher_name = self.username
                teacher = identity.get("teacher") or {}
                if teacher:
                    teacher_name = f"{teacher.get('first_name','')} {teacher.get('last_name','')}".strip() or teacher_name
                try:
                    panel = Panel(teacher_name=teacher_name)
                except TypeError:
                    panel = Panel()
            elif page_name == "دانش‌آموزان":
                try:
                    panel = Panel(student_id=identity.get("student_id"), username=self.username)
                except TypeError:
                    panel = Panel()
            else:
                panel = Panel()

            # Some panels expose an explicit page loader instead of loading
            # their pages in __init__. Call it after construction when present.
            if hasattr(panel, "load_pages") and not getattr(panel, "pages", None):
                try:
                    panel.load_pages()
                except TypeError:
                    pass
            compact_button_rows(panel)

            # Every internal page gets a common, configurable school header
            # and a compact visual shell. The panel itself remains the real
            # widget, so its existing logic and parent chain continue to work.
            # Each panel gets its own visual identity. Management additionally
            # uses a compact accordion shell with a typewriter welcome message.
            panel_colors = {
                "مدیریت": "#e8f1ff",
                "معاونت آموزشی": "#eefcf3",
                "معاونت پرورشی": "#fff7e8",
                "معاونت اجرایی": "#f3efff",
                "مشاور": "#fff0f6",
                "دبیران": "#edf7ff",
                "دانش‌آموزان": "#f0fdf4",
                "اولیا": "#fffaf0",
                "مالی": "#f0fdfa",
                "تابلو هوشمند": "#f5f3ff",
                "هوش مصنوعی": "#f4f4ff",
                "تنظیمات": "#f1f5f9",
            }
            # Use the same compact welcome/accordion pattern for every role.
            # This keeps the screen clean: collapsed = only the entry button;
            # expanded = the real operational panel.
            shell = PanelAccordionShell(
                panel=panel,
                panel_name=page_name,
                school_name=SCHOOL_NAME,
                role_label=page_name,
                background=panel_colors.get(page_name, '#f8fafc'),
            )

            self.pages.addWidget(shell)
            self.loaded_pages[page_name] = shell
            self.pages.setCurrentWidget(shell)



            print(
                "IMPORT SUCCESS"
            )



        except Exception as e:


            print(
                "ERROR OPEN PAGE:",
                repr(e)
            )



            error = QLabel(
                f"خطا در باز کردن صفحه:\n{e}"
            )


            error.setAlignment(
                Qt.AlignmentFlag.AlignCenter
            )


            self.pages.addWidget(
                error
            )


            self.pages.setCurrentWidget(
                error
            )





    # ==================================================
    # استایل داشبورد
    # ==================================================

    def load_style(self):


        self.setStyleSheet(
            """

            QWidget {

                background-color:#eef3f8;

                color:#263238;

                font-family:"B Zar";

            }



            QFrame#header {

                background:white;

                border-radius:20px;

            }



            QFrame#sidebar {

                background:#0d47a1;

                border-radius:22px;

            }



            QFrame#sidebar QLabel {

                color:white;

            }



            QFrame#sidebar QPushButton {


                background:#4CAF50;

                color:black;

                font-family:"B Zar";

                font-size:14px;

                font-weight:bold;

                border-radius:8px;

                padding:6px;

            }



            QFrame#sidebar QPushButton:hover {


                background:#81C784;

            }



            QLabel {

                color:#263238;

            }



            QStackedWidget {

                background:transparent;

            }

            """
        )