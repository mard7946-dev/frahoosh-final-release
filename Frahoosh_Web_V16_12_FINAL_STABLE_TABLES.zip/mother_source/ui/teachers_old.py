import os
import sqlite3

from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QLineEdit,
    QTextEdit,
    QTableWidget,
    QTableWidgetItem,
    QFileDialog,
    QMessageBox,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QFrame,
    QGroupBox,
    QCheckBox,
    QHeaderView
)

from PySide6.QtGui import (
    QPixmap,
    QFont
)

from PySide6.QtCore import Qt

print("=" * 50)
print("LOADING TEACHERS FILE")
print(__file__)
print("=" * 50)


DB_NAME = "school.db"


class Teachers(QWidget):

    def __init__(self):

        super().__init__()

        print("Teachers __init__ started")

        self.photo_path = ""

        self.selected_teacher_id = None

        self.setWindowTitle(
            "مدیریت هوشمند دبیران فراهوش"
        )

        self.resize(
            1400,
            780
        )



        self.create_ui()

        self.load_teachers()


    # =====================================================
        # فرم اطلاعات دبیر
        # =====================================================

        form = QGridLayout()

        row = 0

        form.addWidget(QLabel("نام"), row, 0)
        self.first_name = QLineEdit()
        form.addWidget(self.first_name, row, 1)

        row += 1

        form.addWidget(QLabel("نام خانوادگی"), row, 0)
        self.last_name = QLineEdit()
        form.addWidget(self.last_name, row, 1)

        row += 1

        form.addWidget(QLabel("کد ملی"), row, 0)
        self.national_code = QLineEdit()
        form.addWidget(self.national_code, row, 1)

        row += 1

        form.addWidget(QLabel("کد پرسنلی"), row, 0)
        self.personnel_code = QLineEdit()
        form.addWidget(self.personnel_code, row, 1)

        row += 1

        form.addWidget(QLabel("جنسیت"), row, 0)
        self.gender = QLineEdit()
        form.addWidget(self.gender, row, 1)

        row += 1

        form.addWidget(QLabel("تاریخ تولد"), row, 0)
        self.birth_date = QLineEdit()
        self.birth_date.setPlaceholderText("1405/01/01")
        form.addWidget(self.birth_date, row, 1)

        row += 1

        form.addWidget(QLabel("شماره همراه"), row, 0)
        self.phone = QLineEdit()
        form.addWidget(self.phone, row, 1)

        row += 1

        form.addWidget(QLabel("ایمیل"), row, 0)
        self.email = QLineEdit()
        form.addWidget(self.email, row, 1)

        row += 1

        form.addWidget(QLabel("تاریخ استخدام"), row, 0)
        self.hire_date = QLineEdit()
        self.hire_date.setPlaceholderText("1405/01/01")
        form.addWidget(self.hire_date, row, 1)

        row += 1

        form.addWidget(QLabel("وضعیت"), row, 0)
        self.status = QLineEdit()
        self.status.setPlaceholderText("فعال")
        form.addWidget(self.status, row, 1)

        row += 1

        form.addWidget(QLabel("آدرس"), row, 0)
        self.address = QTextEdit()
        self.address.setFixedHeight(70)
        form.addWidget(self.address, row, 1)

        row += 1

        form.addWidget(QLabel("توضیحات"), row, 0)
        self.description = QTextEdit()
        self.description.setFixedHeight(70)
        form.addWidget(self.description, row, 1)

        self.form_layout.addLayout(form)

        # =====================================================
        # پایه های قابل تدریس
        # =====================================================

        grades_group = QGroupBox("پایه های قابل تدریس")

        grades_layout = QGridLayout()

        self.grade7 = QCheckBox("هفتم")
        self.grade8 = QCheckBox("هشتم")
        self.grade9 = QCheckBox("نهم")

        grades_layout.addWidget(self.grade7,0,0)
        grades_layout.addWidget(self.grade8,0,1)
        grades_layout.addWidget(self.grade9,0,2)

        grades_group.setLayout(grades_layout)

        self.form_layout.addWidget(grades_group)

        # =====================================================
        # دروس
        # =====================================================

        subjects_group = QGroupBox("دروس قابل تدریس")

        subjects_layout = QGridLayout()

        self.math = QCheckBox("ریاضی")
        self.science = QCheckBox("علوم")
        self.persian = QCheckBox("فارسی")
        self.arabic = QCheckBox("عربی")
        self.english = QCheckBox("انگلیسی")
        self.quran = QCheckBox("قرآن")
        self.social = QCheckBox("مطالعات اجتماعی")
        self.defense = QCheckBox("آمادگی دفاعی")
        self.work = QCheckBox("کار و فناوری")
        self.art = QCheckBox("هنر")
        self.sport = QCheckBox("تربیت بدنی")
        self.thinking = QCheckBox("تفکر و سبک زندگی")

        subjects_layout.addWidget(self.math,0,0)
        subjects_layout.addWidget(self.science,0,1)
        subjects_layout.addWidget(self.persian,0,2)

        subjects_layout.addWidget(self.arabic,1,0)
        subjects_layout.addWidget(self.english,1,1)
        subjects_layout.addWidget(self.quran,1,2)

        subjects_layout.addWidget(self.social,2,0)
        subjects_layout.addWidget(self.defense,2,1)
        subjects_layout.addWidget(self.work,2,2)

        subjects_layout.addWidget(self.art,3,0)
        subjects_layout.addWidget(self.sport,3,1)
        subjects_layout.addWidget(self.thinking,3,2)

        subjects_group.setLayout(subjects_layout)

        self.form_layout.addWidget(subjects_group)



    # =====================================================
        # عکس پرسنلی
        # =====================================================

        self.photo = QLabel()

        self.photo.setFixedSize(
            150,
            180
        )

        self.photo.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.photo.setFrameShape(
            QFrame.Box
        )

        self.photo.setText(
            "بدون عکس"
        )

        self.form_layout.addWidget(
            self.photo,
            alignment=Qt.AlignmentFlag.AlignCenter
        )


        self.photo_btn = QPushButton(
            "انتخاب عکس"
        )

        self.photo_btn.clicked.connect(
            self.choose_photo
        )

        self.form_layout.addWidget(
            self.photo_btn
        )


        # =====================================================
        # دکمه ها
        # =====================================================

        buttons = QHBoxLayout()

        self.save_btn = QPushButton("ثبت")

        self.edit_btn = QPushButton("ویرایش")

        self.delete_btn = QPushButton("حذف")

        self.clear_btn = QPushButton("جدید")

        buttons.addWidget(self.save_btn)

        buttons.addWidget(self.edit_btn)

        buttons.addWidget(self.delete_btn)

        buttons.addWidget(self.clear_btn)

        self.form_layout.addLayout(
            buttons
        )


        # =====================================================
        # جدول دبیران
        # =====================================================

        self.search = QLineEdit()

        self.search.setPlaceholderText(
            "جستجوی دبیر..."
        )

        self.search.textChanged.connect(
            self.search_teacher
        )

        self.table_layout.addWidget(
            self.search
        )

        self.table = QTableWidget()

        self.table.setColumnCount(
            9
        )

        self.table.setHorizontalHeaderLabels(

            [

                "کد",

                "نام",

                "نام خانوادگی",

                "کد ملی",

                "کد پرسنلی",

                "پایه ها",

                "دروس",

                "موبایل",

                "وضعیت"

            ]

        )

        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.clicked.connect(
            self.select_teacher
        )

        self.table_layout.addWidget(
            self.table
        )


        # =====================================================
        # اتصال دکمه ها
        # =====================================================

        self.save_btn.clicked.connect(
            self.save_teacher
        )

        self.edit_btn.clicked.connect(
            self.update_teacher
        )

        self.delete_btn.clicked.connect(
            self.delete_teacher
        )

        self.clear_btn.clicked.connect(
            self.clear_form
        )


        self.form_layout.addStretch()



    # =====================================================
    # انتخاب عکس
    # =====================================================

    def choose_photo(self):

        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "انتخاب عکس دبیر",
            "",
            "Images (*.png *.jpg *.jpeg)"
        )

        if file_name:

            self.photo_path = file_name

            pixmap = QPixmap(file_name)

            self.photo.setPixmap(
                pixmap.scaled(
                    150,
                    180,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
            )


    # =====================================================
    # پاک کردن فرم
    # =====================================================

    def clear_form(self):

        self.selected_teacher_id = None

        self.first_name.clear()
        self.last_name.clear()
        self.national_code.clear()
        self.personnel_code.clear()
        self.gender.clear()
        self.birth_date.clear()
        self.phone.clear()
        self.email.clear()
        self.hire_date.clear()
        self.status.clear()
        self.address.clear()
        self.description.clear()

        self.photo_path = ""

        self.photo.clear()
        self.photo.setText("بدون عکس")

        for checkbox in [

            self.grade7,
            self.grade8,
            self.grade9,

            self.math,
            self.science,
            self.persian,
            self.arabic,
            self.english,
            self.quran,
            self.social,
            self.defense,
            self.work,
            self.art,
            self.sport,
            self.thinking

        ]:

            checkbox.setChecked(False)

            self.table.clearSelection()



    # =====================================================
    # بارگذاری دبیران
    # =====================================================

    def load_teachers(self):

        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM teachers ORDER BY id DESC"
        )

        rows = cursor.fetchall()

        conn.close()

        self.table.setRowCount(len(rows))

        active = 0

        for row_index, row_data in enumerate(rows):

            if row_data[11] == "فعال":
                active += 1

            self.table.setItem(
                row_index,
                0,
                QTableWidgetItem(str(row_data[0]))
            )

            self.table.setItem(
                row_index,
                1,
                QTableWidgetItem(row_data[1])
            )

            self.table.setItem(
                row_index,
                2,
                QTableWidgetItem(row_data[2])
            )

            self.table.setItem(
                row_index,
                3,
                QTableWidgetItem(row_data[3])
            )

            self.table.setItem(
                row_index,
                4,
                QTableWidgetItem(row_data[4])
            )

            self.table.setItem(
                row_index,
                5,
                QTableWidgetItem(row_data[12])
            )

            self.table.setItem(
                row_index,
                6,
                QTableWidgetItem(row_data[13])
            )

            self.table.setItem(
                row_index,
                7,
                QTableWidgetItem(row_data[7])
            )

            self.table.setItem(
                row_index,
                8,
                QTableWidgetItem(row_data[11])
            )

        self.total_lbl.setText(
            f"کل دبیران\n{len(rows)}"
        )

        self.active_lbl.setText(
            f"فعال\n{active}"
        )

        self.inactive_lbl.setText(
            f"غیرفعال\n{len(rows)-active}"
        )

        self.update_statistics()


    # =====================================================
    # ثبت دبیر
    # =====================================================

    def save_teacher(self):

        grades = []

        if self.grade7.isChecked():
            grades.append("هفتم")

        if self.grade8.isChecked():
            grades.append("هشتم")

        if self.grade9.isChecked():
            grades.append("نهم")

        grades = " - ".join(grades)


        subjects = []

        if self.math.isChecked():
            subjects.append("ریاضی")

        if self.science.isChecked():
            subjects.append("علوم")

        if self.persian.isChecked():
            subjects.append("فارسی")

        if self.arabic.isChecked():
            subjects.append("عربی")

        if self.english.isChecked():
            subjects.append("انگلیسی")

        if self.quran.isChecked():
            subjects.append("قرآن")

        if self.social.isChecked():
            subjects.append("مطالعات")

        if self.defense.isChecked():
            subjects.append("دفاعی")

        if self.work.isChecked():
            subjects.append("کار و فناوری")

        if self.art.isChecked():
            subjects.append("هنر")

        if self.sport.isChecked():
            subjects.append("ورزش")

        if self.thinking.isChecked():
            subjects.append("تفکر")

        subjects = " - ".join(subjects)


        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()

        try:

            cursor.execute("""

            INSERT INTO teachers(

                first_name,
                last_name,
                national_code,
                personnel_code,
                gender,
                birth_date,
                phone,
                email,
                address,
                hire_date,
                status,
                grades,
                subjects,
                photo,
                description

            )

            VALUES(

                ?,?,?,?,?,?,
                ?,?,?,?,?,?,
                ?,?,?

            )

            """,(

                self.first_name.text(),

                self.last_name.text(),

                self.national_code.text(),

                self.personnel_code.text(),

                self.gender.text(),

                self.birth_date.text(),

                self.phone.text(),

                self.email.text(),

                self.address.toPlainText(),

                self.hire_date.text(),

                self.status.text(),

                grades,

                subjects,

                self.photo_path,

                self.description.toPlainText()

            ))

            conn.commit()

            QMessageBox.information(

                self,

                "ثبت",

                "دبیر با موفقیت ثبت شد."

            )

            self.clear_form()

            self.load_teachers()

        except Exception as e:

            QMessageBox.warning(

                self,

                "خطا",

                str(e)

            )

        finally:

            conn.close()


    # =====================================================
    # انتخاب سطر جدول
    # =====================================================

    def select_teacher(self):

        row = self.table.currentRow()

        if row < 0:
            return

        self.selected_teacher_id = int(
            self.table.item(row, 0).text()
        )

        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM teachers WHERE id=?",
            (self.selected_teacher_id,)
        )

        teacher = cursor.fetchone()

        conn.close()

        if not teacher:
            return

        self.first_name.setText(teacher[1])
        self.last_name.setText(teacher[2])
        self.national_code.setText(teacher[3])
        self.personnel_code.setText(teacher[4])
        self.gender.setText(teacher[5])
        self.birth_date.setText(teacher[6])
        self.phone.setText(teacher[7])
        self.email.setText(teacher[8])
        self.address.setPlainText(teacher[9])
        self.hire_date.setText(teacher[10])
        self.status.setText(teacher[11])
        self.description.setPlainText(teacher[15])

        self.photo_path = teacher[14]

        if self.photo_path and os.path.exists(self.photo_path):

            pixmap = QPixmap(self.photo_path)

            self.photo.setPixmap(
                pixmap.scaled(
                    150,
                    180,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
            )

        grades = teacher[12] if teacher[12] else ""

        self.grade7.setChecked("هفتم" in grades)
        self.grade8.setChecked("هشتم" in grades)
        self.grade9.setChecked("نهم" in grades)

        subjects = teacher[13] if teacher[13] else ""

        self.math.setChecked("ریاضی" in subjects)
        self.science.setChecked("علوم" in subjects)
        self.persian.setChecked("فارسی" in subjects)
        self.arabic.setChecked("عربی" in subjects)
        self.english.setChecked("انگلیسی" in subjects)
        self.quran.setChecked("قرآن" in subjects)
        self.social.setChecked("مطالعات" in subjects)
        self.defense.setChecked("دفاعی" in subjects)
        self.work.setChecked("کار" in subjects)
        self.art.setChecked("هنر" in subjects)
        self.sport.setChecked("ورزش" in subjects)
        self.thinking.setChecked("تفکر" in subjects)


    # =====================================================
    # ویرایش دبیر
    # =====================================================

    def update_teacher(self):

        if not self.selected_teacher_id:

            QMessageBox.warning(
                self,
                "ویرایش",
                "ابتدا یک دبیر را انتخاب کنید."
            )
            return

        grades = []

        if self.grade7.isChecked():
            grades.append("هفتم")

        if self.grade8.isChecked():
            grades.append("هشتم")

        if self.grade9.isChecked():
            grades.append("نهم")

        grades = " - ".join(grades)

        subjects = []

        if self.math.isChecked():
            subjects.append("ریاضی")

        if self.science.isChecked():
            subjects.append("علوم")

        if self.persian.isChecked():
            subjects.append("فارسی")

        if self.arabic.isChecked():
            subjects.append("عربی")

        if self.english.isChecked():
            subjects.append("انگلیسی")

        if self.quran.isChecked():
            subjects.append("قرآن")

        if self.social.isChecked():
            subjects.append("مطالعات")

        if self.defense.isChecked():
            subjects.append("دفاعی")

        if self.work.isChecked():
            subjects.append("کار و فناوری")

        if self.art.isChecked():
            subjects.append("هنر")

        if self.sport.isChecked():
            subjects.append("ورزش")

        if self.thinking.isChecked():
            subjects.append("تفکر")

        subjects = " - ".join(subjects)

        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()

        cursor.execute("""

        UPDATE teachers SET

        first_name=?,
        last_name=?,
        national_code=?,
        personnel_code=?,
        gender=?,
        birth_date=?,
        phone=?,
        email=?,
        address=?,
        hire_date=?,
        status=?,
        grades=?,
        subjects=?,
        photo=?,
        description=?

        WHERE id=?

        """,(

            self.first_name.text(),
            self.last_name.text(),
            self.national_code.text(),
            self.personnel_code.text(),
            self.gender.text(),
            self.birth_date.text(),
            self.phone.text(),
            self.email.text(),
            self.address.toPlainText(),
            self.hire_date.text(),
            self.status.text(),
            grades,
            subjects,
            self.photo_path,
            self.description.toPlainText(),
            self.selected_teacher_id

        ))

        conn.commit()
        conn.close()

        QMessageBox.information(
            self,
            "ویرایش",
            "اطلاعات دبیر بروزرسانی شد."
        )

        self.load_teachers()
        self.clear_form()


    # =====================================================
    # حذف دبیر
    # =====================================================

    def delete_teacher(self):

        if not self.selected_teacher_id:

            QMessageBox.warning(
                self,
                "حذف",
                "ابتدا یک دبیر را انتخاب کنید."
            )
            return

        answer = QMessageBox.question(

            self,

            "حذف دبیر",

            "آیا از حذف این دبیر مطمئن هستید؟",

            QMessageBox.Yes | QMessageBox.No

        )

        if answer != QMessageBox.Yes:
            return

        conn = sqlite3.connect(DB_NAME)

        cursor = conn.cursor()

        cursor.execute(

            "DELETE FROM teachers WHERE id=?",

            (self.selected_teacher_id,)

        )

        conn.commit()

        conn.close()

        QMessageBox.information(

            self,

            "حذف",

            "دبیر با موفقیت حذف شد."

        )

        self.clear_form()

        self.load_teachers()


    # =====================================================
    # جستجو
    # =====================================================

    def search_teacher(self, text):

        text = text.lower()

        for row in range(self.table.rowCount()):

            visible = False

            for col in range(self.table.columnCount()):

                item = self.table.item(row, col)

                if item and text in item.text().lower():

                    visible = True

                    break

            self.table.setRowHidden(
                row,
                not visible
            )


    # =====================================================
    # بروزرسانی آمار
    # =====================================================

    def update_statistics(self):

        total = self.table.rowCount()

        active = 0

        for row in range(total):

            item = self.table.item(row, 8)

            if item and item.text() == "فعال":

                active += 1

        inactive = total - active

        self.total_lbl.setText(
            f"کل دبیران\n{total}"
        )

        self.active_lbl.setText(
            f"فعال\n{active}"
        )

        self.inactive_lbl.setText(
            f"غیرفعال\n{inactive}"
        )