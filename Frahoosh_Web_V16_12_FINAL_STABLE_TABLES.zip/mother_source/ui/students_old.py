from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QFileDialog,
    QMessageBox,
    QFrame,
    QHeaderView
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

from database.db import get_connection

import os
import shutil

import qtawesome as qta



class Students(QWidget):


    def __init__(self):

        super().__init__()


        self.setWindowTitle(
            "مدیریت دانش‌آموزان فراهوش"
        )


        self.resize(
            1400,
            850
        )


        self.old_code = None


        self.photo_path = ""


        self.inputs = []


        self.create_ui()



    def create_ui(self):


        main_layout = QVBoxLayout(
            self
        )


        # ==========================
        # عنوان
        # ==========================


        title = QLabel(
            "👨‍🎓 مدیریت هوشمند دانش‌آموزان فراهوش"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setStyleSheet("""
            QLabel{

                font-size:32px;
                font-weight:bold;
                color:#1565C0;
                padding:15px;

            }
        """)


        main_layout.addWidget(
            title
        )



        # ==========================
        # کارت اطلاعات دانش آموز
        # ==========================


        form_frame = QFrame()


        form_frame.setStyleSheet("""
            QFrame{

                background:#f5f9ff;
                border-radius:15px;
                border:1px solid #bbdefb;

            }
        """)



        form_layout = QGridLayout(
            form_frame
        )



        fields = [

            "نام",

            "نام خانوادگی",

            "کد ملی",

            "شماره دانش‌آموزی",

            "تاریخ تولد",

            "پایه",

            "کلاس",

            "نام پدر",

            "نام مادر",

            "تلفن ولی",

            "ایمیل",

            "شماره صندلی",

            "آدرس",

            "توضیحات"

        ]



        row = 0

        col = 0



        for field in fields:


            box = QLineEdit()



            box.setPlaceholderText(
                field
            )


            box.setMinimumHeight(
                38
            )


            box.setStyleSheet("""
                QLineEdit{

                    background:white;
                    border:1px solid #90caf9;
                    border-radius:8px;
                    padding:6px;
                    font-size:14px;

                }


                QLineEdit:focus{

                    border:2px solid #1976D2;

                }

            """)



            self.inputs.append(
                box
            )



            form_layout.addWidget(
                box,
                row,
                col
            )



            col += 1



            if col == 2:

                col = 0

                row += 1



        main_layout.addWidget(
            form_frame
        )



        # ==========================
        # عکس دانش آموز
        # ==========================


        photo_layout = QHBoxLayout()



        self.photo_label = QLabel(
            "بدون عکس"
        )


        self.photo_label.setFixedSize(
            130,
            130
        )


        self.photo_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.photo_label.setStyleSheet("""
            QLabel{

                border:2px solid #2196F3;
                border-radius:15px;
                background:#eeeeee;
                font-size:16px;

            }

        """)



        photo_btn = QPushButton(
            "انتخاب عکس"
        )


        photo_btn.setIcon(
            qta.icon(
                "fa5s.image"
            )
        )


        photo_btn.setMinimumHeight(
            40
        )


        photo_btn.clicked.connect(
            self.select_photo
        )



        photo_layout.addWidget(
            self.photo_label
        )


        photo_layout.addWidget(
            photo_btn
        )


        photo_layout.addStretch()



        main_layout.addLayout(
            photo_layout
        )



        # ==========================
        # دکمه های عملیاتی
        # ==========================


        buttons_layout = QHBoxLayout()



        add_btn = QPushButton(
            "ثبت دانش‌آموز"
        )


        add_btn.setIcon(
            qta.icon(
                "fa5s.user-plus"
            )
        )



        edit_btn = QPushButton(
            "ویرایش"
        )


        edit_btn.setIcon(
            qta.icon(
                "fa5s.user-edit"
            )
        )



        update_btn = QPushButton(
            "ثبت تغییرات"
        )


        update_btn.setIcon(
            qta.icon(
                "fa5s.save"
            )
        )



        delete_btn = QPushButton(
            "حذف"
        )


        delete_btn.setIcon(
            qta.icon(
                "fa5s.trash"
            )
        )



        excel_btn = QPushButton(
            "ورود از اکسل"
        )


        excel_btn.setIcon(
            qta.icon(
                "fa5s.file-excel"
            )
        )



        buttons = [

            add_btn,

            edit_btn,

            update_btn,

            delete_btn,

            excel_btn

        ]



        for btn in buttons:


            btn.setMinimumHeight(
                45
            )


            btn.setMinimumWidth(
                150
            )


            btn.setStyleSheet("""
                QPushButton{

                    background:#1976D2;
                    color:white;
                    border-radius:10px;
                    font-size:15px;

                }


                QPushButton:hover{

                    background:#0D47A1;

                }

            """)



            buttons_layout.addWidget(
                btn
            )



        main_layout.addLayout(
            buttons_layout
        )



        add_btn.clicked.connect(
            self.add_student
        )


        edit_btn.clicked.connect(
            self.edit_student
        )


        update_btn.clicked.connect(
            self.update_student
        )


        delete_btn.clicked.connect(
            self.delete_student
        )



        # ==========================
        # بخش جستجو
        # ==========================


        search_layout = QHBoxLayout()



        self.search_box = QLineEdit()


        self.search_box.setPlaceholderText(
            "🔍 جستجو نام، نام خانوادگی یا کد ملی..."
        )


        self.search_box.setMinimumHeight(
            40
        )



        search_btn = QPushButton(
            "جستجو"
        )


        search_btn.setIcon(
            qta.icon(
                "fa5s.search"
            )
        )


        search_btn.clicked.connect(
            self.search_student
        )



        search_layout.addWidget(
            self.search_box
        )


        search_layout.addWidget(
            search_btn
        )



        main_layout.addLayout(
            search_layout
        )



        # ==========================
        # جدول دانش آموزان
        # ==========================


        self.table = QTableWidget()



        self.table.setColumnCount(
            15
        )



        self.table.setHorizontalHeaderLabels(

            [

                "نام",

                "نام خانوادگی",

                "کد ملی",

                "شماره دانش‌آموزی",

                "تولد",

                "پایه",

                "کلاس",

                "نام پدر",

                "نام مادر",

                "تلفن ولی",

                "ایمیل",

                "صندلی",

                "آدرس",

                "توضیحات",

                "عکس"

            ]

        )



        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )



        self.table.setAlternatingRowColors(
            True
        )



        self.table.setStyleSheet("""
             QTableWidget{

                border:1px solid #90caf9;
                border-radius:10px;
                font-size:14px;

            }


            QHeaderView::section{

                background:#1565C0;
                color:white;
                padding:8px;
                font-weight:bold;

            }


            QTableWidget::item:selected{

                background:#bbdefb;
                color:black;

            }

        """)



        self.table.cellClicked.connect(
            self.select_row
        )



        main_layout.addWidget(
            self.table
        )



        self.load_students()



     # ==========================
        # دکمه های عملیاتی
        # ==========================


        buttons_layout = QHBoxLayout()



        add_btn = QPushButton(
            "ثبت دانش‌آموز"
        )


        add_btn.setIcon(
            qta.icon(
                "fa5s.user-plus"
            )
        )



        edit_btn = QPushButton(
            "ویرایش"
        )


        edit_btn.setIcon(
            qta.icon(
                "fa5s.user-edit"
            )
        )



        update_btn = QPushButton(
            "ثبت تغییرات"
        )


        update_btn.setIcon(
            qta.icon(
                "fa5s.save"
            )
        )



        delete_btn = QPushButton(
            "حذف"
        )


        delete_btn.setIcon(
            qta.icon(
                "fa5s.trash"
            )
        )



        excel_btn = QPushButton(
            "ورود از اکسل"
        )


        excel_btn.setIcon(
            qta.icon(
                "fa5s.file-excel"
            )
        )



        buttons = [

            add_btn,

            edit_btn,

            update_btn,

            delete_btn,

            excel_btn

        ]



        for btn in buttons:


            btn.setMinimumHeight(
                45
            )


            btn.setMinimumWidth(
                150
            )


            btn.setStyleSheet("""
                QPushButton{

                    background:#1976D2;
                    color:white;
                    border-radius:10px;
                    font-size:15px;

                }


                QPushButton:hover{

                    background:#0D47A1;

                }

            """)



            buttons_layout.addWidget(
                btn
            )



        main_layout.addLayout(
            buttons_layout
        )



        add_btn.clicked.connect(
            self.add_student
        )


        edit_btn.clicked.connect(
            self.edit_student
        )


        update_btn.clicked.connect(
            self.update_student
        )


        delete_btn.clicked.connect(
            self.delete_student
        )



        # ==========================
        # بخش جستجو
        # ==========================


        search_layout = QHBoxLayout()



        self.search_box = QLineEdit()


        self.search_box.setPlaceholderText(
            "🔍 جستجو نام، نام خانوادگی یا کد ملی..."
        )


        self.search_box.setMinimumHeight(
            40
        )



        search_btn = QPushButton(
            "جستجو"
        )


        search_btn.setIcon(
            qta.icon(
                "fa5s.search"
            )
        )


        search_btn.clicked.connect(
            self.search_student
        )



        search_layout.addWidget(
            self.search_box
        )


        search_layout.addWidget(
            search_btn
        )



        main_layout.addLayout(
            search_layout
        )



        # ==========================
        # جدول دانش آموزان
        # ==========================


        self.table = QTableWidget()



        self.table.setColumnCount(
            15
        )



        self.table.setHorizontalHeaderLabels(

            [

                "نام",

                "نام خانوادگی",

                "کد ملی",

                "شماره دانش‌آموزی",

                "تولد",

                "پایه",

                "کلاس",

                "نام پدر",

                "نام مادر",

                "تلفن ولی",

                "ایمیل",

                "صندلی",

                "آدرس",

                "توضیحات",

                "عکس"

            ]

        )



        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )



        self.table.setAlternatingRowColors(
            True
        )



        self.table.setStyleSheet("""
            QTableWidget{

                border:1px solid #90caf9;
                border-radius:10px;
                font-size:14px;

            }


            QHeaderView::section{

                background:#1565C0;
                color:white;
                padding:8px;
                font-weight:bold;

            }


            QTableWidget::item:selected{

                background:#bbdefb;
                color:black;

            }

        """)



        self.table.cellClicked.connect(
            self.select_row
        )



        main_layout.addWidget(
            self.table
        )



        self.load_students()



        # ==========================
    # انتخاب سطر جدول
    # ==========================


    def select_row(self, row, column):


        try:


            data = []


            for col in range(
                self.table.columnCount()
            ):


                item = self.table.item(
                    row,
                    col
                )


                if item:

                    data.append(
                        item.text()
                    )

                else:

                    data.append(
                        ""
                    )



            for index, box in enumerate(
                self.inputs
            ):


                if index < len(data):

                    box.setText(
                        data[index]
                    )



            self.old_code = data[2]



            if len(data) > 14 and data[14]:


                self.photo_path = data[14]


                pixmap = QPixmap(
                    self.photo_path
                )


                self.photo_label.setPixmap(

                    pixmap.scaled(

                        120,

                        120,

                        Qt.KeepAspectRatio

                    )

                )



        except Exception as e:


            print(
                "Select Row Error:",
                e
            )



    # ==========================
    # آماده سازی ویرایش
    # ==========================


    def edit_student(self):


        if self.old_code is None:


            QMessageBox.warning(

                self,

                "هشدار",

                "ابتدا یک دانش‌آموز را از جدول انتخاب کنید."

            )

            return



        QMessageBox.information(

            self,

            "ویرایش",

            "اطلاعات را اصلاح کنید و سپس دکمه ثبت تغییرات را بزنید."

        )



    # ==========================
    # ثبت تغییرات
    # ==========================


    def update_student(self):


        if self.old_code is None:


            QMessageBox.warning(

                self,

                "هشدار",

                "دانش‌آموزی انتخاب نشده است."

            )

            return



        values = []


        for box in self.inputs:


            values.append(
                box.text()
            )



        try:


            conn = get_connection()


            cursor = conn.cursor()



            cursor.execute(

                """

                UPDATE students SET

                    first_name=?,

                    last_name=?,

                    national_code=?,

                    student_code=?,

                    birth_date=?,

                    grade=?,

                    class_name=?,

                    father_name=?,

                    mother_name=?,

                    parent_phone=?,

                    email=?,

                    seat_number=?,

                    address=?,

                    description=?,

                    photo=?

                WHERE national_code=?

                """,

                values +

                [

                    self.photo_path,

                    self.old_code

                ]

            )



            conn.commit()


            conn.close()



            QMessageBox.information(

                self,

                "موفق",

                "تغییرات ذخیره شد."

            )



            self.load_students()


            self.clear_form()



        except Exception as e:


            QMessageBox.warning(

                self,

                "خطا",

                str(e)

            )



    # ==========================
    # حذف دانش آموز
    # ==========================


    def delete_student(self):


        if self.old_code is None:


            QMessageBox.warning(

                self,

                "هشدار",

                "ابتدا یک دانش‌آموز را انتخاب کنید."

            )

            return



        answer = QMessageBox.question(

            self,

            "تایید حذف",

            "آیا از حذف این دانش‌آموز مطمئن هستید؟"

        )



        if answer == QMessageBox.Yes:


            try:


                conn = get_connection()


                cursor = conn.cursor()



                cursor.execute(

                    """

                    DELETE FROM students

                    WHERE national_code=?

                    """,

                    (

                        self.old_code,

                    )

                )



                conn.commit()


                conn.close()



                QMessageBox.information(

                    self,

                    "انجام شد",

                    "دانش‌آموز حذف شد."

                )



                self.load_students()


                self.clear_form()



            except Exception as e:


                QMessageBox.warning(

                    self,

                    "خطا",

                    str(e)

                )



     # ==========================
    # جستجوی دانش آموز
    # ==========================


    def search_student(self):


        text = self.search_box.text()


        if not text:


            self.load_students()

            return



        try:


            conn = get_connection()


            cursor = conn.cursor()



            cursor.execute(

                """

                SELECT * FROM students

                WHERE first_name LIKE ?

                OR last_name LIKE ?

                OR national_code LIKE ?

                """,

                (

                    "%" + text + "%",

                    "%" + text + "%",

                    "%" + text + "%"

                )

            )



            rows = cursor.fetchall()



            conn.close()



            self.table.setRowCount(
                0
            )



            for row_number, row_data in enumerate(rows):


                self.table.insertRow(
                    row_number
                )



                for column_number, data in enumerate(row_data):


                    self.table.setItem(

                        row_number,

                        column_number,

                        QTableWidgetItem(
                            str(data)
                        )

                    )



        except Exception as e:


            QMessageBox.warning(

                self,

                "خطا",

                str(e)

            )



    # ==========================
    # ورود از اکسل (آماده سازی)
    # ==========================


    def import_excel(self):


        QMessageBox.information(

            self,

            "ورود اکسل",

            "بخش ورود اطلاعات از اکسل در نسخه بعدی فعال می‌شود."

        )



    # ==========================
    # پایان کلاس
    # ==========================  



        