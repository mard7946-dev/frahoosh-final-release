import sqlite3, os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QStackedWidget,
    QLineEdit, QTableWidget, QTableWidgetItem, QDialog, QFormLayout,
    QDialogButtonBox, QTextEdit, QComboBox, QMessageBox
)
from PySide6.QtCore import Qt
from utils.export_tools import widget_to_pdf, print_widget
from PySide6.QtGui import QFont
from pages.common_reports import ReportPage

DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

class GenericAdvisorPage(QWidget):
    def __init__(self, title, table_name, parent=None):
        super().__init__(parent); self.title=title; self.table_name=table_name
        self.setLayoutDirection(Qt.RightToLeft); self.ensure_schema(); self.init_ui(); self.load()
    def ensure_schema(self):
        with db() as c:
            c.execute(f'''CREATE TABLE IF NOT EXISTS advisor_workspace (
                id INTEGER PRIMARY KEY AUTOINCREMENT, section TEXT NOT NULL,
                student_id INTEGER, title TEXT NOT NULL, description TEXT DEFAULT '',
                status TEXT DEFAULT 'در حال پیگیری', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(section, id)
            )''')
    def init_ui(self):
        l=QVBoxLayout(self); h=QLabel(f'فراهوش | {self.title}'); h.setAlignment(Qt.AlignmentFlag.AlignCenter); h.setFont(QFont('B Zar',20,QFont.Bold)); l.addWidget(h)
        export_bar=QHBoxLayout(); pdf=QPushButton("ذخیره PDF"); pr=QPushButton("پرینت"); pdf.clicked.connect(lambda: widget_to_pdf(self.stack.currentWidget(), self, "گزارش")); pr.clicked.connect(lambda: print_widget(self.stack.currentWidget(), self)); export_bar.addWidget(pdf); export_bar.addWidget(pr); export_bar.addStretch(); l.addLayout(export_bar)
        bar=QGridLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('جستجو بر اساس نام/موضوع/توضیحات')
        add=QPushButton('ثبت'); edit=QPushButton('ویرایش'); delete=QPushButton('حذف'); refresh=QPushButton('تازه‌سازی');
        for i,b in enumerate([self.search,add,edit,delete,refresh]): bar.addWidget(b,0,i)
        l.addLayout(bar)
        self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','عنوان','توضیحات','وضعیت','تاریخ']); l.addWidget(self.table)
        add.clicked.connect(self.add); edit.clicked.connect(self.edit); delete.clicked.connect(self.delete); refresh.clicked.connect(self.load); self.search.textChanged.connect(self.load)
    def students(self):
        with db() as c:return c.execute('SELECT id,first_name,last_name,student_code FROM students ORDER BY last_name,first_name').fetchall()
    def form(self, row=None):
        d=QDialog(self); d.setWindowTitle(self.title); f=QFormLayout(d); student=QComboBox(); student.addItem('انتخاب دانش‌آموز',None)
        for r in self.students(): student.addItem(f"{r['first_name']} {r['last_name']} | {r['student_code'] or '-'}",r['id'])
        title=QLineEdit(str((row or {}).get('title',''))); desc=QTextEdit(str((row or {}).get('description',''))); status=QComboBox(); status.addItems(['در حال پیگیری','تکمیل شده','نیازمند اقدام'])
        if row:
            ix=student.findData(row.get('student_id')); student.setCurrentIndex(ix if ix>=0 else 0); status.setCurrentText(row.get('status') or 'در حال پیگیری')
        f.addRow('دانش‌آموز',student); f.addRow('عنوان',title); f.addRow('توضیحات',desc); f.addRow('وضعیت',status)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); f.addWidget(bb); bb.accepted.connect(d.accept); bb.rejected.connect(d.reject)
        return d,student,title,desc,status
    def load(self):
        s='%'+self.search.text().strip()+'%';
        with db() as c:
            rows=c.execute('''SELECT a.id,a.student_id,COALESCE(st.first_name||' '||st.last_name,'') name,a.title,a.description,a.status,a.created_at
                              FROM advisor_workspace a LEFT JOIN students st ON st.id=a.student_id
                              WHERE a.section=? AND (name LIKE ? OR a.title LIKE ? OR a.description LIKE ?) ORDER BY a.id DESC''',(self.table_name,s,s,s)).fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r['id'],r['name'],r['title'],r['description'],r['status'],r['created_at']]
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
    def add(self):
        d,student,title,desc,status=self.form()
        if d.exec()!=QDialog.Accepted:return
        if not student.currentData() or not title.text().strip(): QMessageBox.warning(self,'ثبت','دانش‌آموز و عنوان را وارد کنید.'); return
        with db() as c:c.execute('INSERT INTO advisor_workspace(section,student_id,title,description,status) VALUES(?,?,?,?,?)',(self.table_name,student.currentData(),title.text().strip(),desc.toPlainText().strip(),status.currentText())); c.commit()
        self.load()
    def edit(self):
        r=self.table.currentRow()
        if r<0:return
        rid=int(self.table.item(r,0).text());
        with db() as c: old=c.execute('SELECT * FROM advisor_workspace WHERE id=?',(rid,)).fetchone()
        if not old:return
        d,student,title,desc,status=self.form(dict(old))
        if d.exec()!=QDialog.Accepted:return
        with db() as c:c.execute('UPDATE advisor_workspace SET student_id=?,title=?,description=?,status=? WHERE id=?',(student.currentData(),title.text().strip(),desc.toPlainText().strip(),status.currentText(),rid)); c.commit()
        self.load()
    def delete(self):
        r=self.table.currentRow()
        if r<0:return
        rid=int(self.table.item(r,0).text())
        with db() as c:c.execute('DELETE FROM advisor_workspace WHERE id=?',(rid,)); c.commit()
        self.load()

class Panel(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.pages={}; self.init_ui()
    def init_ui(self):
        l=QVBoxLayout(self); l.setContentsMargins(14,14,14,14); l.setSpacing(8)
        title=QLabel('فراهوش | پنل مشاوره'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setFont(QFont('B Zar',24,QFont.Bold)); l.addWidget(title)
        self.menu=QGridLayout(); self.menu.setSpacing(8)
        items=[
            ('📢 تابلو اعلانات مشاور','board'),('📁 پرونده مشاوره','file'),('🔎 پیگیری وضعیت دانش‌آموز','follow'),
            ('↗️ ارجاع به مدیریت','referral'),('👥 جلسه اولیا','parent_meeting'),('🏫 کلاس‌های آموزشی','classes'),
            ('👨‍👩‍👧 آموزش خانواده','family'),('🎯 هدایت تحصیلی','guidance'),('📊 گزارشات','reports'),('🛡️ موارد انضباطی','discipline'),
            ('🔙 بازگشت به صفحه اصلی','back')]
        for i,(text,key) in enumerate(items):
            b=QPushButton(text); b.setMinimumSize(125,44); b.setMaximumHeight(50); b.setFont(QFont('B Zar',14,QFont.Bold)); b.clicked.connect(lambda checked=False,k=key:self.open_page(k)); self.menu.addWidget(b,i//6,i%6)
        l.addLayout(self.menu)
        self.stack=QStackedWidget(); l.addWidget(self.stack,1)
        self.load_pages()
        self.setStyleSheet('QWidget{background:#F5F3FF;} QPushButton{background:#7C3AED;color:white;border:0;border-radius:9px;padding:5px 8px;font-size:14px;} QPushButton:hover{background:#6D28D9;} QLineEdit,QComboBox,QTextEdit{background:white;color:#111827;border:1px solid #C4B5FD;border-radius:7px;padding:5px;}')
    def load_pages(self):
        self.pages['file']=GenericAdvisorPage('پرونده مشاوره','counseling_file',self)
        self.pages['board']=GenericAdvisorPage('تابلو اعلانات مشاور','counselor_board',self)
        self.pages['follow']=GenericAdvisorPage('پیگیری وضعیت دانش‌آموز','student_follow',self)
        self.pages['referral']=GenericAdvisorPage('ارجاع به مدیریت','refer_management',self)
        self.pages['parent_meeting']=GenericAdvisorPage('جلسه اولیا','parent_meeting',self)
        self.pages['classes']=GenericAdvisorPage('کلاس‌های آموزشی','counseling_classes',self)
        self.pages['family']=GenericAdvisorPage('آموزش خانواده','family_training',self)
        self.pages['guidance']=GenericAdvisorPage('هدایت تحصیلی','career_guidance',self)
        for k in ('board','file','follow','referral','parent_meeting','classes','family','guidance'):
            self.stack.addWidget(self.pages[k])
        self.pages['reports']=ReportPage('گزارش‌های مشاوره',self); self.stack.addWidget(self.pages['reports'])
        from pages.discipline import DisciplinePage
        self.pages['discipline']=DisciplinePage(self, actor_role='advisor'); self.stack.addWidget(self.pages['discipline'])
        self.pages['back']=QWidget(); self.stack.addWidget(self.pages['back'])
    def open_page(self,key):
        if key=='back':
            p=self.parent()
            if p is not None and hasattr(p,'show_home'): p.show_home()
            elif p is not None and hasattr(p,'show_main_page'): p.show_main_page()
            return
        page=self.pages.get(key)
        if page is not None:self.stack.setCurrentWidget(page)

AdvisorReportPage=ReportPage
