from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QTextDocument

from PySide6.QtPrintSupport import (
    QPrinter,
    QPrintDialog
)

from database.db import get_connection



class ReportsPage(QWidget):


    def __init__(self, parent=None):

        super().__init__(parent)

        self.report_text = ""

        self.init_ui()



    def init_ui(self):

        layout = QVBoxLayout(self)


        header = QLabel(
            """
وزارت آموزش و پرورش

مدیریت آموزش و پرورش قدس

دبیرستان سردار شهید حاجی زاده ۲
"""
        )


        header.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        header.setFont(
            QFont(
                "B Zar",
                16,
                QFont.Bold
            )
        )


        layout.addWidget(
            header
        )



        title = QLabel(
            "گزارش پایان سال مالی"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )


        layout.addWidget(
            title
        )



        self.table = QTableWidget()


        self.table.setColumnCount(
            8
        )


        self.table.setHorizontalHeaderLabels(
            [
                "شماره سند",
                "حساب",
                "طرف حساب",
                "شرح",
                "بدهکار",
                "بستانکار",
                "مانده",
                "تاریخ"
            ]
        )


        self.table.setLayoutDirection(
            Qt.RightToLeft
        )


        layout.addWidget(
            self.table
        )



        self.total_label = QLabel()


        self.total_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        self.total_label.setFont(
            QFont(
                "B Zar",
                16,
                QFont.Bold
            )
        )


        layout.addWidget(
            self.total_label
        )



        print_btn = QPushButton(
            "چاپ گزارش"
        )


        print_btn.clicked.connect(
            self.print_report
        )


        layout.addWidget(
            print_btn
        )



        self.load_report()



    # ==================================
    # گزارش
    # ==================================

    def load_report(self):

        conn = get_connection()

        cursor = conn.cursor()



        cursor.execute(
            """
            SELECT

            document_no,
            account_title,
            party,
            title,
            amount,
            transaction_type,
            transaction_date

            FROM finance_transactions

            ORDER BY id ASC
            """
        )


        rows = cursor.fetchall()


        conn.close()



        self.table.setRowCount(
            len(rows)
        )


        balance = 0

        total_debit = 0

        total_credit = 0



        report_lines = []



        for r, row in enumerate(rows):


            debit = 0

            credit = 0


            if row[5] == "expense":

                debit = row[4]

                total_debit += debit

                balance -= debit


            else:

                credit = row[4]

                total_credit += credit

                balance += credit



            values = [

                row[0],

                row[1],

                row[2],

                row[3],

                f"{debit:,} ریال" if debit else "",

                f"{credit:,} ریال" if credit else "",

                f"{balance:,} ریال",

                row[6]

            ]



            for c, value in enumerate(values):

                self.table.setItem(
                    r,
                    c,
                    QTableWidgetItem(
                        str(value)
                    )
                )



            report_lines.append(
    " | ".join(
        [
            str(item) if item is not None else ""
            for item in values
        ]
    )
)


        self.total_label.setText(
            f"""
جمع بدهکار: {total_debit:,} ریال

جمع بستانکار: {total_credit:,} ریال

مانده نهایی: {balance:,} ریال
"""
        )



        self.report_text = f"""
وزارت آموزش و پرورش

مدیریت آموزش و پرورش قدس

دبیرستان سردار شهید حاجی زاده ۲


گزارش پایان سال مالی


---------------------------


{"\n".join(report_lines)}


---------------------------


جمع بدهکار:
{total_debit:,} ریال


جمع بستانکار:
{total_credit:,} ریال


مانده نهایی:
{balance:,} ریال

"""



    # ==================================
    # چاپ
    # ==================================

    def print_report(self):

        printer = QPrinter(
            QPrinter.HighResolution
        )


        dialog = QPrintDialog(
            printer,
            self
        )


        if dialog.exec():

            document = QTextDocument()


            document.setPlainText(
                self.report_text
            )


            document.print(
                printer
            )