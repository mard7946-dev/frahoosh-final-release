from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QDialog,
    QFormLayout,
    QDialogButtonBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from database.db import get_connection

from finance.finance_db import add_transaction


# ==================================================
# فرم ویرایش کمک مردمی
# ==================================================

class EditDonationDialog(QDialog):

    def __init__(self, data, parent=None):

        super().__init__(parent)

        self.setWindowTitle(
            "ویرایش کمک مردمی"
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.setMinimumWidth(450)

        layout = QFormLayout(self)

        self.donor_input = QLineEdit(
            str(data[0] or "")
        )

        self.amount_input = QLineEdit(
            str(data[1] or 0)
        )

        self.date_input = QLineEdit(
            str(data[2] or "")
        )

        self.description_input = QLineEdit(
            str(data[3] or "")
        )

        layout.addRow(
            "نام خیر:",
            self.donor_input
        )

        layout.addRow(
            "مبلغ:",
            self.amount_input
        )

        layout.addRow(
            "تاریخ:",
            self.date_input
        )

        layout.addRow(
            "توضیحات:",
            self.description_input
        )

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save |
            QDialogButtonBox.Cancel
        )

        buttons.accepted.connect(
            self.validate_and_accept
        )

        buttons.rejected.connect(
            self.reject
        )

        layout.addWidget(
            buttons
        )

    # ==============================================
    # اعتبارسنجی
    # ==============================================

    def validate_and_accept(self):

        donor = (
            self.donor_input
            .text()
            .strip()
        )

        if not donor:

            QMessageBox.warning(
                self,
                "خطا",
                "نام خیر را وارد کنید."
            )

            return

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        try:

            amount = int(
                amount_text
            )

            if amount <= 0:

                raise ValueError

        except ValueError:

            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ واردشده صحیح نیست."
            )

            return

        self.accept()

    # ==============================================
    # دریافت اطلاعات
    # ==============================================

    def get_values(self):

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        amount = int(
            amount_text or 0
        )

        return (
            self.donor_input.text().strip(),
            amount,
            self.date_input.text().strip(),
            self.description_input.text().strip()
        )


# ==================================================
# صفحه کمک‌های مردمی
# ==================================================

class DonationsPage(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.init_database()

        self.init_ui()

    # ==============================================
    # آماده‌سازی دیتابیس
    # ==============================================

    def init_database(self):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                "PRAGMA table_info(finance_donations)"
            )

            columns = [
                row[1]
                for row in cursor.fetchall()
            ]

            if "document_no" not in columns:

                cursor.execute(
                    """
                    ALTER TABLE finance_donations
                    ADD COLUMN document_no TEXT
                    """
                )

            conn.commit()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای دیتابیس",
                f"خطا در آماده‌سازی بخش کمک‌های مردمی:\n\n{e}"
            )

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

    # ==============================================
    # رابط کاربری
    # ==============================================

    def init_ui(self):

        layout = QVBoxLayout(self)

        layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        layout.setSpacing(10)

        # ------------------------------------------
        # عنوان
        # ------------------------------------------

        title = QLabel(
            "کمک‌های مردمی"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )

        layout.addWidget(
            title
        )

        # ------------------------------------------
        # فرم ثبت
        # ------------------------------------------

        form = QHBoxLayout()

        self.donor_input = QLineEdit()

        self.donor_input.setPlaceholderText(
            "نام خیر"
        )

        self.amount_input = QLineEdit()

        self.amount_input.setPlaceholderText(
            "مبلغ به ریال"
        )

        self.date_input = QLineEdit()

        self.date_input.setPlaceholderText(
            "تاریخ شمسی"
        )

        self.description_input = QLineEdit()

        self.description_input.setPlaceholderText(
            "توضیحات"
        )

        save_btn = QPushButton(
            "ثبت کمک"
        )

        save_btn.clicked.connect(
            self.save_donation
        )

        form.addWidget(
            self.donor_input
        )

        form.addWidget(
            self.amount_input
        )

        form.addWidget(
            self.date_input
        )

        form.addWidget(
            self.description_input
        )

        form.addWidget(
            save_btn
        )

        layout.addLayout(
            form
        )

        # ------------------------------------------
        # جدول
        # ------------------------------------------

        self.table = QTableWidget()

        self.table.setColumnCount(
            6
        )

        self.table.setHorizontalHeaderLabels(
            [
                "شماره سند",
                "نام خیر",
                "مبلغ",
                "تاریخ",
                "توضیحات",
                "عملیات"
            ]
        )

        self.table.setLayoutDirection(
            Qt.RightToLeft
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setAlternatingRowColors(
            True
        )

        self.table.verticalHeader().setDefaultSectionSize(
            45
        )

        self.table.horizontalHeader().setStretchLastSection(
            True
        )

        layout.addWidget(
            self.table
        )

        self.load_data()

    # ==============================================
    # ثبت کمک
    # ==============================================

    def save_donation(self):

        donor = (
            self.donor_input
            .text()
            .strip()
        )

        date = (
            self.date_input
            .text()
            .strip()
        )

        description = (
            self.description_input
            .text()
            .strip()
        )

        if not donor:

            QMessageBox.warning(
                self,
                "خطا",
                "نام خیر را وارد کنید."
            )

            return

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        try:

            amount = int(
                amount_text
            )

            if amount <= 0:

                raise ValueError

        except ValueError:

            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ صحیح وارد کنید."
            )

            return

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            # --------------------------------------
            # ثبت کمک
            # --------------------------------------

            cursor.execute(
                """
                INSERT INTO finance_donations
                (
                    donor_name,
                    amount,
                    description,
                    donation_date
                )

                VALUES (?, ?, ?, ?)
                """,
                (
                    donor,
                    amount,
                    description,
                    date
                )
            )

            donation_id = cursor.lastrowid

            document_no = (
                f"DON-{donation_id:06d}"
            )

            cursor.execute(
                """
                UPDATE finance_donations

                SET document_no=?

                WHERE id=?
                """,
                (
                    document_no,
                    donation_id
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای ثبت",
                f"ثبت کمک انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # ثبت خودکار در حسابداری
        # ------------------------------------------

        try:

            add_transaction(

                transaction_type="income",

                title="کمک مردمی",

                amount=amount,

                category="کمک‌های مردمی",

                transaction_date=date,

                document_no=document_no,

                account_title="کمک‌های مردمی",

                party=donor,

                description=description

            )

        except Exception as e:

            cleanup_conn = None

            try:

                cleanup_conn = get_connection()

                cleanup_cursor = (
                    cleanup_conn.cursor()
                )

                cleanup_cursor.execute(
                    """
                    DELETE FROM finance_donations

                    WHERE id=?
                    """,
                    (
                        donation_id,
                    )
                )

                cleanup_conn.commit()

            except Exception:
                pass

            finally:

                if cleanup_conn is not None:

                    try:
                        cleanup_conn.close()
                    except Exception:
                        pass

            QMessageBox.critical(
                self,
                "خطای حسابداری",
                "کمک ثبت نشد زیرا ثبت سند حسابداری "
                "با خطا مواجه شد.\n\n"
                f"{e}"
            )

            return# ------------------------------------------
        # پاک کردن فرم
        # ------------------------------------------

        self.donor_input.clear()

        self.amount_input.clear()

        self.date_input.clear()

        self.description_input.clear()

        QMessageBox.information(
            self,
            "ثبت کمک",
            f"کمک مردمی با موفقیت ثبت شد.\n\n"
            f"شماره سند: {document_no}"
        )

        self.load_data()

    # ==============================================
    # نمایش اطلاعات
    # ==============================================

    def load_data(self):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    id,
                    document_no,
                    donor_name,
                    amount,
                    donation_date,
                    description

                FROM finance_donations

                ORDER BY id DESC
                """
            )

            rows = cursor.fetchall()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای کمک‌های مردمی",
                f"خطا در خواندن کمک‌ها:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        self.table.setRowCount(
            0
        )

        for row in rows:

            table_row = (
                self.table.rowCount()
            )

            self.table.insertRow(
                table_row
            )

            donation_id = row[0]

            document_no = (
                row[1]
                or f"DON-{donation_id:06d}"
            )

            donor = (
                row[2]
                or ""
            )

            amount = (
                row[3]
                or 0
            )

            donation_date = (
                row[4]
                or ""
            )

            description = (
                row[5]
                or ""
            )

            values = [

                document_no,

                donor,

                f"{amount:,} ریال",

                donation_date,

                description

            ]

            for column, value in enumerate(
                values
            ):

                item = QTableWidgetItem(
                    str(value)
                )

                item.setTextAlignment(
                    Qt.AlignRight |
                    Qt.AlignVCenter
                )

                self.table.setItem(
                    table_row,
                    column,
                    item
                )

            # --------------------------------------
            # ویرایش
            # --------------------------------------

            edit_btn = QPushButton(
                "✏️ ویرایش"
            )

            edit_btn.clicked.connect(
                lambda checked=False,
                item_id=donation_id:
                self.edit_donation(
                    item_id
                )
            )

            # --------------------------------------
            # حذف
            # --------------------------------------

            delete_btn = QPushButton(
                "🗑️ حذف"
            )

            delete_btn.clicked.connect(
                lambda checked=False,
                item_id=donation_id:
                self.delete_donation(
                    item_id
                )
            )

            # --------------------------------------
            # عملیات
            # --------------------------------------

            action_layout = QHBoxLayout()

            action_layout.setContentsMargins(
                4,
                2,
                4,
                2
            )

            action_layout.setSpacing(
                5
            )

            action_layout.addWidget(
                edit_btn
            )

            action_layout.addWidget(
                delete_btn
            )

            action_widget = QWidget()

            action_widget.setLayout(
                action_layout
            )

            self.table.setCellWidget(
                table_row,
                5,
                action_widget
            )

    # ==============================================
    # ویرایش کمک
    # ==============================================

    def edit_donation(
        self,
        donation_id
    ):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    donor_name,
                    amount,
                    donation_date,
                    description,
                    document_no

                FROM finance_donations

                WHERE id=?
                """,
                (
                    donation_id,
                )
            )

            data = cursor.fetchone()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                f"خطا در دریافت کمک:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        if not data:

            QMessageBox.warning(
                self,
                "کمک پیدا نشد",
                "این کمک در پایگاه داده پیدا نشد."
            )

            return

        dialog = EditDonationDialog(
            data,
            self
        )

        if dialog.exec() != QDialog.Accepted:

            return

        values = dialog.get_values()

        new_donor = values[0]

        new_amount = values[1]

        new_date = values[2]

        new_description = values[3]

        old_document_no = (
            data[4]
            or f"DON-{donation_id:06d}"
        )

        # ------------------------------------------
        # ویرایش کمک
        # ------------------------------------------

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                UPDATE finance_donations

                SET
                    donor_name=?,
                    amount=?,
                    donation_date=?,
                    description=?

                WHERE id=?
                """,
                (
                    new_donor,
                    new_amount,
                    new_date,
                    new_description,
                    donation_id
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                f"ویرایش کمک انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # هماهنگ‌سازی حسابداری
        # ------------------------------------------

        accounting_conn = None

        try:

            accounting_conn = get_connection()

            accounting_cursor = (
                accounting_conn.cursor()
            )

            accounting_cursor.execute(
                """
                UPDATE finance_transactions

                SET
                    amount=?,
                    transaction_date=?,
                    party=?,
                    description=?

                WHERE document_no=?
                """,
                (
                    new_amount,new_date,
                    new_donor,
                    new_description,
                    old_document_no
                )
            )

            accounting_conn.commit()

        except Exception as e:

            QMessageBox.warning(
                self,
                "هشدار حسابداری",
                "کمک ویرایش شد، اما هماهنگ‌سازی "
                "سند حسابداری با مشکل مواجه شد.\n\n"
                f"{e}"
            )

        finally:

            if accounting_conn is not None:

                try:
                    accounting_conn.close()
                except Exception:
                    pass

        QMessageBox.information(
            self,
            "ویرایش کمک",
            "کمک مردمی با موفقیت ویرایش شد."
        )

        self.load_data()

    # ==============================================
    # حذف کمک
    # ==============================================

    def delete_donation(
        self,
        donation_id
    ):

        conn = None

        data = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    document_no,
                    donor_name,
                    amount,
                    donation_date

                FROM finance_donations

                WHERE id=?
                """,
                (
                    donation_id,
                )
            )

            data = cursor.fetchone()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت اطلاعات کمک:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        if not data:

            QMessageBox.warning(
                self,
                "کمک پیدا نشد",
                "این کمک دیگر وجود ندارد."
            )

            return

        document_no = (
            data[0]
            or f"DON-{donation_id:06d}"
        )

        donor = (
            data[1]
            or ""
        )

        amount = (
            data[2]
            or 0
        )

        donation_date = (
            data[3]
            or ""
        )

        # ------------------------------------------
        # تأیید حذف
        # ------------------------------------------

        message = (
            f"آیا از حذف این کمک اطمینان دارید؟\n\n"
            f"سند: {document_no}\n"
            f"نام خیر: {donor}\n"
            f"مبلغ: {amount:,} ریال\n"
            f"تاریخ: {donation_date}\n\n"
            f"سند حسابداری مرتبط نیز حذف خواهد شد."
        )

        result = QMessageBox.question(
            self,
            "حذف کمک مردمی",
            message,
            QMessageBox.Yes |
            QMessageBox.No,
            QMessageBox.No
        )

        if result != QMessageBox.Yes:

            return

        # ------------------------------------------
        # حذف کمک
        # ------------------------------------------

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                DELETE FROM finance_donations

                WHERE id=?
                """,
                (
                    donation_id,
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای حذف",
                f"حذف کمک انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # حذف سند حسابداری
        # ------------------------------------------

        accounting_conn = None

        try:

            accounting_conn = get_connection()

            accounting_cursor = (
                accounting_conn.cursor()
            )

            accounting_cursor.execute(
                """
                DELETE FROM finance_transactions

                WHERE document_no=?
                """,
                (
                    document_no,
                )
            )

            accounting_conn.commit()

        except Exception as e:

            QMessageBox.warning(
                self,
                "هشدار حسابداری",
                "کمک از بخش کمک‌های مردمی حذف شد، "
                "اما سند حسابداری مرتبط حذف نشد.\n\n"
                f"{e}"
            )

        finally:

            if accounting_conn is not None:

                try:
                    accounting_conn.close()
                except Exception:
                    pass

        QMessageBox.information(
            self,
            "حذف کمک",
            "کمک مردمی با موفقیت حذف شد."
        )

        self.load_data()