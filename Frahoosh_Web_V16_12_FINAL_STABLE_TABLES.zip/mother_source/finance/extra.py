from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QDialog,
    QFormLayout,
    QDialogButtonBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from database.db import get_connection

from finance.finance_db import add_transaction


# ==================================================
# فرم ویرایش پرداخت فوق برنامه
# ==================================================

class EditExtraDialog(QDialog):

    def __init__(self, data, parent=None):

        super().__init__(parent)

        self.setWindowTitle(
            "ویرایش پرداخت فوق برنامه"
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.setMinimumWidth(450)

        layout = QFormLayout(self)

        # عنوان
        self.title_input = QLineEdit(
            str(data[0] or "")
        )

        # دانش آموز
        self.student_input = QLineEdit(
            str(data[1] or "")
        )

        # مبلغ
        self.amount_input = QLineEdit(
            str(data[2] or 0)
        )

        # تاریخ
        self.date_input = QLineEdit(
            str(data[3] or "")
        )

        layout.addRow(
            "عنوان فوق برنامه:",
            self.title_input
        )

        layout.addRow(
            "نام دانش‌آموز:",
            self.student_input
        )

        layout.addRow(
            "مبلغ:",
            self.amount_input
        )

        layout.addRow(
            "تاریخ:",
            self.date_input
        )

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save |
            QDialogButtonBox.Cancel
        )

        buttons.accepted.connect(
            self.validate_and_accept
        )

        buttons.rejected.connect(
            self.reject
        )

        layout.addWidget(
            buttons
        )

    # ==============================================
    # اعتبارسنجی
    # ==============================================

    def validate_and_accept(self):

        title = self.title_input.text().strip()

        student = self.student_input.text().strip()

        if not title:

            QMessageBox.warning(
                self,
                "خطا",
                "عنوان فوق برنامه را وارد کنید."
            )

            return

        if not student:

            QMessageBox.warning(
                self,
                "خطا",
                "نام دانش‌آموز را وارد کنید."
            )

            return

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        try:

            amount = int(
                amount_text
            )

            if amount <= 0:

                raise ValueError

        except ValueError:

            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ واردشده صحیح نیست."
            )

            return

        self.accept()

    # ==============================================
    # دریافت اطلاعات
    # ==============================================

    def get_values(self):

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        amount = int(
            amount_text or 0
        )

        return (
            self.title_input.text().strip(),
            self.student_input.text().strip(),
            amount,
            self.date_input.text().strip()
        )


# ==================================================
# صفحه پرداخت های فوق برنامه
# ==================================================

class ExtraPage(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.init_database()

        self.init_ui()

    # ==============================================# آماده سازی دیتابیس
    # ==============================================

    def init_database(self):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                "PRAGMA table_info(finance_extra)"
            )

            columns = [
                row[1]
                for row in cursor.fetchall()
            ]

            if "document_no" not in columns:

                cursor.execute(
                    """
                    ALTER TABLE finance_extra
                    ADD COLUMN document_no TEXT
                    """
                )

            conn.commit()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای دیتابیس",
                f"خطا در آماده‌سازی بخش فوق برنامه:\n\n{e}"
            )

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

    # ==============================================
    # رابط کاربری
    # ==============================================

    def init_ui(self):

        layout = QVBoxLayout(self)

        layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        layout.setSpacing(10)

        # ------------------------------------------
        # عنوان
        # ------------------------------------------

        title = QLabel(
            "پرداخت‌های فوق برنامه"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )

        layout.addWidget(
            title
        )

        # ------------------------------------------
        # فرم ثبت
        # ------------------------------------------

        form = QHBoxLayout()

        self.title_input = QLineEdit()

        self.title_input.setPlaceholderText(
            "عنوان فوق برنامه"
        )

        self.student_input = QLineEdit()

        self.student_input.setPlaceholderText(
            "نام دانش‌آموز"
        )

        self.amount_input = QLineEdit()

        self.amount_input.setPlaceholderText(
            "مبلغ به ریال"
        )

        self.date_input = QLineEdit()

        self.date_input.setPlaceholderText(
            "تاریخ شمسی"
        )

        save_btn = QPushButton(
            "ثبت پرداخت"
        )

        save_btn.clicked.connect(
            self.save_payment
        )

        form.addWidget(
            self.title_input
        )

        form.addWidget(
            self.student_input
        )

        form.addWidget(
            self.amount_input
        )

        form.addWidget(
            self.date_input
        )

        form.addWidget(
            save_btn
        )

        layout.addLayout(
            form
        )

        # ------------------------------------------
        # جدول
        # ------------------------------------------

        self.table = QTableWidget()

        self.table.setColumnCount(
            7
        )

        self.table.setHorizontalHeaderLabels(
            [
                "شماره سند",
                "عنوان",
                "دانش‌آموز",
                "مبلغ",
                "تاریخ",
                "وضعیت",
                "عملیات"
            ]
        )

        self.table.setLayoutDirection(
            Qt.RightToLeft
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setAlternatingRowColors(
            True
        )

        self.table.verticalHeader().setDefaultSectionSize(
            45
        )

        self.table.horizontalHeader().setStretchLastSection(
            True
        )

        layout.addWidget(
            self.table
        )

        self.load_data()

    # ==============================================
    # ثبت پرداخت
    # ==============================================

    def save_payment(self):

        title = self.title_input.text().strip()

        student = self.student_input.text().strip()

        date = self.date_input.text().strip()

        if not title:

            QMessageBox.warning(
                self,
                "خطا",
                "عنوان فوق برنامه را وارد کنید."
            )

            return

        if not student:

            QMessageBox.warning(
                self,
                "خطا",
                "نام دانش‌آموز را وارد کنید."
            )

            return

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        try:

            amount = int(
                amount_text
            )

            if amount <= 0:

                raise ValueError

        except ValueError:

            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ صحیح وارد کنید."
            )

            return

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            # --------------------------------------
            # ثبت در فوق برنامه
            # --------------------------------------

            cursor.execute(
                """
                INSERT INTO finance_extra
                (
                    title,
                    student_name,
                    amount,
                    description,
                    payment_date
                )

                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    title,
                    student,
                    amount,
                    "پرداخت شده",
                    date
                )
            )

            extra_id = cursor.lastrowid

            document_no = (
                f"EX-{extra_id:06d}"
            )

            cursor.execute(
                """
                UPDATE finance_extra

                SET document_no=?

                WHERE id=?
                """,
                (
                    document_no,
                    extra_id
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای ثبت",
                f"ثبت پرداخت انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # ثبت در حسابداری
        # ------------------------------------------

        try:

            add_transaction(

                transaction_type="income",

                title=title,

                amount=amount,

                category="فوق برنامه",

                transaction_date=date,

                document_no=document_no,

                account_title="درآمد فوق برنامه",

                party=student,

                description="پرداخت فوق برنامه دانش‌آموز"

            )

        except Exception as e:

            # اگر ثبت حسابداری شکست خورد،
            # رکورد فوق برنامه هم حذف می‌شود.

            cleanup_conn = None

            try:

                cleanup_conn = get_connection()

                cleanup_cursor = (
                    cleanup_conn.cursor()
                )

                cleanup_cursor.execute(
                    """
                    DELETE FROM finance_extra

                    WHERE id=?
                    """,
                    (
                        extra_id,
                    )
                )

                cleanup_conn.commit()

            except Exception:
                pass

            finally:

                if cleanup_conn is not None:

                    try:
                        cleanup_conn.close()
                    except Exception:
                        pass

            QMessageBox.critical(
                self,
                "خطای حسابداری",
                f"پرداخت ثبت نشد زیرا ثبت حسابداری با خطا مواجه شد:\n\n{e}"
            )

            return

        # ------------------------------------------
        # پاک کردن فرم
        # ------------------------------------------

        self.title_input.clear()

        self.student_input.clear()

        self.amount_input.clear()

        self.date_input.clear()

        QMessageBox.information(
            self,
            "ثبت پرداخت",
            f"پرداخت فوق برنامه با موفقیت ثبت شد.\n\n"
            f"شماره سند: {document_no}"
        )

        self.load_data()

    # ==============================================
    # نمایش اطلاعات
    # ==============================================

    def load_data(self):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    id,
                    document_no,
                    title,
                    student_name,
                    amount,
                    payment_date,
                    description

                FROM finance_extra

                ORDER BY id DESC
                """
            )

            rows = cursor.fetchall()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای فوق برنامه",
                f"خطا در خواندن پرداخت‌ها:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # جدول
        # ------------------------------------------

        self.table.setRowCount(
            0
        )

        for row in rows:

            table_row = (
                self.table.rowCount()
            )

            self.table.insertRow(
                table_row
            )

            payment_id = row[0]

            document_no = (
                row[1]
                or f"EX-{payment_id:06d}"
            )

            title = (
                row[2]
                or ""
            )

            student = (
                row[3]
                or ""
            )

            amount = (
                row[4]
                or 0
            )

            payment_date = (
                row[5]
                or ""
            )

            description = (
                row[6]
                or "پرداخت شده"
            )

            values = [

                document_no,

                title,

                student,

                f"{amount:,} ریال",

                payment_date,

                description

            ]

            for column, value in enumerate(
                values
            ):

                item = QTableWidgetItem(
                    str(value)
                )

                item.setTextAlignment(
                    Qt.AlignRight |
                    Qt.AlignVCenter
                )

                self.table.setItem(
                    table_row,
                    column,
                    item
                )

            # --------------------------------------
            # دکمه ویرایش
            # --------------------------------------

            edit_btn = QPushButton(
                "✏️ ویرایش"
            )

            edit_btn.clicked.connect(
                lambda checked=False,
                item_id=payment_id:
                self.edit_payment(
                    item_id
                )
            )

            # --------------------------------------
            # دکمه حذف
            #--------------------------------------

            delete_btn = QPushButton(
                "🗑️ حذف"
            )

            delete_btn.clicked.connect(
                lambda checked=False,
                item_id=payment_id:
                self.delete_payment(
                    item_id
                )
            )

            # --------------------------------------
            # چیدمان عملیات
            # --------------------------------------

            action_layout = QHBoxLayout()

            action_layout.setContentsMargins(
                4,
                2,
                4,
                2
            )

            action_layout.setSpacing(
                5
            )

            action_layout.addWidget(
                edit_btn
            )

            action_layout.addWidget(
                delete_btn
            )

            action_widget = QWidget()

            action_widget.setLayout(
                action_layout
            )

            self.table.setCellWidget(
                table_row,
                6,
                action_widget
            )

    # ==============================================
    # ویرایش پرداخت
    # ==============================================

    def edit_payment(
        self,
        payment_id
    ):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    title,
                    student_name,
                    amount,
                    payment_date,
                    description,
                    document_no

                FROM finance_extra

                WHERE id=?
                """,
                (
                    payment_id,
                )
            )

            data = cursor.fetchone()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                f"خطا در دریافت پرداخت:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        if not data:

            QMessageBox.warning(
                self,
                "پرداخت پیدا نشد",
                "این پرداخت در پایگاه داده پیدا نشد."
            )

            return

        # ------------------------------------------
        # فرم ویرایش
        # ------------------------------------------

        dialog = EditExtraDialog(
            data,
            self
        )

        if dialog.exec() != QDialog.Accepted:

            return

        values = dialog.get_values()

        new_title = values[0]

        new_student = values[1]

        new_amount = values[2]

        new_date = values[3]

        old_document_no = (
            data[5]
            or f"EX-{payment_id:06d}"
        )

        # ------------------------------------------
        # ویرایش فوق برنامه
        # ------------------------------------------

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                UPDATE finance_extra

                SET
                    title=?,
                    student_name=?,
                    amount=?,
                    payment_date=?

                WHERE id=?
                """,
                (
                    new_title,
                    new_student,
                    new_amount,
                    new_date,
                    payment_id
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                f"ویرایش پرداخت انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # هماهنگ کردن حسابداری
        # ------------------------------------------

        accounting_conn = None

        try:

            accounting_conn = get_connection()

            accounting_cursor = (
                accounting_conn.cursor()
            )

            accounting_cursor.execute(
                """
                UPDATE finance_transactions

                SET
                    title=?,
                    amount=?,
                    transaction_date=?,
                    party=?

                WHERE document_no=?
                """,
                (
                    new_title,
                    new_amount,
                    new_date,
                    new_student,
                    old_document_no
                )
            )

            accounting_conn.commit()

        except Exception as e:

            QMessageBox.warning(
                self,
                "هشدار حسابداری",
                "پرداخت فوق برنامه ویرایش شد، "
                "اما هماهنگ‌سازی سند حسابداری با مشکل مواجه شد.\n\n"
                f"{e}"
            )

        finally:

            if accounting_conn is not None:

                try:
                    accounting_conn.close()
                except Exception:
                    pass

        QMessageBox.information(
            self,
            "ویرایش پرداخت",
            "پرداخت فوق برنامه با موفقیت ویرایش شد."
        )

        self.load_data()

    # ==============================================
    # حذف پرداخت
    # ==============================================

    def delete_payment(
        self,
        payment_id
    ):

        conn = None

        document_no = ""

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    document_no,
                    title,
                    student_name,
                    amount

                FROM finance_extra

                WHERE id=?
                """,
                (
                    payment_id,
                )
            )

            data = cursor.fetchone()

            if data:

                document_no = (
                    data[0]
                    or f"EX-{payment_id:06d}"
                )

                title = (
                    data[1]
                    or ""
                )

                student = (
                    data[2]
                    or ""
                )

                amount = (
                    data[3]
                    or 0
                )

            else:

                title = ""

                student = ""

                amount = 0

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت اطلاعات پرداخت:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        if not data:

            QMessageBox.warning(
                self,
                "پرداخت پیدا نشد",
                "این پرداخت دیگر وجود ندارد."
            )

            return

        # ------------------------------------------
        # تأیید حذف
        # ------------------------------------------

        message = (
            f"آیا از حذف این پرداخت اطمینان دارید؟\n\n"
            f"سند: {document_no}\n"
            f"عنوان: {title}\n"
            f"دانش‌آموز: {student}\n"
            f"مبلغ: {amount:,} ریال\n\n"
            f"سند حسابداری مرتبط نیز حذف خواهد شد."
        )

        result = QMessageBox.question(
            self,
            "حذف پرداخت فوق برنامه",
            message,
            QMessageBox.Yes |QMessageBox.No,
            QMessageBox.No
        )

        if result != QMessageBox.Yes:

            return

        # ------------------------------------------
        # حذف از فوق برنامه
        # ------------------------------------------

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                DELETE FROM finance_extra

                WHERE id=?
                """,
                (
                    payment_id,
                )
            )

            conn.commit()

        except Exception as e:

            if conn is not None:

                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطای حذف",
                f"حذف پرداخت انجام نشد:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # حذف سند حسابداری مرتبط
        # ------------------------------------------

        accounting_conn = None

        try:

            accounting_conn = get_connection()

            accounting_cursor = (
                accounting_conn.cursor()
            )

            accounting_cursor.execute(
                """
                DELETE FROM finance_transactions

                WHERE document_no=?
                """,
                (
                    document_no,
                )
            )

            accounting_conn.commit()

        except Exception as e:

            QMessageBox.warning(
                self,
                "هشدار حسابداری",
                "پرداخت از بخش فوق برنامه حذف شد، "
                "اما سند حسابداری مرتبط حذف نشد.\n\n"
                f"{e}"
            )

        finally:

            if accounting_conn is not None:

                try:
                    accounting_conn.close()
                except Exception:
                    pass

        QMessageBox.information(
            self,
            "حذف پرداخت",
            "پرداخت فوق برنامه با موفقیت حذف شد."
        )

        self.load_data()