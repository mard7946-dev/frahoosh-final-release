from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QComboBox,
    QHeaderView,
    QDialog,
    QFormLayout,
    QDialogButtonBox, QGridLayout
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


from database.db import get_connection

from finance.finance_db import (
    add_transaction,
    delete_transaction,
    update_transaction
)

# ==================================================
# دیالوگ ویرایش سند
# ==================================================

class EditAccountingDialog(QDialog):

    def __init__(self, data, parent=None):

        super().__init__(parent)

        self.setWindowTitle(
            "ویرایش سند مالی"
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.setMinimumWidth(
            450
        )


        layout = QFormLayout(
            self
        )


        self.document_input = QLineEdit(
            str(data[0] or "")
        )

        self.account_input = QLineEdit(
            str(data[1] or "")
        )

        self.party_input = QLineEdit(
            str(data[2] or "")
        )

        self.title_input = QLineEdit(
            str(data[3] or "")
        )

        self.amount_input = QLineEdit(
            str(data[4] or "")
        )

        self.date_input = QLineEdit(
            str(data[5] or "")
        )



        layout.addRow(
            "شماره سند:",
            self.document_input
        )

        layout.addRow(
            "حساب:",
            self.account_input
        )

        layout.addRow(
            "طرف حساب:",
            self.party_input
        )

        layout.addRow(
            "شرح:",
            self.title_input
        )

        layout.addRow(
            "مبلغ:",
            self.amount_input
        )

        layout.addRow(
            "تاریخ:",
            self.date_input
        )



        buttons = QDialogButtonBox(
            QDialogButtonBox.Save |
            QDialogButtonBox.Cancel
        )


        buttons.accepted.connect(
            self.accept
        )

        buttons.rejected.connect(
            self.reject
        )


        layout.addWidget(
            buttons
        )



    def get_values(self):

        amount = (
            self.amount_input
            .text()
            .replace(",", "")
            .replace("٬", "")
            .strip()
        )


        return (

            self.document_input.text().strip(),

            self.account_input.text().strip(),

            self.party_input.text().strip(),

            self.title_input.text().strip(),

            int(amount or 0),

            self.date_input.text().strip()

        )



# ==================================================
# صفحه حسابداری
# ==================================================

class AccountingPage(QWidget):


    def __init__(self, parent=None):

        super().__init__(parent)


        self.setLayoutDirection(
            Qt.RightToLeft
        )


        self.init_ui()



    # ==================================================
    # رابط کاربری
    # ==================================================

    def init_ui(self):

        layout = QVBoxLayout(
            self
        )


        layout.setSpacing(
            12
        )


        title = QLabel(
            "حسابداری مالی مدرسه"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )


        layout.addWidget(
            title
        )



        # کارت ثبت سند

        form = QFrame()


        form.setStyleSheet(
            """
            QFrame{
                background:#f59e0b;
                border-radius:14px;
                padding:8px;
            }

            QLineEdit{
                background:white;
                color:#111827;
                border-radius:8px;
                padding:8px;font-family:"B Zar";
            }

            QComboBox{
                background:white;
                color:#111827;
                padding:8px;
                border-radius:8px;
            }

            QPushButton{
                background:#16a34a;
                color:black;
                border-radius:8px;
                padding:8px;
                font-family:"B Zar";
                font-weight:bold;
            }
            """
        )



        form_layout = QGridLayout(form)
        form_layout.setContentsMargins(12, 12, 12, 12)
        form_layout.setHorizontalSpacing(10)
        form_layout.setVerticalSpacing(10)

        self.document_input = QLineEdit(); self.document_input.setPlaceholderText("شماره سند")
        self.account_input = QLineEdit(); self.account_input.setPlaceholderText("حساب")
        self.party_input = QLineEdit(); self.party_input.setPlaceholderText("طرف حساب")
        self.title_input = QLineEdit(); self.title_input.setPlaceholderText("شرح عملیات")
        self.amount_input = QLineEdit(); self.amount_input.setPlaceholderText("مبلغ")
        self.date_input = QLineEdit(); self.date_input.setPlaceholderText("تاریخ")
        self.type_box = QComboBox(); self.type_box.addItems(["درآمد", "هزینه"])
        for w in (self.document_input,self.account_input,self.party_input,self.title_input,self.amount_input,self.date_input,self.type_box):
            w.setMinimumHeight(34)

        form_layout.addWidget(QLabel("شماره سند"), 0, 0); form_layout.addWidget(self.document_input, 0, 1)
        form_layout.addWidget(QLabel("حساب"), 0, 2); form_layout.addWidget(self.account_input, 0, 3)
        form_layout.addWidget(QLabel("طرف حساب"), 1, 0); form_layout.addWidget(self.party_input, 1, 1)
        form_layout.addWidget(QLabel("شرح عملیات"), 1, 2); form_layout.addWidget(self.title_input, 1, 3)
        form_layout.addWidget(QLabel("مبلغ"), 2, 0); form_layout.addWidget(self.amount_input, 2, 1)
        form_layout.addWidget(QLabel("تاریخ"), 2, 2); form_layout.addWidget(self.date_input, 2, 3)
        form_layout.addWidget(QLabel("نوع سند"), 3, 0); form_layout.addWidget(self.type_box, 3, 1)
        save_btn = QPushButton("ثبت سند")
        save_btn.setMinimumHeight(38)
        save_btn.clicked.connect(self.save_transaction)
        form_layout.addWidget(save_btn, 3, 2, 1, 2)
        for col in (1,3): form_layout.setColumnStretch(col, 1)
        layout.addWidget(
            form
        )



        # ==================================================
        # جدول
        # ==================================================

        table_frame = QFrame()


        table_frame.setStyleSheet(
            """
            QFrame{

                background:#f59e0b;
                border-radius:14px;
                padding:8px;

            }
            """
        )


        table_layout = QVBoxLayout(
            table_frame
        )



        self.table = QTableWidget()


        self.table.setColumnCount(
            9
        )


        self.table.setHorizontalHeaderLabels(
            [
                "شماره سند",
                "حساب",
                "طرف حساب",
                "شرح",
                "بدهکار",
                "بستانکار",
                "تاریخ",
                "نوع",
                "عملیات"
            ]
        )


        self.table.setLayoutDirection(
            Qt.RightToLeft
        )


        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )


        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )


        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )


        header = self.table.horizontalHeader()

        for i in range(8):
            header.setSectionResizeMode(
                i,
                QHeaderView.Stretch
            )


        header.setSectionResizeMode(
            8,
            QHeaderView.Fixed
        )


        self.table.setColumnWidth(
            8,
            190
        )


        self.table.setStyleSheet(
            """
            QTableWidget{

                background:white;
                color:#111827;
                font-family:"B Zar";

            }


            QHeaderView::section{

                background:#16a34a;
                color:black;
                padding:8px;
                font-family:"B Zar";
                font-weight:bold;

            }


            QTableWidget::item:selected{

                background:#bbf7d0;
                color:black;

            }

            """
        )



        table_layout.addWidget(
            self.table
        )


        layout.addWidget(
            table_frame
        )



        self.load_data()



    # ==================================================
    # ثبت سند
    # ==================================================

    def save_transaction(self):

        title = self.title_input.text().strip()


        if not title:

            QMessageBox.warning(
                self,
                "خطا",
                "شرح عملیات را وارد کنید."
            )

            return



        amount_text = (
            self.amount_input.text()
            .replace(",", "")
            .replace("٬", "")
            .strip()
        )



        try:

            amount = int(
                amount_text
            )


        except:


            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ صحیح نیست."
            )

            return



        transaction_type = (

            "income"

            if self.type_box.currentText()=="درآمد"

            else "expense"

        )



        try:


            add_transaction(

                transaction_type=transaction_type,

                title=title,

                amount=amount,

                category="حسابداری",

                description=title,

                transaction_date=self.date_input.text(),

                document_no=self.document_input.text(),

                account_title=self.account_input.text(),

                party=self.party_input.text()

            )



        except Exception as e:


            QMessageBox.critical(
                self,
                "خطا",
                str(e)
            )

            return



        self.clear_form()

        self.load_data()


        # ==================================================
    # پاک کردن فرم
    # ==================================================

    def clear_form(self):

        self.document_input.clear()

        self.account_input.clear()

        self.party_input.clear()

        self.title_input.clear()

        self.amount_input.clear()

        self.date_input.clear()



    # ==================================================
    # بارگذاری اطلاعات جدول
    # ==================================================

    def load_data(self):

        conn = None


        try:

            conn = get_connection()

            cursor = conn.cursor()


            cursor.execute(
                """
                SELECT

                    id,
                    document_no,
                    account_title,
                    party,
                    title,
                    amount,
                    transaction_type,
                    transaction_date

                FROM finance_transactions

                ORDER BY id DESC

                """
            )


            rows = cursor.fetchall()



        except Exception as e:


            QMessageBox.critical(
                self,
                "خطای حسابداری",
                str(e)
            )

            return



        finally:


            if conn:

                try:
                    conn.close()

                except:
                    pass




        self.table.setRowCount(
            0
        )



        for row in rows:


            table_row = self.table.rowCount()


            self.table.insertRow(
                table_row
            )


            transaction_id = row[0]

            document_no = row[1] or ""

            account = row[2] or ""

            party = row[3] or ""

            title = row[4] or ""

            amount = row[5] or 0

            transaction_type = row[6] or ""

            date = row[7] or ""



            debt = ""

            credit = ""



            if transaction_type == "expense":

                debt = f"{amount:,} ریال"

            else:

                credit = f"{amount:,} ریال"



            kind = (

                "درآمد"

                if transaction_type == "income"

                else "هزینه"

            )



            values = [

                document_no,

                account,

                party,

                title,

                debt,

                credit,

                date,

                kind

            ]



            for column, value in enumerate(values):


                item = QTableWidgetItem(
                    str(value)
                )


                item.setTextAlignment(
                    Qt.AlignRight |
                    Qt.AlignVCenter
                )


                self.table.setItem(
                    table_row,
                    column,
                    item
                )



            # ======================================
            # دکمه ویرایش
            # ======================================

            edit_btn = QPushButton(
                "ویرایش"
            )


            edit_btn.setFixedSize(
                75,
                30
            )


            edit_btn.setStyleSheet(
                """
                QPushButton{

                    background:#16a34a;

                    color:black;

                    border-radius:6px;

                    font-family:"B Zar";

                    font-weight:bold;

                }


                QPushButton:hover{

                    background:#15803d;

                }

                """
            )



            edit_btn.clicked.connect(
                lambda checked=False,
                item_id=transaction_id:
                self.edit_item(item_id)
            )




            # ======================================
            # دکمه حذف
            # ======================================

            delete_btn = QPushButton(
                "حذف"
            )


            delete_btn.setFixedSize(
                65,
                30
            )


            delete_btn.setStyleSheet(
                """
                QPushButton{

                    background:#dc2626;

                    color:white;

                    border-radius:6px;

                    font-family:"B Zar";

                    font-weight:bold;

                }


                QPushButton:hover{

                    background:#b91c1c;

                }

                """
            )



            delete_btn.clicked.connect(
                lambda checked=False,
                item_id=transaction_id:
                self.delete_item(item_id)
            )



            action_layout = QHBoxLayout()


            action_layout.setContentsMargins(
                3,
                3,
                3,
                3
            )


            action_layout.setSpacing(
                5
            )



            action_layout.addWidget(
                edit_btn
            )


            action_layout.addWidget(
                delete_btn
            )



            action_widget = QWidget()


            action_widget.setLayout(
                action_layout
            )


            self.table.setCellWidget(
                table_row,
                8,
                action_widget
            )


            self.table.setColumnWidth(
                8,
                190
            )



    # ==================================================
    # ویرایش
    # ==================================================

    def edit_item(self, transaction_id):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT

                    document_no,
                    account_title,
                    party,
                    title,
                    amount,
                    transaction_date,
                    transaction_type

                FROM finance_transactions

                WHERE id=?

                """,
                (
                    transaction_id,
                )
            )

            data = cursor.fetchone()


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                str(e)
            )

            return


        finally:

            if conn:

                conn.close()



        if not data:

            QMessageBox.warning(
                self,
                "خطا",
                "سند پیدا نشد."
            )

            return



        dialog = EditAccountingDialog(
            data,
            self
        )


        if dialog.exec() != QDialog.Accepted:

            return



        values = dialog.get_values()


        document_no = values[0]
        account = values[1]
        party = values[2]
        title = values[3]
        amount = values[4]
        date = values[5]


        try:

            update_transaction(

                transaction_id,

                document_no,

                account,

                party,

                title,

                amount,

                data[6],

                "حسابداری",

                title,

                date

            )


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ذخیره",
                str(e)
            )

            return



        QMessageBox.information(
            self,
            "ویرایش",
            "سند با موفقیت ویرایش شد."
        )


        self.load_data()



    # ==================================================
    # حذف
    # ==================================================

    def delete_item(self, transaction_id):


        result = QMessageBox.question(

            self,

            "حذف سند",

            "آیا مطمئن هستید؟",

            QMessageBox.Yes |
            QMessageBox.No

        )


        if result != QMessageBox.Yes:

            return



        try:


            delete_transaction(
                transaction_id
            )


        except Exception as e:


            QMessageBox.critical(
                self,
                "خطا",
                str(e)
            )

            return



        self.load_data()



# ==================================================
# اتصال به داشبورد
# ==================================================

class Panel(AccountingPage):

    pass