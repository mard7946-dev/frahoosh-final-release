from database.db import get_connection



# ==================================
# ساخت جداول مالی
# ==================================

def create_finance_tables():

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_transactions (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            document_no TEXT,

            transaction_type TEXT NOT NULL,

            account_title TEXT,

            party TEXT,

            title TEXT NOT NULL,

            amount INTEGER DEFAULT 0,

            category TEXT,

            description TEXT,

            transaction_date TEXT

        )
        """
    )



    cursor.execute(
        "PRAGMA table_info(finance_transactions)"
    )


    columns = [

        row[1]

        for row in cursor.fetchall()

    ]



    required_columns = {

        "document_no": "TEXT",

        "account_title": "TEXT",

        "party": "TEXT",

        "description": "TEXT",

        "transaction_date": "TEXT"

    }



    for column, dtype in required_columns.items():

        if column not in columns:

            cursor.execute(
                f"""
                ALTER TABLE finance_transactions

                ADD COLUMN {column} {dtype}

                """
            )



    # -------------------------------
    # حساب ها
    # -------------------------------

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_accounts (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,

            balance INTEGER DEFAULT 0,

            created_at TEXT

        )
        """
    )



    # -------------------------------
    # کمک های مردمی
    # -------------------------------

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_donations (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            donor_name TEXT,

            amount INTEGER DEFAULT 0,

            description TEXT,

            donation_date TEXT

        )
        """
    )



    # -------------------------------
    # فوق برنامه
    # -------------------------------

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS finance_extra (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT,

            student_name TEXT,

            amount INTEGER DEFAULT 0,

            description TEXT,

            payment_date TEXT

        )
        """
    )



    conn.commit()

    conn.close()




# ==================================
# ثبت تراکنش مالی
# ==================================

def add_transaction(

    transaction_type,

    title,

    amount,

    category="",

    description="",

    transaction_date="",

    document_no=None,

    account_title="",

    party=""

):


    conn = get_connection()

    cursor = conn.cursor()



    if not document_no:


        cursor.execute(
            """
            SELECT COUNT(*)

            FROM finance_transactions

            """
        )


        count = cursor.fetchone()[0] + 1


        document_no = (
            f"FIN-{count:04d}"
        )



    cursor.execute(
        """
        INSERT INTO finance_transactions

        (

            document_no,

            transaction_type,

            account_title,

            party,

            title,

            amount,

            category,

            description,

            transaction_date

        )


        VALUES

        (?,?,?,?,?,?,?,?,?)

        """,

        (

            document_no,

            transaction_type,

            account_title,

            party,

            title,

            amount,

            category,

            description,

            transaction_date

        )

    )



    conn.commit()

    conn.close()




# ==================================
# حذف تراکنش
# ==================================

def delete_transaction(transaction_id):


    conn = get_connection()

    cursor = conn.cursor()



    cursor.execute(
        """
        DELETE FROM finance_transactions

        WHERE id=?

        """,

        (

            transaction_id,

        )

    )



    conn.commit()

    conn.close()


    # ==================================
# ویرایش کامل تراکنش
# ==================================

def update_transaction(

    transaction_id,

    document_no,

    account_title,

    party,

    title,

    amount,

    transaction_type,

    category="",

    description="",

    transaction_date=""

):


    conn = get_connection()

    cursor = conn.cursor()



    cursor.execute(
        """
        UPDATE finance_transactions

        SET

            document_no=?,

            account_title=?,

            party=?,

            title=?,

            amount=?,

            transaction_type=?,

            category=?,

            description=?,

            transaction_date=?


        WHERE id=?

        """,

        (

            document_no,

            account_title,

            party,

            title,

            amount,

            transaction_type,

            category,

            description,

            transaction_date,

            transaction_id

        )

    )



    conn.commit()

    conn.close()




# ==================================
# مجموع درآمد
# ==================================

def get_total_income():


    conn = get_connection()

    cursor = conn.cursor()



    cursor.execute(
        """
        SELECT SUM(amount)

        FROM finance_transactions

        WHERE transaction_type='income'

        """
    )


    result = cursor.fetchone()[0]


    conn.close()


    return result or 0




# ==================================
# مجموع هزینه
# ==================================

def get_total_expense():


    conn = get_connection()

    cursor = conn.cursor()



    cursor.execute(
        """
        SELECT SUM(amount)

        FROM finance_transactions

        WHERE transaction_type='expense'

        """
    )


    result = cursor.fetchone()[0]


    conn.close()


    return result or 0




# ==================================
# مانده حساب
# ==================================

def get_balance():


    return (

        get_total_income()

        -

        get_total_expense()

    )




# ==================================
# تعداد تراکنش
# ==================================

def get_transaction_count():


    conn = get_connection()

    cursor = conn.cursor()



    cursor.execute(
        """
        SELECT COUNT(*)

        FROM finance_transactions

        """
    )



    result = cursor.fetchone()[0]


    conn.close()


    return result