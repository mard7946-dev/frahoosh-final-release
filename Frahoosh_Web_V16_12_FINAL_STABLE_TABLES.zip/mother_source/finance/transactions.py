from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QFrame,
    QMessageBox,
    QDialog,
    QLineEdit,
    QTextEdit,
    QFormLayout,
    QDialogButtonBox
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from database.db import get_connection

from finance.finance_db import (
    delete_transaction,
    update_transaction
)


# ==================================================
# فرم ویرایش سند مالی
# ==================================================

class EditTransactionDialog(QDialog):

    def __init__(self, data, parent=None):

        super().__init__(parent)

        self.setWindowTitle(
            "ویرایش سند مالی"
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.setMinimumWidth(450)

        layout = QFormLayout(self)

        # عنوان
        self.title_input = QLineEdit(
            str(data[0] or "")
        )

        # مبلغ
        self.amount_input = QLineEdit(
            str(data[1] or 0)
        )

        # دسته
        self.category_input = QLineEdit(
            str(data[2] or "")
        )

        # توضیحات
        self.description_input = QTextEdit(
            str(data[3] or "")
        )

        self.description_input.setMinimumHeight(100)

        # تاریخ
        self.date_input = QLineEdit(
            str(data[4] or "")
        )

        layout.addRow(
            "عنوان:",
            self.title_input
        )

        layout.addRow(
            "مبلغ:",
            self.amount_input
        )

        layout.addRow(
            "دسته:",
            self.category_input
        )

        layout.addRow(
            "توضیحات:",
            self.description_input
        )

        layout.addRow(
            "تاریخ:",
            self.date_input
        )

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save |
            QDialogButtonBox.Cancel
        )

        buttons.accepted.connect(
            self.validate_and_accept
        )

        buttons.rejected.connect(
            self.reject
        )

        layout.addWidget(
            buttons
        )

    # ==============================================
    # بررسی اطلاعات فرم
    # ==============================================

    def validate_and_accept(self):

        title = self.title_input.text().strip()

        if not title:

            QMessageBox.warning(
                self,
                "خطا",
                "عنوان سند را وارد کنید."
            )

            return

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        try:

            amount = int(
                amount_text
            )

            if amount < 0:

                raise ValueError

        except ValueError:

            QMessageBox.warning(
                self,
                "خطا",
                "مبلغ واردشده صحیح نیست."
            )

            return

        self.accept()

    # ==============================================
    # دریافت اطلاعات
    # ==============================================

    def get_values(self):

        amount_text = (
            self.amount_input
            .text()
            .strip()
            .replace(",", "")
            .replace("٬", "")
            .replace("ریال", "")
            .strip()
        )

        amount = int(
            amount_text or 0
        )

        return (

            self.title_input
            .text()
            .strip(),

            amount,

            self.category_input
            .text()
            .strip(),

            self.description_input
            .toPlainText()
            .strip(),

            self.date_input
            .text()
            .strip()

        )


# ==================================================
# صفحه درآمدها و هزینه‌ها
# ==================================================

class TransactionsPage(QWidget):

    def __init__(
        self,
        parent=None
    ):

        super().__init__(parent)

        self.current_filter = "all"

        self.init_ui()

    # ==============================================
    # رابط کاربری
    # ==============================================

    def init_ui(self):

        layout = QVBoxLayout(self)

        layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        layout.setSpacing(10)

        # ------------------------------------------
        # عنوان
        # ------------------------------------------

        title = QLabel(
            "درآمدها و هزینه‌ها"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )

        layout.addWidget(
            title
        )

        # ------------------------------------------
        # کارت آمار
        # ------------------------------------------

        info = QFrame()

        info_layout = QHBoxLayout(info)

        self.income_label = QLabel(
            "جمع درآمد: 0 ریال"
        )

        self.expense_label = QLabel(
            "جمع هزینه: 0 ریال"
        )

        self.income_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.expense_label.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        self.income_label.setFont(
            QFont(
                "B Zar",
                14,
                QFont.Bold
            )
        )

        self.expense_label.setFont(
            QFont(
                "B Zar",
                14,
                QFont.Bold
            )
        )

        info_layout.addWidget(
            self.income_label
        )

        info_layout.addWidget(
            self.expense_label
        )

        layout.addWidget(
            info
        )

        # ------------------------------------------
        # فیلترها
        # ------------------------------------------

        buttons = QHBoxLayout()

        all_btn = QPushButton(
            "همه"
        )

        income_btn = QPushButton(
            "درآمدها"
        )

        expense_btn = QPushButton(
            "هزینه‌ها"
        )

        all_btn.clicked.connect(
            lambda: self.set_filter(
                "all"
            )
        )

        income_btn.clicked.connect(
            lambda: self.set_filter(
                "income"
            )
        )

        expense_btn.clicked.connect(
            lambda: self.set_filter(
                "expense"
            )
        )

        buttons.addWidget(
            all_btn
        )

        buttons.addWidget(
            income_btn
        )

        buttons.addWidget(
            expense_btn
        )

        layout.addLayout(
            buttons
        )

        # ------------------------------------------
        # جدول
        # ------------------------------------------

        self.table = QTableWidget()

        self.table.setColumnCount(
            7
        )

        self.table.setHorizontalHeaderLabels(
            [
                "شماره سند",
                "نوع",
                "عنوان",
                "مبلغ",
                "دسته",
                "تاریخ",
                "عملیات"
            ]
        )

        self.table.setLayoutDirection(
            Qt.RightToLeft
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setAlternatingRowColors(
            True
        )

        self.table.verticalHeader().setDefaultSectionSize(
            45
        )

        self.table.horizontalHeader().setStretchLastSection(
            True
        )

        layout.addWidget(
            self.table
        )

        # ------------------------------------------
        # بارگذاری اطلاعات
        # ------------------------------------------

        self.load_data()

    # ==============================================
    # فیلتر
    # ==============================================

    def set_filter(
        self,
        value
    ):

        self.current_filter = value

        self.load_data()

    # ==============================================
    # خواندن اطلاعات
    # ==============================================

    def load_data(self):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            # --------------------------------------
            # دریافت تراکنش‌ها
            # --------------------------------------

            if self.current_filter == "all":

                cursor.execute(
                    """
                    SELECT
                        id,
                        document_no,
                        transaction_type,
                        title,
                        amount,
                        category,
                        transaction_date

                    FROM finance_transactions

                    ORDER BY id DESC
                    """
                )

            else:

                cursor.execute(
                    """
                    SELECT
                        id,
                        document_no,
                        transaction_type,
                        title,
                        amount,
                        category,
                        transaction_date

                    FROM finance_transactions

                    WHERE transaction_type = ?

                    ORDER BY id DESC
                    """,
                    (
                        self.current_filter,
                    )
                )

            rows = cursor.fetchall()

            # --------------------------------------
            # مجموع درآمد
            # --------------------------------------

            cursor.execute(
                """
                SELECT
                    SUM(amount)

                FROM finance_transactions

                WHERE transaction_type = 'income'
                """
            )

            income_result = cursor.fetchone()

            income = (
                income_result[0]
                if income_result and income_result[0]
                else 0
            )

            # --------------------------------------
            # مجموع هزینه
            # --------------------------------------

            cursor.execute(
                """
                SELECT
                    SUM(amount)

                FROM finance_transactions

                WHERE transaction_type = 'expense'
                """
            )

            expense_result = cursor.fetchone()

            expense = (
                expense_result[0]
                if expense_result and expense_result[0]
                else 0
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای مالی",
                f"خطا در خواندن اطلاعات مالی:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # نمایش آمار
        # ------------------------------------------

        self.income_label.setText(
            f"جمع درآمد: {income:,} ریال"
        )

        self.expense_label.setText(
            f"جمع هزینه: {expense:,} ریال"
        )

        # ------------------------------------------
        # پاک‌سازی جدول
        # ------------------------------------------

        self.table.setRowCount(
            0
        )

        # ------------------------------------------
        # پر کردن جدول
        # ------------------------------------------

        for row in rows:

            table_row = (
                self.table.rowCount()
            )

            self.table.insertRow(
                table_row
            )

            transaction_id = row[0]

            document_no = (
                row[1]
                or ""
            )

            transaction_type = (
                row[2]
                or ""
            )

            title = (
                row[3]
                or ""
            )

            amount = (
                row[4]
                or 0
            )

            category = (
                row[5]
                or ""
            )

            transaction_date = (
                row[6]
                or ""
            )

            # نوع سند

            if transaction_type == "income":

                kind = "درآمد"

            elif transaction_type == "expense":

                kind = "هزینه"

            else:

                kind = transaction_type

            values = [

                document_no,

                kind,

                title,

                f"{amount:,} ریال",

                category,

                transaction_date

            ]

            # --------------------------------------
            # سلول‌های جدول
            # --------------------------------------

            for column, value in enumerate(
                values
            ):

                item = QTableWidgetItem(
                    str(value)
                )

                item.setTextAlignment(
                    Qt.AlignRight |
                    Qt.AlignVCenter
                )

                self.table.setItem(
                    table_row,
                    column,
                    item
                )

            # --------------------------------------
            # دکمه ویرایش
            # --------------------------------------

            edit_btn = QPushButton(
                "✏️ ویرایش"
            )

            edit_btn.setFont(
                QFont(
                    "B Zar",
                    10
                )
            )

            edit_btn.clicked.connect(
                lambda checked=False,
                item_id=transaction_id:
                self.edit_item(
                    item_id
                )
            )

            # --------------------------------------
            # دکمه حذف
            # --------------------------------------

            delete_btn = QPushButton(
                "🗑️ حذف"
            )

            delete_btn.setFont(
                QFont(
                    "B Zar",
                    10
                )
            )

            delete_btn.clicked.connect(
                lambda checked=False,
                item_id=transaction_id:
                self.delete_item(
                    item_id
                )
            )

            # --------------------------------------
            # چیدمان عملیات
            # --------------------------------------

            action_layout = QHBoxLayout()

            action_layout.setContentsMargins(
                4,
                2,
                4,
                2
            )

            action_layout.setSpacing(
                5
            )

            action_layout.addWidget(
                edit_btn
            )

            action_layout.addWidget(
                delete_btn
            )

            action_widget = QWidget()

            action_widget.setLayout(
                action_layout
            )

            self.table.setCellWidget(
                table_row,
                6,
                action_widget
            )

    # ==============================================
    # ویرایش سند
    # ==============================================

    def edit_item(
        self,
        transaction_id
    ):

        conn = None

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    title,
                    amount,
                    category,
                    description,
                    transaction_date

                FROM finance_transactions

                WHERE id = ?
                """,
                (
                    transaction_id,
                )
            )

            data = cursor.fetchone()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای مالی",
                f"خطا در دریافت سند:\n\n{e}"
            )

            return

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        if not data:

            QMessageBox.warning(
                self,
                "سند پیدا نشد",
                "این سند در پایگاه داده پیدا نشد."
            )

            return

        # ------------------------------------------
        # باز کردن فرم ویرایش
        # ------------------------------------------

        dialog = EditTransactionDialog(
            data,
            self
        )

        if dialog.exec() != QDialog.Accepted:

            return

        values = dialog.get_values()

        # ------------------------------------------
        # ذخیره تغییرات
        # ------------------------------------------

        try:

            update_transaction(
                transaction_id,
                values[0],
                values[1],
                values[2],
                values[3],
                values[4]
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای ویرایش",
                f"ویرایش سند انجام نشد:\n\n{e}"
            )

            return

        QMessageBox.information(
            self,
            "ویرایش سند",
            "سند مالی با موفقیت ویرایش شد."
        )

        self.load_data()

    # ==============================================
    # حذف سند
    # ==============================================

    def delete_item(
        self,
        transaction_id
    ):

        # ------------------------------------------
        # پیدا کردن شماره سند برای پیام
        # ------------------------------------------

        conn = None

        document_no = ""

        try:

            conn = get_connection()

            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT document_no

                FROM finance_transactions

                WHERE id = ?
                """,
                (
                    transaction_id,
                )
            )

            result = cursor.fetchone()

            if result:

                document_no = (
                    result[0]
                    or ""
                )

        except Exception:

            document_no = ""

        finally:

            if conn is not None:

                try:
                    conn.close()
                except Exception:
                    pass

        # ------------------------------------------
        # تأیید حذف
        # ------------------------------------------

        if document_no:

            message = (
                f"آیا از حذف سند "
                f"{document_no} "
                f"اطمینان دارید؟"
            )

        else:

            message = (
                "آیا از حذف این سند "
                "اطمینان دارید؟"
            )

        result = QMessageBox.question(
            self,
            "حذف سند مالی",
            message,
            QMessageBox.Yes |
            QMessageBox.No,
            QMessageBox.No
        )

        if result != QMessageBox.Yes:

            return

        # ------------------------------------------
        # حذف
        # ------------------------------------------

        try:

            delete_transaction(
                transaction_id
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای حذف",
                f"حذف سند انجام نشد:\n\n{e}"
            )

            return

        QMessageBox.information(
            self,
            "حذف سند",
            "سند مالی با موفقیت حذف شد."
        )

        # ------------------------------------------
        # تازه‌سازی جدول و آمار
        # ------------------------------------------

        self.load_data()

        