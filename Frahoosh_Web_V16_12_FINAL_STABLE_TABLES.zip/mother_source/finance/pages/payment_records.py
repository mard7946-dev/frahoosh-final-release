from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QComboBox,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox
import sqlite3, os
from datetime import datetime
from utils.jalali import iso_to_jalali
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..','school.db'))
class PaymentRecordsPage(QWidget):
 def __init__(self,parent=None):
  super().__init__(parent); self.build(); self.load()
 def db(self): return sqlite3.connect(DB)
 def build(self):
  l=QVBoxLayout(self); bar=QHBoxLayout()
  self.sid=QLineEdit();self.sid.setPlaceholderText('شناسه دانش‌آموز')
  self.parent=QLineEdit();self.parent.setPlaceholderText('نام کاربری ولی')
  self.title=QLineEdit();self.title.setPlaceholderText('عنوان پرداخت')
  self.amount=QLineEdit();self.amount.setPlaceholderText('مبلغ')
  self.status=QComboBox();self.status.addItems(['pending','paid','failed','لغو'])
  b=QPushButton('ثبت پرداخت');b.clicked.connect(self.save)
  ref=QPushButton('تازه‌سازی');ref.clicked.connect(self.load)
  for x in (self.sid,self.parent,self.title,self.amount,self.status,b,ref):bar.addWidget(x)
  l.addLayout(bar);self.table=QTableWidget(0,8);self.table.setHorizontalHeaderLabels(['ID','دانش‌آموز','ولی','عنوان','مبلغ','وضعیت','تاریخ شمسی','مرجع']);l.addWidget(self.table)
 def load(self):
  with self.db() as c: rows=c.execute('SELECT id,student_id,parent_username,title,amount,status,payment_date_shamsi,reference FROM payment_records ORDER BY id DESC').fetchall()
  self.table.setRowCount(len(rows))
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
 def save(self):
  try:sid=int(self.sid.text());amount=int(self.amount.text().replace(',',''))
  except: QMessageBox.warning(self,'مالی','شناسه دانش‌آموز و مبلغ باید عددی باشند.');return
  sh=iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
  with self.db() as c:
   c.execute('''INSERT INTO payment_records(student_id,parent_username,title,amount,status,payment_date,payment_date_shamsi,parent_name)
                VALUES(?,?,?,?,?,CURRENT_TIMESTAMP,?,?)''',(sid,self.parent.text(),self.title.text(),amount,self.status.currentText(),sh,self.parent.text()));c.commit()
  self.load()
