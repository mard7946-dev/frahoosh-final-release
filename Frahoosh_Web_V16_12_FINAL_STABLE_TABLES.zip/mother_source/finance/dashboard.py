from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QFrame
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from finance.finance_db import (
    get_total_income,
    get_total_expense,
    get_balance,
    get_transaction_count
)



class DashboardPage(QWidget):


    def __init__(self, parent=None):

        super().__init__(parent)

        self.init_ui()



    # ==================================
    # ساخت رابط داشبورد
    # ==================================

    def init_ui(self):

        layout = QVBoxLayout(self)


        title = QLabel(
            "داشبورد مالی فراهوش"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )


        layout.addWidget(
            title
        )



        cards = QHBoxLayout()



        income = get_total_income()

        expense = get_total_expense()

        balance = get_balance()

        count = get_transaction_count()



        items = [

            (
                "موجودی صندوق",
                f"{balance:,} ریال"
            ),

            (
                "درآمدها",
                f"{income:,} ریال"
            ),

            (
                "هزینه‌ها",
                f"{expense:,} ریال"
            ),

            (
                "تراکنش‌ها",
                str(count)
            )

        ]



        for name, value in items:


            frame = QFrame()


            frame.setFixedHeight(
                120
            )


            box = QVBoxLayout(
                frame
            )



            value_label = QLabel(
                value
            )


            value_label.setAlignment(
                Qt.AlignmentFlag.AlignCenter
            )


            value_label.setFont(
                QFont(
                    "B Zar",
                    20,
                    QFont.Bold
                )
            )



            name_label = QLabel(
                name
            )


            name_label.setAlignment(
                Qt.AlignmentFlag.AlignCenter
            )


            name_label.setFont(
                QFont(
                    "B Zar",
                    14
                )
            )



            box.addWidget(
                value_label
            )


            box.addWidget(
                name_label
            )



            frame.setStyleSheet(
                """
                QFrame {

                    background:#fef3c7;

                    border-radius:15px;

                    border-right:5px solid #92400e;

                }
                """
            )


            cards.addWidget(
                frame
            )



        layout.addLayout(
            cards
        )


        layout.addStretch()