from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
    QStackedWidget,
    QGridLayout
)

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


from finance.dashboard import DashboardPage
from finance.accounting import AccountingPage
from finance.transactions import TransactionsPage
from finance.reports import ReportsPage
from finance.extra import ExtraPage
from finance.donations import DonationsPage
from finance.pages.payment_records import PaymentRecordsPage
from ui.payment_gateway import PaymentManagerPage



class Panel(QWidget):


    def __init__(self, parent=None):

        super().__init__(parent)

        self.pages = {}

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.init_ui()



    # ==================================
    # رابط اصلی
    # ==================================

    def init_ui(self):

        main_layout = QVBoxLayout(self)


        main_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )


        main_layout.setSpacing(
            15
        )


        main_layout.addWidget(
            self.create_header()
        )


        body = QHBoxLayout()


        body.setSpacing(
            15
        )


        self.stack = QStackedWidget()


        body.addWidget(
            self.stack,
            1
        )


        body.addWidget(
            self.create_menu()
        )


        main_layout.addLayout(
            body
        )


        self.load_pages()


        self.apply_style()



    # ==================================
    # هدر
    # ==================================

    def create_header(self):

        frame = QFrame()

        frame.setObjectName(
            "finance_header"
        )


        layout = QVBoxLayout(frame)



        title = QLabel(
            "فراهوش | پنل هوشمند مالی"
        )


        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )



        subtitle = QLabel(
            "مدیریت حسابداری، درآمدها، هزینه‌ها و گزارش‌های مالی مدرسه"
        )


        subtitle.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )


        layout.addWidget(
            title
        )


        layout.addWidget(
            subtitle
        )


        return frame



    # ==================================
    # منو
    # ==================================

    def create_menu(self):

        frame = QFrame()


        frame.setObjectName(
            "finance_menu"
        )


        frame.setFixedWidth(
            250
        )


        layout = QVBoxLayout(frame)
        grid = QVBoxLayout()
        grid.setSpacing(10)

        buttons = [

            ("داشبورد مالی", "dashboard"),

            ("حسابداری مدرسه", "accounting"),

            ("درآمدها و هزینه‌ها", "transactions"),

            ("گزارش پایان سال", "reports"),

            ("پرداخت‌ها | payment_records", "payments"),
            ("⚙️ تنظیمات پرداخت آنلاین", "online_payment"),
            ("پرداخت‌های فوق برنامه", "extra"),

            ("کمک‌های مردمی", "donations"),

        ]



        for i, (text, key) in enumerate(buttons):
            btn = QPushButton(text)
            btn.setMinimumSize(190, 44)
            btn.setMaximumHeight(48)
            btn.setFont(QFont("B Zar", 13, QFont.Bold))
            btn.clicked.connect(lambda checked=False, p=key: self.change_page(p))
            grid.addWidget(btn)
        layout.addLayout(grid)
        layout.addStretch()


        return frame



    # ==================================
    # بارگذاری صفحات
    # ==================================

    def load_pages(self):


        pages = {


            "dashboard":

                DashboardPage(),



            "accounting":

                AccountingPage(),



            "transactions":

                TransactionsPage(),



            "reports":

                ReportsPage(),



            "extra":

                ExtraPage(),

            "payments":

                PaymentRecordsPage(),

            "online_payment":

                PaymentManagerPage(),



            "donations":

                DonationsPage()

        }



        for name, page in pages.items():


            self.pages[name] = page


            self.stack.addWidget(
                page
            )

            self.stack.setCurrentWidget(
            self.pages["dashboard"]
        )



    # ==================================
    # تغییر صفحه
    # ==================================

    def change_page(self, page_name):


        if page_name in self.pages:


            self.stack.setCurrentWidget(
                self.pages[page_name]
            )


        else:


            page = QLabel(
                "این بخش در حال توسعه است"
            )


            page.setAlignment(
                Qt.AlignmentFlag.AlignCenter
            )


            self.stack.addWidget(
                page
            )


            self.pages[page_name] = page


            self.stack.setCurrentWidget(
                page
            )



    # ==================================
    # استایل
    # ==================================

    def apply_style(self):

        self.setStyleSheet(
            """

            QWidget {

                background:#f8fafc;

                color:black;

                font-family:"B Zar";

            }



            QFrame#finance_header {

                background:#fef3c7;

                border-radius:20px;

                padding:15px;

            }



            QFrame#finance_menu {

                background:#92400b;

                border-radius:20px;

                padding:10px;

            }



            QFrame#finance_menu QPushButton {


                background:#22c55e;

                color:black;

                border-radius:10px;

                padding:8px;

                font-weight:bold;

            }



            QFrame#finance_menu QPushButton:hover {


                background:#16a34a;

            }



            QStackedWidget {

                background:white;

                border-radius:20px;

            }

            """
        )