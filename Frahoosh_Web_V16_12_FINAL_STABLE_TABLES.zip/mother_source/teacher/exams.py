from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect, now
from .context import get_teacher_name
import secrets
class ExamsPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build(); self.load()
 def build(self):
  l=QVBoxLayout(self);l.addWidget(QLabel('آزمون آنلاین استاندارد'))
  f=QFormLayout();self.title=QLineEdit();self.subject=QLineEdit();self.duration=QSpinBox();self.duration.setRange(1,240);self.duration.setValue(30);self.class_id=QSpinBox();self.class_id.setRange(0,999999);f.addRow('عنوان',self.title);f.addRow('درس',self.subject);f.addRow('مدت (دقیقه)',self.duration);f.addRow('شناسه کلاس',self.class_id);l.addLayout(f)
  b=QHBoxLayout();create=QPushButton('ساخت آزمون');add=QPushButton('افزودن سوال');link=QPushButton('لینک عمومی');b.addWidget(create);b.addWidget(add);b.addWidget(link);l.addLayout(b);create.clicked.connect(self.create);add.clicked.connect(self.add_question);link.clicked.connect(self.link)
  self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(['شناسه','عنوان','درس','مدت','تاریخ','لینک']);l.addWidget(self.table);self.qtable=QTableWidget(0,3);self.qtable.setHorizontalHeaderLabels(['ID','نوع سوال','متن']);l.addWidget(self.qtable)
 def load(self):
  c=connect();rows=c.execute('SELECT q.id,q.title,q.subject,q.duration,q.created_at,COALESCE(l.token,"") FROM online_quizzes q LEFT JOIN teacher_quiz_links l ON l.quiz_id=q.id WHERE q.teacher=? ORDER BY q.id DESC',(get_teacher_name(),)).fetchall();self.table.setRowCount(len(rows));
  for i,r in enumerate(rows):
   for j,v in enumerate(r):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
 def selected_quiz(self):
  r=self.table.currentRow();return int(self.table.item(r,0).text()) if r>=0 else None
 def create(self):
  if not self.title.text().strip() or not self.subject.text().strip():QMessageBox.warning(self,'خطا','عنوان و درس الزامی است.');return
  c=connect();c.execute('INSERT INTO online_quizzes(class_id,title,subject,duration,teacher,created_at) VALUES(?,?,?,?,?,?)',(self.class_id.value() or None,self.title.text().strip(),self.subject.text().strip(),self.duration.value(),get_teacher_name(),now()));c.commit();c.close();self.load()
 def add_question(self):
  qid=self.selected_quiz()
  if not qid:QMessageBox.warning(self,'سوال','یک آزمون را انتخاب کنید.');return
  d=QDialog(self);d.setWindowTitle('افزودن سوال استاندارد');f=QFormLayout(d);typ=QComboBox();typ.addItems(['چهارگزینه‌ای','تشریحی','درست/نادرست','کوتاه پاسخ','جای خالی']);txt=QTextEdit();a=QLineEdit();bb=QLineEdit();cc=QLineEdit();dd=QLineEdit();correct=QLineEdit();f.addRow('نوع',typ);f.addRow('متن سوال',txt);f.addRow('گزینه ۱',a);f.addRow('گزینه ۲',bb);f.addRow('گزینه ۳',cc);f.addRow('گزینه ۴',dd);f.addRow('پاسخ صحیح',correct);ok=QPushButton('ذخیره سوال');f.addWidget(ok);ok.clicked.connect(d.accept)
  if d.exec()==QDialog.Accepted:
   c=connect();c.execute('INSERT INTO quiz_questions(quiz_id,question,option1,option2,option3,option4,correct_answer) VALUES(?,?,?,?,?,?,?)',(qid,typ.currentText()+' | '+txt.toPlainText().strip(),a.text(),bb.text(),cc.text(),dd.text(),correct.text()));c.commit();c.close();QMessageBox.information(self,'آزمون','سوال اضافه شد.')
 def link(self):
  qid=self.selected_quiz()
  if not qid:return
  token=secrets.token_urlsafe(18);c=connect();c.execute('INSERT INTO teacher_quiz_links(quiz_id,token,created_at) VALUES(?,?,?)',(qid,token,now()));c.commit();c.close();QMessageBox.information(self,'لینک آزمون',f'https://quiz.local/join/{token}')
