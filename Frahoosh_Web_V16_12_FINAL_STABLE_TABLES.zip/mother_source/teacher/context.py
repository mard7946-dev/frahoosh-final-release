"""Authenticated teacher context.

Callers provide the logged-in username/name only.  The teacher database key is
resolved internally and is never entered manually by the UI.
"""
import os
from .db import teacher_id
from services.data_link_service import resolve

CURRENT_TEACHER_NAME = os.environ.get('FRAHOOSH_TEACHER_NAME', '')
_CURRENT_USER = None


def set_teacher(name='', tid=None):
    """Set the active teacher from the authenticated account.

    ``tid`` is retained only for backwards compatibility; new code should
    never supply it.  When omitted, the linked teacher is resolved from the
    username/account automatically.
    """
    global CURRENT_TEACHER_NAME, _CURRENT_USER
    CURRENT_TEACHER_NAME = name or CURRENT_TEACHER_NAME
    _CURRENT_USER = resolve(CURRENT_TEACHER_NAME) if CURRENT_TEACHER_NAME else None
    return _CURRENT_USER


def get_teacher_id():
    """Internal DB key, resolved automatically; never entered by the user."""
    if _CURRENT_USER:
        value = _CURRENT_USER.get('teacher_id')
        if value is not None:
            return value
    if CURRENT_TEACHER_NAME:
        try:
            return teacher_id(CURRENT_TEACHER_NAME)
        except Exception:
            return None
    return None


def get_teacher_name():
    if _CURRENT_USER and _CURRENT_USER.get('teacher'):
        t = _CURRENT_USER['teacher']
        name = ' '.join(str(t.get(k) or '').strip() for k in ('first_name', 'last_name')).strip()
        if name:
            return name
    return CURRENT_TEACHER_NAME
