from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect
from .context import get_teacher_id,get_teacher_name
class ReportsPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); l=QVBoxLayout(self); l.addWidget(QLabel('گزارشات آموزشی دبیر')); self.out=QTextEdit(); self.out.setReadOnly(True); l.addWidget(self.out); b=QPushButton('به‌روزرسانی گزارش'); b.clicked.connect(self.load); l.addWidget(b); self.load()
 def load(self):
  c=connect(); tid=get_teacher_id(); q=lambda sql,args=(): c.execute(sql,args).fetchone()[0]
  self.out.setPlainText(f'دبیر: {get_teacher_name() or "-"}\nکلاس‌های مجازی: {q("SELECT count(*) FROM online_classes WHERE teacher=?",(get_teacher_name(),))}\nتکالیف: {q("SELECT count(*) FROM assignments WHERE teacher_id=?",(tid,)) if tid else 0}\nنمرات ثبت‌شده: {q("SELECT count(*) FROM grades WHERE teacher_id=?",(tid,)) if tid else 0}\nطرح درس: {q("SELECT count(*) FROM lesson_plans WHERE teacher_id=?",(tid,)) if tid else 0}')
  c.close()
