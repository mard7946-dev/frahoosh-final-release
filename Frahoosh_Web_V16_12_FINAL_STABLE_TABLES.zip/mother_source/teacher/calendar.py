from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect
from .context import get_teacher_name
class CalendarPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); l=QVBoxLayout(self); l.addWidget(QLabel('برنامه هفتگی و امتحانات')); self.table=QTableWidget(); self.table.setColumnCount(7); self.table.setHorizontalHeaderLabels(['نوع','درس','پایه','کلاس','شروع','پایان','وضعیت']); l.addWidget(self.table); b=QPushButton('تازه‌سازی'); b.clicked.connect(self.load); l.addWidget(b); self.load()
 def load(self):
  c=connect(); rows=c.execute("SELECT 'کلاس',COALESCE(lesson,subject,title),grade,class_name,start_time,end_time,status FROM online_classes WHERE teacher=? UNION ALL SELECT 'طرح درس',subject,grade,class_name,plan_date,'','' FROM lesson_plans WHERE teacher_id=(SELECT id FROM teachers WHERE trim(first_name||' '||last_name)=? LIMIT 1) ORDER BY 5 DESC",(get_teacher_name(),get_teacher_name())).fetchall(); self.table.setRowCount(0)
  for r in rows:
   i=self.table.rowCount(); self.table.insertRow(i)
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
