from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QPushButton,
    QHBoxLayout,
    QMessageBox
)

from PySide6.QtCore import Qt

import sqlite3
from .context import get_teacher_name


from database.db import DATABASE_NAME


class ClassesPage(QWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.init_ui()

        self.load_classes()

    # =====================================================
    # رابط کاربری
    # =====================================================

    def init_ui(self):

        layout = QVBoxLayout(self)

        layout.setContentsMargins(
            15,
            15,
            15,
            15
        )

        layout.setSpacing(
            10
        )

        # =================================================
        # عنوان
        # =================================================

        title = QLabel(
            "کلاس‌های من"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setStyleSheet("""
            QLabel {
                font-family: "B Zar";
                font-size: 24px;
                font-weight: bold;
                color: #2E7D32;
                padding: 10px;
            }
        """)

        layout.addWidget(
            title
        )

        # =================================================
        # توضیح
        # =================================================

        info = QLabel(
            "کلاس‌های تأییدشده مدیریت در این قسمت نمایش داده می‌شوند."
        )

        info.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        info.setStyleSheet("""
            QLabel {
                font-family: "B Zar";
                font-size: 14px;
                color: #555555;
                padding: 5px;
            }
        """)

        layout.addWidget(
            info
        )

        # =================================================
        # دکمه‌های عملیاتی
        # =================================================

        button_layout = QHBoxLayout()

        refresh_button = QPushButton(
            "تازه‌سازی کلاس‌ها"
        )

        refresh_button.setMinimumHeight(
            42
        )

        refresh_button.clicked.connect(
            self.load_classes
        )

        button_layout.addWidget(
            refresh_button
        )

        start_button = QPushButton(
            "شروع کلاس انتخاب‌شده"
        )

        start_button.setMinimumHeight(
            42
        )

        start_button.clicked.connect(
            self.start_selected_class
        )

        button_layout.addWidget(
            start_button
        )

        layout.addLayout(
            button_layout
        )

        # =================================================
        # جدول
        # =================================================

        self.table = QTableWidget()

        self.table.setColumnCount(
            7
        )

        self.table.setHorizontalHeaderLabels([
            "درس",
            "دبیر",
            "پایه",
            "کلاس",
            "شروع",
            "وضعیت",
            "عملیات"
        ])

        self.table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        self.table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        self.table.setAlternatingRowColors(
            True
        )

        layout.addWidget(
            self.table
        )

        # =================================================
        # استایل
        # =================================================

        self.setStyleSheet("""
            QWidget {
                background: #F8FAFD;
                font-family: "B Zar";
            }

            QTableWidget {
                background: white;
                border: 1px solid #DDE5E7;
                border-radius: 10px;
                font-family: "B Zar";
                font-size: 14px;
            }

            QHeaderView::section {
                background: #2E7D32;
                color: white;
                font-family: "B Zar";
                font-weight: bold;
                padding: 8px;
                border: none;
            }

            QPushButton {
                background: #4CAF50;
                color: black;
                font-family: "B Zar";
                font-size: 14px;
                font-weight: bold;
                border-radius: 8px;
                padding: 8px;
            }

            QPushButton:hover {
                background: #81C784;
            }

            QPushButton:pressed {
                background: #388E3C;
            }
        """)

    # =====================================================
    # دریافت کلاس‌ها
    # =====================================================

    def load_classes(self):
        """نمایش کلاس‌های متصل به دبیر، حتی اگر هنوز در انتظار تأیید باشند."""
        conn = None
        try:
            conn = sqlite3.connect(DATABASE_NAME)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            current = (get_teacher_name() or '').strip()

            def norm(v):
                return ''.join(ch for ch in str(v or '').strip().lower() if ch.isalnum())

            aliases = {current} if current else set()
            target = norm(current)

            # Resolve login/display-name aliases from the teacher record.
            try:
                teachers = cursor.execute(
                    "SELECT first_name,last_name,email,phone,mobile,national_code FROM teachers"
                ).fetchall()
                for t in teachers:
                    full = f"{t['first_name'] or ''} {t['last_name'] or ''}".strip()
                    candidates = [full, t['first_name'], t['last_name'], t['email'],
                                  t['phone'], t['mobile'], t['national_code']]
                    if target and any(
                        target == norm(x) or target in norm(x) or norm(x) in target
                        for x in candidates if x
                    ):
                        aliases.update(str(x).strip() for x in candidates if x and str(x).strip())
            except Exception:
                pass

            # Resolve linked_teacher_id from the logged-in account if available.
            try:
                ur = cursor.execute(
                    "SELECT linked_teacher_id FROM users WHERE username=? LIMIT 1",
                    (current,)
                ).fetchone()
                if ur and ur['linked_teacher_id']:
                    tr = cursor.execute(
                        "SELECT first_name,last_name,email,phone,mobile,national_code FROM teachers WHERE id=?",
                        (ur['linked_teacher_id'],)
                    ).fetchone()
                    if tr:
                        vals = [f"{tr['first_name'] or ''} {tr['last_name'] or ''}".strip(),
                                tr['first_name'], tr['last_name'], tr['email'], tr['phone'],
                                tr['mobile'], tr['national_code']]
                        aliases.update(str(x).strip() for x in vals if x and str(x).strip())
            except Exception:
                pass

            rows = []
            if aliases:
                placeholders = ','.join('?' for _ in aliases)
                rows = cursor.execute(
                    f"""SELECT id,lesson,subject,teacher,grade,class_name,start_time,status
                        FROM online_classes
                        WHERE lower(trim(teacher)) IN ({placeholders})
                          AND status NOT IN ('cancelled','finished')
                        ORDER BY id DESC""",
                    tuple(str(a).lower() for a in aliases)
                ).fetchall()

            # Some management builds store the assigned class in executive_classes.
            # Surface those records too, so the teacher never loses an assigned class.
            if not rows and aliases:
                placeholders = ','.join('?' for _ in aliases)
                try:
                    erows = cursor.execute(
                        f"""SELECT id,name,grade,teacher,created_at
                            FROM executive_classes
                            WHERE lower(trim(teacher)) IN ({placeholders})
                            ORDER BY id DESC""",
                        tuple(str(a).lower() for a in aliases)
                    ).fetchall()
                    rows = [
                        {
                            'id': -int(r['id']),
                            'lesson': 'کلاس',
                            'subject': 'کلاس',
                            'teacher': r['teacher'],
                            'grade': r['grade'],
                            'class_name': r['name'],
                            'start_time': r['created_at'],
                            'status': 'approved'
                        }
                        for r in erows
                    ]
                except Exception:
                    pass

            self.table.setRowCount(0)
            for data in rows:
                class_id = int(data['id'])
                lesson = data['lesson'] or data['subject'] or '-'
                teacher = data['teacher'] or '-'
                grade = data['grade'] or '-'
                class_name = data['class_name'] or '-'
                start_time = data['start_time'] or '-'
                status = data['status'] or '-'

                row = self.table.rowCount()
                self.table.insertRow(row)
                values = [lesson, teacher, grade, class_name, start_time, self.status_text(status)]
                for col, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.table.setItem(row, col, item)

                button = QPushButton('ورود به کلاس' if status == 'live' else ('شروع کلاس' if status == 'approved' else 'در انتظار تأیید'))
                button.setEnabled(status in ('approved', 'live'))
                button.clicked.connect(lambda checked=False, cid=class_id: self.open_class(cid) if cid > 0 else None)
                self.table.setCellWidget(row, 6, button)

            if not rows:
                self.table.setRowCount(1)
                item = QTableWidgetItem('کلاسی برای این دبیر پیدا نشد.')
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(0, 0, item)
                self.table.setSpan(0, 0, 1, 7)

        except Exception as e:
            QMessageBox.critical(self, 'خطای کلاس‌ها', f'خطا در دریافت کلاس‌ها:\n\n{e}')
        finally:
            if conn:
                conn.close()

    # =====================================================
    # تبدیل وضعیت
    # =====================================================

    def status_text(
        self,
        status
    ):

        if status == "approved":
            return "تأیید شده"

        if status == "live":
            return "در حال برگزاری"

        if status == "finished":
            return "پایان یافته"

        if status == "pending":
            return "در انتظار تأیید"

        return status

    # =====================================================
    # باز کردن کلاس
    # =====================================================

    def open_class(
        self,
        class_id
    ):

        conn = None

        try:

            conn = sqlite3.connect(
                DATABASE_NAME
            )

            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    lesson,
                    teacher,
                    grade,
                    class_name,
                    status
                FROM online_classes
                WHERE id = ?
            """, (
                class_id,
            ))

            result = cursor.fetchone()

            if not result:

                QMessageBox.warning(
                    self,
                    "کلاس",
                    "کلاس موردنظر پیدا نشد."
                )

                return

            lesson = result[0] or "-"
            teacher = result[1] or "-"
            grade = result[2] or "-"
            class_name = result[3] or "-"
            status = result[4] or ""

            # =============================================
            # کلاس تأیید شده
            # =============================================

            if status == "approved":

                QMessageBox.information(
                    self,
                    "کلاس آنلاین",
                    f"""
کلاس: {lesson}

دبیر: {teacher}

پایه: {grade}

کلاس: {class_name}

این کلاس توسط مدیریت تأیید شده است.

برای شروع، دکمه «شروع کلاس انتخاب‌شده» را بزنید.
"""
                )

                return

            # =============================================
            # کلاس در حال برگزاری
            # =============================================

            if status == "live":

                QMessageBox.information(
                    self,
                    "کلاس آنلاین",
                    f"""
ورود به کلاس:

{lesson}

دبیر:
{teacher}

پایه:
{grade}

کلاس:
{class_name}

کلاس در حال برگزاری است.
"""
                )

                return

            QMessageBox.warning(
                self,
                "کلاس آنلاین",
                "این کلاس در وضعیت قابل ورود نیست."
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطای کلاس",
                str(e)
            )

        finally:

            if conn:
                conn.close()

    # =====================================================
    # شروع کلاس انتخاب شده
    # =====================================================

    def start_selected_class(self):

        row = self.table.currentRow()

        if row < 0:

            QMessageBox.warning(
                self,
                "شروع کلاس",
                "ابتدا یک کلاس رااز جدول انتخاب کنید."
            )

            return

        button = self.table.cellWidget(
            row,
            6
        )

        if not button:

            return

        self.open_class_from_row(
            row
        )

    # =====================================================
    # باز کردن کلاس از ردیف
    # =====================================================

    def open_class_from_row(
        self,
        row
    ):

        lesson_item = self.table.item(
            row,
            0
        )

        if not lesson_item:

            return

        lesson = lesson_item.text()

        conn = None

        try:

            conn = sqlite3.connect(
                DATABASE_NAME
            )

            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    id,
                    status
                FROM online_classes
                WHERE lesson = ?
                ORDER BY id DESC
                LIMIT 1
            """, (
                lesson,
            ))

            result = cursor.fetchone()

            if not result:

                QMessageBox.warning(
                    self,
                    "کلاس",
                    "شناسه کلاس پیدا نشد."
                )

                return

            class_id = result[0]
            status = result[1]

            if status == "approved":

                cursor.execute("""
                    UPDATE online_classes
                    SET status = 'live'
                    WHERE id = ?
                """, (
                    class_id,
                ))

                conn.commit()

                QMessageBox.information(
                    self,
                    "کلاس آنلاین",
                    "کلاس با موفقیت شروع شد و اکنون برای دبیر و دانش‌آموز قابل مشاهده است."
                )

                self.load_classes()

                return

            if status == "live":

                self.open_class(
                    class_id
                )

        except Exception as e:

            if conn:

                conn.rollback()

            QMessageBox.critical(
                self,
                "خطای شروع کلاس",
                str(e)
            )

        finally:

            if conn:
                conn.close()