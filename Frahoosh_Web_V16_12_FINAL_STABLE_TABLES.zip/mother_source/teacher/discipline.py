from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect,now
from .context import get_teacher_id
class DisciplinePage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); l=QVBoxLayout(self); l.addWidget(QLabel('انضباط دانش‌آموزان')); f=QFormLayout(); self.student=QComboBox(); self.title=QLineEdit(); self.desc=QTextEdit(); self.priority=QComboBox(); self.priority.addItems(['کم','متوسط','زیاد']); f.addRow('دانش‌آموز',self.student); f.addRow('عنوان',self.title); f.addRow('شرح',self.desc); f.addRow('اولویت',self.priority); l.addLayout(f); b=QPushButton('ثبت مورد انضباطی'); b.clicked.connect(self.add); l.addWidget(b); self.table=QTableWidget(); self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['شناسه','دانش‌آموز','عنوان','اولویت','وضعیت']); l.addWidget(self.table); self.load()
 def load(self):
  c=connect(); self.student.clear()
  for r in c.execute('SELECT id,first_name||" "||last_name FROM students ORDER BY last_name').fetchall(): self.student.addItem(r[1],r[0])
  rows=c.execute('SELECT d.id,s.first_name||" "||s.last_name,d.title,d.priority,d.status FROM discipline_records d JOIN students s ON s.id=d.student_id WHERE d.teacher_id=? ORDER BY d.id DESC',(get_teacher_id(),)).fetchall(); self.table.setRowCount(0)
  for r in rows:
   i=self.table.rowCount(); self.table.insertRow(i)
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
 def add(self):
  if self.student.currentData() is None or not self.title.text().strip(): return
  c=connect(); c.execute('INSERT INTO discipline_records(student_id,teacher_id,title,description,priority,status,created_at) VALUES(?,?,?,?,?,?,?)',(self.student.currentData(),get_teacher_id(),self.title.text(),self.desc.toPlainText(),self.priority.currentText(),'pending',now())); c.commit(); c.close(); self.load()
