import sqlite3
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLineEdit,QComboBox,QTimeEdit,QPushButton,QTableWidget,QTableWidgetItem,QLabel,QMessageBox,QCheckBox
from PySide6.QtCore import Qt,QTime
from utils.jalali import iso_to_jalali, jalali_to_iso
from database.db import DATABASE_NAME

def db():
    c=sqlite3.connect(DATABASE_NAME);c.row_factory=sqlite3.Row;return c

class ExamSchedulerPage(QWidget):
    def __init__(self,teacher_id=None,teacher_name='',parent=None):
        super().__init__(parent);self.teacher_id=teacher_id;self.teacher_name=teacher_name;self._ensure();self._build();self.load()
    def _ensure(self):
        with db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS teacher_exam_slots(
              id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,class_id INTEGER,class_name TEXT,
              exam_date_shamsi TEXT NOT NULL, start_time_shamsi TEXT NOT NULL,end_time_shamsi TEXT NOT NULL,
              coordinated INTEGER DEFAULT 0,secure_mode INTEGER DEFAULT 1,created_at_shamsi TEXT DEFAULT '')""");c.commit()
    def _build(self):
        l=QVBoxLayout(self);l.addWidget(QLabel('آزمون‌ها | زمان‌بندی اختصاصی کلاس‌ها'))
        f=QFormLayout();self.exam=QLineEdit();self.subject=QLineEdit();self.date=QLineEdit();self.date.setPlaceholderText('تاریخ شمسی 1405/06/04');self.cls=QComboBox();self._fill_classes()
        f.addRow('آزمون',self.exam);f.addRow('درس',self.subject);f.addRow('تاریخ',self.date);f.addRow('کلاس',self.cls);l.addLayout(f)
        self.coordinated=QCheckBox('برگزاری هماهنگ؛ همه کلاس‌ها در یک زمان');self.secure=QCheckBox('حالت آزمون امن؛ چت‌های داخل فراهوش مسدود');self.secure.setChecked(True);l.addWidget(self.coordinated);l.addWidget(self.secure)
        self.times=[]
        for i in range(3):
            row=QHBoxLayout();cb=QCheckBox(f'تایم {i+1}');cb.setChecked(i==0);st=QTimeEdit(QTime(8+i*2,0));en=QTimeEdit(QTime(8+i*2,45));row.addWidget(cb);row.addWidget(QLabel('شروع'));row.addWidget(st);row.addWidget(QLabel('پایان'));row.addWidget(en);self.times.append((cb,st,en));l.addLayout(row)
        b=QPushButton('ثبت برنامه آزمون');b.clicked.connect(self.save);l.addWidget(b)
        self.table=QTableWidget(0,8);self.table.setHorizontalHeaderLabels(['ID','کلاس','تاریخ شمسی','شروع','پایان','هماهنگ','امن','آزمون']);l.addWidget(self.table)
    def _fill_classes(self):
        with db() as c:
            q="SELECT id,class_name,subject FROM teacher_classes WHERE teacher_id=? ORDER BY class_name" if self.teacher_id else "SELECT id,class_name,subject FROM teacher_classes WHERE teacher_name=? ORDER BY class_name"
            rows=c.execute(q,(self.teacher_id,)).fetchall() if self.teacher_id else c.execute(q,(self.teacher_name,)).fetchall()
        self.cls.clear();self.cls.addItem('انتخاب کلاس',None)
        for r in rows:self.cls.addItem(f"{r['class_name']} | {r['subject'] or ''}",r['id'])
    def save(self):
        if not self.exam.text().strip() or not self.subject.text().strip() or not self.date.text().strip():return QMessageBox.warning(self,'آزمون','عنوان، درس و تاریخ الزامی است.')
        try:jalali_to_iso(self.date.text().strip())
        except Exception:return QMessageBox.warning(self,'تاریخ','تاریخ شمسی نامعتبر است.')
        active=[x for x in self.times if x[0].isChecked()]
        if not active:return QMessageBox.warning(self,'آزمون','حداقل یک تایم را انتخاب کنید.')
        now=iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
        with db() as c:
            if self.coordinated.isChecked():
                q="SELECT id,class_name FROM teacher_classes WHERE teacher_id=?" if self.teacher_id else "SELECT id,class_name FROM teacher_classes WHERE teacher_name=?"
                classes=c.execute(q,(self.teacher_id,)).fetchall() if self.teacher_id else c.execute(q,(self.teacher_name,)).fetchall()
                cb,st,en=active[0]
                for cl in classes:
                    c.execute('INSERT INTO teacher_exam_slots(quiz_id,class_id,class_name,exam_date_shamsi,start_time_shamsi,end_time_shamsi,coordinated,secure_mode,created_at_shamsi) VALUES(?,?,?,?,?,?,?,?,?)',(None,cl['id'],cl['class_name'],self.date.text().strip(),st.time().toString('HH:mm'),en.time().toString('HH:mm'),1,int(self.secure.isChecked()),now))
            else:
                cid=self.cls.currentData()
                if cid is None:return QMessageBox.warning(self,'کلاس','کلاس را از کشوی واقعی انتخاب کنید.')
                cname=self.cls.currentText().split('|')[0].strip()
                for cb,st,en in active:
                    c.execute('INSERT INTO teacher_exam_slots(quiz_id,class_id,class_name,exam_date_shamsi,start_time_shamsi,end_time_shamsi,coordinated,secure_mode,created_at_shamsi) VALUES(?,?,?,?,?,?,?,?,?)',(None,cid,cname,self.date.text().strip(),st.time().toString('HH:mm'),en.time().toString('HH:mm'),0,int(self.secure.isChecked()),now))
            c.commit()
        self.load()
    def load(self):
        with db() as c:rows=c.execute('SELECT id,class_name,exam_date_shamsi,start_time_shamsi,end_time_shamsi,coordinated,secure_mode,quiz_id FROM teacher_exam_slots ORDER BY id DESC').fetchall()
        self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[r['id'],r['class_name'],r['exam_date_shamsi'],r['start_time_shamsi'],r['end_time_shamsi'],'بله' if r['coordinated'] else 'خیر','فعال' if r['secure_mode'] else 'خاموش',r['quiz_id'] or '-']
            for j,v in enumerate(vals):self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
