import os,sqlite3
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QTableWidget,QTableWidgetItem,QMessageBox,QHeaderView,QTextEdit
from PySide6.QtCore import Qt
from services.online_class_service import OnlineClassService
from utils.jalali import iso_to_jalali
from .context import get_teacher_name, get_teacher_id
from ui.online_class_room import OnlineClassRoom
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))
def db(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

class OnlineClassesPage(QWidget):
    def __init__(self, teacher_name=None, parent=None):
        super().__init__(parent); self.teacher_name=teacher_name or get_teacher_name() or 'دبیر'; self.teacher_id=get_teacher_id(); self.room=None; self.setLayoutDirection(Qt.RightToLeft); self._build(); self.load()
    def _build(self):
        l=QVBoxLayout(self); bar=QHBoxLayout()
        self.refresh_button=QPushButton('تازه‌سازی کلاس‌ها'); self.refresh_button.setEnabled(True); self.refresh_button.clicked.connect(self.load); bar.addWidget(self.refresh_button)
        for text,slot in [('شروع کلاس',self.start),('ورود به کلاس',self.enter),('پایان کلاس',self.finish),('گزارش کامل',self.report),('تحلیل هوش مصنوعی',self.ai)]:
            b=QPushButton(text); b.clicked.connect(slot); bar.addWidget(b)
        l.addLayout(bar); self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(['شناسه','درس','پایه','کلاس','شروع شمسی','وضعیت','عملیات']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); l.addWidget(self.table); self.out=QTextEdit(); self.out.setReadOnly(True); l.addWidget(self.out)
    def load(self):
        self.table.setRowCount(0)
        rows=OnlineClassService.get_teacher_classes(self.teacher_name,self.teacher_id); self.table.setRowCount(len(rows));
        for i,r in enumerate(rows):
            vals=[r['id'],r['lesson'],r['grade'],r['class_name'],r['start_time'] or '-',r['status'],'']
            for j,v in enumerate(vals): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
        self.out.setPlainText('کلاس‌های مجازی متصل به شناسه دبیر در اینجا نمایش داده می‌شوند.')
    def cid(self):
        r=self.table.currentRow(); return int(self.table.item(r,0).text()) if r>=0 else None
    def start(self):
        cid=self.cid()
        if not cid:return
        row=OnlineClassService.get_class_by_id(cid)
        if not row or row['status']!='approved':
            QMessageBox.warning(self,'کلاس','فعال‌سازی این کلاس فقط توسط مدیر یا معاون اجرایی انجام می‌شود.'); return
        OnlineClassService.start_class(cid); self.load(); QMessageBox.information(self,'کلاس','کلاس فعال شد و برای دانش‌آموزان قابل ورود است.')
    def enter(self):
        cid=self.cid()
        if not cid:return
        if not OnlineClassService.is_class_live(cid):QMessageBox.warning(self,'کلاس','کلاس هنوز فعال نیست.');return
        self.room=OnlineClassRoom(class_id=cid,teacher_id=self.teacher_id,teacher_name=self.teacher_name,role='teacher'); self.room.show()
    def finish(self):
        cid=self.cid()
        if cid: OnlineClassService.finish_class(cid); self.load()
    def report(self):
        cid=self.cid()
        if not cid:return
        rows=OnlineClassService.get_class_report(cid); lines=['گزارش کامل کلاس مجازی','']
        for r in rows:lines.append(f"{r['student_name'] or r['student_id']} | ورود: {r['join_time'] or '-'} | خروج: {r['leave_time'] or '-'} | تأیید: {r['confirmed_checks'] or 0} | عدم تأیید: {r['missed_checks'] or 0}")
        self.out.setPlainText('\n'.join(lines))
    def ai(self):
        cid=self.cid()
        if not cid:return
        result=OnlineClassService.ai_analyze_class(cid); self.out.setPlainText('\n'.join(f"{x['student_name']} | سطح: {x['risk_level']} | {x['report']}" for x in result) or 'داده کافی برای تحلیل وجود ندارد.')
