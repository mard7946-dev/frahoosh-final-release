from PySide6.QtWidgets import *
from utils.shamsi_date_edit import ShamsiDateEdit
from PySide6.QtCore import Qt, QDate
from .db import connect,now
from .context import get_teacher_id
class MeetingsPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); l=QVBoxLayout(self); l.addWidget(QLabel('جلسات و ارتباط با والدین')); f=QFormLayout(); self.student=QComboBox(); self.reason=QLineEdit(); self.date=ShamsiDateEdit(); self.date.setCalendarPopup(True); self.date.setDate(QDate.currentDate()); f.addRow('دانش‌آموز',self.student); f.addRow('دلیل',self.reason); f.addRow('تاریخ',self.date); l.addLayout(f); b=QPushButton('ثبت درخواست جلسه'); b.clicked.connect(self.add); l.addWidget(b); self.table=QTableWidget(); self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['شناسه','دانش‌آموز','دلیل','تاریخ','وضعیت']); l.addWidget(self.table); self.load()
 def load(self):
  c=connect(); self.student.clear()
  for r in c.execute('SELECT id,first_name||" "||last_name FROM students ORDER BY last_name').fetchall(): self.student.addItem(r[1],r[0])
  rows=c.execute('SELECT m.id,s.first_name||" "||s.last_name,m.reason,m.meeting_date,m.status FROM parent_meetings m JOIN students s ON s.id=m.student_id WHERE m.teacher_id=? ORDER BY m.id DESC',(get_teacher_id(),)).fetchall(); self.table.setRowCount(0)
  for r in rows:
   i=self.table.rowCount(); self.table.insertRow(i)
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
 def add(self):
  sid=self.student.currentData(); tid=get_teacher_id()
  if sid is None or not self.reason.text().strip(): return
  if tid is None:
   QMessageBox.warning(self,'خطا','شناسه دبیر وارد نشده است. لطفاً از حساب دبیر وارد شوید.')
   return
  c=connect()
  try:
   s=c.execute('SELECT parent_phone FROM students WHERE id=?',(sid,)).fetchone()
   c.execute('INSERT INTO parent_meetings(student_id,teacher_id,parent_phone,reason,meeting_date,status,created_at) VALUES(?,?,?,?,?,?,?)',(sid,tid,s['parent_phone'] if s else '',self.reason.text().strip(),self.date.date().toString('yyyy-MM-dd'),'pending',now()))
   c.commit()
  except Exception:
   c.rollback(); raise
  finally:
   c.close()
  self.reason.clear(); self.load()
