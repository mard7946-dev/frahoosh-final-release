from __future__ import annotations
import os, sqlite3
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, 'school.db')

def connect():
    # One shared SQLite policy for all teacher pages: prevent transient locks
    # when several pages refresh/write around the same time.
    c = sqlite3.connect(DB, timeout=30.0)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA foreign_keys=ON')
    return c

def ensure():
    c = connect(); cur = c.cursor()
    cur.executescript('''
    CREATE TABLE IF NOT EXISTS teacher_quiz_links(
      id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_id INTEGER NOT NULL,
      token TEXT UNIQUE NOT NULL, expires_at TEXT, max_uses INTEGER DEFAULT 0,
      uses INTEGER DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS teacher_class_settings(
      class_id INTEGER PRIMARY KEY, allow_public_chat INTEGER DEFAULT 0,
      allow_student_audio INTEGER DEFAULT 0, allow_student_video INTEGER DEFAULT 0,
      capacity INTEGER DEFAULT 700, server_url TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS lesson_plans(
      id INTEGER PRIMARY KEY AUTOINCREMENT, teacher_id INTEGER, subject TEXT, grade TEXT,
      class_name TEXT, lesson_title TEXT, description TEXT, plan_date TEXT, status TEXT);
    CREATE TABLE IF NOT EXISTS teachers(
      id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT,
      national_code TEXT, phone TEXT, email TEXT, subject TEXT, grades TEXT,
      description TEXT);
    CREATE TABLE IF NOT EXISTS staff(
      id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT,
      role TEXT, phone TEXT, description TEXT);
    ''')
    # Columns used by the various teacher screens. Older databases may not have them.
    cols = {r[1] for r in cur.execute('PRAGMA table_info(teachers)').fetchall()}
    teacher_cols = {
        'personnel_code':'TEXT', 'mobile':'TEXT', 'lessons':'TEXT',
        'employment_status':'TEXT', 'source_staff_id':'INTEGER', 'photo':'TEXT'
    }
    for col, typ in teacher_cols.items():
        if col not in cols:
            cur.execute(f'ALTER TABLE teachers ADD COLUMN {col} {typ}')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_teachers_source_staff ON teachers(source_staff_id)')

    # The core bootstrap owns the canonical lesson_plans table.  Older teacher
    # code used lesson_title/description/plan_date while newer code uses
    # title/objective/content/session_date.  Keep both names synchronized so
    # either generation can read/write the same records.
    lp_cols = {r[1] for r in cur.execute('PRAGMA table_info(lesson_plans)').fetchall()}
    for col, typ in {
        'teacher_name':'TEXT', 'lesson_title':'TEXT', 'description':'TEXT',
        'plan_date':'TEXT', 'status':'TEXT', 'title':'TEXT', 'objective':'TEXT',
        'content':'TEXT', 'session_date':'TEXT'
    }.items():
        if col not in lp_cols:
            cur.execute(f'ALTER TABLE lesson_plans ADD COLUMN {col} {typ}')
    # Backfill the aliases once; subsequent writes keep both sets populated.
    cur.execute("UPDATE lesson_plans SET lesson_title=COALESCE(NULLIF(lesson_title,''),title), description=COALESCE(NULLIF(description,''),content), plan_date=COALESCE(NULLIF(plan_date,''),session_date), title=COALESCE(NULLIF(title,''),lesson_title), content=COALESCE(NULLIF(content,''),description), session_date=COALESCE(NULLIF(session_date,''),plan_date)")
    c.commit(); c.close()

def sync_staff_teachers():
    """Ensure staff records marked as teachers are visible in the teachers table.
    Also repairs records created before the staff↔teacher link was introduced.
    """
    c = connect()
    try:
        cols = {r[1] for r in c.execute('PRAGMA table_info(teachers)').fetchall()}
        for col, typ in {'lessons':'TEXT','mobile':'TEXT','personnel_code':'TEXT','source_staff_id':'INTEGER','employment_status':'TEXT','photo':'TEXT'}.items():
            if col not in cols:
                c.execute(f'ALTER TABLE teachers ADD COLUMN {col} {typ}')
        staff_cols = {r[1] for r in c.execute('PRAGMA table_info(staff)').fetchall()}
        # The executive module uses position; older records may use role.
        rows = c.execute('SELECT * FROM staff ORDER BY id').fetchall()
        for s in rows:
            data = dict(s)
            position = str(data.get('position') or data.get('role') or '').strip().lower()
            if not any(x in position for x in ('دبیر','معلم','teacher','استاد')):
                continue
            sid = data['id']
            existing = c.execute('SELECT id FROM teachers WHERE source_staff_id=? LIMIT 1', (sid,)).fetchone()
            if not existing:
                nc = str(data.get('national_code') or '').strip()
                phone = str(data.get('mobile') or data.get('phone') or '').strip()
                fn = str(data.get('first_name') or '').strip()
                ln = str(data.get('last_name') or '').strip()
                if nc:
                    existing = c.execute('SELECT id FROM teachers WHERE national_code=? LIMIT 1', (nc,)).fetchone()
                if not existing and phone:
                    existing = c.execute('SELECT id FROM teachers WHERE phone=? OR mobile=? LIMIT 1', (phone, phone)).fetchone()
                if not existing and (fn or ln):
                    existing = c.execute('SELECT id FROM teachers WHERE trim(first_name||" "||last_name)=? LIMIT 1', (f'{fn} {ln}'.strip(),)).fetchone()
            values = (
                data.get('first_name') or '', data.get('last_name') or '',
                data.get('national_code') or '', data.get('mobile') or data.get('phone') or '',
                data.get('email') or '', data.get('position') or data.get('role') or '',
                data.get('employment_status') or 'فعال', data.get('photo') or '', sid
            )
            if existing:
                c.execute('''UPDATE teachers SET first_name=?,last_name=?,national_code=?,phone=?,email=?,
                    subject=?,employment_status=?,photo=?,source_staff_id=? WHERE id=?''', values + (existing[0],))
            else:
                c.execute('''INSERT INTO teachers(first_name,last_name,national_code,phone,email,subject,
                    employment_status,photo,source_staff_id) VALUES(?,?,?,?,?,?,?,?,?)''', values)
        c.commit()
    finally:
        c.close()

def teacher_id(name: str|None):
    if not name: return None
    c=connect(); r=c.execute("SELECT id FROM teachers WHERE trim(first_name||' '||last_name)=? LIMIT 1",(name.strip(),)).fetchone(); c.close()
    return r['id'] if r else None

def now(): return datetime.now().isoformat(timespec='seconds')
