from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .context import get_teacher_id
from .db import connect
from services.grade_service import save_grade, ASSESSMENT_TYPES

class GradesPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build(); self.load()
    def build(self):
        l=QVBoxLayout(self); l.addWidget(QLabel('ثبت استاندارد نمرات | همه انواع ارزشیابی'))
        bar=QHBoxLayout()
        self.subject=QLineEdit(); self.subject.setPlaceholderText('درس')
        self.exam=QLineEdit(); self.exam.setPlaceholderText('عنوان ارزشیابی')
        self.kind=QComboBox(); self.kind.addItems(ASSESSMENT_TYPES)
        self.coeff=QDoubleSpinBox(); self.coeff.setRange(0.01,100); self.coeff.setValue(1); self.coeff.setDecimals(2)
        self.term=QLineEdit(); self.term.setPlaceholderText('نوبت/دوره')
        self.save=QPushButton('ذخیره نمرات'); self.save.clicked.connect(self.save_grades)
        self.refresh=QPushButton('تازه‌سازی'); self.refresh.clicked.connect(self.load)
        for x in (self.subject,self.exam,self.kind,self.coeff,self.term,self.save,self.refresh): bar.addWidget(x)
        l.addLayout(bar)
        self.table=QTableWidget(); self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(['شناسه','دانش‌آموز','کلاس','نمره','ضریب','توضیح','آخرین تاریخ']); l.addWidget(self.table)
    def load(self):
        tid=get_teacher_id(); c=connect()
        try:
            q="""SELECT s.id,s.first_name||' '||s.last_name,s.class_name,
                    COALESCE((SELECT sg.score FROM student_grades sg WHERE sg.student_id=s.id AND sg.teacher_id=? ORDER BY sg.id DESC LIMIT 1),''),
                    COALESCE((SELECT sg.coefficient FROM student_grades sg WHERE sg.student_id=s.id AND sg.teacher_id=? ORDER BY sg.id DESC LIMIT 1),1),
                    COALESCE((SELECT sg.description FROM student_grades sg WHERE sg.student_id=s.id AND sg.teacher_id=? ORDER BY sg.id DESC LIMIT 1),''),
                    COALESCE((SELECT sg.grade_date_shamsi FROM student_grades sg WHERE sg.student_id=s.id AND sg.teacher_id=? ORDER BY sg.id DESC LIMIT 1),'')
                    FROM students s ORDER BY s.class_name,s.last_name"""
            rows=c.execute(q,(tid,tid,tid,tid)).fetchall() if tid else c.execute("SELECT id,first_name||' '||last_name,class_name,'',1,'','' FROM students ORDER BY class_name,last_name").fetchall()
        finally: c.close()
        self.table.setRowCount(0)
        for r in rows:
            i=self.table.rowCount(); self.table.insertRow(i)
            for j,v in enumerate(r):
                w=QTableWidgetItem(str(v if v is not None else '')); w.setTextAlignment(Qt.AlignmentFlag.AlignCenter); self.table.setItem(i,j,w)
    def save_grades(self):
        if not self.subject.text().strip() or not self.exam.text().strip():
            QMessageBox.warning(self,'خطا','درس و عنوان ارزشیابی الزامی است.'); return
        tid=get_teacher_id(); saved=0
        for i in range(self.table.rowCount()):
            score=(self.table.item(i,3).text() if self.table.item(i,3) else '').strip()
            if not score: continue
            try: score=float(score)
            except ValueError: continue
            sid=int(self.table.item(i,0).text()); cls=self.table.item(i,2).text()
            desc=(self.table.item(i,5).text() if self.table.item(i,5) else '').strip()
            try:
                save_grade(sid,tid,self.subject.text().strip(),cls,self.kind.currentText(),self.exam.text().strip(),
                           score,self.coeff.value(),self.term.text().strip(),desc); saved+=1
            except Exception as e:
                QMessageBox.critical(self,'خطای ذخیره',str(e)); return
        QMessageBox.information(self,'انجام شد',f'{saved} نمره در student_grades ذخیره شد و برای کارنامه آماده است.'); self.load()
