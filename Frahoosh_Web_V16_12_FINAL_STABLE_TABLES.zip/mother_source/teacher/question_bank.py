from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect, now
from .context import get_teacher_name
class QuestionBankPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build(); self.load()
 def build(self):
  l=QVBoxLayout(self); l.addWidget(QLabel('بانک سوالات'))
  f=QFormLayout(); self.question=QTextEdit(); self.a=QLineEdit(); self.b=QLineEdit(); self.c=QLineEdit(); self.d=QLineEdit(); self.correct=QComboBox(); self.correct.addItems(['1','2','3','4']); f.addRow('سوال',self.question); f.addRow('گزینه ۱',self.a); f.addRow('گزینه ۲',self.b); f.addRow('گزینه ۳',self.c); f.addRow('گزینه ۴',self.d); f.addRow('پاسخ صحیح',self.correct); l.addLayout(f)
  b=QHBoxLayout(); s=QPushButton('ثبت سوال'); s.clicked.connect(self.save); d=QPushButton('حذف سوال'); d.clicked.connect(self.delete); b.addWidget(s); b.addWidget(d); l.addLayout(b)
  self.table=QTableWidget(); self.table.setColumnCount(6); self.table.setHorizontalHeaderLabels(['شناسه','سوال','۱','۲','۳','۴']); l.addWidget(self.table)
 def load(self):
  c=connect(); rows=c.execute('SELECT id,question,option1,option2,option3,option4 FROM quiz_questions ORDER BY id DESC').fetchall(); self.table.setRowCount(0)
  for r in rows:
   i=self.table.rowCount(); self.table.insertRow(i)
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
 def save(self):
  q=self.question.toPlainText().strip()
  if not q: QMessageBox.warning(self,'خطا','متن سوال الزامی است.'); return
  c=connect(); c.execute('INSERT INTO quiz_questions(quiz_id,question,option1,option2,option3,option4,correct_answer) VALUES(?,?,?,?,?,?,?)',(None,q,self.a.text(),self.b.text(),self.c.text(),self.d.text(),self.correct.currentText())); c.commit(); c.close(); self.load(); self.question.clear()
 def delete(self):
  r=self.table.currentRow()
  if r<0:return
  c=connect(); c.execute('DELETE FROM quiz_questions WHERE id=?',(int(self.table.item(r,0).text()),)); c.commit(); c.close(); self.load()
