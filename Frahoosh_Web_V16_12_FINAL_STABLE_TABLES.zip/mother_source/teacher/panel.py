from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel,QPushButton,QGridLayout,QStackedWidget,QHBoxLayout
from PySide6.QtCore import Qt
from .db import ensure, sync_staff_teachers
from .context import set_teacher
from .classes import ClassesPage
from .assignments import AssignmentsPage
from .exams import ExamsPage
from .question_bank import QuestionBankPage
from .reports import ReportsPage
from .calendar import CalendarPage
from .meetings import MeetingsPage
from .grades import GradesPage
from .discipline import DisciplinePage
from .lesson_plan import LessonPlanPage
from .profile import ProfilePage
from .teacher_list import TeacherListPage
from .online_classes import OnlineClassesPage

class Panel(QWidget):
 def __init__(self,parent=None, teacher_name=None):
  super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); ensure(); sync_staff_teachers(); name=teacher_name or ''
  p=parent
  while p is not None:
   if getattr(p,'username',None): name=p.username; break
   p=p.parent() if hasattr(p,'parent') else None
  set_teacher(name=name); self.teacher_name=__import__('teacher.context',fromlist=['get_teacher_name']).get_teacher_name(); self.pages={}; self.init_ui()
 def init_ui(self):
  l=QVBoxLayout(self); title=QLabel('پنل هوشمند دبیران فراهوش'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setStyleSheet('font-size:24px;font-weight:bold;color:#1565C0;padding:8px'); l.addWidget(title)
  self.stack=QStackedWidget(); menu=QGridLayout(); pages=[('کلاس‌ها','classes',ClassesPage()),('تکالیف','assignments',AssignmentsPage()),('آزمون آنلاین','exams',ExamsPage()),('بانک سوالات','question_bank',QuestionBankPage()),('کلاس مجازی','online_classes',OnlineClassesPage(teacher_name=self.teacher_name)),('نمرات','grades',GradesPage()),('طرح درس','lesson_plan',LessonPlanPage()),('برنامه','calendar',CalendarPage()),('جلسات والدین','meetings',MeetingsPage()),('انضباط','discipline',DisciplinePage()),('گزارشات','reports',ReportsPage()),('پروفایل','profile',ProfilePage()),('لیست دبیران','teacher_list',TeacherListPage())]
  for i,(txt,key,page) in enumerate(pages):
   self.pages[key]=page; self.stack.addWidget(page); b=QPushButton(txt); b.setMinimumSize(125,44); b.setMaximumHeight(50); b.clicked.connect(lambda _,k=key:self.open_page(k)); menu.addWidget(b,i//6,i%6)
  l.addLayout(menu); l.addWidget(self.stack,1); self.stack.setCurrentIndex(0)
 def open_page(self,key):
  if key in self.pages:self.stack.setCurrentWidget(self.pages[key])
