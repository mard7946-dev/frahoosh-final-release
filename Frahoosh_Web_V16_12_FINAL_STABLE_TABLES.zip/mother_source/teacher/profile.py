from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect
from .context import get_teacher_id,get_teacher_name
class ProfilePage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build(); self.load()
 def build(self):
  l=QVBoxLayout(self); l.addWidget(QLabel('پروفایل دبیر'))
  f=QFormLayout(); self.fields={}
  for k,label in [('first_name','نام'),('last_name','نام خانوادگی'),('national_code','کد ملی'),('phone','موبایل'),('email','ایمیل'),('subject','درس'),('grades','پایه‌ها'),('description','توضیحات')]: self.fields[k]=QLineEdit(); f.addRow(label,self.fields[k])
  l.addLayout(f); b=QHBoxLayout(); save=QPushButton('ذخیره پروفایل'); refresh=QPushButton('تازه‌سازی'); b.addWidget(save);b.addWidget(refresh);l.addLayout(b); save.clicked.connect(self.save);refresh.clicked.connect(self.load)
  self.status=QLabel(); l.addWidget(self.status)
 def load(self):
  tid=get_teacher_id();
  if not tid:self.status.setText(f'دبیر فعال: {get_teacher_name() or "شناسه دبیر تنظیم نشده"}');return
  c=connect(); r=c.execute('SELECT first_name,last_name,national_code,phone,email,subject,grades,description FROM teachers WHERE id=?',(tid,)).fetchone();c.close()
  if r:
   for k,v in zip(self.fields,r):self.fields[k].setText(str(v or ''))
   self.status.setText('اطلاعات پروفایل بارگذاری شد.')
 def save(self):
  tid=get_teacher_id()
  if not tid:QMessageBox.warning(self,'پروفایل','شناسه دبیر مشخص نیست.');return
  c=connect(); c.execute('UPDATE teachers SET first_name=?,last_name=?,national_code=?,phone=?,email=?,subject=?,grades=?,description=? WHERE id=?',tuple(self.fields[k].text().strip() for k in self.fields)+(tid,));c.commit();c.close();self.status.setText('پروفایل با موفقیت ذخیره شد.')
