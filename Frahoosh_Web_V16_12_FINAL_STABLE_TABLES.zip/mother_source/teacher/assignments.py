from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from .db import connect,now
from .context import get_teacher_id
class AssignmentsPage(QWidget):
 def __init__(self,parent=None): super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.build(); self.load()
 def build(self):
  l=QVBoxLayout(self); l.addWidget(QLabel('مدیریت تکالیف'))
  f=QFormLayout(); self.student=QComboBox(); self.title=QLineEdit(); self.desc=QTextEdit(); self.status=QComboBox(); self.status.addItems(['active','finished']); f.addRow('دانش‌آموز',self.student); f.addRow('عنوان',self.title); f.addRow('توضیحات',self.desc); f.addRow('وضعیت',self.status); l.addLayout(f)
  b=QHBoxLayout(); a=QPushButton('ثبت تکلیف'); a.clicked.connect(self.add); d=QPushButton('حذف'); d.clicked.connect(self.delete); r=QPushButton('تازه‌سازی'); r.clicked.connect(self.load); b.addWidget(a); b.addWidget(d); b.addWidget(r); l.addLayout(b); self.table=QTableWidget(); self.table.setColumnCount(5); self.table.setHorizontalHeaderLabels(['شناسه','دانش‌آموز','عنوان','وضعیت','تاریخ']); l.addWidget(self.table)
 def load(self):
  c=connect(); self.student.clear(); self.student.addItem('همه دانش‌آموزان',0)
  for r in c.execute('SELECT id,first_name||" "||last_name FROM students ORDER BY last_name').fetchall(): self.student.addItem(r[1],r[0])
  rows=c.execute('SELECT a.id,COALESCE(s.first_name||" "||s.last_name,"همه"),a.title,a.status,a.created_at FROM assignments a LEFT JOIN students s ON s.id=a.student_id WHERE a.teacher_id=? ORDER BY a.id DESC',(get_teacher_id(),)).fetchall(); self.table.setRowCount(0)
  for r in rows:
   i=self.table.rowCount(); self.table.insertRow(i)
   for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or '')))
  c.close()
 def add(self):
  if not self.title.text().strip(): QMessageBox.warning(self,'خطا','عنوان الزامی است.'); return
  try:
   sid=self.student.currentData(); sid=None if sid in (None,0) else int(sid)
   from ui.audience_selector import AudienceSelectorDialog
   defaults=[('student',str(sid)),('student_parents',str(sid))] if sid is not None else [('school_students',''),('school_parents','')]
   defaults += [('manager',''),('vice',''),('teacher','')]
   d=AudienceSelectorDialog(self,defaults)
   if not d.exec(): return
   from services.audience_service import begin_capture,end_capture
   c=connect()
   begin_capture('assignments',d.targets(),c)
   c.execute('INSERT INTO assignments(student_id,teacher_id,title,description,status,created_at) VALUES(?,?,?,?,?,?)',(sid,get_teacher_id(),self.title.text().strip(),self.desc.toPlainText(),self.status.currentText(),now()))
   c.commit(); end_capture('assignments')
  except Exception:
   try:
    c.rollback()
   except Exception: pass
   try: from services.audience_service import end_capture; end_capture('assignments')
   except Exception: pass
   raise
  finally:
   try: c.close()
   except Exception: pass
  self.title.clear(); self.desc.clear(); self.load()
 def delete(self):
  r=self.table.currentRow()
  if r<0:return
  c=connect(); c.execute('DELETE FROM assignments WHERE id=? AND teacher_id=?',(int(self.table.item(r,0).text()),get_teacher_id())); c.commit(); c.close(); self.load()
