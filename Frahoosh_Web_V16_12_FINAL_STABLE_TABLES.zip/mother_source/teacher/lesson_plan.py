from PySide6.QtWidgets import *
from utils.shamsi_date_edit import ShamsiDateEdit
from PySide6.QtCore import Qt, QDate
from .db import connect, now, ensure
from .context import get_teacher_id, get_teacher_name

class LessonPlanPage(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); ensure(); self.build(); self.load()
    def build(self):
        l=QVBoxLayout(self); l.addWidget(QLabel("طرح درس"))
        f=QFormLayout(); self.subject=QLineEdit(); self.grade=QLineEdit(); self.cls=QLineEdit(); self.title=QLineEdit(); self.desc=QTextEdit(); self.date=ShamsiDateEdit(); self.date.setCalendarPopup(True); self.date.setDate(QDate.currentDate())
        for label,w in [("درس",self.subject),("پایه",self.grade),("کلاس",self.cls),("عنوان جلسه",self.title),("توضیحات",self.desc),("تاریخ",self.date)]: f.addRow(label,w)
        l.addLayout(f); b=QPushButton("ثبت طرح درس"); b.clicked.connect(self.save); l.addWidget(b)
        self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(["شناسه","درس","پایه","کلاس","عنوان","تاریخ"]); l.addWidget(self.table)
    def load(self):
        c=connect(); tid=get_teacher_id();
        if tid:
            rows=c.execute("SELECT id,subject,grade,class_name,COALESCE(NULLIF(title,''),lesson_title),COALESCE(NULLIF(session_date,''),plan_date) FROM lesson_plans WHERE teacher_id=? ORDER BY id DESC",(tid,)).fetchall()
        else: rows=[]
        self.table.setRowCount(0)
        for r in rows:
            i=self.table.rowCount(); self.table.insertRow(i)
            for j,v in enumerate(r): self.table.setItem(i,j,QTableWidgetItem(str(v or "")))
        c.close()
    def save(self):
        tid=get_teacher_id()
        if not tid:
            QMessageBox.warning(self,"طرح درس","حساب دبیر به رکورد دبیران متصل نیست."); return
        title=self.title.text().strip(); subject=self.subject.text().strip()
        if not title or not subject:
            QMessageBox.warning(self,"طرح درس","درس و عنوان جلسه الزامی است."); return
        plan_date=self.date.date().toString("yyyy-MM-dd"); desc=self.desc.toPlainText().strip(); name=get_teacher_name()
        c=connect(); c.execute("INSERT INTO lesson_plans(teacher_id,teacher_name,subject,grade,class_name,title,objective,content,session_date,lesson_title,description,plan_date,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(tid,name,subject,self.grade.text().strip(),self.cls.text().strip(),title,"",desc,plan_date,title,desc,plan_date,"active",now())); c.commit(); c.close(); self.load()
