from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox
from PySide6.QtCore import Qt
from .db import connect, ensure, sync_staff_teachers
from .context import set_teacher


class TeacherListPage(QWidget):
    """Operational teacher list for the teacher panel: search, refresh and open a selected teacher profile."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.RightToLeft)
        ensure()
        self.build()
        self.load()

    def build(self):
        layout = QVBoxLayout(self)
        title = QLabel('لیست دبیران')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet('font-size:20px;font-weight:bold;padding:8px;')
        layout.addWidget(title)

        tools = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText('جستجوی نام، نام خانوادگی، کد ملی یا درس...')
        tools.addWidget(self.search, 1)
        refresh = QPushButton('تازه‌سازی')
        refresh.clicked.connect(self.load)
        tools.addWidget(refresh)
        open_profile = QPushButton('پروفایل دبیر منتخب')
        open_profile.clicked.connect(self.open_selected)
        tools.addWidget(open_profile)
        layout.addLayout(tools)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(['شناسه', 'نام', 'نام خانوادگی', 'کد ملی', 'درس', 'وضعیت'])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(lambda _: self.open_selected())
        layout.addWidget(self.table, 1)
        self.status = QLabel()
        layout.addWidget(self.status)
        self.search.textChanged.connect(self.load)

    def load(self):
        term = self.search.text().strip() if hasattr(self, 'search') else ''
        sync_staff_teachers()
        c = connect()
        try:
            if term:
                like = f'%{term}%'
                rows = c.execute('''SELECT id, first_name, last_name, national_code,
                    COALESCE(subject, lessons, "") AS subject, COALESCE(employment_status, "فعال")
                    FROM teachers
                    WHERE first_name LIKE ? OR last_name LIKE ? OR national_code LIKE ?
                       OR subject LIKE ? OR lessons LIKE ?
                    ORDER BY last_name, first_name''', (like, like, like, like, like)).fetchall()
            else:
                rows = c.execute('''SELECT id, first_name, last_name, national_code,
                    COALESCE(subject, lessons, "") AS subject, COALESCE(employment_status, "فعال")
                    FROM teachers ORDER BY last_name, first_name''').fetchall()
        except Exception as e:
            self.table.setRowCount(0)
            self.status.setText(f'خطا در دریافت لیست دبیران: {e}')
            c.close()
            return
        c.close()
        self.table.setRowCount(0)
        for row in rows:
            r = self.table.rowCount()
            self.table.insertRow(r)
            for col, value in enumerate(row):
                self.table.setItem(r, col, QTableWidgetItem(str(value or '')))
        self.status.setText(f'{len(rows)} دبیر در لیست نمایش داده شد.')

    def open_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'لیست دبیران', 'لطفاً یک دبیر را انتخاب کنید.')
            return
        tid = int(self.table.item(row, 0).text())
        c = connect()
        rec = c.execute('SELECT first_name, last_name FROM teachers WHERE id=?', (tid,)).fetchone()
        c.close()
        if not rec:
            QMessageBox.warning(self, 'لیست دبیران', 'رکورد دبیر پیدا نشد.')
            return
        set_teacher(name=f'{rec[0] or ""} {rec[1] or ""}'.strip(), tid=tid)
        parent = self.parentWidget()
        while parent is not None:
            pages = getattr(parent, 'pages', None)
            if isinstance(pages, dict) and 'profile' in pages:
                pages['profile'].load()
                if hasattr(parent, 'open_page'):
                    parent.open_page('profile')
                return
            parent = parent.parentWidget() if hasattr(parent, 'parentWidget') else None
