# ============================================================
# Smart Board Database - Frahoosh
# دیتابیس تابلو هوشمند فراهوش
# ============================================================

from datetime import datetime

from database.db import get_connection


# ============================================================
# ساخت جداول تابلو هوشمند
# ============================================================

def create_smart_board_tables():

    conn = get_connection()

    cursor = conn.cursor()


    # ========================================================
    # اطلاعیه های مدرسه
    # ========================================================

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS smart_board_messages (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,

            message TEXT NOT NULL,

            priority TEXT DEFAULT 'normal',

            publish_date TEXT,

            created_by TEXT

        )
        """
    )


    # ========================================================
    # پیام های انگیزشی
    # ========================================================

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS daily_motivations (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            message TEXT NOT NULL,

            show_date TEXT

        )
        """
    )


    # ========================================================
    # روزشمارها
    # ========================================================

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS school_countdowns (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,

            target_date TEXT NOT NULL,

            description TEXT

        )
        """
    )


    # ========================================================
    # مناسبت ها و رویدادهای مدرسه
    # ========================================================

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS smart_board_school_events (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            event_date TEXT NOT NULL,

            title TEXT NOT NULL,

            description TEXT

        )
        """
    )


    # Never reuse the unified school_events table; that table belongs to the
    # cross-panel event hub. Migrate legacy smart-board rows when the old
    # dedicated table exists and the unified table is already in use.
    try:
        legacy_cols = [r[1] for r in cursor.execute("PRAGMA table_info(school_events)").fetchall()]
        if legacy_cols and "event_date" in legacy_cols and "description" in legacy_cols:
            cursor.execute("""CREATE TABLE IF NOT EXISTS smart_board_school_events(
                id INTEGER PRIMARY KEY AUTOINCREMENT, event_date TEXT NOT NULL,
                title TEXT NOT NULL, description TEXT
            )""")
            cursor.execute("""INSERT OR IGNORE INTO smart_board_school_events(id,event_date,title,description)
                              SELECT id,event_date,title,description FROM school_events""")
    except Exception:
        pass

    conn.commit()

    conn.close()


# ============================================================
# ثبت اطلاعیه
# ============================================================

def add_message(
    title,
    message,
    priority="normal",
    publish_date="",
    created_by=""
):

    conn = get_connection()

    cursor = conn.cursor()


    if not publish_date:

        publish_date = datetime.now().strftime(
            "%Y-%m-%d"
        )


    cursor.execute(
        """
        INSERT INTO smart_board_messages
        (
            title,
            message,
            priority,
            publish_date,
            created_by
        )

        VALUES (?, ?, ?, ?, ?)
        """,
        (
            title,
            message,
            priority,
            publish_date,
            created_by
        )
    )


    conn.commit()

    conn.close()


# ============================================================
# دریافت اطلاعیه ها
# ============================================================

def get_messages():

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        SELECT
            id,
            title,
            message,
            priority,
            publish_date,
            created_by

        FROM smart_board_messages

        ORDER BY id DESC
        """
    )


    rows = cursor.fetchall()

    conn.close()


    return rows


# ============================================================
# حذف اطلاعیه
# ============================================================

def delete_message(
    message_id
):

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        DELETE FROM smart_board_messages

        WHERE id = ?
        """,
        (
            message_id,
        )
    )


    conn.commit()

    conn.close()# ============================================================
# ثبت روزشمار
# ============================================================

def add_countdown(
    title,
    target_date,
    description=""
):

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        INSERT INTO school_countdowns
        (
            title,
            target_date,
            description
        )

        VALUES (?, ?, ?)
        """,
        (
            title,
            target_date,
            description
        )
    )


    conn.commit()

    conn.close()


# ============================================================
# دریافت همه روزشمارها
# ============================================================

def get_countdowns():

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        SELECT
            id,
            title,
            target_date,
            description

        FROM school_countdowns

        ORDER BY target_date ASC
        """
    )


    rows = cursor.fetchall()

    conn.close()


    return rows


# ============================================================
# حذف روزشمار
# ============================================================

def delete_countdown(
    countdown_id
):

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        DELETE FROM school_countdowns

        WHERE id = ?
        """,
        (
            countdown_id,
        )
    )


    conn.commit()

    conn.close()


# ============================================================
# ثبت مناسبت مدرسه
# ============================================================

def add_school_event(
    event_date,
    title,
    description=""
):

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        INSERT INTO smart_board_school_events
        (
            event_date,
            title,
            description
        )

        VALUES (?, ?, ?)
        """,
        (
            event_date,
            title,
            description
        )
    )


    conn.commit()

    conn.close()


# ============================================================
# دریافت مناسبت ها
# ============================================================

def get_school_events():

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        SELECT
            id,
            event_date,
            title,
            description

        FROM smart_board_school_events

        ORDER BY event_date ASC
        """
    )


    rows = cursor.fetchall()

    conn.close()


    return rows


# ============================================================
# حذف مناسبت
# ============================================================

def delete_school_event(
    event_id
):

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        DELETE FROM smart_board_school_events

        WHERE id = ?
        """,
        (
            event_id,
        )
    )


    conn.commit()

    conn.close()# ============================================================
# آمار کلی سامانه
# ============================================================

def get_system_statistics():

    conn = get_connection()

    cursor = conn.cursor()


    statistics = {}


    # ========================================================
    # تعداد کاربران
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM users
        """
    )

    statistics["users"] = cursor.fetchone()[0]


    # ========================================================
    # تعداد دانش آموزان
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM students
        """
    )

    statistics["students"] = cursor.fetchone()[0]


    # ========================================================
    # تعداد دبیران
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM teachers
        """
    )

    statistics["teachers"] = cursor.fetchone()[0]


    # ========================================================
    # تعداد کارکنان
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM staff
        """
    )

    statistics["staff"] = cursor.fetchone()[0]


    conn.close()


    return statistics


# ============================================================
# تبدیل تاریخ شمسی به عدد قابل مقایسه
# ============================================================

def _jalali_to_number(
    date_text
):

    try:

        parts = str(
            date_text
        ).strip().split("/")


        if len(parts) != 3:

            return None


        year = int(parts[0])

        month = int(parts[1])

        day = int(parts[2])


        return (
            year * 10000
            + month * 100
            + day
        )

    except Exception:

        return None


# ============================================================
# دریافت نزدیک ترین رویداد
# ============================================================

def get_next_event():

    conn = get_connection()

    cursor = conn.cursor()


    cursor.execute(
        """
        SELECT
            id,
            event_date,
            title,
            description

        FROM smart_board_school_events
        """
    )


    events = cursor.fetchall()


    cursor.execute(
        """
        SELECT
            id,
            title,
            target_date,
            description

        FROM school_countdowns
        """
    )


    countdowns = cursor.fetchall()


    conn.close()


    # ========================================================
    # تاریخ امروز شمسی
    # ========================================================

    try:

        from smart_board.calendar import (
            get_today_info
        )

        info = get_today_info()

        today_text = info["shamsi"]


        # استخراج تاریخ از متن شمسی
        #
        # مثال:
        # سه‌شنبه 20 مرداد 1405
        #
        # برای مقایسه، از jdatetime استفاده می‌کنیم.

        import jdatetime

        today = jdatetime.date.today()

        today_number = (
            today.year * 10000
            + today.month * 100
            + today.day
        )

    except Exception:

        today_number = None


    candidates = []


    # ========================================================
    # بررسی مناسبت ها
    # ========================================================

    for item in events:

        event_id = item[0]

        event_date = item[1]

        title = item[2]

        description = item[3]


        event_number = _jalali_to_number(
            event_date
        )


        if (
            event_number is None
            or today_number is None
        ):

            continue


        days_remaining = (
            event_number - today_number
        )


        if days_remaining >= 0:

            candidates.append({
                    "id": event_id,

                    "title": title,

                    "date": event_date,

                    "description": description or "",

                    "days_remaining": days_remaining,

                    "type": "event"
                }
            )


    # ========================================================
    # بررسی روزشمارها
    # ========================================================

    for item in countdowns:

        countdown_id = item[0]

        title = item[1]

        target_date = item[2]

        description = item[3]


        target_number = _jalali_to_number(
            target_date
        )


        if (
            target_number is None
            or today_number is None
        ):

            continue


        days_remaining = (
            target_number - today_number
        )


        if days_remaining >= 0:

            candidates.append(
                {
                    "id": countdown_id,

                    "title": title,

                    "date": target_date,

                    "description": description or "",

                    "days_remaining": days_remaining,

                    "type": "countdown"
                }
            )


    # ========================================================
    # هیچ رویداد آینده ای وجود ندارد
    # ========================================================

    if not candidates:

        return None


    # ========================================================
    # نزدیک ترین رویداد
    # ========================================================

    candidates.sort(
        key=lambda x: x["days_remaining"]
    )


    return candidates[0]