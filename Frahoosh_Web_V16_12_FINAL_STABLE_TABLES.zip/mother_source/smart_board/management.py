# ============================================================
# Smart Board Management - Frahoosh
# مدیریت تابلو هوشمند فراهوش
# ============================================================

from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QFrame,
    QLineEdit,
    QTextEdit,
    QComboBox,
    QTableWidget,
    QTableWidgetItem,
    QMessageBox,
    QHeaderView,
    QAbstractItemView,
    QTabWidget,
)

from PySide6.QtCore import Qt

from PySide6.QtGui import QFont


# ============================================================
# Database
# ============================================================

from smart_board.smart_board_db import (
    add_message,
    get_messages,
    delete_message,
    add_countdown,
    get_countdowns,
    delete_countdown,
    add_school_event,
    get_school_events,
    delete_school_event,
)


# ============================================================
# صفحه مدیریت تابلو هوشمند
# ============================================================

class SmartBoardManagement(QWidget):

    def __init__(
        self,
        parent=None
    ):

        super().__init__(
            parent
        )

        self.setLayoutDirection(
            Qt.RightToLeft
        )

        self.init_ui()

        self.load_all_data()


    # ========================================================
    # رابط کاربری
    # ========================================================

    def init_ui(
        self
    ):

        main_layout = QVBoxLayout(
            self
        )

        main_layout.setSpacing(
            15
        )

        main_layout.setContentsMargins(
            20,
            20,
            20,
            20
        )


        # ====================================================
        # نوار بالایی
        # ====================================================

        top_layout = QHBoxLayout()

        top_layout.setSpacing(
            15
        )


        # ====================================================
        # دکمه بازگشت
        # ====================================================

        back_btn = QPushButton(
            "⬅️  بازگشت به تابلو هوشمند"
        )

        back_btn.setMinimumSize(
            220,
            50
        )

        back_btn.setMaximumWidth(
            270
        )

        back_btn.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        back_btn.clicked.connect(
            self.close
        )

        self.apply_button_style(
            back_btn
        )

        top_layout.addWidget(
            back_btn
        )


        # ====================================================
        # عنوان
        # ====================================================

        title = QLabel(
            "مدیریت تابلو هوشمند فراهوش"
        )

        title.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        title.setFont(
            QFont(
                "B Zar",
                24,
                QFont.Bold
            )
        )

        top_layout.addWidget(
            title,
            1
        )

        top_layout.addSpacing(
            270
        )

        main_layout.addLayout(
            top_layout
        )


        # ====================================================
        # توضیح
        # ====================================================

        description = QLabel(
            "مدیریت اطلاعیه‌ها، روزشمار آزمون‌ها، "
            "امتحانات و مناسبت‌های مدرسه"
        )

        description.setAlignment(
            Qt.AlignmentFlag.AlignCenter
        )

        description.setFont(
            QFont(
                "B Zar",
                13
            )
        )

        main_layout.addWidget(
            description
        )


        # ====================================================
        # تب ها
        # ====================================================

        self.tabs = QTabWidget()

        self.tabs.setFont(QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )


        # ====================================================
        # تب اطلاعیه
        # ====================================================

        self.messages_tab = (
            self.create_messages_tab()
        )

        self.tabs.addTab(
            self.messages_tab,
            "📢 اطلاعیه‌های مدرسه"
        )


        # ====================================================
        # تب روزشمار
        # ====================================================

        self.countdowns_tab = (
            self.create_countdowns_tab()
        )

        self.tabs.addTab(
            self.countdowns_tab,
            "⏳ روزشمار آزمون‌ها و امتحانات"
        )


        # ====================================================
        # تب مناسبت
        # ====================================================

        self.events_tab = (
            self.create_events_tab()
        )

        self.tabs.addTab(
            self.events_tab,
            "🎉 مناسبت‌ها و رویدادها"
        )


        main_layout.addWidget(
            self.tabs
        )


        # ====================================================
        # دکمه پایین
        # ====================================================

        bottom_layout = QHBoxLayout()

        bottom_layout.setSpacing(
            10
        )


        refresh_btn = QPushButton(
            "🔄 تازه‌سازی اطلاعات تابلو"
        )

        refresh_btn.setMinimumHeight(
            45
        )

        refresh_btn.clicked.connect(
            self.load_all_data
        )

        self.apply_button_style(
            refresh_btn
        )

        bottom_layout.addWidget(
            refresh_btn
        )

        main_layout.addLayout(
            bottom_layout
        )


    # ========================================================
    # تب اطلاعیه ها
    # ========================================================

    def create_messages_tab(
        self
    ):

        widget = QWidget()

        layout = QVBoxLayout(
            widget
        )

        layout.setSpacing(
            12
        )


        # ====================================================
        # فرم ثبت اطلاعیه
        # ====================================================

        form = QFrame()

        form.setStyleSheet(
            """
            QFrame {

                background: #FFE0B2;

                border: 2px solid #F57C00;

                border-radius: 12px;

                padding: 10px;

            }
            """
        )

        form_layout = QGridLayout(
            form
        )


        title_label = QLabel(
            "عنوان اطلاعیه:"
        )

        title_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.message_title = QLineEdit()

        self.message_title.setPlaceholderText(
            "مثلاً: زمان برگزاری امتحان ریاضی"
        )


        message_label = QLabel(
            "متن اطلاعیه:"
        )

        message_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.message_text = QTextEdit()

        self.message_text.setPlaceholderText(
            "متن اطلاعیه را وارد کنید..."
        )

        self.message_text.setMinimumHeight(
            90
        )


        priority_label = QLabel(
            "اولویت:"
        )

        priority_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.message_priority = QComboBox()

        self.message_priority.addItems(
            [
                "normal",
                "important",
                "urgent"
            ]
        )


        add_btn = QPushButton(
            "➕ ثبت اطلاعیه"
        )

        add_btn.setMinimumHeight(
            40
        )

        add_btn.clicked.connect(
            self.add_message_clicked
        )

        self.apply_button_style(
            add_btn
        )


        form_layout.addWidget(
            title_label,
            0,
            0
        )

        form_layout.addWidget(
            self.message_title,
            0,
            1
        )

        form_layout.addWidget(
            priority_label,
            0,
            2
        )

        form_layout.addWidget(
            self.message_priority,
            0,
            3
        )

        form_layout.addWidget(
            message_label,
            1,
            0
        )

        form_layout.addWidget(
            self.message_text,
            1,
            1,
            1,
            3
        )

        form_layout.addWidget(
            add_btn,
            2,
            0,
            1,
            4
        )


        layout.addWidget(
            form
        )


        # ====================================================
        # جدول اطلاعیه ها
        # ====================================================

        self.messages_table = QTableWidget()

        self.messages_table.setColumnCount(
            5
        )

        self.messages_table.setHorizontalHeaderLabels(
            [
                "شناسه",
                "عنوان",
                "متن",
                "اولویت",
                "عملیات"
            ]
        )

        self.messages_table.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.messages_table.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.messages_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(
            self.messages_table
        )

        return widget


    # ========================================================
    # ثبت اطلاعیه
    # ========================================================

    def add_message_clicked(
        self
    ):

        title = (
            self.message_title
            .text()
            .strip()
        )

        message = (
            self.message_text
            .toPlainText()
            .strip()
        )

        priority = (
            self.message_priority
            .currentText()
        )


        if not title:

            QMessageBox.warning(
                self,
                "اطلاعیه",
                "عنوان اطلاعیه را وارد کنید."
            )

            return


        if not message:

            QMessageBox.warning(
                self,
                "اطلاعیه",
                "متن اطلاعیه را وارد کنید."
            )

            return


        try:

            add_message(
                title,
                message,
                priority
            )

            self.message_title.clear()

            self.message_text.clear()

            self.message_priority.setCurrentIndex(
                0
            )

            self.load_messages()

            QMessageBox.information(
                self,
                "ثبت موفق",
                "اطلاعیه با موفقیت ثبت شد."
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در ثبت اطلاعیه:\n{e}"
            )


    # ========================================================
    # نمایش اطلاعیه ها
    # ========================================================

    def load_messages(
        self
    ):

        try:

            messages = get_messages()

            self.messages_table.setRowCount(
                0
            )

            for item in messages:

                row = (
                    self.messages_table
                    .rowCount()
                )

                self.messages_table.insertRow(
                    row
                )

                self.messages_table.setItem(
                    row,
                    0,
                    QTableWidgetItem(
                        str(item[0])
                    )
                )

                self.messages_table.setItem(
                    row,
                    1,
                    QTableWidgetItem(
                        str(item[1])
                    )
                )

                self.messages_table.setItem(
                    row,
                    2,
                    QTableWidgetItem(
                        str(item[2])
                    )
                )

                self.messages_table.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        str(item[3])
                    )
                )

                delete_btn = QPushButton(
                    "🗑️ حذف"
                )

                delete_btn.clicked.connect(
                    lambda checked=False,
                    message_id=item[0]:
                    self.delete_message_clicked(
                        message_id
                    )
                )

                self.apply_delete_style(
                    delete_btn
                )

                self.messages_table.setCellWidget(
                    row,
                    4,
                    delete_btn
                )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت اطلاعیه‌ها:\n{e}"
            )


    # ========================================================
    # حذف اطلاعیه
    # ========================================================

    def delete_message_clicked(
        self,
        message_id
    ):

        answer = QMessageBox.question(
            self,
            "تأیید حذف",
            "آیا از حذف این اطلاعیه مطمئن هستید؟",
            QMessageBox.Yes | QMessageBox.No
        )

        if answer != QMessageBox.Yes:

            return

        try:

            delete_message(
                message_id
            )

            self.load_messages()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در حذف اطلاعیه:\n{e}"
            )

            # ========================================================
    # تب روزشمار
    # ========================================================

    def create_countdowns_tab(
        self
    ):

        widget = QWidget()

        layout = QVBoxLayout(
            widget
        )

        layout.setSpacing(
            12
        )


        # ====================================================
        # فرم ثبت روزشمار
        # ====================================================

        form = QFrame()

        form.setStyleSheet(
            """
            QFrame {

                background: #FFE0B2;

                border: 2px solid #F57C00;

                border-radius: 12px;

                padding: 10px;

            }
            """
        )

        form_layout = QGridLayout(
            form
        )


        # ====================================================
        # عنوان
        # ====================================================

        title_label = QLabel(
            "عنوان:"
        )

        title_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.countdown_title = QLineEdit()

        self.countdown_title.setPlaceholderText(
            "مثلاً: امتحان نهایی ریاضی"
        )


        # ====================================================
        # تاریخ
        # ====================================================

        date_label = QLabel(
            "تاریخ شمسی:"
        )

        date_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.countdown_date = QLineEdit()

        self.countdown_date.setPlaceholderText(
            "مثلاً: 1405/03/20"
        )


        # ====================================================
        # توضیحات
        # ====================================================

        description_label = QLabel(
            "توضیحات:"
        )

        description_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )

        self.countdown_description = QLineEdit()

        self.countdown_description.setPlaceholderText(
            "توضیح کوتاه"
        )


        # ====================================================
        # دکمه ثبت
        # ====================================================

        add_btn = QPushButton(
            "➕ ثبت روزشمار"
        )

        add_btn.setMinimumHeight(
            40
        )

        add_btn.clicked.connect(
            self.add_countdown_clicked
        )

        self.apply_button_style(
            add_btn
        )


        # ====================================================
        # چیدمان فرم
        # ====================================================

        form_layout.addWidget(
            title_label,
            0,
            0
        )

        form_layout.addWidget(
            self.countdown_title,
            0,
            1
        )

        form_layout.addWidget(
            date_label,
            0,
            2
        )

        form_layout.addWidget(
            self.countdown_date,
            0,
            3
        )

        form_layout.addWidget(
            description_label,
            1,
            0
        )

        form_layout.addWidget(
            self.countdown_description,
            1,
            1,
            1,
            3
        )

        form_layout.addWidget(
            add_btn,
            2,
            0,
            1,
            4
        )


        layout.addWidget(
            form
        )


        # ====================================================
        # جدول روزشمار
        # ====================================================

        self.countdowns_table = QTableWidget()

        self.countdowns_table.setColumnCount(
            5
        )

        self.countdowns_table.setHorizontalHeaderLabels(
            [
                "شناسه","عنوان",
                "تاریخ",
                "توضیحات",
                "عملیات"
            ]
        )

        self.countdowns_table.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.countdowns_table.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.countdowns_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(
            self.countdowns_table
        )


        return widget


    # ========================================================
    # ثبت روزشمار
    # ========================================================

    def add_countdown_clicked(
        self
    ):

        title = (
            self.countdown_title
            .text()
            .strip()
        )

        target_date = (
            self.countdown_date
            .text()
            .strip()
        )

        description = (
            self.countdown_description
            .text()
            .strip()
        )


        # ====================================================
        # بررسی عنوان
        # ====================================================

        if not title:

            QMessageBox.warning(
                self,
                "روزشمار",
                "عنوان رویداد را وارد کنید."
            )

            return


        # ====================================================
        # بررسی تاریخ
        # ====================================================

        if not target_date:

            QMessageBox.warning(
                self,
                "روزشمار",
                "تاریخ را وارد کنید."
            )

            return


        try:

            add_countdown(
                title,
                target_date,
                description
            )

            self.countdown_title.clear()

            self.countdown_date.clear()

            self.countdown_description.clear()

            self.load_countdowns()

            QMessageBox.information(
                self,
                "ثبت موفق",
                "روزشمار با موفقیت ثبت شد."
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در ثبت روزشمار:\n{e}"
            )


    # ========================================================
    # نمایش روزشمارها
    # ========================================================

    def load_countdowns(
        self
    ):

        try:

            countdowns = get_countdowns()

            self.countdowns_table.setRowCount(
                0
            )


            for item in countdowns:

                row = (
                    self.countdowns_table
                    .rowCount()
                )

                self.countdowns_table.insertRow(
                    row
                )


                # ============================================
                # شناسه
                # ============================================

                self.countdowns_table.setItem(
                    row,
                    0,
                    QTableWidgetItem(
                        str(item[0])
                    )
                )


                # ============================================
                # عنوان
                # ============================================

                self.countdowns_table.setItem(
                    row,
                    1,
                    QTableWidgetItem(
                        str(item[1])
                    )
                )


                # ============================================
                # تاریخ
                # ============================================

                self.countdowns_table.setItem(
                    row,
                    2,
                    QTableWidgetItem(
                        str(item[2])
                    )
                )


                # ============================================
                #توضیحات
                # ============================================

                self.countdowns_table.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        str(item[3] or "")
                    )
                )


                # ============================================
                # دکمه حذف
                # ============================================

                delete_btn = QPushButton(
                    "🗑️ حذف"
                )

                delete_btn.clicked.connect(
                    lambda checked=False,
                    countdown_id=item[0]:
                    self.delete_countdown_clicked(
                        countdown_id
                    )
                )

                self.apply_delete_style(
                    delete_btn
                )

                self.countdowns_table.setCellWidget(
                    row,
                    4,
                    delete_btn
                )


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت روزشمارها:\n{e}"
            )


    # ========================================================
    # حذف روزشمار
    # ========================================================

    def delete_countdown_clicked(
        self,
        countdown_id
    ):

        answer = QMessageBox.question(
            self,
            "تأیید حذف",
            "آیا از حذف این روزشمار مطمئن هستید؟",
            QMessageBox.Yes | QMessageBox.No
        )


        if answer != QMessageBox.Yes:

            return


        try:

            delete_countdown(
                countdown_id
            )

            self.load_countdowns()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در حذف روزشمار:\n{e}"
            )

            # ========================================================
    # تب مناسبت ها
    # ========================================================

    def create_events_tab(
        self
    ):

        widget = QWidget()

        layout = QVBoxLayout(
            widget
        )

        layout.setSpacing(
            12
        )


        # ====================================================
        # فرم ثبت مناسبت
        # ====================================================

        form = QFrame()

        form.setStyleSheet(
            """
            QFrame {

                background: #FFE0B2;

                border: 2px solid #F57C00;

                border-radius: 12px;

                padding: 10px;

            }
            """
        )

        form_layout = QGridLayout(
            form
        )


        # ====================================================
        # عنوان مناسبت
        # ====================================================

        title_label = QLabel(
            "عنوان مناسبت:"
        )

        title_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )


        self.event_title = QLineEdit()

        self.event_title.setPlaceholderText(
            "مثلاً: روز معلم"
        )


        # ====================================================
        # تاریخ مناسبت
        # ====================================================

        date_label = QLabel(
            "تاریخ شمسی:"
        )

        date_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )


        self.event_date = QLineEdit()

        self.event_date.setPlaceholderText(
            "مثلاً: 1405/02/12"
        )


        # ====================================================
        # توضیحات
        # ====================================================

        description_label = QLabel(
            "توضیحات:"
        )

        description_label.setFont(
            QFont(
                "B Zar",
                13,
                QFont.Bold
            )
        )


        self.event_description = QLineEdit()

        self.event_description.setPlaceholderText(
            "توضیح مناسبت"
        )


        # ====================================================
        # دکمه ثبت
        # ====================================================

        add_btn = QPushButton(
            "➕ ثبت مناسبت"
        )

        add_btn.setMinimumHeight(
            40
        )

        add_btn.clicked.connect(
            self.add_event_clicked
        )

        self.apply_button_style(
            add_btn
        )


        # ====================================================
        # چیدمان فرم
        # ====================================================

        form_layout.addWidget(
            title_label,
            0,
            0
        )

        form_layout.addWidget(
            self.event_title,
            0,
            1
        )

        form_layout.addWidget(
            date_label,
            0,
            2
        )

        form_layout.addWidget(
            self.event_date,
            0,
            3
        )

        form_layout.addWidget(
            description_label,
            1,
            0
        )

        form_layout.addWidget(
            self.event_description,
            1,
            1,
            1,
            3
        )

        form_layout.addWidget(
            add_btn,
            2,
            0,
            1,
            4
        )


        layout.addWidget(
            form
        )


        # ====================================================
        # جدول مناسبت ها
        # ====================================================

        self.events_table = QTableWidget()

        self.events_table.setColumnCount(
            5
        )

        self.events_table.setHorizontalHeaderLabels(
            [
                "شناسه",
                "تاریخ",
                "عنوان","توضیحات",
                "عملیات"
            ]
        )

        self.events_table.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.events_table.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.events_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        layout.addWidget(
            self.events_table
        )


        return widget


    # ========================================================
    # ثبت مناسبت
    # ========================================================

    def add_event_clicked(
        self
    ):

        event_date = (
            self.event_date
            .text()
            .strip()
        )

        title = (
            self.event_title
            .text()
            .strip()
        )

        description = (
            self.event_description
            .text()
            .strip()
        )


        # ====================================================
        # بررسی تاریخ
        # ====================================================

        if not event_date:

            QMessageBox.warning(
                self,
                "مناسبت",
                "تاریخ مناسبت را وارد کنید."
            )

            return


        # ====================================================
        # بررسی عنوان
        # ====================================================

        if not title:

            QMessageBox.warning(
                self,
                "مناسبت",
                "عنوان مناسبت را وارد کنید."
            )

            return


        try:

            add_school_event(
                event_date,
                title,
                description
            )

            self.event_date.clear()

            self.event_title.clear()

            self.event_description.clear()

            self.load_events()

            QMessageBox.information(
                self,
                "ثبت موفق",
                "مناسبت با موفقیت ثبت شد."
            )

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در ثبت مناسبت:\n{e}"
            )


    # ========================================================
    # نمایش مناسبت ها
    # ========================================================

    def load_events(
        self
    ):

        try:

            events = get_school_events()

            self.events_table.setRowCount(
                0
            )


            for item in events:

                row = (
                    self.events_table
                    .rowCount()
                )

                self.events_table.insertRow(
                    row
                )


                # ============================================
                # شناسه
                # ============================================

                self.events_table.setItem(
                    row,
                    0,
                    QTableWidgetItem(
                        str(item[0])
                    )
                )


                # ============================================
                # تاریخ
                # ============================================

                self.events_table.setItem(
                    row,
                    1,
                    QTableWidgetItem(
                        str(item[1])
                    )
                )


                # ============================================
                # عنوان
                # ============================================

                self.events_table.setItem(
                    row,
                    2,
                    QTableWidgetItem(
                        str(item[2])
                    )
                )


                # ============================================
                # توضیحات
                # ============================================

                self.events_table.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        str(item[3] or "")
                    )
                )


                # ============================================
                # دکمه حذف
                # ============================================

                delete_btn = QPushButton(
                    "🗑️ حذف"
                )

                delete_btn.clicked.connect(
                    lambda checked=False,
                    event_id=item[0]:
                    self.delete_event_clicked(
                        event_id
                    )
                )

                self.apply_delete_style(
                    delete_btn
                )

                self.events_table.setCellWidget(
                    row,
                    4,
                    delete_btn
                )


        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت مناسبت‌ها:\n{e}"
            )


    # ========================================================
    # حذف مناسبت
    # ========================================================

    def delete_event_clicked(
        self,
        event_id
    ):

        answer = QMessageBox.question(
            self,
            "تأیید حذف",
            "آیا از حذف این مناسبت مطمئن هستید؟",
            QMessageBox.Yes | QMessageBox.No
        )


        if answer != QMessageBox.Yes:

            return


        try:

            delete_school_event(
                event_id
            )

            self.load_events()

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در حذف مناسبت:\n{e}"
            )

            # ========================================================
    # بارگذاری همه اطلاعات
    # ========================================================

    def load_all_data(
        self
    ):

        self.load_messages()

        self.load_countdowns()

        self.load_events()


    # ========================================================
    # استایل دکمه اصلی
    # ========================================================

    def apply_button_style(
        self,
        button
    ):

        button.setStyleSheet(
            """
            QPushButton {

                background: #16A34A;

                color: black;

                border: none;

                border-radius: 8px;

                padding: 8px 15px;

                font-family: "B Zar";

                font-size: 13px;

                font-weight: bold;

            }

            QPushButton:hover {

                background: #15803D;

            }

            QPushButton:pressed {

                background: #166534;

            }
            """
        )


    # ========================================================
    # استایل دکمه حذف
    # ========================================================

    def apply_delete_style(
        self,
        button
    ):

        button.setStyleSheet(
            """
            QPushButton {

                background: #DC2626;

                color: white;

                border: none;

                border-radius: 6px;

                padding: 5px 10px;

                font-family: "B Zar";

                font-weight: bold;

            }

            QPushButton:hover {

                background: #B91C1C;

            }

            QPushButton:pressed {

                background: #991B1B;

            }
            """
        )


# ============================================================
# سازگاری با Dashboard
# ============================================================

class ManagementPanel(
    SmartBoardManagement
):

    pass