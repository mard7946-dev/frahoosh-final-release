# Compatibility entry point for the Smart Board module.
# The dashboard imports smart_board.panel; keep that path stable while using
# the fully operational page implementation.
from pages.smart_board import Panel as _SmartBoardPanel

class Panel(_SmartBoardPanel):
    """Stable entry point for dashboard imports."""
    pass

__all__ = ['Panel']
