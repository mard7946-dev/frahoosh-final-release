# -*- coding: utf-8 -*-
import sqlite3, os
from datetime import datetime
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QTextEdit,QLineEdit,QMessageBox,QTabWidget
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from utils.jalali import iso_to_jalali
DB=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','school.db'))

class Panel(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent); self.setLayoutDirection(Qt.RightToLeft); self.result=QTextEdit(); self.result.setReadOnly(True); self.init_ui()
    def _db(self): return sqlite3.connect(DB)
    def _date(self): return iso_to_jalali(datetime.now().strftime('%Y-%m-%d'))
    def init_ui(self):
        l=QVBoxLayout(self); title=QLabel('هوش مصنوعی فراهوش'); title.setAlignment(Qt.AlignmentFlag.AlignCenter); title.setFont(QFont('B Zar',26,QFont.Bold)); l.addWidget(title)
        l.addWidget(QLabel('چهار ابزار عملیاتی؛ هر درخواست در پایگاه داده ثبت و خروجی بر اساس داده‌های واقعی مدرسه تولید می‌شود.'))
        self.question=QLineEdit(); self.question.setPlaceholderText('برای دستیار یا پرسش و پاسخ، سؤال خود را بنویسید...'); l.addWidget(self.question)
        grid=QGridLayout()
        actions=[('دستیار هوشمند',self.assistant),('تحلیل آموزشی',self.analysis),('گزارش هوشمند',self.report),('پرسش و پاسخ',self.qa)]
        for i,(t,f) in enumerate(actions):
            b=QPushButton(t); b.setMinimumHeight(50); b.clicked.connect(f); grid.addWidget(b,0,i)
        l.addLayout(grid)

        self.action_tabs=QTabWidget()
        self._ai_outputs={}
        for title in ('دستیار هوشمند','تحلیل آموزشی','گزارش هوشمند','پرسش و پاسخ'):
            page=QWidget(); pv=QVBoxLayout(page); out=QTextEdit(); out.setReadOnly(True); pv.addWidget(out)
            self.action_tabs.addTab(page,title); self._ai_outputs[title]=out
        l.addWidget(self.action_tabs,1)
        self.result=self._ai_outputs['دستیار هوشمند']
        self.action_tabs.currentChanged.connect(self._sync_result)
    def _sync_result(self,index):
        if 0 <= index < self.action_tabs.count():
            title=self.action_tabs.tabText(index)
            self.result=self._ai_outputs.get(title,self.result)

    def _user(self):
        return 'admin'
    def assistant(self):
        q=self.question.text().strip() or 'وضعیت کلی مدرسه چیست؟'
        with self._db() as c:
            n=c.execute('SELECT COUNT(*) FROM students').fetchone()[0]
            avg=c.execute('SELECT AVG(score) FROM student_grades').fetchone()[0]
            low=c.execute('SELECT COUNT(DISTINCT student_id) FROM student_grades WHERE score<12').fetchone()[0]
        answer=f'دستیار هوشمند | {self._date()}\n\nسؤال: {q}\n\nپاسخ داده‌محور:\nتعداد دانش‌آموزان {n} نفر است. میانگین نمرات ثبت‌شده {avg:.2f} است.' if avg is not None else f'دستیار هوشمند | {self._date()}\n\nسؤال: {q}\nهنوز نمره کافی برای تحلیل عددی ثبت نشده است.'
        if avg is not None: answer+=f' تعداد دانش‌آموزان دارای نمره زیر ۱۲: {low} نفر. پیشنهاد: بررسی این گروه و برنامه تقویتی.'
        with self._db() as c:
            c.execute('INSERT INTO ai_assistant_sessions(username,role,title,context,request_date_shamsi) VALUES(?,?,?,?,?)',(self._user(),'manager','دستیار هوشمند',q,self._date())); c.commit()
        self.result.setPlainText(answer)
    def analysis(self):
        with self._db() as c:
            rows=c.execute('SELECT subject,ROUND(AVG(score),2) avg_score,COUNT(*) n FROM student_grades GROUP BY subject ORDER BY avg_score').fetchall()
        lines=['تحلیل آموزشی واقعی | '+self._date(),'']
        if not rows: lines.append('داده نمرات برای تحلیل وجود ندارد.')
        else:
            for sub,avg,n in rows:
                level='نیازمند مداخله' if avg<12 else ('قابل قبول' if avg<16 else 'خوب')
                lines.append(f'• {sub or "بدون درس"}: میانگین {avg} | {n} ارزشیابی | {level}')
        text='\n'.join(lines)
        with self._db() as c:
            c.execute('INSERT INTO ai_educational_analysis(subject,period,analysis,score,risk_level,created_at,analysis_date_shamsi) VALUES(?,?,?,?,?,?,?)',('همه دروس','جاری',text,None,'normal',datetime.now().strftime('%Y-%m-%d %H:%M:%S'),self._date())); c.commit()
        self.result.setPlainText(text)
    def report(self):
        with self._db() as c:
            tables=[('students','دانش‌آموزان'),('teachers','دبیران'),('student_grades','ارزشیابی‌ها'),('attendance','حضور و غیاب'),('payment_records','پرداخت‌ها'),('messages','پیام‌ها')]
            lines=['گزارش هوشمند سامانه | '+self._date(),'']
            for table,label in tables:
                try: lines.append(f'• {label}: {c.execute("SELECT COUNT(*) FROM "+table).fetchone()[0]} رکورد')
                except sqlite3.Error: lines.append(f'• {label}: 0 رکورد')
            avg=c.execute('SELECT AVG(score) FROM student_grades').fetchone()[0]
            if avg is not None: lines.append(f'• میانگین کل نمرات: {avg:.2f}')
        text='\n'.join(lines)
        with self._db() as c:
            c.execute('INSERT INTO ai_smart_reports(title,report_type,target_type,report,created_by,report_date_shamsi) VALUES(?,?,?,?,?,?)',('گزارش هوشمند مدرسه','داشبورد','school',text,self._user(),self._date())); c.commit()
        self.result.setPlainText(text)
    def qa(self):
        q=self.question.text().strip()
        if not q: QMessageBox.warning(self,'پرسش و پاسخ','سؤال را وارد کنید.'); return
        with self._db() as c:
            low=c.execute('SELECT subject,ROUND(AVG(score),2) FROM student_grades GROUP BY subject HAVING AVG(score)<12 ORDER BY AVG(score)').fetchall()
        if 'نمره' in q or 'تحصیل' in q or 'آموز' in q:
            ans='بر اساس داده فعلی: '+('، '.join(f'{s or "درس نامشخص"} با میانگین {a}' for s,a in low) if low else 'درس با میانگین زیر ۱۲ شناسایی نشد.')
        elif 'پرداخت' in q or 'مالی' in q:
            with self._db() as c: total=c.execute('SELECT COALESCE(SUM(amount),0) FROM payment_records WHERE status IN ("paid","موفق","تسویه")').fetchone()[0]
            ans=f'مجموع پرداخت‌های ثبت‌شده با وضعیت تسویه/موفق: {total:,}'
        else:
            with self._db() as c:
                n=c.execute('SELECT COUNT(*) FROM students').fetchone()[0]; g=c.execute('SELECT COUNT(*) FROM student_grades').fetchone()[0]
            ans=f'برای سؤال «{q}»، داده فعلی نشان می‌دهد {n} دانش‌آموز و {g} ارزشیابی در سامانه ثبت شده است. برای پاسخ دقیق‌تر، سؤال را درباره نمرات، حضور، پرداخت یا فعالیت‌ها مشخص کنید.'
        with self._db() as c:
            c.execute('INSERT INTO ai_questions(username,role,question,answer,created_at,answered_at,answer_date_shamsi) VALUES(?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?)',(self._user(),'manager',q,ans,self._date())); c.commit()
        self.result.setPlainText(f'پرسش و پاسخ | {self._date()}\n\nسؤال: {q}\n\n{ans}')
